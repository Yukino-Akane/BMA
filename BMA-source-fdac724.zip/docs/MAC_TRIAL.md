# M 系列 Mac 小范围试用

这是需要终端操作的开发预览版，不是已完成全部验收的桌面应用。选择 `darwin-arm64.tar.gz`；无需安装 Go、Python 或 Node，无需 sudo。已实际验证 M5 / macOS 26.4，其他 M 系列和 macOS 版本仍需各自确认。

## 四种应用目前能用到什么

| 应用 | 当前可用范围 | 证据与限制 |
| --- | --- | --- |
| Claude Code | 指定进程/目录观察；明确选定会话 JSONL 后导入任务与工具请求 | M5 普通权限下真实 CLI 2.1.278 的 Read/Edit、日志及回环 HTTP/HTTPS 代理已验证；不是 Claude 桌面聊天应用验收 |
| Codex | 指定进程/目录观察；明确选定会话 JSONL 后使用 codex 适配 | 已有真实本机日志验证及 Mac 原生解析测试；尚无 Mac 真实 Codex 会话端到端验收，不承诺覆盖所有 CLI/桌面/扩展版本 |
| 豆包 | 显式 PID/目录通用观察；无专用日志适配 | M5 / 2.29.12 已完成用户配合附件操作期间的限定观察；VPN 场景只见本机代理连接、聚合采样，未独立验证文件上传归因，见 [实测边界](DOUBAO_QA.md)。浏览器共享进程不能精确归到标签页 |
| WorkBuddy | 当前源码支持指定进程/目录和 workbuddy 持久化 JSONL 适配；旧 preview.1 不含此适配 | M5 上 5.2.5 附带的 CLI 2.106.4 已完成真实 Read/Edit 与本地模型接口计量；未验收 GUI，后台/helper 需明确选择。详见 [验收记录](WORKBUDDY_QA.md) |

BMA 只能观察本机被选中的进程和目录，不能看到云端执行过程。四个应用不要在首次试用中同时观察；先用一个小型测试目录跑通。缺少日志时可手动填写任务目标，但不会凭空得到 Agent 的自述。未知格式不要强行指定 claude、codex 或 generic。

## 1. 解压与演示

将归档解压到新目录，在终端进入该目录。下载时核对同时提供的 `SHA256SUMS`；校验和不是发布者签名。此包尚未 Apple 签名、公证；如果 macOS 拒绝启动，先核对来源，再按系统“隐私与安全性”中的提示处理。若组织策略不允许运行，请保留错误给维护者；不要关闭 Gatekeeper、批量移除隔离属性或用 sudo 绕过。

```sh
./bma version
./bma demo --output-dir ./demo-output
./bma serve --report ./demo-output/demo-report.json --port 0
```

打开终端显示的本机网址，查看时间线、规则和证据跳转；结束时按 Ctrl+C。`demo-output` 必须不存在。演示全部是标注为模拟的记录，不调用模型。首批推荐本机网页方式；直接双击 HTML 的 `file://` 交互尚未完成验收。

## 2. 观察一次真实任务

先打开要测试的 Agent，让它等待输入。用 macOS 活动监视器确认自己的应用/CLI 对应的 PID；桌面应用的实际网络连接可能属于 helper。只选本次任务所需 PID；`--process 12345,12346` 可显式指定多个进程，不会自动覆盖全部子进程。不要用整个浏览器或通用 node/python 名称代替明确会话。

在另一个终端运行以下命令，替换 PID、目录和目标。监听目录必须存在；不要选择整个个人主目录。输出使用默认的独立用户缓存目录，终端会显示实际位置。

```sh
./bma watch --process 12345 --workspace "/Users/你的用户名/bma-test-project" \
  --goal "只修改这个测试项目的 README" --duration 120s --port 0 --no-llm
```

看到观察就绪后，再让 Agent 执行任务。网页展示采集事件和缺口，120 秒结束保存 JSON/HTML，或按 Ctrl+C 提前结束。观察期间 Agent 重启后须重新确认 PID。文件变化只表明同时段目录发生变化，不直接证明由选定 Agent 操作。读取内容也不能仅凭打开文件采样确认。

## 3. Claude / Codex 添加会话证据

如果已经确认本次会话文件，可在 watch 命令中添加下列参数。文件必须实际存在，并属于本次任务；工具不会自动搜索所有会话。Claude Code 的默认会话目录通常为 `~/.claude/projects/`，Codex 通常为 `~/.codex/sessions/`，自定义配置会改变位置。没有确认路径时先做上面的通用观察，不读取账号/认证配置来猜路径。

```sh
# Claude Code：加到上述 watch 命令中
--agent-log "/绝对路径/本次会话.jsonl" --agent-format claude

# Codex：加到上述 watch 命令中
--agent-log "/绝对路径/本次会话.jsonl" --agent-format codex
```

日志中的工具调用是 Agent 发出的请求，不等于操作系统证明工具成功执行；请结合文件/网络证据看。WorkBuddy 当前支持明确选定的持久化 JSONL，参数为 `--agent-format workbuddy`，格式边界见 [WorkBuddy 验收](WORKBUDDY_QA.md)。豆包没有日志适配，用 `--goal` 明确本次任务即可。

## 4. 网络计量与现有 VPN

初次试用保留现有 Clash/VPN 设置，上述命令不修改系统代理。nettop 按进程采样，短连接可能漏采；第一条只建立基线，不能把其后增量当作完整上传总量。macOS 进程 IO 当前不支持，当前开发版会单独显示不支持状态；没有异常提示不代表没有外传。

可选 HTTP/CONNECT 代理只精确计量实际经过它的连接。当前源码支持 `--proxy-port 0 --proxy-upstream http://127.0.0.1:7897`：由选定 Agent 单独使用 BMA 输出的代理地址，再由 BMA 连接现有 Clash。端口须与实际 HTTP 代理一致；旧 preview.2 包不含此选项。它不改系统代理，不自动接管应用；无法单独配置代理的应用仍使用通用观察，不替换整个系统的代理设置。上游失败不直连，报告不把 Clash 的本机 IP 当成最终目标 IP。M5 真实 Claude 的受控回环 TLS 链路已通过，详见 [日志格式依据](AGENT_LOG_SOURCES.md)。豆包附件测试没有通过这条链路，不能据此补造其目标域名或精确上传量。没有经过 BMA 的连接不能算在代理计量中，也不能据此判断证书固定或规避审计；本地模拟模型不证明真实外网服务都能正常连接。

## 5. 结束与反馈

观察结束后如需重开页面：`./bma serve --report "/实际输出目录/report.json" --port 0`，再打开显示的网址。不调用分析模型也能查看采集记录和规则。BMA 不安装常驻服务，停止进程后不再观察。

反馈时先提供 macOS 版本、芯片、应用版本、BMA version、操作步骤及报错类别。原始报告可能包含真实目标、路径、域名等；不要默认公开发送报告或会话日志，也不要发送模型 key、账号配置或 SSH 私钥。所有试用限制与待办继续保留在 [STATUS.md](STATUS.md)，本指南不将未验证项算作完成。
