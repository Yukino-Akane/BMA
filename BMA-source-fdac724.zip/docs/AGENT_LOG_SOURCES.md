# Agent 日志格式依据

这些记录说明适配依据及证据边界。公开源码与合成 fixture 验证不等于真实安装环境验证；不得读取凭证文件作为替代。

## Claude Code：真实 CLI 的受控会话

新增现有代理串联验证：M5 / macOS 26.4、UID/EUID 501、Claude 2.1.278，经 BMA → Clash `127.0.0.1:7897` → 独立回环 TLS relay → 本地模拟模型完成 Read/Edit。三个 TLS 1.2 请求中，BMA 与独立 relay 加密出站计数均为 **16,704** 字节，解密 HTTP 为 **11,952** 字节；nettop 独立采样仅 **5,179** 字节，不完整。真实文件修改、任务、日志行号/时间、预览脱敏、报告私有权限均通过，三条连接已结束、relay 无错误。代理事件保留 `transport_route=upstream_connect` 和上游地址，最终 `remote_ip` 留空。仍保留进程 IO 未实现、初始计数缺失及选定进程退出缺口。

此轮 BMA SHA-256 为 `48b657afe7f706e3fa88441a3bc2478b687832b32ee5c48dade6a1f4dc32a281`，Mac 证据在 `~/aea-validation-6602c4d/claude-clash-upstream-qa/verification.json`，本机副本在 `dist/mac-upstream-evidence/verification.json`。复跑时在下文 HTTPS 命令增加 `--proxy-upstream http://127.0.0.1:7897`，并指定新的输出目录。未修改系统代理，没有调用付费模型；本轮不证明外部网络、豆包代理配置或豆包文件上传归因。下文 AEA 数值属于此前直接连接的历史验收。

2026-09-20 在 Apple M5 / macOS 26.4、普通用户 UID/EUID 501、Clash Verge 已启用的隔离配置下验证 Claude Code 2.1.278。官方 `claude.ai/install.sh` 经本地 Clash HTTP 代理安装到 `~/.local/bin/claude`；没有读取既有配置或凭证。真实 CLI 在独立 `CLAUDE_CONFIG_DIR` 和新工作区运行，本地模拟模型依次要求 `Read`、`Edit`，AEA 观察指定 Claude PID。HTTP 回环会话的 AEA 代理出站字节与接口收到字节为 11,993 / 11,993；HTTPS/CONNECT 会话为 16,668 / 16,668，独立 relay 收到相同密文，终端解密 HTTP 为 11,916 字节，协商 TLS 1.2。文件修改、原生日志工具名/调用编号/时间戳、任务目标、脱敏预览和报告私有权限均通过。该验证证明 Mac 真实 CLI 与本地链路可运行，不证明外部网络、真实模型质量、普通 Windows 用户或其他 Agent。

Mac 的短连接可能在 nettop 采样间隔内结束；本轮 HTTPS 运行仍保留 5,268 字节的 nettop 增量作为独立采样（HTTP 为 841 字节，也未完整覆盖）。nettop 计量与代理 relay 计量分开呈现，不互相替代。Mac 报告保留 `process_io` 未实现、首条/退出后的采集缺口；这不是失败隐藏。

2026-09-19 在 Windows 管理员账户下验证了本机独立 CLI 2.1.126，以及 VS Code 扩展附带的 CLI 2.1.224。后者是直接运行扩展中的程序，不等于验证 VS Code 扩展界面或所有扩展工作流。

模型端是仅监听 `127.0.0.1` 的固定响应接口；Claude 本身、工具执行、会话落盘、文件变化和代理转发是真实运行。接口依次要求 `Read`、`Edit` 一个隔离目录中的测试文件，随后结束。没有使用真实项目、已有用户会话、真实模型密钥或付费模型。

| 本机程序 | Claude 版本 | 工具日志 | AEA 代理出站字节 / 接口实际收到字节 |
| --- | --- | --- | --- |
| 独立 CLI | 2.1.126 | `Read`、`Edit` | 12,547 / 12,547 |
| 扩展附带的 CLI | 2.1.224 | `Read`、`Edit` | 12,449 / 12,449 |

字节数包含实际 HTTP 请求行、请求头和正文，不等于测试文件大小；每次运行的随机路径/会话字段可能改变字节数。验证比较双方本次实测值，不固定期待上述数值。

随后使用当前工作树重建 AEA，在 `dist/claude-tls-current-tree-qa` 复跑 2.1.224 的 HTTPS/CONNECT 会话：三个实际模型请求均协商 TLS 1.3，AEA 代理计到 13,760 个出站加密字节，独立 TCP relay 实际收到 13,760 字节；终端 TLS 接口解密后读取的 HTTP 内容共 12,686 字节。relay 只转发并计数密文，TLS 终止和解密发生在测试模型接口，AEA 不解密、不读取正文。Read/Edit、真实文件修改、原日志行号/时间/调用编号及预览脱敏均通过；连接全部结束，relay 无错误。先前 `dist/claude-tls-persisted-qa` 的 13,751 / 13,751 / 12,677 字节是另一轮证据，不是此次结果。

确认的日志格式是 `projects/<project>/<session>.jsonl` 中的 `type:user` + `message.role:user` 文本，以及 `type:assistant` + `message.content[].type:tool_use`，包含 `name`、`input` 和 `id`。实际工具记录的行号、调用编号、工具名和 `timestamp` 已逐项与 AEA 证据对照；工具返回内容没有误作用户目标。文件事件保持 `temporal` 且没有 PID。使用 `analyze --dry-run-llm --redact-goal` 验证预览不包含文件正文、原始文件路径或任务文本，终端输出与保存正文一致。

2.1.224 此次最终日志未包含首轮初始化用户消息，但包含随后真实执行的任务。适配器只导入实际存在的记录，不补造缺失会话内容。Claude 退出后，AEA 保留指定进程不再存在的采集缺口；没有将其隐藏或当作 Agent 违规。此次报告目录 ACL 关闭继承，只有当前用户的一条允许规则；管理员环境检查不能替代普通账户验证。

当前 BMA 源码可用已安装的 Claude 和已构建的 BMA 复跑（下列命令使用新名，上述数值属于历史 AEA 验收），输出目录必须不存在：

```powershell
python scripts/verify_claude.py --claude C:/path/to/claude.exe --bma dist/bma.exe --out dist/claude-live-check

# HTTPS/CONNECT；维护者 Python 环境另需 cryptography（此次使用 46.0.5）
python scripts/verify_claude.py --claude C:/path/to/claude.exe --bma dist/bma.exe --https --out dist/claude-tls-check
```

HTTP 模式只使用 Python 标准库；HTTPS 模式使用 `cryptography` 生成一天有效的本地测试 CA 和服务证书。这些都是维护者验证依赖，不是产品运行依赖。CA 仅通过子进程 `NODE_EXTRA_CA_CERTS` 提供，不安装到系统信任库，也不关闭 TLS 校验。证书和新生成的测试私钥留在此次输出目录，不用于任何真实服务。

脚本支持 Windows/macOS，记录平台及管理员状态或 UID/EUID；Mac 输出以私有权限创建并检查报告权限。脚本清除继承的模型凭证与代理设置，使用新的 `CLAUDE_CONFIG_DIR`、`--bare`、空设置来源和空 MCP 配置，只开放 `Read,Edit`。`--bare` 的工具范围不含 `Write`，所以此验证采用读取后编辑，不使用跳过全部权限检查的选项。初始化使用回环 HTTP 的流式输入，确认 user/assistant 完整日志已落盘后才结束初始化，避免把 CLI 成功退出当作日志已保存的证明。随后启动独立的被观察会话，保持流式输入直到 Read/Edit 日志已持久化并被采集后关闭；Mac 还等待 nettop 初始基线。先启动 AEA 对指定 PID 的观察和代理，再给 Claude 输入任务；代理没有按时就绪或没有测到真实字节会失败，不改为绕过代理运行。

输出目录保留此次新生成的合成内容会话、报告、命令输出、`fixture-requests.json`（仅请求大小等元数据）和 `verification.json`（版本、二进制/日志 SHA-256、管理员状态、工具/文件/计量检查结果）；HTTPS 另存 `tls-relay.json` 的双向计数、结束状态与错误类别。这些测试输出不提交到 Git。脚本结束时关闭自己的进程与本地监听，不改动用户原有配置。它验证的是回环 HTTP 或 HTTPS/CONNECT 和受控工具调用；Windows 普通账户、外部网络/TLS 条件、真实模型质量及其他 Agent 仍需单独验证。Mac 普通权限受控会话已通过，复跑命令与本轮证据位置见 [Mac 验收](MACOS_QA.md)。

配置依据：[Claude 环境变量](https://code.claude.com/docs/en/env-vars)中的 `CLAUDE_CONFIG_DIR`、`ANTHROPIC_BASE_URL`、`HTTP_PROXY` / `HTTPS_PROXY`、`CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC`，以及[非交互 bare 模式](https://code.claude.com/docs/en/headless#start-faster-with-bare-mode)；本机 `claude --help` 也已核对对应参数。

## Roo

核对日期：2026-09-19。仓库 `RooCodeInc/Roo-Code`，固定提交 `b867ec9145750d0ae1ff7f02d35406e9bf2a0b16`。

- [message.ts](https://github.com/RooCodeInc/Roo-Code/blob/b867ec9145750d0ae1ff7f02d35406e9bf2a0b16/packages/types/src/message.ts)：`ts`、`type`、`say` / `ask`、`text`、`partial`、`isAnswered` 等 UI 消息字段。
- [Task.ts](https://github.com/RooCodeInc/Roo-Code/blob/b867ec9145750d0ae1ff7f02d35406e9bf2a0b16/src/core/task/Task.ts)：初始任务用 `say("text", task, images)`；后续用户文本为 `user_feedback`。其他 `say:text` 不代表用户目标。`ask` 是批准/交互请求，不证明执行；流式消息会更新到完整版本，批准状态也可后续变化。
- [globalFileNames.ts](https://github.com/RooCodeInc/Roo-Code/blob/b867ec9145750d0ae1ff7f02d35406e9bf2a0b16/src/shared/globalFileNames.ts)、[storage.ts](https://github.com/RooCodeInc/Roo-Code/blob/b867ec9145750d0ae1ff7f02d35406e9bf2a0b16/src/utils/storage.ts)：在扩展 globalStorage 或用户自定义存储根下，任务路径为 `tasks/<taskId>/ui_messages.json`。
- [taskMessages.ts](https://github.com/RooCodeInc/Roo-Code/blob/b867ec9145750d0ae1ff7f02d35406e9bf2a0b16/src/core/task-persistence/taskMessages.ts)、[safeWriteJson.ts](https://github.com/RooCodeInc/Roo-Code/blob/b867ec9145750d0ae1ff7f02d35406e9bf2a0b16/src/utils/safeWriteJson.ts)：保存完整消息数组，先写临时文件，再移动旧文件及替换；目标路径可能短暂不存在。

实现选择：轮询明确选择的任务文件，只接收完整快照中的最终语义消息。保留数组位置和日志时间；内存哈希检查已观察语义内容是否变化，不把原始工具参数复制进证据。首条任务也是会话锚点；仅有批准状态/进度元数据变化可继续。语义历史被改写或删除时停止该日志输入，不能把任务重放伪装成新执行记录。

已验证：合成日志的部分消息完成、文件替换、界面状态更新、缺失/损坏恢复、历史改写拒绝、容量限制、停止收尾；CLI `watch` 中替换文件并保存含来源的 JSON/HTML；在线中文筛选与离线数据中的批准请求名称；模型正文保留批准语义且剔除参数。未安装 Roo，未运行真实 Roo 会话。

## Cline

核对的仓库为 `cline/cline`，提交 `2755adfa463fdebde5510378a14b8bcc919e6295`。当前 VS Code 端使用 SDK 会话存储；旧 UI 数组文件的存在不能当作当前会话格式依据。

- [vscode-session-host.ts](https://github.com/cline/cline/blob/2755adfa463fdebde5510378a14b8bcc919e6295/apps/vscode/src/sdk/vscode-session-host.ts)：VS Code 使用 `ClineCore` 的本地会话后端。
- [sdk-session-history-loader.ts](https://github.com/cline/cline/blob/2755adfa463fdebde5510378a14b8bcc919e6295/apps/vscode/src/sdk/sdk-session-history-loader.ts)：说明持久化快照只在轮次边界追上内存状态；不能把缺少当前工具记录当作没有执行或故意隐瞒。
- [session-data.ts](https://github.com/cline/cline/blob/2755adfa463fdebde5510378a14b8bcc919e6295/sdk/packages/core/src/services/session-data.ts)：`buildMessagesFilePayload` 写出 `version:1`、`sessionId`、`agent`、`updated_at`、`messages` 等字段；初始会话可以为空数组。`updated_at` 是快照更新时间，不能赋给每条消息作为行为时间。
- [messages.ts](https://github.com/cline/cline/blob/2755adfa463fdebde5510378a14b8bcc919e6295/sdk/packages/shared/src/llms/messages.ts)：消息角色为 user/assistant，内容为字符串或类型化块；消息 `id` 和毫秒 `ts` 可缺省；用户角色也承载 `tool_result`，必须排除其正文。`tool_use` 表示助手发起调用，不证明调用完成。
- [session-manifest-store.ts](https://github.com/cline/cline/blob/2755adfa463fdebde5510378a14b8bcc919e6295/sdk/packages/core/src/session/stores/session-manifest-store.ts)：`persistSessionMessages` 使用整份 `writeFileSync`，读取期间可能看到截断/未完成文件。
- [session-artifacts.ts](https://github.com/cline/cline/blob/2755adfa463fdebde5510378a14b8bcc919e6295/sdk/packages/core/src/services/session-artifacts.ts)、[paths.ts](https://github.com/cline/cline/blob/2755adfa463fdebde5510378a14b8bcc919e6295/sdk/packages/shared/src/storage/paths.ts)：默认会话根 `~/.cline/data/sessions`，消息文件为 `<sessionId>/<sessionId>.messages.json`；环境和应用配置可覆盖根目录。

实现选择：独立 `cline` 格式，仅接受当前 SDK version 1，不加旧 UI 数组兼容层。核对顶层会话身份；完整校验每份快照后才发出新证据，按照数组位置及源消息哈希检测已观察历史变更。保留工具请求、委派角色、时间来源及本地来源定位；不把系统提示、模型用量、文件/媒体/工具结果或推理导入证据。已观察消息在源码内容或时间上变化会停止该日志输入；用量等附加元数据更新不重复发出证据。单条消息含多个工具时，回调失败后只重试未成功写入的事件。

已验证：合成 SDK 快照、空会话启动、lead/subagent/teammate 来源、文件重写、元数据变化、缺口/恢复、身份变化和历史改写拒绝、消息和调用编号重复拒绝、类型及容量校验、部分写入回调重试、取消后收尾。CLI `watch` 在运行中重写快照，最终 JSON/HTML 保留调用请求语义；报告区分委派目标，模型正文不发送参数。本机未安装 Cline，真实扩展会话仍待验证。

## WorkBuddy

2026-09-20 以 M5 上已安装的 WorkBuddy 5.2.5 / 内置 CodeBuddy CLI 2.106.4 为依据。读取安装包公开的 CLI 使用文档，并在新的 CODEBUDDY_CONFIG_DIR 下实际运行 Read/Edit，核对其自行保存的 `projects/<workspace>/<session>.jsonl`。仅检查此次合成会话，不寻找或读取既有私人日志。

持久化记录为顶层 `type:message` + `role:user` + `content[].type:input_text`，工具请求为 `type:function_call` + `name` + `callId`；`timestamp` 是 Unix 毫秒。适配保留用户文本、工具名称、调用编号、行号和时间；忽略 `function_call_result`、assistant message、文件快照、providerData、arguments 和嵌套 message 镜像。工具请求标为 self_reported / tool_request，不当作完成证明。语义记录的时间缺失、非数值、负数、非整数或超出年份 9999 时拒绝；工具名/调用编号缺失拒绝。

直接复用现有 JSONL 有界逐行读取、追加游标和文件替换/截断拒绝机制。仅支持上述实测持久化格式，不把 CLI stream-json stdout 或未知版本自动解释为相同格式。合成测试检查语义提取、隐私字段排除、来源/时间/行号、重复轮询以及非法记录，并在 M5 执行。实机过程、额外遥测域名及计量边界见 [WorkBuddy 验收](WORKBUDDY_QA.md)。

## 豆包

2.29.12 arm64 已安装并完成用户配合附件操作期间的限定 PID/目录观察，见 [豆包实测](DOUBAO_QA.md)。本轮没有读取应用凭证或既有私人会话，没有取得可据以实现的当前任务日志；因此仍无豆包语义适配，不把进程流量、用户界面确认或工作区文件采样伪装为工具调用日志。
