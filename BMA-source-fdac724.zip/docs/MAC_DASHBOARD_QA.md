# Mac 实时面板验收

> 本文原始记录对应 preview.3。后续开发版已加入进程树、签名锁定和健康/采样时间显示；最新验证见 [本地接手记录](LOCAL_TAKEOVER.md)。

2026-09-23：AppKit 首页改为 Claude / Codex / 豆包 / WorkBuddy 应用卡片、五个指标和最近活动。点击一张运行中的卡片，选择该应用当时的当前账户进程；后启动的进程需重新开始观察。当前每次观察一个范围。目录和任务目标不再必填，未选目录时不启动文件监听或打开文件采样。PID、多选、日志、代理和采样间隔移到高级设置。

面板从现有回环报告服务的只读 `/api/dashboard` 获取有界摘要，每两秒刷新；请求禁用代理、Cookie 和重定向，失败显示上次数据及更新中断。停止后的最终摘要通过已有 JSONL 生命周期通道送达，避免漏掉收尾计量。开始与停止不自动跳浏览器，完整报告按需打开。

连接是累计系统连接观察记录，不是当前活跃 socket 数；代理连接不重复计入。系统 nettop 和代理流量分开，不合计；无样本显示待采样。文件事件与采集错误分开；缺口保留历史累计，不表示风险评分。最近活动不含任务正文、路径或原始错误。

验证：

- Windows Go 1.27.1 全量 `go test ./... -count=1`（13 个包）、`go vet ./...` 通过。
- 新测试覆盖无目录时无隐式工作区/文件事件、控制管道关闭保存、最终摘要、摘要字段限制、网络来源分离、IO 排除、缺口恢复后保留、整数溢出、只读 Host/方法边界。
- 新增 Go 面板摘要、无目录模式及桌面管道生命周期测试已交叉编译后在 M5 UID 501 原生执行通过。
- M5 / macOS 26.4 / UID 501 原生 Swift 6.3.3 编译通过。`desktop/macos/tests/Smoke.swift` 使用同一界面源码和新 Go 后端，启动独立 Python 回环测试进程，通过卡片入口启动、实时 HTTP 更新、停止、最终摘要和报告文件核对。无目录模式有真实网络 egress，报告没有文件事件或隐式目录。
- AppKit 原生视图渲染覆盖空闲、监控中、停止后、高级设置和最小窗口。透明 PNG 需合成到相应系统背景后查看。证据在本机 `dist/dashboard-evidence/`，远端隔离目录 `~/aea-validation-6602c4d/dashboard-20260923/evidence/`。

这些是合成回环和原生视图测试，不代替真实 Agent 完整流程、真实 Finder 下载启动或文件精确上传归因。签名/公证的当前结果见 RELEASE.md；任何 App 内容改动后必须重新签名、公证。

复跑原生测试：将当前 darwin-arm64 CLI 放到隔离的 `Smoke.app/Contents/Helpers/bma`，编译 `AppController.swift`、`Backend.swift`、`Processes.swift`、`Dashboard.swift` 与 `tests/Smoke.swift` 为 `Smoke.app/Contents/MacOS/Smoke`，链接 `AppKit` 与 `Security`，不要加入产品 `main.swift`；传入已建好的独立证据目录。测试报告保存于 BMA 本机 Sessions 下的新 UUID 目录。测试不读取既有 Agent 会话或凭证，不请求外部模型。
