# 本地接手记录

## 2026-09-24 修复

用户截图对应仍在运行的 `/Applications/BMA.app` preview.3，而 preview.4-dev 同时在开发目录运行。旧会话锁定的两个 codex PID 在 9 月 23 日退出，不能据此推断当前 Codex 应用已退出。已正常退出旧版并保存报告。新窗口增加完整构建版本号；新版启动时检测同 bundle ID 的运行实例，提示现有路径并显示原实例，避免两个新窗口混淆。

真实新会话覆盖 21 个进程时暴露 nettop 的 20 PID 过滤器上限（exit 64）。采样现按最多 20 个 PID 分批，仍严格使用显式 PID 和禁用 DNS；总调用有 5 秒截止时间，任一批次失败不接受部分结果、不推进计数基线。新增 1/20/21/41 PID 边界测试、后批失败测试和 Mac 原生 21 个受控进程回归。修复包版本 `0.4.0-preview.4.1-dev`，交付目录 `dist/delivery-preview4-1/`，仍为本机 ad-hoc 签名、未公证开发版。

日期：2026-09-23。工作区：`/Users/dqb/Documents/bma`。分支：`codex/process-scope`。

## 恢复来源与本轮范围

从 `BMA-Mac-ChatGPT-Handoff-20260923.zip` 恢复源码与完整 Git 历史。基线为 `6486d6b44fc442bf6e75e67236a4f196d95e40bb`。恢复后工作区和索引干净；原 ZIP 保留在 Downloads，包内 16 个清单成员校验通过。源码 ZIP 使用 CRLF，实际开发文件来自 bundle 中的 Git 提交。未配置远端仓库。

本轮完成交接文档中的进程范围、身份锁定、采集健康分类、dashboard 时间和代理范围共用修复，并制作本地开发包。未修改 `/Applications/BMA.app` 或已公证 preview.3；未读取用户 Agent 会话、账号、凭证或私钥，未发送模型请求或对外发布。

## 实现

- 桌面端通过 `proc_pidinfo` 获取 PID/毫秒启动时间，作为 `--root-process PID@START_TIME_MS` 传给后端。每轮从当前账户元数据重建父子树，动态纳入后代，拒绝复用 PID 和早于父实例启动的旧后代。
- 应用卡片通过 Security.framework 读取运行代码身份，传入 `--root-code PID@BUNDLE_ID@SIGNING_ID@TEAM_ID@CDHASH`。后端通过系统 codesign 对运行 PID 核验签名标识和 CDHash；采样前后及代理归属复用范围/身份核验。CDHash 绑定代码目录中的 team 标识；不错误地把 Apple 程序的 TeamIdentifier 等同于证书 OU。根代码不匹配时连同后代排除，不允许借另一根的父子链重新进入。
- 根代码身份记录在 `scope_member_added` 事件中。签名失败、PID 复用、父子链不可核验会报告缺口；明确退出单独记录。成员加入和移除有事件，历史缺口不会因恢复而删除。
- ChatGPT.app 中 `com.openai.codex` 的根可识别为 Codex 卡片候选。卡片名称/路径/bundle ID 用于发现候选，不是官方发行者白名单；签名锁定保证选择后身份保持一致。手动非应用进程以及 CLI 仅使用 `--root-process` 时只有 PID/时间/父子链约束。
- `CollectorHealth` 按进程实例和采集源区分 `ok`、`unsupported`、`idle`、`failed`、`process_exited`，失败转恢复只记录一次。Darwin gopsutil 进程 IO 标为不支持；nettop 成功但缺少目标 PID 行标为空闲并清除基线。重复行、命令失败、计数下降等仍披露缺口，未知间隔不计为流量。
- 每轮 `collector_sample` 记录完成时间、间隔、选定根数、当前覆盖/子进程数及健康计数。最近完整成功要求覆盖至少一个进程且本轮无失败；它描述进程采样，不代表独立文件监听器或代理全部正常。dashboard 同时支持内存与 JSON 解码的数值表示，只公开固定健康字段，不把汇总事件挤入最近活动。
- 桌面显示后端采样时间、最近完整成功时间、间隔和健康项计数，支持 RFC3339 纳秒时间。请求失败保留上次数据并标出陈旧；正常空闲/退出/不支持不作为失败着色。停止后显示最终摘要。
- 修复既有代理测试丢失同包缓冲数据的问题；文件突发测试改用独立事件输入，避免直接写入 fsnotify 管理的通道引发关闭竞态，仍执行同一生产队列处理路径。
- 修复打包清单：App 最终签名会重写主程序，外部 BUILD.json 在签名后记录最终启动程序哈希；包内清单明确标为签名前哈希，避免自引用。后端及 Swift 源码哈希与实际文件逐项核对。

## 验证证据

- 全量 `go test ./... -count=1`（13 个包）、`go vet ./...`、`git diff --check`。
- `go test -race ./internal/collect ./internal/report ./cmd/bma -count=1`，覆盖采集、报告和 CLI 并发路径。
- 受控父子进程：观察开始后创建子进程、只由子进程建立回环 socket，验证动态成员和代理归属；根 PID/父 PID 复用用确定性数据测试。
- Mac 原生签名：正确 CDHash 通过，错误 CDHash 被刷新及最终身份核验拒绝。受控 shell 在同一 PID/启动时间下 exec 为 sleep 后，原代码身份被拒绝。错误参数和 requirement 注入被拒绝。
- 真实应用仅做元数据验收：本机 ChatGPT/Codex 根及 19 个后代、新增受控 marker 的父子链核验通过。此项没有调用连接表、nettop、打开文件或日志采集；证据在 `dist/health-qa/evidence/app-metadata.txt`。
- 原生 Swift/AppKit Smoke：签名锁定的合成 Python 回环进程、卡片启动、真实流量、无目录观察、后端采样时间、健康显示、请求失败保留数据、纳秒时间解析、陈旧状态、停止保存与最终摘要。测试等待系统 Python 启动器完成 exec 后再选择，避免锁定启动器身份。证据在 `dist/health-qa/evidence/verification.json`。
- 界面正常/停止/陈旧及最小窗口 PNG 在同目录；`*-background.png` 为透明原生视图合成到浅色背景后检查的版本。它们不是 Finder 下载启动或真实 Agent 完整任务验收。
- 四平台 CLI 归档构建；Mac 本地包的深度签名、DMG 校验、归档 SHA-256、内置后端 version/demo 和启动检查。最终包及证据见下节。

## 本地交付

版本：`0.4.0-preview.4.1-dev`。最终命令行归档在 `dist/delivery-preview4-1/cli/`；Mac ZIP、DMG、BUILD.json、SHA256SUMS 与开始使用说明在 `dist/delivery-preview4-1/macos/`。解压后的试运行入口为 `dist/delivery-preview4-1/macos/local/BMA.app`。

本地包使用 ad-hoc 签名，`notarized:false`，不继承 preview.3 的 Developer ID/公证结果。其他 `dist/*preview4*/` 构建为收尾前的中间产物，交付只使用 `dist/delivery-preview4-1/`。独立可执行文件没有可取得的 bundle ID 时留空，不把签名标识虚构成 bundle ID。

## 保留的产品边界

周期枚举和父子链核验不是原子系统快照；短命进程、短连接、毫秒启动时间碰撞及核验之间的竞态仍可能漏采。父进程退出或后代重新托管时分支离开范围；应用重启或根代码变化后需要重新选择。系统聚合字节不等于文件上传量，文件变化不具有精确进程归因。

本轮没有中断用户正在使用的 ChatGPT/Codex 来做退出重启，也没有执行真实付费模型/私有会话任务；动态树、退出、代理和代码替换由受控进程验证。正式 Developer ID 签名、公证、下载隔离启动和其他机器完整验收属于后续发布流程；本地开发包不能当作已公证发行版。
