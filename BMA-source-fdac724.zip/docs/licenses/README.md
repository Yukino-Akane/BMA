# 许可证来源

`Apache-2.0.txt` 是 Apache Software Foundation 提供的 Apache License 2.0 完整文本，来源：

- https://raw.githubusercontent.com/apache/.github/main/LICENSE
- 收集日期：2026-09-19
- 文件 SHA-256：`c71d239df91726fc519c6eb72d318ec65820627232b2f796219e87dcf35d0ab4`

该文件随包补充 `go.yaml.in/yaml/v3` 的 Apache 2.0 条款；该模块自身的 LICENSE 和 NOTICE 也原文收录在发布包的 `THIRD_PARTY_NOTICES.txt` 中。

发布工具从每个二进制的 Go build info 提取实际链接模块的版本与模块校验值，再从对应版本源码的已编译包目录及祖先目录收集 LICENSE、NOTICE、COPYING、COPYRIGHT、PATENTS、AUTHORS 等文件；Go 标准库及参与构建的内置包同样收集。每个模块的来源文件相对路径列在 `BUILD.json`，本机绝对路径不写入归档。文本仅统一 CRLF 为 LF。

构建会拒绝来源版本不一致、模块替换、缺失模块校验值、找不到许可证或空声明文件。升级依赖时仍需审查新版本附带声明及特殊分发要求；自动收集按文件名和包目录工作，不负责推断源码注释中的独立条款。
