# 发布检查

2026-09-23 实时面板：Mac 首页已改为应用卡片和实时指标；目录/任务可选，高级参数收起，停止保留最终数据。Windows 全量测试/vet 与 M5 原生编译、合成回环端到端和视图渲染通过，详见 [面板验收](MAC_DASHBOARD_QA.md)。新面板已完成 Developer ID 签名、Apple 公证（Accepted）、DMG/ZIP 内 App 票据装订和 Gatekeeper 验证。最终包在 `dist/release-dashboard-signed-8b6e98f/`，下载后 SHA-256 已核对；朋友机器首次下载/Finder 启动仍未验收。

本轮新归档 `0.4.0-preview.3` 来自产品提交 `a725076`，保存在 `dist/release-dashboard-a725076/`；四平台 SHA-256 及 Windows version/demo 通过。M5 新面板的 Developer ID App/DMG 已签名并通过构建期完整性校验，外部产物在远端 `signed-preview-3/`。用户已在 Mac 本机运行发布脚本，Apple 提交 `41818260-fa3c-4892-b9f9-3ca16cac6cd9` 返回 `Accepted`，DMG 和 ZIP 内 App 已装订票据；Gatekeeper 均返回 `accepted / Notarized Developer ID`。最终包、BUILD、SHA256SUMS 与验证证据已取回 `dist/release-dashboard-signed-8b6e98f/`。DMG SHA-256：`203a93d6247eaa885efe87ca82f84061b9e5c6378f7f78db204110660cd53a7d`；ZIP SHA-256：`b0e2e2acb6af8106c7e199939adda43736dc03fa08ee7fb01129b4a9a607e127`。

当前已本地构建 BMA `0.4.0-preview.2` 四平台归档，源码 `5d46859`，目录 `dist/release-bma-0.4.0-preview.2/`；归档校验通过，Mac arm64 内部二进制校验及 M5 version/demo 通过。新交接包与 SHA-256 见 [资产交接](ASSET_HANDOFF.md)。尚未签名、公证或公开发布。下述 preview.1 为旧 AEA 历史产物。

正式分发物为可直接解压使用的归档，运行时不依赖 Go、Python 或 Node。当前仍是开发版，没有进行对外发布。

当前源码可在 Apple Silicon Mac 生成 `BMA-<version>-macos-arm64.dmg` 与 ZIP：`scripts/build_macos_app.py` 会校验 darwin-arm64 CLI 的 `BUILD.json`/SHA-256，编译 AppKit 桌面端，嵌入后端和开始使用说明，执行 `version`/`demo`，校验 bundle 和 DMG。M5 / macOS 26.4 已完成本机挂载、启动、退出和 `codesign --verify --deep --strict`；当前已有 Developer ID 签名版产物。没有 `--sign-identity` 时只产生 `ad-hoc-local-only` 预览。签名不等于公证，脚本不提交公证、不上传，也不修改系统设置。

改名前的 M 系列小范围试用版本使用 `0.4.0-preview.1` 标签，选择 `aea-0.4.0-preview.1-darwin-arm64.tar.gz`；包内新增 [Mac 试用指南](MAC_TRIAL.md)。这是指定范围的开发预览，不代表以下完整发布检查全部通过。Claude Code 有 M5 真机受控会话证据；该旧包不含后续 WorkBuddy 适配；当前源码的 WorkBuddy 内置 CLI 验收见 WORKBUDDY_QA.md。Codex Mac 真实会话和 WorkBuddy GUI 仍未验收；豆包已有限定附件操作观察记录（DOUBAO_QA.md），完整任务及上传独立归因仍未验收。首次下载后的 Gatekeeper 流程仍待验证，不把 SSH 上传运行当作首次下载安装证据。

该预览包已从提交 `baafe1e` 构建，在 M5 普通权限实际解压运行 version/demo/本机 HTTP，并通过真实 Claude HTTPS 受控会话复验；本机文件在 `dist/release-0.4.0-preview.1/`。arm64 归档 SHA-256 为 `63e48b1caf97317e69a102b97eea594ce8d8bb144cd8030ce01d0b6ff4cbf76d`，AEA 二进制为 `97431e3a758d0f9b810f6dd0db44664da8e94ae3968453a9b46b3195354eecc5`。这段是构建后的验收记录，包内文档固定为上述源码提交，不为了加入本次结果而改写已校验归档。

在仓库根目录构建，输出目录必须不存在；已有目录会直接报错，不混入或覆盖旧版本产物：

```powershell
./scripts/build.ps1 -Version 0.4.0-dev -Output dist/release
Get-Content dist/release/SHA256SUMS
```

PowerShell 可通过 `-Go` 指定 Go 可执行文件。Unix 使用：

```sh
sh scripts/build.sh 0.4.0-dev dist/release
```

两种脚本调用同一个 `scripts/release` Go 工具，固定生成：

| 文件 | 平台 |
| --- | --- |
| `bma-0.4.0-dev-windows-amd64.zip` | Windows x64 |
| `bma-0.4.0-dev-darwin-amd64.tar.gz` | macOS Intel |
| `bma-0.4.0-dev-darwin-arm64.tar.gz` | macOS Apple Silicon |
| `bma-0.4.0-dev-linux-amd64.tar.gz` | Linux x64 |
| `SHA256SUMS` | 四份归档的 SHA-256 |

每份归档包含 `bma.exe` 或 `bma`、README、MIT LICENSE、`rules.yaml`、解压使用说明、[五步演示](DEMO.md)及 GIF/静态 PNG、交付/平台限制、日志适配来源、服务网段来源说明和可审阅的 `storage-ranges.json`、`THIRD_PARTY_NOTICES.txt`、Apache 2.0 全文及 `BUILD.json`。二进制校验值、Go 版本和实际链接模块的版本/校验值保存在 `BUILD.json`；按目标分别收集依赖，Windows 依赖不会冒充 macOS 已链接模块。许可证来源和收集范围见 [说明](licenses/README.md)。

构建使用 `-mod=readonly -trimpath -buildvcs=false`，清空 Go build id，注入版本，并强制 `CGO_ENABLED=0`。子构建明确设置平台/架构和通用 CPU 基线，清除继承的 GOFLAGS/GOEXPERIMENT。PowerShell 入口结束后恢复调用者的工作目录和其修改的环境变量，Unix 入口仅在子进程设置环境。

归档成员按名称排序、文件权限固定、时间戳固定为 2000-01-01 UTC；文档和许可证统一 LF，避免本机 checkout 时间、换行和时区进入校验值。Unix 二进制权限为 0755。所有产物先在输出目录旁的随机临时目录构建；任一步失败清理该目录，全部成功才改名为指定输出目录。不会递归删除或覆盖用户已有的输出目录。

在同一 Windows 主机、同一 Go 1.27.1 下，PowerShell 与 Git sh 入口生成的四个归档逐字节一致，归档及内部二进制校验通过；Windows 解压运行 version/demo 通过。测试覆盖归档元数据、许可证收集、失败清理和既有目录保护。可重复性验证需保持源码、文档、依赖和 Go 工具链一致；尚未验证不同构建主机产生相同归档。CI 已配置构建和上传归档，但没有远端执行结果，不能据此声明 CI 已通过。macOS 包尚未签名、公证；M5 / macOS 26.4 普通权限合成回环和原生测试已通过，Intel Mac/Linux 尚未实机验证。旧 6602c4d 验收包有已发现的 macOS 采集问题，仅保留作失败基线，重新分发须包含后续修复。

发布前仍需完成：

- `go test ./... -count=1`、`go vet ./...`。
- 检查四个归档的 SHA-256、内部二进制校验值、目标平台和依赖声明；从新目录解压执行演示。
- Windows 普通账户、macOS Intel 及 Linux 实际运行验证；M5 / macOS 26.4 普通权限的合成回环、原生测试及真实 Claude 2.1.278 本地模拟模型 HTTP/HTTPS 会话已通过。其他 Agent、外部网络、计数重置/PID 复用及权限拒绝场景仍待验证。
- Mac 可先运行[限定范围的平台验收工具及 Claude 验收](MACOS_QA.md)。M5 使用 arm64，Intel 使用 amd64；维护者验收工具独立于产品运行依赖，已通过范围不能替代剩余场景。
- 真实浏览器直接打开离线 HTML 的交互/视觉检查和完整产品清单验收；三层模拟演示及 GIF 已完成，不能替代真实 Agent 验证。
- 对外发布前明确版本和已知限制；本构建步骤不执行上传、发帖、签名或公证。

归档布局参考 [GoReleaser 自身的发布配置](https://github.com/goreleaser/goreleaser/blob/main/.goreleaser.yaml) 的按平台命名、Windows ZIP、随包文档/许可证及校验文件模式；压缩使用 Go 标准库 `archive/zip`、`archive/tar` 和 `compress/gzip`。
