# 解压后开始使用

发布包内的 BMA 是独立程序，运行时不需要 Go、Python 或 Node。当前版本仍为开发版；已验证范围和未完成项见 [交付状态](STATUS.md)，不要把交叉编译成功视作所有平台均已验证。

在解压目录打开终端。Windows 使用 `./bma.exe`；macOS/Linux 使用 `./bma`。macOS 归档目前未签名、公证；M5 / macOS 26.4 普通权限合成回环及真实 Claude 受控会话已验证，Intel Mac 尚需实机验证。M 系列朋友首次试用先看 [Mac 试用指南](MAC_TRIAL.md)，其中区分 Claude、Codex、豆包和 WorkBuddy 的实际支持范围。

先运行不联网的演示，输出目录必须不存在：

```powershell
./bma.exe version
./bma.exe demo --output-dir demo-output
```

```sh
./bma version
./bma demo --output-dir demo-output
```

打开 `demo-output/demo-report.html` 查看报告，或运行 `./bma.exe serve --report demo-output/demo-report.json --port 0` 后打开输出的本机网址。演示串起任务、自述、文件变化和网络记录，并附模型发送前预览；全部行为均为模拟，没有读取真实项目、创建压缩包、上传数据或调用模型。[五步图解与 GIF](DEMO.md)说明如何查看线索和证据。

观察实际 Agent 时，明确指定进程名称或 PID、工作目录和任务目标。例如 Windows：

```powershell
./bma.exe watch --process YOUR_AGENT.exe --workspace C:\work\project --goal "只修改 README" --duration 60s --rules ./rules.yaml
```

macOS/Linux 示例：

```sh
./bma watch --process 12345 --workspace /path/to/project --goal "只修改 README" --duration 60s --rules ./rules.yaml
```

将示例进程和路径换成实际值。只观察当前用户显式选择的进程与目录；Windows 连接和进程 IO 不等于纯网络上传量，精确计量需要配置可选代理；macOS arm64 的 nettop 已通过普通权限回环验证，真实 Claude 受控会话也已验证，但短连接 nettop 增量可能不完整，其他 Agent、计数重置/PID 复用仍待验证；当前依赖不支持 macOS 进程 IO，当前开发版会标为不支持，不计作采集失败。Linux 不提供 nettop 计量。结束时保存本地 JSON/HTML 报告，观察期间按 Ctrl+C 也会保存已有记录。

默认不调用模型。模型分析、日志适配、额外目录、恢复和平台限制见包内 [README](../README.md)。不要把“没有记录”或“未命中规则”解释为安全。

已有模型分析报告 `analyzed.json` 时，可用 `./bma.exe reconcile analyzed.json --dry-run-llm --out review-preview.json --html-out review-preview.html` 查看跨批复核将提交的内容；预览不联网、不需要 key。实际复核需指定模型端点，额外请求一次模型，保留原结论并展示修正或未解决的判断。完整命令、容量和脱敏范围见 README 的“复核不同批次的判断”。macOS/Linux 将 `./bma.exe` 换为 `./bma`。

包内 `BUILD.json` 记录版本、目标平台、Go 版本、二进制 SHA-256 和实际链接的模块版本/校验信息。下载时使用发布目录的 `SHA256SUMS` 核对归档；第三方声明见 `THIRD_PARTY_NOTICES.txt`，Apache 2.0 完整文本见 `docs/licenses/Apache-2.0.txt`。校验和用于核对文件一致性，不等同于发布者签名。
