# BMA 下一会话交接

更新时间：2026-09-23

## 当前目标与完成情况

用户要求的 Mac 实时监控面板已实现、测试并提交；新版 Developer ID 签名、Apple 公证、票据装订与 Gatekeeper 验证全部完成。不要重复提交公证或重建已核验的安装包。

- 分支 `feat/go-product`；产品代码提交 `a725076`（Replace Mac setup form with a live application dashboard）。
- 首页：Claude / Codex / 豆包 / WorkBuddy 卡片，点击运行中的应用即可观察；无需选择目录或填写任务。实时展示连接、出入站流量、文件事件、历史采集缺口和最近活动。
- PID、多选、可选目录/任务/日志、代理及采样间隔位于高级设置。
- 不选目录时没有隐式工作区，不启动文件监听或打开文件采样。仅选定开始时的进程；后启动的进程需重新开始观察。
- 启动、停止后保持面板，完整报告按需打开。停止时通过 JSONL 生命周期通道送达最终摘要。
- 系统采样与代理流量分别显示，不重复相加；连接是累计观察记录，不是当前在线数；HTTPS 不解密。

## 本轮测试与构建

- Windows Go 1.27.1 全量测试 13 个包、vet、差异检查通过。
- 新增摘要、无目录范围、桌面控制管道和最终保存测试；在 M5 原生执行通过。
- M5 / UID 501 / Swift 6.3.3 原生编译、卡片启动→真实回环流量→面板更新→停止保存通过。
- 原生视图渲染已检查空闲、监控中、停止、高级设置和最小窗口；本机 `dist/dashboard-evidence/`。这不是 Finder 首次下载验收或真实 Agent 全流程。
- 完整说明：`docs/MAC_DASHBOARD_QA.md`。
- 新版本 `0.4.0-preview.3` 四平台 CLI 归档：`dist/release-dashboard-a725076/`，SHA-256 全部核对。Windows 解压 version/demo 通过。
- arm64 CLI 归档 SHA-256：`3bee20c9f9ac98f638f3233755e1b1ad4a3f0e3f6f3f8af3cca1f266d39b7af0`。
- M5 `package-validation-preview-3` 的 App/ZIP/DMG 构建、version/demo、签名完整性和 DMG 校验通过；这是明确标记的 **ad-hoc-local-only 打包验收产物**，不能当作 Developer ID 版。打包 Swift 源码哈希已与提交工作区逐个核对。

## 已完成的签名与公证

- 产品提交 `a725076`；显式签名钥匙串修复提交 `8b6e98f`。
- Apple 提交 `41818260-fa3c-4892-b9f9-3ca16cac6cd9` 返回 `Accepted`。
- DMG 和 ZIP 内的 App 已装订票据，stapler validate、codesign 完整性、hdiutil 校验通过；两项 Gatekeeper 均显示 `accepted / Notarized Developer ID`。
- 最终安装包和证据已取回 `dist/release-dashboard-signed-8b6e98f/`，两个安装包 SHA-256 与远端一致，所有打包 Swift 源码哈希与工作区一致。
- DMG SHA-256：`203a93d6247eaa885efe87ca82f84061b9e5c6378f7f78db204110660cd53a7d`。
- ZIP SHA-256：`b0e2e2acb6af8106c7e199939adda43736dc03fa08ee7fb01129b4a9a607e127`。
- 这是 M5 命令行 Gatekeeper 检查，尚不代表朋友机器首次浏览器下载/Finder 启动验收或真实 Agent 全流程验收。

## Mac 连接

2026-09-23 安装与清理：新版 `0.4.0-preview.3` 已从已装订 ZIP 安装至 `/Applications/BMA.app`，实际启动的进程路径核对通过，安装后 codesign 与 Gatekeeper 再次通过。此前 `/Applications` 和用户 Applications 均没有正式安装的 BMA；旧 App 仅位于测试目录，现已清除。

按用户要求，仅清理隔离验收根目录内列明的 55 项旧 App、旧安装归档、测试二进制、测试插件缓存和 TLS 测试环境，共 1,476,460,544 字节（约 1.38 GiB 分配占用）；根目录从约 1.4G 降至 31M。保留报告、原始验收证据、源码、证书材料、签名钥匙串、密码文件和最终公证安装包。清理清单位于远端 `dashboard-20260923/cleanup-20260923.json` 和本地 `dist/release-dashboard-signed-8b6e98f/cleanup-20260923.json`。本文提及的历史测试二进制、旧版 DMG 与 Smoke.app 已删除，历史测试结果继续保留；复跑测试须重新构建，不要尝试运行已删除的历史产物。

M5 当前地址为 `dqb@192.168.110.144`。使用本机已有专用 SSH 密钥 `~/.ssh/aea-m5-qa-20260919`，加 `HostKeyAlias=192.168.110.168` 和严格主机校验；已验证是原 M5 的同一主机密钥。

此前断联由 Mac 电量耗尽造成；用户已开机，`.144` 已恢复连接。Windows 仍为 `192.168.110.103`。不修改 VPN 或扫描整个网络。

远端本轮目录：`/Users/dqb/aea-validation-6602c4d/dashboard-20260923/`。

`signed-preview-3/` 中已有 `notary-submission.json`、`notary-result.json`、两份 Gatekeeper 记录和 `RELEASE-COMPLETE`。`release-terminal.log` 记录完整成功过程。不要重复签名或提交同一 DMG。

## 钥匙串的重要区别

- 签名身份：`Developer ID Application: qian bin dai (N64VVGW6Y2)`，证书有效至 2031-09-17；已核实一个有效身份。
- 登录钥匙串 `~/Library/Keychains/login.keychain-db` 使用 Mac 本机登录密码，不是 Apple ID 密码。用户已在 Mac 终端成功执行解锁命令。
- **`BMA-Signing.keychain-db` 是独立钥匙串。**密码仅保存在 Mac `~/Library/Application Support/BMA Signing/keychain-password`（0600），不写入交接或聊天。Mac-local `verify-signing-unlock.py` 已在不输出密码的前提下返回 `BMA_SIGNING_UNLOCK_SUCCEEDED`。
- `scripts/build_macos_app.py` 新增 `--sign-keychain`，签名命令明确使用 BMA-Signing；新版 `signed-preview-3/` 已生成，Developer ID App/DMG 构建期完整性校验通过。
- 本轮 SSH 读取 `BMANotary` 返回登录钥匙串 `keychainLocked`，显式选择 BMA-Signing 则找不到该 profile；这不是签名密码错误。用户在 Mac 本机终端运行发布脚本后公证成功，无需再解锁、重置或更改私钥访问权限。

## 已执行成功的发布脚本

Mac 本机：`zsh ~/aea-validation-6602c4d/dashboard-20260923/finish-release.command`。

本机副本：`dist/finish-dashboard-release.command`。脚本不读取任何密码，复用已配置的 `BMANotary` profile；检查 CLI SHA-256，必要时用显式 BMA-Signing 钥匙串构建 Developer ID App/ZIP/DMG，核对产物，保存唯一公证提交 ID。当前版本还会等待公证、装订 DMG 与 ZIP 内 App 的票据、校验 Gatekeeper、更新外部 BUILD.json/SHA256SUMS 并写 RELEASE-COMPLETE。

用户已运行当前脚本，Apple 接受、票据装订和最终验证已完成；最终产物已下载并核对装订后的哈希。无需再次运行。

## 旧版公证（仅历史）

旧表单版有效 DMG 在 `/Users/dqb/aea-validation-6602c4d/bma-notary-verified-20260922/BMA.dmg`，SHA-256 `c5cfcfbb38f286ff861629f2e9213f1b3bef62bd2380b22e3ad1ae07a7da280a`。旧提交 `53751776-de1c-4854-b77b-66fee7609914` 最后已知 In Progress；本轮因钥匙串会话限制未获得新的状态。旧零字节提交 `46f53400-2aed-4356-a504-227293e5d917` 已失败，不再使用。

任何旧版结果都不能覆盖新面板。公证是 Apple 自动检查，不是 App Store 上架审核，也不验证监控能力。

## 保持边界

不导出私钥、Apple ID 密码、App 专用密码或用户会话。独立钥匙串密码仅由 Mac 本机 helper 读取并传给原生解锁命令，不返回工具输出、不复制到 Windows 或 Git。所有凭据输入留在 Mac 本机。不改系统 Clash/VPN，不做全系统监控，不加阻断、驱动或常驻服务。不把加密字节或豆包附件观察说成具体文件上传证明。
