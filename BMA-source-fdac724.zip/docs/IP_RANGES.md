# 服务网段快照

BMA 按官方公开网段提供一条**有日期的地址线索**。它不查询 DNS、不访问 IP 归属 API，也不会在运行时下载或更新网段。识别使用 Go 标准库 `net/netip`；没有添加依赖、驱动或在线规则服务。

这是 AWS 官方发布 IP 范围、微软发布 Service Tags 的既有模式。BMA 只抽取服务标签，不把整个 AWS、Azure、Google 或 Cloudflare 的地址空间当作对象存储。

## 当前来源

两份数据采集完成时间为 `2026-09-19T19:46:50Z`。原始文件 SHA-256、来源 URL、版本及全部抽取网段保存在源码 `internal/destination/data/storage-ranges.json`；发布包将同一文件附为根目录的 `storage-ranges.json`。二进制内嵌同一快照，旁边的 JSON 供审阅，不是运行时配置。

| 服务 | 官方数据版本 | 选择方法 | 网段数 |
| --- | --- | --- | --- |
| AWS S3 | `createDate=2026-09-19-17-27-06`，`syncToken=1789838826` | IPv4/IPv6 中 `service` 严格等于 `S3` | 467 IPv4 + 662 IPv6 |
| Azure Storage，Public cloud | `ServiceTags_Public_20260914.json`，`changeNumber=418` | 全局 `Storage` 标签且 `systemService=AzureStorage` | 496 IPv4 + 80 IPv6 |

官方来源：

- [AWS IP 范围说明](https://docs.aws.amazon.com/vpc/latest/userguide/aws-ip-ranges.html)与 [JSON 数据](https://ip-ranges.amazonaws.com/ip-ranges.json)。SHA-256：`7841becab1782f9078575037bbc1b76a8695162fb4653611621d8b0b212562d6`。
- [Azure Service Tags 说明](https://learn.microsoft.com/en-us/azure/virtual-network/service-tags-overview)、[官方发布页](https://www.microsoft.com/en-us/download/details.aspx?id=56519)及[本次版本 JSON](https://download.microsoft.com/download/7/1/d/71d86715-5596-4529-9b13-da13a5de5b63/ServiceTags_Public_20260914.json)。SHA-256：`238141eec0d82ed23402be7107c5d23ed9377fb6b085b24b28254b5c7487805f`。

AWS 的发布日期来自数据内的 `createDate`；Azure 的日期来自官方版本文件名，只精确到天，不虚构发布时间。采集完成时间表示文件已下载到本机，不表示逐个端点在该时刻经过实测。校验值用于核对原始文件，不是发布者签名或服务身份认证。

## 如何解释命中

域名格式分类与 IP 网段线索分开保留。例如 `13.65.107.33` 可以命中 Azure Storage 快照，但域名用途仍显示“未知”。Azure Storage 包括 Blob、文件、队列等能力，不能把整个标签称为对象存储，更不能据此断言上传了项目。

优先匹配记录中的 `remote_ip`；没有该字段时，只接受 `remote_host` 中的字面 IP，不解析域名。无效的显式 IP 不会被另一个字段代替。支持 IPv4、IPv6、IPv4-mapped IPv6 及带数字端口的地址；排除私有、本机及带 scope 的地址。存在重叠前缀时，每项服务保留最长匹配，不隐藏其他服务的重叠范围。

`net/storage-ip-range` 规则只对连接记录和非聚合网络记录提供提示。同一会话、同一进程运行实例、同一 IP 只提示一次，不随每段流量重复告警。配置中的模型 API 域名不会豁免 IP 线索或流量规则。失败的连接可以在时间线展示尝试目标的线索，但不据此生成该连接已经发生的规则提示；进程聚合流量不分配给单个地址。

规则 JSON 和事件时间线包含匹配前缀、服务名、日期、来源、原始数据校验值。模型预览额外包含本机计算的 `ip_range_matches` 和 `ip_range_match_field`；导入记录中同名标签不会被信任。匹配不改变上传量计算，也不修改原始事件。

网段可能变化、过时或被多个服务共享。命中不确认观察时或当前的服务归属、具体账户、域名、传输内容或上传方向；事件早于快照时尤其不能据此推算历史归属。页面始终展示快照日期，不以“已更新”或“当前归属”作承诺。用其他 BMA 版本重看报告时，时间线解释可能变化；已存规则、模型结论和请求正文保留当时记录。

目前没有纳入 OSS、GCS、R2 的已核实服务专用网段，也不将通用云/CDN 网段替代为这些服务。它们仍可通过已有的服务域名格式提供线索。未匹配地址、自定义端点、私有端点和未覆盖云分区保持未知；未命中不能解释为安全。

## 维护者更新

维护者从上述官方地址下载新文件，核对来源和日期后，在源码仓库运行离线导入程序。以本次输入为例：

```powershell
go run ./scripts/ipranges `
  --aws dist/address-sources/aws-ip-ranges.json `
  --azure dist/address-sources/azure-service-tags.json `
  --azure-url https://download.microsoft.com/download/7/1/d/71d86715-5596-4529-9b13-da13a5de5b63/ServiceTags_Public_20260914.json `
  --retrieved-at 2026-09-19T19:46:50Z `
  --out internal/destination/data/storage-ranges.json
```

输入只在本地读取，单个源文件最多 16 MiB；输出前检查服务身份、日期、校验值、规范网段、重复和数量。哈希从完整原始文件计算。相同文件和参数生成相同输出。更新时必须使用实际下载 URL、采集时间，复核数据差异并同步上表，运行测试后通过 Git 提交，随新版本分发。不自动刷新用户已安装的程序。
