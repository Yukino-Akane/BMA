# 项目资产交接：开发中快照

## BMA 新交接包（2026-09-20）

当前改名后的包为 `dist/handoff/BMA-project-assets-5d46859.zip`，7,251,392 字节，SHA-256：`5ce6f2abbcbee62f94ee70daea501558acb83337a4fad4a5f8d6b4671821617d`。含提交 `5d468595cca15e2cb8db5b2b1e88273829799391` 的源码、BMA 0.4.0-preview.2 Mac arm64 CLI、README-FIRST、源码及校验清单；ZIP 完整性检查通过，不包含本机原始会话或账号数据。

Mac CLI 归档 SHA-256 为 `873ce9dabce9b66459173790ba851a6153c7c16bcf79e7f76cd3ba2d1a9129cb`，内部二进制为 `c82359d35c1d52edabdf7a65700246ac7eed3e49f43ea60b910855f8d3ee3a37`。已在 M5 普通账户解压运行 version/demo。WorkBuddy 完整受控验收使用同源码开发构建，其二进制 SHA 与本包不同，详见 WORKBUDDY_QA.md；本包不额外声称已经重复完成全量 Agent 会话验收。

仍是未签名、未公证、需要终端的开发资产；桌面界面未完成，豆包未验收。旧 AEA 交接包和 Word 说明保持原样，下面是历史记录。


这个包用于提前交接项目资产，接收方已明确接受“开发到一半”的版本。它不是正式交付版，也不是已签名的 Mac 桌面安装包。

## 包里有什么

- `source/`：当前 Git 提交的完整源码、测试、规则、README、状态文档、演示 GIF/PNG、构建脚本和许可证。
- `mac-cli/aea-0.4.0-preview.1-darwin-arm64.tar.gz`：此前已在 M5 普通权限验证的独立命令行预览版，运行仍需终端。其内容固定在较早的构建提交，不冒充当前源码构建结果。
- `SOURCE.json`：本次源码的 Git 提交及上述预览包的构建来源。
- `SHA256SUMS`：包内所有交付文件的校验值（校验文件自身除外）。

不包含 `.git`、现有账号或模型凭证、Apple 签名材料、SSH 密钥、原始用户会话、测试生成的证书/私钥及整个 dist 目录。合成测试代码/fixture、官方服务网段快照和开发文档属于项目源码，会随包保留。

## 当前能用与不能用

核心采集、规则、报告、恢复等已有实现；Mac CLI 的真实 Claude 受控模型会话已验证。Codex 有日志适配但缺 Mac 真实会话端到端验收；豆包/WorkBuddy 暂无专用日志适配及真实应用验收。详情见 `source/docs/MAC_TRIAL.md`。

`source/desktop/macos/` 是正在开发的原生桌面端，源码已在 M5 / Xcode 26.6 编译通过，**尚未完成应用打包、界面行为验收、Developer ID 签名及 Apple 公证**。尚不能双击这些源文件直接使用；也不要把包内较早的 CLI 直接配给新桌面端，两者状态协议不同。

不熟悉终端的接收方可先保存和查看资产，等待后续 `.app` 图形版本。完整产品进度与剩余项见 `source/docs/STATUS.md`。本次先交接资产，不中止后续桌面端与签名工作。
