# WorkBuddy 受控验收

验证对象为 M5 / macOS 26.4、普通用户 UID 501 上已安装的 WorkBuddy 5.2.5，实际执行其安装包附带的 CodeBuddy CLI 2.106.4。不是桌面界面操作验收，也没有使用真实付费模型。

## 范围和方法

只启动一个新的 CLI 进程，使用新建配置目录及只含 `fixture.txt` 的工作区。BMA 仅观察这个 PID、这个工作区和 CLI 自己创建的本次会话日志；没有读取已有会话、账号配置或凭证，也没有停止用户原有 WorkBuddy。

模型配置来自安装包中 `cli/dist/web-ui/docs/en/cli/models.md`、`env-vars.md` 和实际 `--help`。`CODEBUDDY_CONFIG_DIR` 指向隔离目录，`models.json` 的主模型及关联模型均指向本地固定响应接口，使用无效测试 key。仅开放 `Read,Edit`，使用 `acceptEdits` 模式，不跳过全部权限检查。第一次尝试停在 Edit 批准请求，未算成功；后续使用上述明确的编辑权限完成验证。

固定响应接口依次请求 Read、Edit、结束，独立计算实际读取的 HTTP 请求头和正文；BMA 代理对所选 PID 进行 socket 归属校验并计数。核对工具调用、源日志行号/调用编号/毫秒时间、真实文件修改及 temporal 归因、任务不混入工具结果、模型预览脱敏、报告与日志私有权限。JSON/HTML 和失败结果均保留。

维护者复跑需要 Mac 已安装 WorkBuddy 和它使用的 Node，以及 Python 3；这些不是 BMA 产品运行依赖。路径须按本机安装位置明确指定，输出目录必须不存在：

```sh
python3 scripts/verify_workbuddy.py \
  --node /absolute/path/to/node \
  --cli /Applications/WorkBuddy.app/Contents/Resources/app.asar.unpacked/cli/bin/codebuddy \
  --bma /absolute/path/to/bma \
  --out /absolute/path/to/new-workbuddy-qa
```

## 实际发现与限制

尽管测试设置了 `DISABLE_TELEMETRY=1`、`DISABLE_ERROR_REPORTING=1`、`DISABLE_AUTOUPDATER=1`，所选 CLI 仍通过 CONNECT 连接 `galileotelemetry.tencent.com:443`。加密出站字节单独记在 `external_proxy_bytes_out`，不与本地模型接口实收比较；没有解密，不能据此宣称上传了文件、提示词或其他具体内容，也不能认定某项关闭开关覆盖了所有网络行为。

因此只能称“模型接口为本地模拟”，不能称“整个应用只连接回环”。启动和初始化流量不保证全被观察；nettop 是独立聚合采样，可能漏掉短连接，不能和代理相加。报告保留 process_io 未实现、初始缺样、退出缺口及启动连接失败等原始证据。计数下降可能被标为 counter_reset_or_invalid_interval，这不等于已受控验证真实计数重置或 PID 复用。

当前不包含 WorkBuddy GUI、真实模型质量、HTTPS 模型接口、外部文件上传及所有版本兼容性验收。豆包 2.29.12 arm64 已于 2026-09-20 从官网安装到 M5 的 /Applications/Doubao.app，安装副本 codesign 校验通过，Gatekeeper 为 accepted / Notarized Developer ID；后续用户确认登录，并配合完成一次附件操作期间的限定观察，见 [豆包实测边界](DOUBAO_QA.md)；仍未独立验证上传归因或完整工作任务。不能用 WorkBuddy 的结果代替豆包。

## 2026-09-20 最终结果

`workbuddy-final-qa-2/verification.json` 为 `passed:true`：Read/Edit、真实文件修改、日志行号/调用编号/毫秒时间、任务、预览脱敏和私有权限均通过。三个本地模型请求的代理出站为 **26,018 字节**，服务端独立实收 **26,018 字节**；另记录上述遥测目标 **6,031 字节**加密出站。不同轮次的随机会话和路径会改变长度，不能固定期待这些字节数。

Mac 原始证据位于 `~/aea-validation-6602c4d/workbuddy-final-qa-2/`，本机摘要为 `dist/workbuddy-evidence/verification.json`。BMA 二进制 SHA-256 为 `5976fd60daa389ee4af4bd6c20d4fc07d0b45312cacdca79b4e94ba48bc7f549`；内置 CLI bundle 为 `261d7adbf379d7a126aff1148c9d9435153bb7965c1943aa8110861d01f5f21f`。全量 13 个 Go 测试包、go vet 通过；新增适配测试亦在 M5 原生执行通过。

失败基线保留：`workbuddy-qa-1` 为 Edit 等待批准；`workbuddy-final-qa` 为验证脚本在 Python 3.9 解析可变小数位时间时报错。修正时间解析后完整重跑上述最终目录，不修改旧结果。最终报告仍有 process_io、nettop 初始缺样/计数下降、lsof 退出阶段失败及进程退出缺口，未将它们当作应用违规或隐藏。
