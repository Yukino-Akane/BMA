# macOS 外传检测验收边界

本文是当前源码的能力说明，不是功能目标清单。结论以本仓库的用户态采集器为准；文档中提到的历史安装包不能替代当前源码验收。当前工作树没有 EndpointSecurity、NetworkExtension、系统扩展或额外 entitlement。相关能力若未在事件中出现，必须报告采集缺口或“授权状态未知”，不能补造为已发生。

## 参考取证

本轮先对照了 [Ferstar 的 ZCode workspace snapshot 取证](https://blog.ferstar.org/posts/zcode-silent-workspace-snapshot-upload/)。该记录区分了问题版 3.12.3 的 313 MB 打包和 564 次失败尝试（没有成功上传）、另一个约 15 KB 仓库快照的服务端接收状态，以及 3.14.0 删除链路后、3.14.3 未重新触发的整改观察。因而本实现不使用“大流量即外传”作为唯一条件：小文件、低速分段、失败重试、产物删除和接收证据分别记录。

## 证据等级

报告应把下面几类事实分开。每个较强结论都必须能回到对应的原始事件；时间接近、大小相似、熵高和扩展名只支持疑似关联。

| 结论 | 当前可接受的证据 | 当前不能证明的内容 |
| --- | --- | --- |
| 文件存在或产生了产物 | 指定根目录中的 `file_create`、`file_modify`、`file_rename_from`，含大小、扩展名和可选熵线索 | 哪个进程读了它、文件内容是什么、已经上传 |
| 文件曾处于打开状态 | macOS `lsof` 返回的 `file_open_observed` | 实际发生过 `read(2)`、读取了哪些字节、打开后关闭的短时访问 |
| 进程有网络连接 | `connection_observed` 的 PID/启动时间、socket 地址和状态 | 连接发送了字节、目标应用收到请求、连接对应某个文件 |
| 进程产生了网络字节增量 | macOS `nettop` 经过基线和身份核验后的 `egress`；这是进程级聚合计数 | 单个目标、请求内容、文件与字节的精确对应；短连接在采样间隔外可能漏掉 |
| 观察到上传尝试 | 显式 BMA HTTP/CONNECT 代理记录的目标、连接建立、成功写入字节或失败/重试阶段 | 远端应用收到全部字节、TLS 中的文件内容、上传成功 |
| 确认发送了特定内容 | 当前采集器不产生此等级；需要独立的受控明文内容证明或测试接收端比对 | 仅凭 TLS 字节、连接成功、Agent 自述或模型 API 域名升级到此等级 |
| 获得接收证据 | 隔离接收服务独立保存的内容和哈希，并与检测器事件按测试标识核对 | 把接收服务的真值偷偷注入检测器；生产报告不能把“写入本地 socket”当成远端接收 |

`process_io` 在 Darwin 明确为 `unsupported`（[`io_darwin.go`](../internal/collect/io_darwin.go#L10-L13)）；它不是网络量，也不能换算上传量。Agent 日志、`--claims-file` 和任务目标是自述或用户输入，不是操作系统证据（[`README.md`](../README.md#L74-L84) 的三层证据说明）。

## 当前 macOS 采集链

### 进程范围和身份

- 桌面端只列当前 UID 的进程，读取 PID、可执行路径和 `proc_pidinfo` 启动时间；应用候选再通过 Security.framework 取得 bundle/signing identifier/team/CDHash（[`Processes.swift`](../desktop/macos/Processes.swift#L58-L90)）。
- 观察开始时传入 `PID@START_TIME_MS`，每轮重建当前账户的父子树；后代只有在父链和启动时间能重新核验时才加入。退出、PID 复用、重新托管或父链缺失会产生 `scope_member_removed`/健康缺口（[`scope.go`](../internal/collect/scope.go#L20-L108)）。这是减少误归属的用户态检查，不是原子系统快照。
- 对带 `--root-code` 的根进程，Darwin 后端以数字 PID 调用 `codesign --verify -R`，要求 identifier 和 CDHash 匹配（[`code_identity_darwin.go`](../internal/collect/code_identity_darwin.go#L23-L38)）。它锁定被选中的代码实例，不等于“官方发行者白名单”。手动选择的非应用进程和只提供 PID/启动时间的 CLI 模式没有这层代码签名约束。
- 代理授权复用同一范围，并逐个检查系统连接表中源/目的地址是否属于选定实例（[`proxy_identity.go`](../internal/collect/proxy_identity.go#L15-L66)）。socket 变化和采样之间仍有竞态；核验失败时代理拒绝，不猜测归属。

### 文件和打开文件

- 只有用户明确选择的工作区或额外目录进入 `fsnotify` 递归监听；监听记录创建、修改、删除和重命名，文件事件没有 PID，归因是 `temporal` 或未归属（[`files.go`](../internal/collect/files.go#L147-L191)）。监听器溢出、目录替换、路径边界和容量限制会留下 `collector_error`。
- Darwin 的 `gopsutil` 不实现打开文件查询，后端改用 `/usr/sbin/lsof -nP -a -p PID -F0pfn`，只接收同一 PID 的数字文件描述符和绝对路径，再按已选根目录过滤（[`openfiles_darwin.go`](../internal/collect/openfiles_darwin.go#L10-L20)、[`lsof_parse.go`](../internal/collect/lsof_parse.go#L12-L59)）。路径解析有歧义时拒绝样本并保留缺口。
- `lsof` 只是采样时仍打开的描述符。`access: "unknown"` 是刻意的保守值；它不表示已读文件，更不能替代 EndpointSecurity 的文件访问事件。文件大小、压缩/加密扩展名和熵在规则中只是线索（[`rules.go`](../internal/rules/rules.go#L78-L100)）。

### 网络

- 默认连接采样来自 `ConnectionsWithContext`，只记录瞬时 socket 的 PID、IP、端口和状态，方向及字节量未知（[`watch.go`](../internal/collect/watch.go#L265-L290)）。反向 DNS 是可选线索，不证明应用层请求域名。
- Darwin 字节采样调用固定路径 `/usr/bin/nettop`，使用显式 `-p PID`、禁用名称解析并按最多 20 个 PID 分批；首个有效样本只建立基线，缺行、失败或计数回退会清除基线（[`nettop_command.go`](../internal/collect/nettop_command.go#L10-L62)、[`netbytes.go`](../internal/collect/netbytes.go#L21-L81)）。它是进程聚合累计量，不能拆分到连接、目标或文件；未采到短连接不等于没有发送。
- 显式 `--proxy-port` 才启动本机 HTTP/CONNECT 代理。代理只为系统 socket 表核验到的选定进程转发，按成功写入两端连接的字节记录增量、目标和失败/结束阶段；不记录请求正文、请求头或原始错误（[`proxy.go`](../internal/collect/proxy.go#L18-L20)、[`proxy.go`](../internal/collect/proxy.go#L95-L184)、[`proxy_evidence.go`](../internal/collect/proxy_evidence.go#L42-L143)）。应用必须自行配置该代理；绕过代理的连接不会进入代理计量。CONNECT 中的 TLS 字节保持加密，代理不解密。
- 代理字节包含协议和 TLS 开销，不能直接当作文件大小。写入成功也只证明 BMA 写入了下一跳 TCP 连接；上游服务是否收到由独立接收端证明。上游失败或重试不得被改写成成功上传。

## 保护范围和授权状态

当前桌面端能记录用户选择的项目目录、缓存/临时目录、保护目录、敏感类别、允许上传目录、允许目标和授权状态（[`AppController.swift`](../desktop/macos/AppController.swift#L429-L536)）。命令行也可用 `--protected-dir`、`--sensitive-category`、`--allow-upload-dir`、`--allow-upload-target` 和 `--authorization-state` 显式记录同一策略。允许上传目录必须是绝对路径，允许目标只能是可由代理核验的主机/端口或根 HTTP(S) URL；不把 Agent 自述的批准请求当作操作系统授权。因而验收报告应至少区分：

1. **明确授权**：由用户在本次会话中保存的授权状态、允许目录和允许目标共同证明，且目标/文件落在该范围内。
2. **授权状态未知**：没有授权记录、授权记录不完整，或只能看到 Agent 自述/模型 API 域名。
3. **超出范围**：证据足以显示目标、文件或进程不在用户保存的允许范围内。

缺少第 1 类记录，或 `authorized` 没有同时配置允许目录和允许目标时，只能输出“授权状态未知”或“授权范围不完整”，不能把外传直接定性为未经授权。模型 API 域名也不自动安全；离线规则应在本地运行，模型结论必须引用本批次已有证据，不能取代授权记录或操作系统证据。

## macOS 权限、entitlement 和分发

### 当前普通权限方案

当前 AppKit 启动器和 Go 后端不要求 `sudo`、不修改 SIP、系统代理或根证书，不安装常驻服务；Swift 构建只链接 AppKit/Security，生成的 `Info.plist` 没有沙盒、EndpointSecurity 或 NetworkExtension entitlement（[`scripts/build_macos_app.py`](../scripts/build_macos_app.py#L90-L126)）。因此：

- 进程枚举、`lsof`、`ConnectionsWithContext` 和 `nettop` 可能受当前用户、系统隐私策略、受保护进程和瞬时状态影响；失败必须以健康事件披露。不能用“命令没有返回结果”当作“没有文件访问/没有网络”。
- 用户选取的工作区不等于系统范围授权。Desktop、Documents、iCloud、其他用户目录和受 TCC 保护的位置可能需要用户在系统设置中授予文件访问权限；本项目没有静默扩大权限的路径。未能读取时报告缺口，不能自动改为扫描整个主目录。
- 当前运行方式是用户启动、会话内观察。退出后没有内核事件订阅、开机自启或系统范围历史，因此短命进程、关闭后文件、未经过代理的网络和会话外行为不可回溯。

### EndpointSecurity 可行性

EndpointSecurity 客户端可以在获得 Apple 授权的 `com.apple.developer.endpoint-security.client` entitlement 后订阅系统级进程和文件事件；实际部署还需要相应的签名、公证、系统扩展或受支持的客户端打包方式，以及用户批准/隐私配置。它能提高 `open/close/rename/unlink` 等元数据覆盖，但单凭 open 仍不能证明应用读了具体内容；要证明读取内容还需要更深的受控观测，且仍不自动解开应用层加密上传。

本项目没有该 entitlement、系统扩展或相关代码。不得把 EndpointSecurity 的可行性描述成当前已实现，也不得为了验收临时关闭 SIP、安装驱动或扩大全盘权限。

### Network Extension 可行性

Network Extension 的 content filter、transparent proxy 或 packet tunnel 方案可以比 `nettop` 提供更完整的 flow/进程归属，但每种 provider 都需要对应的 `com.apple.developer.networking.networkextension` entitlement、Apple 审核/授权、Developer ID 签名、公证、系统扩展安装和用户批准。它们通常仍只能看到 TLS 密文；HTTPS 解密需要额外的用户信任和应用支持，且不能自动解开应用层自加密包。

本项目没有 Network Extension provider，也不接管系统代理。可选 BMA loopback 代理是用户显式配置的会话内测试/计量通道，不能替代系统级覆盖。

## 验收解释规则

下列解释适用于隔离测试目录、合成敏感文件、受控测试进程和本地接收服务；接收端内容/哈希必须独立保存，不能传给检测器作为输入：

| 场景 | 检测器可能看到的证据 | 允许的结论 |
| --- | --- | --- |
| 正常读取并本地打包，无上传 | 文件变化、可能的 `lsof` 打开状态；没有代理 `egress` | “发现产物，未观察到可核验外传”；不能说全系统没有外传 |
| 小文件或模拟敏感配置经显式代理发送 | 目标连接、少量 `egress`、写入/结束或失败重试 | “观察到上传尝试/已向该连接写入字节”；不能确认特定文件内容或远端接收 |
| Git 历史打包后发送 | `.git`/归档线索与时间相近的文件和网络事件 | “疑似文件与出站相关”；关联依据和不确定性必须列出 |
| 项目目录外生成加密产物后发送 | 若目录未选中则可能只有进程/网络证据；若路径不在允许上传目录则记录范围外 | “加密出站无法识别内容”；授权状态按允许目录和目标核对，不能报告已确认文件外传 |
| 辅助进程上传 | 动态父子范围中该进程的身份、socket/代理事件；或范围缺口 | 只有父链核验通过才能归属；缺失时披露“无法归属/可能漏采” |
| 失败、重试、上传后删除 | 代理 `connection_failed`、多段增量、文件删除及原始 `created_event_id` | 分别显示尝试、失败重试和删除；删除窗口规则不能升级为上传成功 |
| 明确授权上传 | 授权记录、范围内文件/目标及同一进程证据 | “授权范围内观察到上传尝试/发送”；仍需独立接收证据才能说收到 |
| 未配置授权 | 行为证据但没有授权记录 | “授权状态未知”，不能直接断言未经授权 |

## 可复现运行

验收必须使用新建的隔离目录、合成内容和本地接收端。接收端保存的正文/哈希只用于验收脚本最后的真值对照，不写入 BMA 输入。当前仓库提供受控场景驱动器；在 macOS 上从源码构建后运行：

```sh
go build -trimpath -o /tmp/bma-exfilqa-bma ./cmd/bma
go build -trimpath -o /tmp/bma-exfilqa ./scripts/exfilqa
mkdir -p /tmp/bma-exfilqa-output
/tmp/bma-exfilqa --bma /tmp/bma-exfilqa-bma \
  --out /tmp/bma-exfilqa-output/run-$(date +%Y%m%d-%H%M%S)
```

脚本覆盖本地打包、小文件、合成敏感配置、Git 历史快照、目录外无扩展名/加密产物、辅助进程失败重试与删除、明确授权、未配置授权以及 TLS 内容不可见等场景。运行输出中的 `receiver_truth` 是独立接收端真值；`detector_evidence`、`detector_findings` 和 `collection_gaps` 是检测器实际保存的证据。若采样没有看到所需证据，结果必须是 `missed_or_uncertain` 或带采集缺口的保守状态，不能通过改写报告补齐。

该脚本不会读取真实主目录、凭证或既有 Agent 日志，也不会安装根证书、改系统代理、关闭 SIP 或请求系统级权限。TLS 场景只证明当前观察器看到加密字节，不能把接收端真值升级为“生产环境已确认文件外传”。

## 本轮实际结果

以下结果来自当前源码在 macOS arm64 的新隔离目录运行；BMA 和 QA 二进制分别为 `5c4d20a30dd092cedc7ce1d8fd1ae88dd446f8a27088b2718f675f0d9f5d1b7c` 和 `ed6864660da88a4820f6022f76d284a73956111feac45dc4f2a5fa40628a9e4a`。完整原始结果在 [`verification.json`](/tmp/bma-exfilqa-final-run-1790227055145386000/verification.json)。`receiver_truth` 的正文和哈希只由隔离接收服务保存并在 QA 结束时核对，没有作为检测器输入。

| 场景 | 检测器实际看到的证据 | 检测器结论 | 接收端真值 | 误报/漏报 |
| --- | --- | --- | --- | --- |
| 正常读取、构建、本地打包 | `file_create`/`file_modify` 的 `local-build.zip`；无代理 `egress` | 仅文件打包线索，未报告外传 | 0 条接收 | 无误报；不把“未观察到”扩大为全系统安全 |
| 小文件 | `file_open_observed`；HTTP `POST` 代理写入 17,843 B | `观察到上传尝试`，授权 `unknown` | 17,664 B，SHA-256 相符 | 无误报/漏报标志；仍未确认远端接收 |
| 敏感配置 | `.env.synthetic` 打开；HTTP `POST` 代理写入 235 B | `观察到上传尝试`，授权 `unknown` | 59 B，SHA-256 相符 | 同上 |
| Git 历史快照 | `.git` 打开、快照产物创建/修改、HTTP `POST` 633 B | `观察到上传尝试`；Git 路径为敏感线索，快照为产物线索 | 456 B，SHA-256 相符 | 同上；没有把普通 `.git` 文件单独称为新打包 |
| 目录外加密产物 | 选定缓存中的无扩展名高熵产物；HTTP `POST` 17,871 B | `观察到上传尝试`，内容身份仍未知，授权 `unknown` | 17,692 B，SHA-256 相符 | 未升级为特定文件已确认外传 |
| 辅助进程、失败重试、删除 | 子进程加入范围；失败拨号；成功 `POST` 235 B；删除事件引用原始创建事件 | 分别报告失败请求尝试、成功写入和产物删除；删除未升级为成功接收 | 59 B，SHA-256 相符 | 无误报/漏报标志；失败不被写成成功 |
| 明确授权上传 | 允许目录内文件打开；HTTP `POST` 17,843 B；目标含端口 | `观察到上传尝试`，授权 `authorized` | 17,664 B，SHA-256 相符 | 授权目录/目标匹配；仍不确认内容只来自允许目录 |
| 未配置授权 | 与上例相同的文件、进程和 `POST` 字节 | `观察到上传尝试`，授权 `unknown` | 17,664 B，SHA-256 相符 | 没有把 unknown 说成未经授权 |
| TLS / 应用层加密 | `CONNECT` 隧道 1,828 B；没有可见 HTTP 方法或正文 | `疑似数据外传`，`suggestive_proxy_bytes`；不能确认特定内容 | 59 B，SHA-256 相符 | 没有报告“确认发送了特定内容” |

九个场景的接收端哈希全部匹配，`infrastructure_passed=true`，QA 的 `false_positive=false` 和 `missed_or_uncertain=false` 均成立；这些标志只表示预期的受控证据等级被观察到，不代表生产环境不存在采集缺口。

本轮还加入了无文件关联的代理小请求规则：经过选定进程身份核验的 HTTP `POST`、`PUT`、`PATCH` 仍会报告“观察到上传尝试（内容未知）”，但不伪造文件路径或内容关联。模型分析发送路径同样要求精确允许目标和绝对允许目录；`unknown` 只能在范围完整且目标匹配时发送并保留未知状态，`denied` 或范围缺失在创建请求日志前阻止。

## 剩余缺口

- 没有 EndpointSecurity 时无法完整捕获系统级文件读取；没有 Network Extension 时无法保证所有网络 flow 和短连接都被看到。
- `nettop` 聚合量和普通文件监听没有文件到网络的硬关联；当前关联最多是时间、大小、路径类别和同一进程范围的疑似关系。
- TLS/应用层加密内容不在当前采集器可见范围；连接成功、字节发送、模型 API 域名和 Agent 自述都不能单独确认特定文件上传成功。
- 进程退出、PID 复用、父子关系短暂不可核验、TCC/系统隐私拒绝、监听队列溢出和报告写入失败必须作为采集缺口保留。未命中规则不代表安全。
- 本文不声称已公证安装包包含当前开发分支的进程树和健康修复；验收须记录二进制版本、SHA-256、签名、公证状态和实际运行路径。
