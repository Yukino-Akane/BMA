# BMA macOS ChatGPT 交接

> 本文保留交接包基线状态；2026-09-23 本地接手后的源码改动、验证和剩余工作见 [本地接手记录](LOCAL_TAKEOVER.md)。已发布安装包与当前开发源码必须区分。

更新时间：2026-09-23  
当前分支：`feat/go-product`

这份文档给 macOS 上继续接手本项目的 ChatGPT 使用。截图是当前真实运行反馈，不是新的功能规格；其中“采集缺口”问题需要按本文的诊断处理。

## 当前已完成

- Mac 首页已经从表单改成 Claude、Codex、豆包、WorkBuddy 应用卡片和实时摘要面板。
- 目录、目标、日志、代理、采样间隔和手动进程选择进入高级设置；目录和目标不再必填。
- 当前用户进程、连接、系统网络字节、可选文件事件、会话日志和缺口都写入受限本地会话。
- M5 原生 Swift 编译、Go 测试、回环端到端、AppKit 视图渲染通过。
- Developer ID 签名、Apple 公证、DMG/ZIP 票据装订、Gatekeeper 验证均通过。
- 当前 M5 已安装并启动：`/Applications/BMA.app`，版本 `0.4.0-preview.3`。

重要提交：

- `a725076`：实时应用面板产品实现。
- `8b6e98f`：显式选择 BMA-Signing 钥匙串的签名修复。
- `a3374b1`：Apple 公证和 Gatekeeper 证据记录。
- `90f7899`：M5 安装和测试产物清理记录。

最终安装包：

- `BMA-0.4.0-preview.3-macos-arm64.dmg`
  - SHA-256：`203a93d6247eaa885efe87ca82f84061b9e5c6378f7f78db204110660cd53a7d`
- `BMA-0.4.0-preview.3-macos-arm64.zip`
  - SHA-256：`b0e2e2acb6af8106c7e199939adda43736dc03fa08ee7fb01129b4a9a607e127`
- Apple 公证提交：`41818260-fa3c-4892-b9f9-3ca16cac6cd9`，状态 `Accepted`。

## 当前真实问题

### P0：应用卡片没有跟踪子进程

点击 Codex 卡片时，桌面端只把当时选中的 PID 传给 Go 后端。ChatGPT.app 里的 `codex` 会再启动 `node_repl`、`uv`、MCP Python 和其他子进程；子进程可能承担真正的网络工作，却不会进入范围。

修复方向：保存根进程 PID + 启动时间 + bundle/code-signing 身份；Go 端每个采样周期刷新父子关系，动态维护后代集合；报告记录 `scope_member_added/removed`，面板显示根进程和子进程数量。

### P0：PID 复用没有被完全锁定

当前 App 传入的是 PID 字符串。进程退出后，系统可能把相同 PID 分配给另一个进程。必须把“PID + CreateTime/启动时间”作为固定身份；复用时停止旧成员并记录缺口。

### P1：采集缺口分类错误

当前 macOS `gopsutil` 的 `IOCountersWithContext` 返回 `not implemented yet`，但被计为采集缺口。`nettop` 正常执行但没有该 PID 的行，也会被计为缺口。应分成：

- `unsupported`：该平台不提供此能力；
- `idle`：采样成功但当前没有可见流量；
- `failed`：命令或权限真正失败；
- `process_exited`：目标进程退出；
- `recovered`：之前失败后恢复。

面板不要把这些状态都显示为橙色“采集缺口”。

### P1：实时面板时间和健康状态不够准确

“实时更新”使用本机 UI 当前时间，不是后端最后一次成功采样时间。应显示 `last_sample_at`、`last_success_at`、采样间隔和覆盖进程数；请求失败时保留上次数据但明确标注数据陈旧。

### P1：代理归属与应用范围相同样会漏子进程

代理只接受能由 socket 表核实为选中进程的连接。进程树范围修复后，代理身份核验必须复用同一 `ProcessScope`。

### 已确认的边界

- 没有 `egress` 事件不能证明发生上传。
- 一个子进程存在 socket 不能证明发生外网传输。
- macOS `nettop` 是聚合字节计数，不能把网络字节精确归因到文件。
- 文件变化没有 PID，打开文件只是尽力而为。
- 当前测试没有覆盖真实 ChatGPT/Codex 进程树、PID 复用、权限拒绝、短命进程和代理绕过。

## 推荐实施顺序

1. 先做 `ProcessScope`：根身份锁定、父子树刷新、成员增删事件、PID 复用测试。
2. 再做 `CollectorHealth`：把 unsupported、idle、failed、exited、recovered 从 `collector_error` 分离。
3. 修改 `/api/dashboard` 返回健康状态、最后成功采样时间、覆盖 PID 数和范围变化。
4. 面板显示“Codex（根进程 1，子进程 N）”和准确的采样说明。
5. 在 M5 用真实 ChatGPT/Codex 进程树验证动态子进程、nettop 空样本、代理归属和退出重启。
6. 最后再考虑流量图、目的地时间线、会话保留策略和应用配置。

## 更大范围方案的边界

当前方案是用户态、当前会话、只观察，不阻断、不常驻、不修改 VPN。它适合普通用户安全审计。

如果要捕获所有短连接、系统范围网络事件或阻止连接，需要 Network Extension / Endpoint Security 系统扩展和 Apple entitlement，安装和权限模型都会改变。先不要把这条路线混入当前修复。

成熟产品可参考 Little Snitch 的代码签名身份和应用组模式、LuLu 的连接事件与规则分离模式。BMA 当前只吸收“身份和范围”设计，不加入拦截功能。

## 安全和发布规则

- 不读取、复制或在聊天中发送私钥、登录钥匙串密码、BMA-Signing 密码、Apple ID 或 SSH 私钥。
- 已公证安装包不要直接修改；任何源码或 App 内容改动都必须重新构建、签名、公证和 Gatekeeper 验证。
- 使用成熟依赖和现有 Go/Swift 入口，不增加向后兼容层、migration 或 fallback。
- 不改变当前用户进程限制、无驱动、无后台服务、无 HTTPS 解密的产品边界，除非用户明确重新授权。

## 开始接手时的安全检查

```sh
cd ~/BMA
git status --short
git log --oneline -8
go test ./... -count=1
go vet ./...
codesign --verify --deep --strict /Applications/BMA.app
spctl --assess --type execute --verbose=2 /Applications/BMA.app
```

继续修改前先复制到新工作目录；不要在 `/Applications/BMA.app` 内编辑。先做本地 ad-hoc 构建和测试，最终发布才使用 Mac 本机的 Developer ID 会话。

## 文件说明

交接包中的 `source-head.zip` 是当前源码快照，`BMA-history.bundle` 保留 Git 历史，`release/` 是已公证安装包和证据，`docs/` 是相关验收文档。交接包不含任何密码、私钥或钥匙串文件。
