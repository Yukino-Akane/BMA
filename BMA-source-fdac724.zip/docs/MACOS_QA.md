# macOS 真机验收

Apple M5 使用 `darwin-arm64` 二进制。2026-09-19 已在用户的 M5 / macOS 26.4、UID/EUID 501、无 sudo 环境完成下面的合成回环验证。Intel Mac 仍需要单独运行 `darwin-amd64`；Windows 交叉编译不代替任何真机结果。

## 会话边界

当前复跑命令使用 BMA 名称；旧包与历史结果保留 AEA 名称，复跑前须从当前源码构建 bma 和 platformqa，不能将新参数用于旧包。

无需 sudo、模型密钥、真实项目或 Agent 登录。维护者工具 `platformqa` 自己启动一个合成子进程，只让 AEA 观察这个 PID 和新建的测试工作区，所有流量只到 `127.0.0.1`。直连及 CONNECT 两轮各发送 2 MiB 固定数据并接收回显。CONNECT 轮是 TCP 回显，不是 TLS 验证，也不是 Claude/Roo/Cline 的真实 Agent 会话。

工具检查真实文件内容、文件事件的 temporal 归因、PID/启动时间、回环连接、JSON/HTML 输出和代理双向计数。Mac 额外要求 nettop 出站增量、lsof 打开文件证据及输出目录/文件没有组或其他用户权限。所有采集缺口保留，不把进程退出后的缺口隐藏。无法取得所需证据时返回非零并保留 `verification.json`，不能通过改成 sudo、移除失败检查或跳过采集来宣称普通权限验收。

`nettop.txt` 和 `lsof.txt` 只采集此次子进程。nettop 使用 `-p PID` 和 `-n`；lsof 使用 `-a -p PID -nP`，不查询全系统、解析域名或采集既有会话。记录还包含 `sw_vers`、OS/架构、UID/EUID、二进制 SHA-256、检查结果及错误文件。进程退出会关闭监听和子进程；输出目录保留供检查，不会删除已有目录。

## 运行

本轮可复跑的已修复验收包为 `aea-m5-qa-f3d6453.tar.gz`（源码提交 `f3d6453`）；它已在 M5 核对成员校验值、运行 version/demo 和两轮 platformqa，通过结果在 `~/aea-validation-6602c4d/release-qa-f3d6453/verification.json`。旧 `6602c4d` 包仅保留作失败基线。

以下仅为旧 f3d6453 QA 包的历史复跑命令，当前源码构建命令见下一代码块。旧包解压后在该目录运行；产品和维护者工具都是 Go 二进制，不需要安装 Go、Python 或 Node。请先核对包内 `SHA256SUMS`：

```sh
shasum -a 256 -c SHA256SUMS
./aea version
./platformqa --aea ./aea --out "$HOME/aea-platform-qa-$(date +%Y%m%d-%H%M%S)"
```

输出目录必须不存在。两轮通常约 50 秒；失败时也查看终端打印的 `verification.json`。所有检查通过只能证明上述合成链路，不能将 `passed:true` 解释为完整产品验收。若系统对未签名下载程序要求用户确认，按系统界面审阅并批准这两个明确的程序；不关闭 Gatekeeper 或修改全局安全设置。

从源码自行构建维护者工具：

```sh
go build -trimpath -o bma ./cmd/bma
go build -trimpath -o platformqa ./scripts/platformqa
./platformqa --bma ./bma --out "$HOME/bma-platform-qa-$(date +%Y%m%d-%H%M%S)"
```

Go 标准库负责子进程、TCP 回显和 JSON；复用项目现有报告读取及 Windows ACL 代码。该工具不加入正式 AEA 的命令或运行依赖。

## 已核实的系统格式与后续验收

已按 [nettop 手册](https://keith.github.io/xcode-man-pages/nettop.1.html) 明确设置 `-n`，按已核实的 PID 重复传入 `-p`，拒绝空选择；不能先获取全系统输出再以此代替采集范围限制。手册说明 `-L` 输出 CSV、`-P` 输出进程摘要、`-x` 输出数字、`-J` 选择字段。

真机确认 `pid,process` 不是可供 `-J` 选择的指标，会使 nettop 退出失败。现已只选择 `bytes_in,bytes_out`，按实际 CSV 首列的 `进程名.PID` 解析身份，保留末尾空列；不再保留旧四列猜测或空白分隔解析。表头决定入站/出站位置，未知表头、损坏后段或非法计数拒绝整个样本。仅包含合成子进程的原始样例保存在 `internal/collect/testdata/nettop-macos26.4.csv`。

gopsutil v4.25.6 在 Darwin 的打开文件接口返回未实现，现改用系统 `/usr/sbin/lsof -nP -a -p PID -F0pfn` 的 NUL 字段协议；只接收同 PID、数字文件描述符及绝对路径，再由已有监听根过滤逻辑限制范围。NUL 分隔仍会转义文件名，按系统手册解码 C 转义和 UTF-8 十六进制字节。真实打开的中文、空格、反斜杠、换行、字面 `\\x41` 和双引号文件均有 Mac 原生测试。lsof 把控制字节 0x01 和字面 `^A` 都输出为 `^A`，无法无歧义还原；遇到这类路径时拒绝样本并报采集缺口，不能把描述符归到另一个碰巧存在的文件。真机同时打开这两类文件的拒绝测试也已通过。

nettop/lsof 使用固定系统程序路径，输出限 4 MiB、运行限 5 秒；错误不复制原始命令输出。普通权限下已观察到文件变化、打开文件、选定进程身份与连接；直连和 CONNECT 两轮各 2,097,152 字节的 nettop 出站增量与端点实收一致，CONNECT 代理双向各 2,097,152 字节，二者分别展示而不相加。报告目录及 JSON/HTML/日志无组和其他用户权限。当前 gopsutil 仍未实现 macOS 进程 IO，报告保留 `process_io` 缺口；最终直连测试在尚未建立 socket 的首轮出现缺失样本，下一轮建立基线并记录恢复，两条记录均保留；测试子进程退出后的缺口也保留。

基线失败结果保存在 Mac `~/aea-validation-6602c4d/baseline-qa`，修复后的首轮结果在 `fixed-qa`，包含路径转义/歧义处理的最终结果在 `final-qa`；本机副本位于 `dist/mac-baseline-evidence/`。旧 `6602c4d` 验收包保留作基线，它没有本次修复，不能直接作为已通过版本继续分发。测试二进制在 Windows 交叉编译后在 Mac 实际执行，未在 Mac 安装 Go、Python 或额外依赖。

此工具不制造 PID 复用、真实计数器重置、权限拒绝、系统丢包、断电或磁盘故障；这些仍需单独场景。进程身份与计数状态机的合成测试也不能替代真机场景。

真实 Claude 的受控会话见下一节；其他 Agent/外部网络仍待验证。还需使用 Finder 或浏览器直接打开生成的 `report.html`，验证 `file://` 下分页、筛选、证据定位、原始事件展开、模型预览与长文本显示。只打开本地 HTTP 页面或自动生成 HTML 不算完成这一项。

## 真实 Claude 受控会话（2026-09-20）

已通过用户的 Clash Verge 本地代理安装官方 Claude Code 2.1.278（`~/.local/bin/claude`）。验证使用 UID/EUID 501、无 sudo、新的配置目录与测试工作区，只开放 Read/Edit，假测试 key 和本地模拟模型；安装下载使用 Clash，模型验收使用 AEA 自己的回环代理。没有登录真实模型或读取用户既有凭证。

`scripts/verify_claude.py` 支持 Windows/macOS，HTTP 模式只需系统 Python 3.9+；HTTPS 模式另需隔离 venv 内的 cryptography（此轮 46.0.5），证书只提供给测试子进程，不安装系统 CA。

```sh
python3 scripts/verify_claude.py --claude "$HOME/.local/bin/claude" --bma ./bma --out ./claude-http-check
# 使用已安装 cryptography 的维护者 Python 环境
python3 scripts/verify_claude.py --claude "$HOME/.local/bin/claude" --bma ./bma --https --out ./claude-tls-check
```

输出目录必须不存在。HTTP 代理与端点实收均 11,993 字节；HTTPS/CONNECT 三个请求为 TLS 1.2，代理与独立 relay 均 16,668 加密字节，解密 HTTP 11,916 字节。真实文件修改、任务/Read/Edit 日志、行号/调用编号/时间戳、脱敏和报告私有权限全部通过；源 AEA 来自 f3d6453 验收包，SHA-256 为 `620d41c6c3cbd0fbcf8979d9883db152f1db54129fd78b0c9fa4534e62fc7459`。

nettop 对短连接仅取得部分增量（HTTP 841 / HTTPS 5,268 字节），不能当作完整流量；此前合成持久连接的 2 MiB 精确结果不覆盖此场景。首轮无 socket、结束后的缺失样本及未实现 process_io 均保留。一次尝试要求 nettop 出现正增量因短连接未采到而超时，该失败目录也保留，不算通过。

Mac 证据在 `~/aea-validation-6602c4d/claude-http-final-qa` 与 `claude-tls-qa-1`；本机只复制计量摘要到 `dist/mac-claude-evidence/http-verification.json` 和 `tls-verification.json`，原始隔离会话/报告保留在 Mac。Windows 2.1.126 同脚本 HTTP/TLS 回归通过；TLS 连接收尾记录的 connection_reset 未隐藏。这些是受控模型回环验证，不是外部服务、付费模型质量或其他 Agent 验证。

## 通过 SSH 协作

在 Mac「系统设置 → 通用 → 共享 → 远程登录」只允许实际使用的账户。提供页面显示的用户名和地址即可，不发送密码、私钥或凭证文件。先确认双方网络可达，再在 Mac 上为本次操作加入专用公钥；验收结束后可以删除该公钥，并按用户意愿关闭远程登录。无需开放公网路由器端口，也不安装常驻维护程序。

13 个包含测试的包（cmd/aea、9 个 internal 包、3 个维护者工具包）均已在这台 Mac 上执行通过。测试二进制由 Windows Go 1.27.1 交叉编译；规则包需要按源码相对位置提供 rules.yaml，首次缺少该 fixture 的失败已在补齐目录后重跑通过。最终修改影响的 collect 和 cmd/aea 测试重新编译并在 Mac 通过。
