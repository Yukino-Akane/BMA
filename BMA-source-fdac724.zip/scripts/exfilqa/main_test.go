package main

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"behavior-monitoring-audit/internal/report"
	"behavior-monitoring-audit/internal/rules"
)

func TestLoopbackURLRejectsNonLoopbackAndCredentials(t *testing.T) {
	for _, raw := range []string{
		"https://example.invalid:443",
		"http://user:pass@127.0.0.1:8080",
		"http://127.0.0.1",
		"http://localhost:8080",
	} {
		if err := loopbackURL(raw); err == nil {
			t.Errorf("accepted unsafe fixture endpoint %q", raw)
		}
	}
	if err := loopbackURL("http://127.0.0.1:8080"); err != nil {
		t.Fatal(err)
	}
	if err := loopbackURL("http://[::1]:8080"); err != nil {
		t.Fatal(err)
	}
}

func TestEncryptChangesPayloadAndIsRepeatableOnlyByTruthHash(t *testing.T) {
	plain := []byte("synthetic fixture data")
	a, err := encrypt(plain)
	if err != nil {
		t.Fatal(err)
	}
	b, err := encrypt(plain)
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Equal(a, plain) || bytes.Equal(a, b) || len(a) <= len(plain) {
		t.Fatal("encrypted fixture is not opaque and nonce-bearing")
	}
}

func TestPrepareUsesOnlySyntheticFiles(t *testing.T) {
	dir := t.TempDir()
	cfg, err := prepare(scenario{Name: "encrypted_external"}, dir)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Workspace == "" || cfg.Cache == "" {
		t.Fatal("fixture scope missing")
	}
	if _, err := os.Stat(filepath.Join(cfg.Workspace, ".env.synthetic")); err != nil {
		t.Fatal(err)
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		t.Fatal(err)
	}
	for _, entry := range entries {
		if strings.Contains(entry.Name(), "HOME") || strings.Contains(entry.Name(), "credential") {
			t.Fatal("fixture escaped synthetic namespace")
		}
	}
}

func TestAssessmentDoesNotUpgradeEncryptedContentFromReceiverTruth(t *testing.T) {
	workspace := t.TempDir()
	payload := []byte("synthetic opaque fixture")
	if err := os.WriteFile(filepath.Join(workspace, ".env.synthetic"), payload, 0600); err != nil {
		t.Fatal(err)
	}
	row := result{Scenario: scenario{Name: "opaque_tls", TLS: true}, BMAStatus: "stopped", Receiver: []receipt{{Bytes: len(payload), SHA256: digest(payload)}}}
	r := reportForTest()
	got, err := assess(row, r, fixtureConfig{Mode: "opaque_tls", Workspace: workspace})
	if err != nil || !got.MissedOrUncertain || got.LinkedFinding {
		t.Fatalf("opaque content unexpectedly confirmed: %+v err=%v", got, err)
	}
}

func reportForTest() report.Report {
	return report.Report{Status: "stopped", Events: nil, Findings: nil}
}

func TestVerificationSerializationKeepsReceiverSeparate(t *testing.T) {
	value := verification{Scenarios: []result{{Receiver: []receipt{{SHA256: "synthetic-hash"}}, Assessment: "unknown"}}}
	data, err := json.Marshal(value)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Contains(data, []byte("receiver_truth")) || !bytes.Contains(data, []byte("synthetic-hash")) {
		t.Fatal("receiver truth was omitted from verification")
	}
}

func TestExpectedConclusionDistinguishesHTTPAndOpaqueTLS(t *testing.T) {
	attempt := rules.Finding{Rule: "correlation/upload-attempt", AuthorizationState: "unknown"}
	suspected := rules.Finding{Rule: "correlation/suspected-exfiltration", AuthorizationState: "unknown"}
	if !matchesExpectedConclusion("small_file", "unknown", []rules.Finding{attempt}) || matchesExpectedConclusion("small_file", "unknown", []rules.Finding{suspected}) {
		t.Fatal("HTTP upload must have an observed upload attempt")
	}
	if !matchesExpectedConclusion("opaque_tls", "unknown", []rules.Finding{suspected}) || matchesExpectedConclusion("opaque_tls", "unknown", []rules.Finding{attempt}) {
		t.Fatal("opaque TLS should remain suspected, without a content-aware upload attempt")
	}
	if matchesExpectedConclusion("authorized_upload", "authorized", []rules.Finding{attempt}) || !matchesExpectedConclusion("unknown_authorization", "unknown", []rules.Finding{attempt}) {
		t.Fatal("authorization state must come from the finding")
	}
}

func TestSameFilePathResolvesParentOfDeletedFile(t *testing.T) {
	root := t.TempDir()
	realDir := filepath.Join(root, "cache")
	if err := os.Mkdir(realDir, 0700); err != nil {
		t.Fatal(err)
	}
	alias := filepath.Join(root, "cache-link")
	if err := os.Symlink(realDir, alias); err != nil {
		t.Fatal(err)
	}
	if !sameFilePath(filepath.Join(alias, "deleted.blob"), filepath.Join(realDir, "deleted.blob")) {
		t.Fatal("same deleted file through symlinked parent was not recognized")
	}
	if sameFilePath(filepath.Join(alias, "other.blob"), filepath.Join(realDir, "deleted.blob")) {
		t.Fatal("different files were treated as equal")
	}
}
