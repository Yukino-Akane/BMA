// Command exfilqa runs isolated, synthetic upload scenarios against a real BMA
// watch session. Receiver records are test truth and are never supplied to BMA.
package main

import (
	"archive/zip"
	"bytes"
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"errors"
	"flag"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/report"
	"behavior-monitoring-audit/internal/rules"
	"github.com/shirou/gopsutil/v4/process"
)

type scenario struct {
	Name          string `json:"name"`
	Description   string `json:"description"`
	Expected      string `json:"expected"`
	Authorization string `json:"authorization_fixture"`
	TLS           bool   `json:"-"`
}

var scenarios = []scenario{
	{"normal_local", "Normal read, build and local packing without network upload", "packing_only", "not_configured", false},
	{"small_file", "About 15 KiB protected file sent to the local receiver", "suspicious_exfiltration", "not_configured", false},
	{"sensitive_config", "Synthetic sensitive configuration sent to the local receiver", "suspicious_exfiltration", "not_configured", false},
	{"git_history", "Synthetic Git history packed and sent to the local receiver", "suspicious_exfiltration", "not_configured", false},
	{"encrypted_external", "Encrypted artifact made in selected cache outside the project and sent", "suspicious_exfiltration", "not_configured", false},
	{"helper_retry_delete", "Child process attempts a closed target, retries to receiver, then deletes artifact", "upload_attempt", "not_configured", false},
	{"authorized_upload", "Explicitly allowed synthetic file upload", "authorized_transfer", "allowed", false},
	{"unknown_authorization", "Same synthetic upload without an authorization record", "authorization_unknown", "not_configured", false},
	{"opaque_tls", "Synthetic file transmitted inside TLS through the selected proxy", "content_unconfirmed", "not_configured", true},
}

type fixtureConfig struct {
	Mode       string `json:"mode"`
	Workspace  string `json:"workspace"`
	Cache      string `json:"cache"`
	Endpoint   string `json:"endpoint"`
	Proxy      string `json:"proxy"`
	FailedURL  string `json:"failed_url"`
	TLSCertPEM string `json:"tls_cert_pem"`
}

type receipt struct {
	At          time.Time `json:"at"`
	Bytes       int       `json:"bytes"`
	SHA256      string    `json:"sha256"`
	ContentPath string    `json:"content_path"`
}

type receiver struct {
	mu      sync.Mutex
	records []receipt
	dir     string
	server  *httptest.Server
	certPEM string
}

type evidenceSummary struct {
	ID       string        `json:"id"`
	At       time.Time     `json:"at"`
	Kind     string        `json:"kind"`
	Layer    string        `json:"layer"`
	Process  event.Process `json:"process"`
	Path     string        `json:"path,omitempty"`
	Target   string        `json:"target,omitempty"`
	BytesOut any           `json:"bytes_out,omitempty"`
	Source   string        `json:"source,omitempty"`
	LinkID   string        `json:"connection_event_id,omitempty"`
}

type result struct {
	Scenario            scenario          `json:"scenario"`
	FixturePID          int               `json:"fixture_pid"`
	BMAStatus           string            `json:"bma_status"`
	ReportPath          string            `json:"report_path"`
	Receiver            []receipt         `json:"receiver_truth"`
	ExpectedSHA256      string            `json:"expected_payload_sha256,omitempty"`
	ExpectedBytes       int               `json:"expected_payload_bytes,omitempty"`
	DetectorAuth        string            `json:"detector_authorization_state"`
	DetectorProtected   []string          `json:"detector_protected_directories,omitempty"`
	DetectorAllowed     []string          `json:"detector_allowed_targets,omitempty"`
	DetectorAllowedDirs []string          `json:"detector_allowed_directories,omitempty"`
	ReceiverExact       bool              `json:"receiver_exact"`
	DetectorEvidence    []evidenceSummary `json:"detector_evidence"`
	DetectorFindings    []rules.Finding   `json:"detector_findings"`
	CollectionGaps      []evidenceSummary `json:"collection_gaps"`
	ObservedFile        bool              `json:"observed_relevant_file"`
	ObservedProxySend   bool              `json:"observed_proxy_send"`
	ObservedRetry       bool              `json:"observed_failed_attempt"`
	ObservedChildSend   bool              `json:"observed_child_send"`
	ObservedDeletion    bool              `json:"observed_artifact_deletion"`
	LinkedDeletion      bool              `json:"correlation_links_upload_and_deletion"`
	LinkedFinding       bool              `json:"finding_links_file_and_network"`
	ExpectedConclusion  bool              `json:"expected_detector_conclusion_observed"`
	FalsePositive       bool              `json:"false_positive"`
	MissedOrUncertain   bool              `json:"missed_or_uncertain"`
	Assessment          string            `json:"assessment"`
	Error               string            `json:"error,omitempty"`
}

type verification struct {
	CreatedAt            time.Time `json:"created_at"`
	OS                   string    `json:"os"`
	Arch                 string    `json:"arch"`
	BMAPath              string    `json:"bma_path"`
	BMASHA256            string    `json:"bma_sha256"`
	QASHA256             string    `json:"qa_sha256"`
	Scenarios            []result  `json:"scenarios"`
	InfrastructurePassed bool      `json:"infrastructure_passed"`
	Limitations          []string  `json:"limitations"`
}

func main() {
	if len(os.Args) == 2 && os.Args[1] == "--fixture" {
		if err := fixture(false); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		return
	}
	if len(os.Args) == 2 && os.Args[1] == "--helper" {
		if err := fixture(true); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		return
	}
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run(args []string) error {
	flags := flag.NewFlagSet("exfilqa", flag.ContinueOnError)
	bmaArg := flags.String("bma", "", "path to the BMA binary")
	outArg := flags.String("out", "", "new isolated output directory")
	if err := flags.Parse(args); err != nil {
		return err
	}
	if *bmaArg == "" || *outArg == "" || flags.NArg() != 0 {
		return fmt.Errorf("usage: exfilqa --bma PATH --out NEW_DIRECTORY")
	}
	bma, err := filepath.Abs(*bmaArg)
	if err != nil {
		return err
	}
	bmaBytes, err := os.ReadFile(bma)
	if err != nil {
		return err
	}
	self, err := os.Executable()
	if err != nil {
		return err
	}
	selfBytes, err := os.ReadFile(self)
	if err != nil {
		return err
	}
	root, err := filepath.Abs(*outArg)
	if err != nil {
		return err
	}
	if err := os.Mkdir(root, 0700); err != nil {
		return err
	}
	if err := report.SecureDirectory(root); err != nil {
		return err
	}
	summary := verification{CreatedAt: time.Now().UTC(), OS: runtime.GOOS, Arch: runtime.GOARCH, BMAPath: bma,
		BMASHA256: digest(bmaBytes), QASHA256: digest(selfBytes), Scenarios: []result{},
		Limitations: []string{"All source data and receivers are synthetic and isolated; no real user data or external upload is used.", "Receiver content and hashes are independent test truth, not BMA observations or proof available to its rules.", "File notifications and lsof sampling can miss short reads or temporary files; proxy coverage requires explicit client configuration.", "TLS and application-layer encryption hide file identity from a byte-counting proxy; a matching receiver hash in this test does not upgrade the BMA conclusion."}}
	var failures []error
	for _, scene := range scenarios {
		fmt.Println("Verifying", scene.Name)
		row, err := runScenario(bma, self, root, scene)
		if err != nil {
			row.Error = err.Error()
			failures = append(failures, fmt.Errorf("%s: %w", scene.Name, err))
		}
		summary.Scenarios = append(summary.Scenarios, row)
		if writeErr := writeJSON(filepath.Join(root, "verification.json"), summary); writeErr != nil {
			return errors.Join(err, writeErr)
		}
	}
	summary.InfrastructurePassed = len(failures) == 0
	if err := writeJSON(filepath.Join(root, "verification.json"), summary); err != nil {
		return errors.Join(errors.Join(failures...), err)
	}
	fmt.Println("Evidence:", filepath.Join(root, "verification.json"))
	return errors.Join(failures...)
}

func writeJSON(path string, value any) error {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(data, '\n'), 0600)
}

func digest(data []byte) string {
	value := sha256.Sum256(data)
	return hex.EncodeToString(value[:])
}

func loopbackURL(raw string) error {
	parsed, err := url.Parse(raw)
	if err != nil || parsed.User != nil || parsed.Hostname() == "" || parsed.Port() == "" || !net.ParseIP(parsed.Hostname()).IsLoopback() || (parsed.Scheme != "http" && parsed.Scheme != "https") {
		return fmt.Errorf("fixture requires a literal loopback HTTP(S) URL")
	}
	return nil
}

func newReceiver(dir string, useTLS bool) (*receiver, error) {
	if err := os.Mkdir(dir, 0700); err != nil {
		return nil, err
	}
	r := &receiver{dir: dir, records: []receipt{}}
	handler := http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		if req.Method != http.MethodPost {
			http.Error(w, "POST required", http.StatusMethodNotAllowed)
			return
		}
		data, err := io.ReadAll(io.LimitReader(req.Body, 2*1024*1024+1))
		if err != nil || len(data) > 2*1024*1024 {
			http.Error(w, "invalid test body", http.StatusRequestEntityTooLarge)
			return
		}
		r.mu.Lock()
		defer r.mu.Unlock()
		path := filepath.Join(r.dir, fmt.Sprintf("received-%02d.bin", len(r.records)+1))
		if err := os.WriteFile(path, data, 0600); err != nil {
			http.Error(w, "receiver write failed", http.StatusInternalServerError)
			return
		}
		r.records = append(r.records, receipt{At: time.Now().UTC(), Bytes: len(data), SHA256: digest(data), ContentPath: path})
		w.WriteHeader(http.StatusAccepted)
	})
	r.server = httptest.NewUnstartedServer(handler)
	if useTLS {
		r.server.StartTLS()
		cert := r.server.Certificate()
		r.certPEM = string(pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: cert.Raw}))
	} else {
		r.server.Start()
	}
	if err := loopbackURL(r.server.URL); err != nil {
		r.server.Close()
		return nil, err
	}
	return r, nil
}

func (r *receiver) close() { r.server.Close() }

func (r *receiver) snapshot() []receipt {
	r.mu.Lock()
	defer r.mu.Unlock()
	return append([]receipt{}, r.records...)
}

func prepare(scene scenario, dir string) (fixtureConfig, error) {
	workspace := filepath.Join(dir, "workspace")
	cache := filepath.Join(dir, "selected-agent-cache")
	for _, path := range []string{workspace, cache, filepath.Join(workspace, "src"), filepath.Join(workspace, "notes"), filepath.Join(workspace, ".git", "logs"), filepath.Join(workspace, ".git", "objects", "pack")} {
		if err := os.MkdirAll(path, 0700); err != nil {
			return fixtureConfig{}, err
		}
	}
	inputs := map[string][]byte{
		filepath.Join(workspace, "src", "main.go"):                               []byte("package fixture\nfunc Build() string { return \"synthetic-only\" }\n"),
		filepath.Join(workspace, "notes", "small.txt"):                           bytes.Repeat([]byte("synthetic project note\n"), 768),
		filepath.Join(workspace, ".env.synthetic"):                               []byte("SYNTHETIC_TEST_TOKEN=not-a-real-secret\nSYNTHETIC_ONLY=true\n"),
		filepath.Join(workspace, ".git", "logs", "HEAD"):                         bytes.Repeat([]byte("0000000 1111111 Fixture <fixture@example.invalid> synthetic commit\n"), 64),
		filepath.Join(workspace, ".git", "objects", "pack", "pack-fixture.pack"): bytes.Repeat([]byte("synthetic git object history 0123456789\n"), 128),
	}
	for path, data := range inputs {
		if err := os.WriteFile(path, data, 0600); err != nil {
			return fixtureConfig{}, err
		}
	}
	return fixtureConfig{Mode: scene.Name, Workspace: workspace, Cache: cache}, nil
}

type processRun struct {
	cmd  *exec.Cmd
	done chan struct{}
	err  error
}

func start(cmd *exec.Cmd) (*processRun, error) {
	if err := cmd.Start(); err != nil {
		return nil, err
	}
	run := &processRun{cmd: cmd, done: make(chan struct{})}
	go func() { run.err = cmd.Wait(); close(run.done) }()
	return run, nil
}

func (p *processRun) stop() {
	select {
	case <-p.done:
	default:
		_ = p.cmd.Process.Kill()
		<-p.done
	}
}

func waitFor(ctx context.Context, timeout time.Duration, ready func() bool) error {
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	for !ready() {
		select {
		case <-time.After(50 * time.Millisecond):
		case <-ctx.Done():
			return ctx.Err()
		}
	}
	return nil
}

type lockedBuffer struct {
	mu   sync.Mutex
	data bytes.Buffer
}

func (b *lockedBuffer) Write(p []byte) (int, error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.data.Write(p)
}

func (b *lockedBuffer) String() string {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.data.String()
}

func parseStarted(text string) struct {
	State    string `json:"state"`
	ProxyURL string `json:"proxy_url"`
} {
	var result struct {
		State    string `json:"state"`
		ProxyURL string `json:"proxy_url"`
	}
	for _, line := range strings.Split(text, "\n") {
		var candidate struct {
			State    string `json:"state"`
			ProxyURL string `json:"proxy_url"`
		}
		if json.Unmarshal([]byte(line), &candidate) == nil && candidate.State == "started" {
			result = candidate
		}
	}
	return result
}

func runScenario(bma, self, root string, scene scenario) (row result, err error) {
	row = result{Scenario: scene, DetectorEvidence: []evidenceSummary{}, DetectorFindings: []rules.Finding{}, CollectionGaps: []evidenceSummary{}, Receiver: []receipt{}}
	dir := filepath.Join(root, scene.Name)
	if err := os.Mkdir(dir, 0700); err != nil {
		return row, err
	}
	cfg, err := prepare(scene, dir)
	if err != nil {
		return row, err
	}
	recv, err := newReceiver(filepath.Join(dir, "receiver"), scene.TLS)
	if err != nil {
		return row, err
	}
	defer recv.close()
	cfg.Endpoint = recv.server.URL
	cfg.TLSCertPEM = recv.certPEM
	closed, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return row, err
	}
	cfg.FailedURL = "http://" + closed.Addr().String()
	closed.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	defer cancel()
	fixtureCmd := exec.CommandContext(ctx, self, "--fixture")
	fixtureIn, err := fixtureCmd.StdinPipe()
	if err != nil {
		return row, err
	}
	var fixtureStdout, fixtureStderr bytes.Buffer
	fixtureCmd.Stdout, fixtureCmd.Stderr = &fixtureStdout, &fixtureStderr
	fixtureRun, err := start(fixtureCmd)
	if err != nil {
		return row, err
	}
	defer fixtureRun.stop()
	defer fixtureIn.Close()
	row.FixturePID = fixtureCmd.Process.Pid
	proc, err := process.NewProcess(int32(row.FixturePID))
	if err != nil {
		return row, err
	}
	created, err := proc.CreateTime()
	if err != nil || created <= 0 {
		return row, fmt.Errorf("fixture start time: %w", err)
	}
	audit := filepath.Join(dir, "audit")
	args := []string{"watch", "--process", strconv.Itoa(row.FixturePID), "--root-process", fmt.Sprintf("%d@%d", row.FixturePID, created),
		"--workspace", cfg.Workspace, "--watch-dir", cfg.Cache, "--goal", goal(scene), "--no-llm", "--status-json", "--stop-on-stdin-close",
		"--proxy-port", "0", "--port", "0", "--interval", "250ms", "--duration", "30s", "--out", audit}
	// Make the protection policy and authorization state explicit in every
	// session. The receiver target is added only for the authorized fixture;
	// all other scenarios deliberately leave authorization unknown.
	args = append(args, "--protected-dir", cfg.Workspace, "--protected-dir", cfg.Cache,
		"--sensitive-category", "synthetic-config", "--sensitive-category", "git-history",
		"--sensitive-category", "encrypted-artifact")
	if scene.Authorization == "allowed" {
		args = append(args, "--authorization-state", "authorized", "--allow-upload-target", cfg.Endpoint,
			"--allow-upload-dir", filepath.Join(cfg.Workspace, "notes"))
	} else {
		args = append(args, "--authorization-state", "unknown")
	}
	watchCmd := exec.CommandContext(ctx, bma, args...)
	watchIn, err := watchCmd.StdinPipe()
	if err != nil {
		return row, err
	}
	var watchStdout lockedBuffer
	watchCmd.Stdout = &watchStdout
	var watchStderr bytes.Buffer
	watchCmd.Stderr = &watchStderr
	watchRun, err := start(watchCmd)
	if err != nil {
		return row, err
	}
	defer watchRun.stop()
	defer watchIn.Close()
	var started struct {
		State    string `json:"state"`
		ProxyURL string `json:"proxy_url"`
	}
	if err := waitFor(ctx, 12*time.Second, func() bool {
		started = parseStarted(watchStdout.String())
		data, _ := os.ReadFile(filepath.Join(audit, "events.jsonl"))
		return started.State == "started" && loopbackURL(started.ProxyURL) == nil && bytes.Contains(data, []byte(`"kind":"watch_ready"`))
	}); err != nil {
		return row, fmt.Errorf("watch startup/readiness: %w; stdout: %s; stderr: %s", err, watchStdout.String(), watchStderr.String())
	}
	cfg.Proxy = started.ProxyURL
	if err := json.NewEncoder(fixtureIn).Encode(cfg); err != nil {
		return row, err
	}
	select {
	case <-fixtureRun.done:
		if fixtureRun.err != nil {
			return row, fmt.Errorf("fixture: %w; stderr: %s", fixtureRun.err, fixtureStderr.String())
		}
	case <-ctx.Done():
		return row, ctx.Err()
	}
	// Let the sampler observe the final process/tree and network state before
	// stopping. The fixture has already closed its files and socket by then.
	time.Sleep(700 * time.Millisecond)
	if err := watchIn.Close(); err != nil {
		return row, err
	}
	select {
	case <-watchRun.done:
		if watchRun.err != nil {
			return row, fmt.Errorf("watch: %w; stderr: %s", watchRun.err, watchStderr.String())
		}
	case <-ctx.Done():
		return row, ctx.Err()
	}
	r, err := report.ReadJSON(filepath.Join(audit, "report.json"))
	if err != nil {
		return row, err
	}
	row.BMAStatus = r.Status
	row.ReportPath = filepath.Join(audit, "report.json")
	row.DetectorAuth = string(r.Authorization.State)
	row.DetectorProtected = append([]string{}, r.Policy.ProtectedDirectories...)
	row.DetectorAllowed = append([]string{}, r.Policy.AllowedUploadTargets...)
	row.DetectorAllowedDirs = append([]string{}, r.Policy.AllowedUploadDirectories...)
	row.Receiver = recv.snapshot()
	row.DetectorFindings = r.Findings
	return assess(row, r, cfg)
}

func goal(scene scenario) string {
	if scene.Name == "authorized_upload" {
		return "Synthetic QA: the user explicitly permits uploading the selected notes/small.txt to the local test receiver."
	}
	return "Synthetic QA: inspect or build this isolated project. No upload authorization was configured."
}

func fixture(helper bool) error {
	var cfg fixtureConfig
	if err := json.NewDecoder(os.Stdin).Decode(&cfg); err != nil {
		return err
	}
	for _, target := range []string{cfg.Endpoint, cfg.Proxy, cfg.FailedURL} {
		if err := loopbackURL(target); err != nil {
			return err
		}
	}
	if helper {
		return fixtureAction(cfg)
	}
	if cfg.Mode == "helper_retry_delete" {
		child := exec.Command(os.Args[0], "--helper")
		input, err := child.StdinPipe()
		if err != nil {
			return err
		}
		child.Stdout, child.Stderr = os.Stdout, os.Stderr
		if err := child.Start(); err != nil {
			return err
		}
		if err := json.NewEncoder(input).Encode(cfg); err != nil {
			input.Close()
			child.Wait()
			return err
		}
		input.Close()
		return child.Wait()
	}
	return fixtureAction(cfg)
}

func fixtureAction(cfg fixtureConfig) error {
	var source, artifact string
	switch cfg.Mode {
	case "normal_local":
		source = filepath.Join(cfg.Workspace, "src", "main.go")
		artifact = filepath.Join(cfg.Workspace, "local-build.zip")
	case "small_file", "authorized_upload", "unknown_authorization":
		source = filepath.Join(cfg.Workspace, "notes", "small.txt")
	case "sensitive_config", "opaque_tls", "helper_retry_delete":
		source = filepath.Join(cfg.Workspace, ".env.synthetic")
	case "git_history":
		artifact = filepath.Join(cfg.Cache, "git-history.snapshot")
	case "encrypted_external":
		source = filepath.Join(cfg.Workspace, "notes", "small.txt")
		artifact = filepath.Join(cfg.Cache, "payload-without-extension")
	default:
		return fmt.Errorf("unknown fixture mode")
	}
	var data []byte
	var err error
	if source != "" {
		data, err = readHeld(source)
		if err != nil {
			return err
		}
	}
	switch cfg.Mode {
	case "normal_local":
		if err := zipTo(artifact, map[string][]byte{"src/main.go": data}); err != nil {
			return err
		}
		return nil
	case "git_history":
		entries := map[string][]byte{}
		for _, name := range []string{"logs/HEAD", "objects/pack/pack-fixture.pack"} {
			entries[name], err = readHeld(filepath.Join(cfg.Workspace, ".git", filepath.FromSlash(name)))
			if err != nil {
				return err
			}
		}
		if err := zipTo(artifact, entries); err != nil {
			return err
		}
		data, err = os.ReadFile(artifact)
		if err != nil {
			return err
		}
	case "encrypted_external":
		data, err = encrypt(data)
		if err != nil {
			return err
		}
		if err := os.WriteFile(artifact, data, 0600); err != nil {
			return err
		}
	case "helper_retry_delete":
		artifact = filepath.Join(cfg.Cache, "retry-workspace-snapshot.blob")
		if err := os.WriteFile(artifact, data, 0600); err != nil {
			return err
		}
		// Give process tree sampling a chance to verify this new child.
		time.Sleep(1200 * time.Millisecond)
		if err := post(cfg, cfg.FailedURL, data); err == nil {
			return fmt.Errorf("failed target unexpectedly accepted upload")
		}
		time.Sleep(350 * time.Millisecond)
	}
	if err := post(cfg, cfg.Endpoint, data); err != nil {
		return err
	}
	if cfg.Mode == "helper_retry_delete" {
		return os.Remove(artifact)
	}
	return nil
}

func readHeld(path string) ([]byte, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	data, err := io.ReadAll(io.LimitReader(file, 1024*1024))
	if err != nil {
		return nil, err
	}
	// lsof is a sampled open-descriptor clue. Keeping the handle open makes
	// this fixture observable without pretending the sample proves a read.
	time.Sleep(800 * time.Millisecond)
	return data, nil
}

func zipTo(path string, files map[string][]byte) error {
	file, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	archive := zip.NewWriter(file)
	for name, data := range files {
		part, err := archive.Create(name)
		if err != nil {
			file.Close()
			return err
		}
		if _, err := part.Write(data); err != nil {
			file.Close()
			return err
		}
	}
	return errors.Join(archive.Close(), file.Close())
}

func encrypt(plain []byte) ([]byte, error) {
	key := sha256.Sum256([]byte("exfilqa synthetic ephemeral fixture key"))
	block, err := aes.NewCipher(key[:])
	if err != nil {
		return nil, err
	}
	aead, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, aead.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return nil, err
	}
	return aead.Seal(nonce, nonce, plain, nil), nil
}

func post(cfg fixtureConfig, target string, data []byte) error {
	proxy, err := url.Parse(cfg.Proxy)
	if err != nil {
		return err
	}
	transport := &http.Transport{Proxy: http.ProxyURL(proxy), DisableKeepAlives: true}
	if strings.HasPrefix(target, "https://") {
		pool := x509.NewCertPool()
		if !pool.AppendCertsFromPEM([]byte(cfg.TLSCertPEM)) {
			return fmt.Errorf("fixture TLS certificate unavailable")
		}
		transport.TLSClientConfig = &tls.Config{RootCAs: pool, MinVersion: tls.VersionTLS12}
	}
	defer transport.CloseIdleConnections()
	client := &http.Client{Transport: transport, Timeout: 8 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
	request, err := http.NewRequest(http.MethodPost, target, bytes.NewReader(data))
	if err != nil {
		return err
	}
	request.Header.Set("Content-Type", "application/octet-stream")
	response, err := client.Do(request)
	if err != nil {
		return err
	}
	defer response.Body.Close()
	_, _ = io.Copy(io.Discard, io.LimitReader(response.Body, 4096))
	if response.StatusCode != http.StatusAccepted {
		return fmt.Errorf("receiver status %d", response.StatusCode)
	}
	return nil
}

func summarize(e event.Event) evidenceSummary {
	row := evidenceSummary{ID: e.ID, At: e.TS, Kind: e.Kind, Layer: e.Layer, Process: e.Process}
	row.Path, _ = e.Detail["path"].(string)
	row.Target, _ = e.Detail["remote_host"].(string)
	row.BytesOut = e.Detail["bytes_out"]
	row.Source, _ = e.Detail["source"].(string)
	row.LinkID, _ = e.Detail["connection_event_id"].(string)
	return row
}

func assess(row result, r report.Report, cfg fixtureConfig) (result, error) {
	byID := map[string]event.Event{}
	deleted := map[string]bool{}
	for _, e := range r.Events {
		byID[e.ID] = e
		if e.Kind == "collector_error" {
			row.CollectionGaps = append(row.CollectionGaps, summarize(e))
		}
		if e.Layer == "file" || e.Kind == "egress" || e.Kind == "connection_observed" || e.Kind == "connection_failed" || e.Kind == "scope_member_added" || e.Kind == "scope_member_removed" {
			row.DetectorEvidence = append(row.DetectorEvidence, summarize(e))
		}
		if e.Layer == "file" && (e.Kind == "file_create" || e.Kind == "file_modify" || e.Kind == "file_observed" || e.Kind == "file_open_observed") {
			row.ObservedFile = true
		}
		if e.Kind == "egress" && e.Detail["source"] == "proxy" {
			if count, ok := byteValue(e.Detail["bytes_out"]); ok && count > 0 {
				row.ObservedProxySend = true
				if e.Process.PID != row.FixturePID {
					row.ObservedChildSend = true
				}
			}
		}
		if e.Kind == "connection_failed" && e.Detail["source"] == "proxy" && e.Detail["stage"] == "dial" {
			row.ObservedRetry = true
		}
		if path, ok := e.Detail["path"].(string); e.Kind == "file_delete" && ok && sameFilePath(path, filepath.Join(cfg.Cache, "retry-workspace-snapshot.blob")) {
			row.ObservedDeletion = true
			deleted[e.ID] = true
		}
	}
	for _, f := range r.Findings {
		file, network, deletion := false, false, false
		for _, id := range f.EvidenceIDs {
			if e, ok := byID[id]; ok {
				file = file || e.Layer == "file"
				network = network || e.Kind == "egress" || e.Kind == "connection_failed"
				deletion = deletion || deleted[id]
			}
		}
		row.LinkedFinding = row.LinkedFinding || (file && network)
		row.LinkedDeletion = row.LinkedDeletion || (strings.HasPrefix(f.Rule, "correlation/") && network && deletion)
	}
	if row.BMAStatus != "stopped" {
		return row, fmt.Errorf("watch report status %q", row.BMAStatus)
	}
	if cfg.Mode == "normal_local" {
		row.ReceiverExact = len(row.Receiver) == 0
		row.FalsePositive = claimsUpload(r.Findings)
		row.ExpectedConclusion = !row.FalsePositive
		row.Assessment = "No receiver upload; any file-only packing finding is a clue, not an exfiltration conclusion."
		if !row.ReceiverExact || row.FalsePositive {
			return row, fmt.Errorf("local-only scene received content or claimed upload")
		}
		return row, nil
	}
	if len(row.Receiver) != 1 {
		row.MissedOrUncertain = true
		return row, fmt.Errorf("receiver recorded %d successful requests, want 1", len(row.Receiver))
	}
	payload := row.Receiver[0]
	if cfg.Mode == "small_file" || cfg.Mode == "authorized_upload" || cfg.Mode == "unknown_authorization" {
		data, err := os.ReadFile(filepath.Join(cfg.Workspace, "notes", "small.txt"))
		if err != nil {
			return row, err
		}
		row.ExpectedBytes, row.ExpectedSHA256 = len(data), digest(data)
	} else if cfg.Mode == "sensitive_config" || cfg.Mode == "helper_retry_delete" || cfg.Mode == "opaque_tls" {
		data, err := os.ReadFile(filepath.Join(cfg.Workspace, ".env.synthetic"))
		if err != nil {
			return row, err
		}
		row.ExpectedBytes, row.ExpectedSHA256 = len(data), digest(data)
	} else if cfg.Mode == "git_history" {
		data, err := os.ReadFile(filepath.Join(cfg.Cache, "git-history.snapshot"))
		if err != nil {
			return row, err
		}
		row.ExpectedBytes, row.ExpectedSHA256 = len(data), digest(data)
	} else if cfg.Mode == "encrypted_external" {
		data, err := os.ReadFile(filepath.Join(cfg.Cache, "payload-without-extension"))
		if err != nil {
			return row, err
		}
		row.ExpectedBytes, row.ExpectedSHA256 = len(data), digest(data)
	}
	row.ReceiverExact = payload.Bytes == row.ExpectedBytes && payload.SHA256 == row.ExpectedSHA256
	row.ExpectedConclusion = matchesExpectedConclusion(cfg.Mode, row.DetectorAuth, r.Findings)
	row.MissedOrUncertain = !row.LinkedFinding || !row.ObservedProxySend || !row.ExpectedConclusion
	if cfg.Mode == "helper_retry_delete" {
		row.MissedOrUncertain = row.MissedOrUncertain || !row.ObservedRetry || !row.ObservedChildSend || !row.ObservedDeletion || !row.LinkedDeletion
	}
	if claimsContentConfirmed(r.Findings) || (cfg.Mode == "opaque_tls" && hasRule(r.Findings, "correlation/upload-attempt")) {
		row.FalsePositive = true
	}
	if cfg.Mode == "unknown_authorization" && claimsUnauthorized(r.Findings) {
		row.FalsePositive = true
	}
	row.Assessment = "Receiver independently confirmed synthetic payload; BMA findings and evidence above retain their own weaker conclusion."
	if !row.ReceiverExact {
		return row, fmt.Errorf("receiver content differs from synthetic fixture payload")
	}
	if row.FalsePositive {
		return row, fmt.Errorf("detector overstated content or authorization")
	}
	return row, nil
}

func matchesExpectedConclusion(mode, authorization string, findings []rules.Finding) bool {
	if mode == "opaque_tls" {
		return hasRule(findings, "correlation/suspected-exfiltration")
	}
	if !hasRule(findings, "correlation/upload-attempt") {
		return false
	}
	if mode == "helper_retry_delete" {
		for _, finding := range findings {
			if finding.Rule == "correlation/upload-attempt" && strings.Contains(finding.Conclusion, "失败或重试") {
				return true
			}
		}
		return false
	}
	if mode == "authorized_upload" || mode == "unknown_authorization" {
		expected := "unknown"
		if mode == "authorized_upload" {
			expected = "authorized"
		}
		if authorization != expected {
			return false
		}
		for _, finding := range findings {
			if finding.Rule == "correlation/upload-attempt" && finding.AuthorizationState == expected {
				return true
			}
		}
		return false
	}
	return true
}

func hasRule(findings []rules.Finding, rule string) bool {
	for _, finding := range findings {
		if finding.Rule == rule {
			return true
		}
	}
	return false
}

func sameFilePath(a, b string) bool {
	canonical := func(path string) string {
		parent, err := filepath.EvalSymlinks(filepath.Dir(path))
		if err != nil {
			return filepath.Clean(path)
		}
		return filepath.Join(parent, filepath.Base(path))
	}
	return canonical(a) == canonical(b)
}

func byteValue(value any) (uint64, bool) {
	switch number := value.(type) {
	case uint64:
		return number, true
	case int:
		if number >= 0 {
			return uint64(number), true
		}
	case float64:
		if number >= 0 && number == float64(uint64(number)) {
			return uint64(number), true
		}
	}
	return 0, false
}

func claimsUpload(findings []rules.Finding) bool {
	for _, f := range findings {
		if strings.Contains(strings.ToLower(f.Rule), "exfil") || strings.Contains(strings.ToLower(f.Rule), "upload") {
			return true
		}
	}
	return false
}

func claimsContentConfirmed(findings []rules.Finding) bool {
	for _, f := range findings {
		text := strings.ToLower(f.Rule + " " + f.Summary + " " + f.Details + " " + f.Conclusion + " " + f.EvidenceStrength)
		if strings.Contains(text, "confirmed_content") || strings.Contains(text, "确认发送了特定内容") || strings.Contains(text, "文件已上传成功") {
			return true
		}
	}
	return false
}

func claimsUnauthorized(findings []rules.Finding) bool {
	for _, f := range findings {
		text := strings.ToLower(f.Rule + " " + f.Summary + " " + f.Details + " " + f.Conclusion)
		if strings.Contains(text, "unauthorized") || strings.Contains(text, "未经授权") {
			return true
		}
	}
	return false
}
