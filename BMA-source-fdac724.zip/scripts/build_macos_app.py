"""Package the native launcher with a verified darwin-arm64 CLI release on macOS.

Uses Apple's bundle, nested-code signing, ditto and disk-image tools. No install,
system setting, credential discovery, notarization submission or upload occurs.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import plistlib
import re
import shutil
import subprocess
import tarfile
import tempfile


def digest(path):
    with path.open('rb') as source:
        value = hashlib.sha256()
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def run(*args):
    return subprocess.check_output([str(arg) for arg in args], stderr=subprocess.STDOUT).decode('utf-8').strip()


def unpack_cli(archive, destination):
    # Never extract links, special files, duplicate entries, or traversal paths.
    with tarfile.open(archive, 'r:gz') as source:
        seen, total = set(), 0
        for member in source:
            path = PurePosixPath(member.name)
            if (not member.isfile() or path.is_absolute() or '..' in path.parts
                    or not path.parts or '\\' in member.name or str(path) in seen):
                raise ValueError('invalid CLI archive member')
            seen.add(str(path))
            total += member.size
            if total > 256 * 1024 * 1024 or len(seen) > 256:
                raise ValueError('CLI archive exceeds package limits')
            target = destination.joinpath(*path.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with source.extractfile(member) as data, target.open('xb') as output:
                shutil.copyfileobj(data, output)
            target.chmod(0o755 if str(path) == 'bma' else 0o644)
    manifest = json.loads((destination / 'BUILD.json').read_text(encoding='utf-8'))
    if (manifest.get('os') != 'darwin' or manifest.get('arch') != 'arm64'
            or manifest.get('binary') != 'bma'
            or manifest.get('binary_sha256') != digest(destination / 'bma')
            or not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+(?:-[A-Za-z0-9.-]+)?', manifest.get('version', ''))):
        raise ValueError('CLI manifest, platform or binary checksum mismatch')
    return manifest


def build(archive, out, identity, keychain):
    if platform.system() != 'Darwin' or platform.machine() != 'arm64':
        raise ValueError('build on an Apple Silicon Mac with Xcode command line tools')
    if out.exists() or out.is_symlink():
        raise ValueError('output already exists; choose a new directory')
    if identity and not identity.startswith('Developer ID Application: '):
        raise ValueError('supply an installed Developer ID Application identity')
    if keychain and (not identity or not keychain.is_file()):
        raise ValueError('an explicit signing keychain requires a Developer ID identity and an existing file')
    src = Path(__file__).resolve().parents[1] / 'desktop' / 'macos'
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.bma-app-', dir=out.parent) as temporary:
        stage = Path(temporary)
        cli = stage / 'cli'
        cli.mkdir()
        manifest = unpack_cli(archive, cli)
        version = manifest['version']
        result = stage / 'result'
        result.mkdir()
        volume = stage / 'volume'
        app = volume / 'BMA.app'
        contents = app / 'Contents'
        resources = contents / 'Resources'
        helpers = contents / 'Helpers'
        binaries = contents / 'MacOS'
        for directory in (resources, helpers, binaries):
            directory.mkdir(parents=True, exist_ok=True)
        backend = helpers / 'bma'
        shutil.move(str(cli / 'bma'), backend)
        shutil.copytree(cli, resources / 'CLI')
        shutil.copyfile(src / 'START_HERE.txt', resources / 'START_HERE.txt')
        launcher = binaries / 'BMA'
        sources = [src / name for name in ('AppController.swift', 'Backend.swift', 'Processes.swift', 'Dashboard.swift', 'main.swift')]
        run('xcrun', 'swiftc', '-swift-version', '5', '-O', '-target', 'arm64-apple-macosx14.0',
            '-framework', 'AppKit', '-framework', 'Security', *sources, '-o', launcher)
        iconset = stage / 'BMA.iconset'
        iconset.mkdir()
        icon_tool = stage / 'make-icon'
        run('xcrun', 'swiftc', src / 'Icon.swift', '-framework', 'AppKit', '-o', icon_tool)
        run(icon_tool, iconset)
        run('iconutil', '-c', 'icns', iconset, '-o', resources / 'BMA.icns')
        # Bundle identity is stable; no legacy application or command alias.
        info = dict(CFBundleIdentifier='app.bma.audit', CFBundleName='BMA',
                    BMABuildVersion=version, LSUIElement=False,
                    CFBundleDisplayName='BMA', CFBundleExecutable='BMA', CFBundlePackageType='APPL',
                    CFBundleShortVersionString=version.split('-')[0], CFBundleVersion=version.split('-')[0],
                    CFBundleIconFile='BMA', LSMinimumSystemVersion='14.0',
                    NSHighResolutionCapable=True, NSPrincipalClass='NSApplication',
                    NSHumanReadableCopyright='BMA contributors. MIT license.')
        with (contents / 'Info.plist').open('wb') as output:
            plistlib.dump(info, output)
        sign_args = ['--force', '--sign', identity or '-', '--options', 'runtime']
        if identity:
            sign_args.append('--timestamp')
        keychain_args = ['--keychain', str(keychain)] if keychain else []
        sign_args += keychain_args
        for code in (backend, launcher):
            run('codesign', *sign_args, code)
        build_info = dict(version=version, platform='darwin-arm64', minimum_macos='14.0',
                          signing='developer-id' if identity else 'ad-hoc-local-only', notarized=False,
                          cli_archive_sha256=digest(archive), cli_original_binary_sha256=manifest['binary_sha256'],
                          packaged_backend_sha256=digest(backend), launcher_pre_bundle_signing_sha256=digest(launcher),
                          swift_sources_sha256={path.name: digest(path) for path in sources + [src / 'Icon.swift']},
                          compiler=run('xcrun', 'swiftc', '--version'))
        metadata = json.dumps(build_info, ensure_ascii=False, indent=2) + '\n'
        (resources / 'DESKTOP-BUILD.json').write_text(metadata, encoding='utf-8')
        run('codesign', *sign_args, app)
        run('codesign', '--verify', '--deep', '--strict', '--verbose=2', app)
        # Signing the bundle rewrites its main executable. Record the final
        # hash only in the external manifest: embedding it inside the signed
        # resource envelope would make the executable hash self-referential.
        build_info['launcher_sha256'] = digest(launcher)
        run('plutil', '-lint', contents / 'Info.plist')
        build_info['backend_version_output'] = run(backend, 'version')
        # Demo runs in a fresh staging directory and never calls a model.
        run(backend, 'demo', '--output-dir', stage / 'demo')
        build_info['packaged_backend_demo_verified'] = (stage / 'demo' / 'demo-report.html').is_file()
        (result / 'BUILD.json').write_text(json.dumps(build_info, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        shutil.copyfile(src / 'START_HERE.txt', volume / '开始使用.txt')
        (volume / 'Applications').symlink_to('/Applications')
        zip_file = result / f'BMA-{version}-macos-arm64.zip'
        dmg_file = result / f'BMA-{version}-macos-arm64.dmg'
        run('ditto', '-c', '-k', '--sequesterRsrc', '--keepParent', app, zip_file)
        run('hdiutil', 'create', '-quiet', '-volname', 'BMA', '-srcfolder', volume,
            '-format', 'UDZO', dmg_file)
        if identity:
            run('codesign', '--sign', identity, '--timestamp', *keychain_args, dmg_file)
        run('hdiutil', 'verify', dmg_file)
        shutil.copyfile(src / 'START_HERE.txt', result / '开始使用.txt')
        (result / 'SHA256SUMS').write_text(''.join(f'{digest(path)}  {path.name}\n' for path in (zip_file, dmg_file)), encoding='utf-8')
        if out.exists():
            raise ValueError('output appeared during build; refusing to overwrite')
        result.rename(out)
    return build_info


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cli-archive', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--sign-identity', help='installed Developer ID Application name; omission creates local ad-hoc preview')
    parser.add_argument('--sign-keychain', type=Path, help='explicit existing signing keychain; unlock it in the invoking session before building')
    args = parser.parse_args()
    try:
        result = build(args.cli_archive.resolve(), args.out.absolute(), args.sign_identity,
                       args.sign_keychain.expanduser().resolve() if args.sign_keychain else None)
    except (ValueError, OSError, subprocess.CalledProcessError) as error:
        if isinstance(error, subprocess.CalledProcessError):
            print(error.output.decode('utf-8', errors='replace'))
        parser.exit(1, f'Build failed: {error}\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
