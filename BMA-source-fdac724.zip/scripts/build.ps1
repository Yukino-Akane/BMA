param(
    [ValidatePattern('^[0-9]+\.[0-9]+\.[0-9]+(-[A-Za-z0-9.-]+)?$')]
    [string]$Version = "0.4.0-dev",
    [string]$Output = "dist\release",
    [string]$Go = "go"
)

$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot ".." )).Path
$goCommand = (Get-Command $Go -ErrorAction Stop).Source
$savedGOOS = $env:GOOS
$savedGOARCH = $env:GOARCH
$savedCGO = $env:CGO_ENABLED
$savedFlags = $env:GOFLAGS
$savedExperiment = $env:GOEXPERIMENT
Push-Location $root
try {
  # Run the helper on the host; it sets each target for child builds.
  $env:GOOS = $null
  $env:GOARCH = $null
  $env:CGO_ENABLED = '0'
  $env:GOFLAGS = $null
  $env:GOEXPERIMENT = $null
  & $goCommand run -mod=readonly ./scripts/release --version $Version --out $Output --go $goCommand
  if ($LASTEXITCODE -ne 0) { throw "release build failed" }
} finally {
  $env:GOOS = $savedGOOS
  $env:GOARCH = $savedGOARCH
  $env:CGO_ENABLED = $savedCGO
  $env:GOFLAGS = $savedFlags
  $env:GOEXPERIMENT = $savedExperiment
  Pop-Location
}
