"""Ephemeral TLS endpoint and independent wire counter for verify_claude.py."""

from datetime import datetime, timedelta, timezone
import ipaddress
import socket
from socketserver import BaseRequestHandler, ThreadingTCPServer
import ssl
import threading


def server_certificate(directory):
    # cryptography is a maintainer dependency, never part of the BMA binary.
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

    now = datetime.now(timezone.utc)
    issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'BMA local fixture CA')])
    ca_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    ca = (x509.CertificateBuilder().subject_name(issuer).issuer_name(issuer)
          .public_key(ca_key.public_key()).serial_number(x509.random_serial_number())
          .not_valid_before(now - timedelta(minutes=1)).not_valid_after(now + timedelta(days=1))
          .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
          .sign(ca_key, hashes.SHA256()))
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, '127.0.0.1')])
    cert = (x509.CertificateBuilder().subject_name(subject).issuer_name(issuer)
            .public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(now - timedelta(minutes=1)).not_valid_after(now + timedelta(days=1))
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(x509.SubjectAlternativeName([
                x509.IPAddress(ipaddress.ip_address('127.0.0.1')),
                x509.DNSName('localhost'),
            ]), critical=False)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
            .sign(ca_key, hashes.SHA256()))
    ca_path, cert_path, key_path = (directory / name for name in ('ca.pem', 'server.pem', 'server-key.pem'))
    ca_path.write_bytes(ca.public_bytes(serialization.Encoding.PEM))
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    key_path.write_bytes(key.private_bytes(serialization.Encoding.PEM,
                         serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(cert_path, key_path)
    return context, ca_path


class CountingRelay(ThreadingTCPServer):
    """Forward encrypted bytes unchanged; retain counts, never TLS contents."""

    daemon_threads = True

    def __init__(self, target, phase):
        self.target = target
        self.phase = phase
        self.lock = threading.Lock()
        self.connections = []
        self.sockets = set()
        self.errors = []
        super().__init__(('127.0.0.1', 0), RelayConnection)

    def close_connections(self):
        with self.lock:
            for connection in self.sockets:
                try:
                    connection.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass


class RelayConnection(BaseRequestHandler):
    def handle(self):
        relay = self.server
        record = {'phase': relay.phase(), 'bytes_received': 0, 'bytes_returned': 0, 'closed': False}
        with relay.lock:
            relay.connections.append(record)
            relay.sockets.add(self.request)
        upstream = None
        forward = None
        try:
            upstream = socket.create_connection(relay.target, timeout=5)
            upstream.settimeout(25)
            self.request.settimeout(25)
            with relay.lock:
                relay.sockets.add(upstream)

            def copy(source, destination, count):
                stage = 'receive'
                try:
                    while True:
                        stage = 'receive'
                        data = source.recv(64 * 1024)
                        if not data:
                            break
                        with relay.lock:
                            record[count] += len(data)
                        stage = 'forward'
                        destination.sendall(data)
                except OSError as exc:
                    with relay.lock:
                        relay.errors.append({'phase': record['phase'], 'direction': count,
                                             'stage': stage, 'error': type(exc).__name__})
                finally:
                    try:
                        destination.shutdown(socket.SHUT_WR)
                    except OSError:
                        pass

            forward = threading.Thread(target=copy, args=(self.request, upstream, 'bytes_received'), daemon=True)
            forward.start()
            copy(upstream, self.request, 'bytes_returned')
            forward.join(timeout=26)
            if forward.is_alive():
                with relay.lock:
                    relay.errors.append({'phase': record['phase'], 'error': 'relay thread did not stop'})
        except OSError as exc:
            with relay.lock:
                relay.errors.append({'phase': record['phase'], 'error': type(exc).__name__})
        finally:
            if upstream is not None:
                upstream.close()
            with relay.lock:
                relay.sockets.discard(upstream)
                relay.sockets.discard(self.request)
                record['closed'] = forward is None or not forward.is_alive()
