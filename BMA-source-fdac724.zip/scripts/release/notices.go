package main

import (
	"bytes"
	"fmt"
	"os"
	"path/filepath"
	"runtime/debug"
	"sort"
	"strings"
)

type dependency struct {
	Path        string   `json:"path"`
	Version     string   `json:"version"`
	Sum         string   `json:"sum"`
	NoticeFiles []string `json:"notice_files"`
}

type moduleSource struct {
	version string
	root    string
	dirs    []string
}

func dependencyNotices(goTool string, t target, linked []*debug.Module) ([]byte, []dependency, error) {
	rootData, err := command(goTool, t, "env", "GOROOT")
	if err != nil {
		return nil, nil, err
	}
	standard := moduleSource{root: strings.TrimSpace(string(rootData))}
	// Query package directories, not `go list -m all`: test-only and unlinked
	// platform modules do not belong to this binary's dependency inventory.
	format := `{{.Dir}}{{"\t"}}{{with .Module}}{{.Path}}{{"\t"}}{{.Version}}{{"\t"}}{{.Dir}}{{else}}{{"\t\t"}}{{end}}`
	data, err := command(goTool, t, "list", "-mod=readonly", "-deps", "-f", format, "./cmd/bma")
	if err != nil {
		return nil, nil, err
	}
	sources := map[string]*moduleSource{}
	for _, line := range strings.Split(strings.TrimSuffix(strings.TrimSuffix(string(data), "\n"), "\r"), "\n") {
		fields := strings.Split(strings.TrimSuffix(line, "\r"), "\t")
		if len(fields) != 4 {
			return nil, nil, fmt.Errorf("unexpected package inventory format")
		}
		if fields[0] == "" {
			continue
		}
		if fields[1] == "" {
			standard.dirs = append(standard.dirs, fields[0])
			continue
		}
		if fields[1] == "behavior-monitoring-audit" {
			continue
		}
		m := sources[fields[1]]
		if m == nil {
			m = &moduleSource{version: fields[2], root: fields[3]}
			sources[fields[1]] = m
		}
		if m.version != fields[2] || m.root != fields[3] {
			return nil, nil, fmt.Errorf("inconsistent module source: %s", fields[1])
		}
		m.dirs = append(m.dirs, fields[0])
	}
	var output bytes.Buffer
	fmt.Fprintln(&output, "BMA third-party notices\n\nThe inventory below is derived from this binary's linked modules. Original\nlicense, notice and patent texts are reproduced from their source packages.\nApache License 2.0 full text is included at docs/licenses/Apache-2.0.txt.\nGo standard library and bundled package notices follow the module notices.")
	sort.Slice(linked, func(i, j int) bool { return linked[i].Path < linked[j].Path })
	modules := make([]dependency, 0, len(linked))
	for _, m := range linked {
		if m.Replace != nil {
			return nil, nil, fmt.Errorf("release does not accept replaced module %s", m.Path)
		}
		source := sources[m.Path]
		if source == nil || source.version != m.Version || source.root == "" || m.Sum == "" {
			return nil, nil, fmt.Errorf("missing exact source/checksum for linked module %s@%s", m.Path, m.Version)
		}
		files, text, err := legalTexts(*source)
		if err != nil {
			return nil, nil, fmt.Errorf("%s@%s: %w", m.Path, m.Version, err)
		}
		fmt.Fprintf(&output, "\n============================================================\n%s@%s\n%s\n%s", m.Path, m.Version, m.Sum, text)
		modules = append(modules, dependency{Path: m.Path, Version: m.Version, Sum: m.Sum, NoticeFiles: files})
	}
	_, text, err := legalTexts(standard)
	if err != nil {
		return nil, nil, fmt.Errorf("Go notices: %w", err)
	}
	fmt.Fprintf(&output, "\n============================================================\nGo standard library and bundled packages\n%s", text)
	return output.Bytes(), modules, nil
}

func isLegalFile(name string) bool {
	upper := strings.ToUpper(name)
	for _, prefix := range []string{"LICENSE", "LICENCE", "COPYING", "COPYRIGHT", "NOTICE", "PATENTS", "AUTHORS"} {
		if upper == prefix || strings.HasPrefix(upper, prefix+".") || strings.HasPrefix(upper, prefix+"-") {
			return true
		}
	}
	return false
}

// Include notices in each compiled package and all its ancestors up to the
// module root. This retains subpackage/vendored notices as well as root licenses.
func legalTexts(source moduleSource) ([]string, []byte, error) {
	root := filepath.Clean(source.root)
	if !filepath.IsAbs(root) {
		return nil, nil, fmt.Errorf("absolute source root required")
	}
	dirs := map[string]bool{root: true}
	for _, dir := range source.dirs {
		rel, err := filepath.Rel(root, dir)
		if err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) || filepath.IsAbs(rel) {
			return nil, nil, fmt.Errorf("package directory outside source root")
		}
		for dir = filepath.Clean(dir); ; dir = filepath.Dir(dir) {
			rel, err := filepath.Rel(root, dir)
			if err != nil {
				return nil, nil, err
			}
			if rel == "." {
				break
			}
			if filepath.Dir(dir) == dir {
				return nil, nil, fmt.Errorf("source root was not reached")
			}
			dirs[dir] = true
		}
	}
	texts := map[string][]byte{}
	hasLicense := false
	for dir := range dirs {
		files, err := os.ReadDir(dir)
		if err != nil {
			return nil, nil, err
		}
		for _, file := range files {
			if !isLegalFile(file.Name()) || file.IsDir() {
				continue
			}
			info, err := file.Info()
			if err != nil {
				return nil, nil, err
			}
			if !info.Mode().IsRegular() || info.Size() > 4*1024*1024 {
				return nil, nil, fmt.Errorf("invalid license file %s", file.Name())
			}
			path := filepath.Join(dir, file.Name())
			data, err := os.ReadFile(path)
			if err != nil {
				return nil, nil, err
			}
			if len(bytes.TrimSpace(data)) == 0 {
				return nil, nil, fmt.Errorf("empty notice file %s", file.Name())
			}
			rel, err := filepath.Rel(root, path)
			if err != nil {
				return nil, nil, err
			}
			texts[filepath.ToSlash(rel)] = normalizeText(data)
			upper := strings.ToUpper(file.Name())
			if strings.HasPrefix(upper, "LICENSE") || strings.HasPrefix(upper, "LICENCE") || strings.HasPrefix(upper, "COPYING") {
				hasLicense = true
			}
		}
	}
	if !hasLicense {
		return nil, nil, fmt.Errorf("no license text found; inspect dependency before packaging")
	}
	names := make([]string, 0, len(texts))
	for name := range texts {
		names = append(names, name)
	}
	sort.Strings(names)
	var output bytes.Buffer
	for _, name := range names {
		fmt.Fprintf(&output, "\n--- %s ---\n%s\n", name, texts[name])
	}
	return names, output.Bytes(), nil
}
