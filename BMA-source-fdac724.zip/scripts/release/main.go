// Command release builds the fixed BMA targets and their distributable archives.
package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"debug/buildinfo"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strings"
	"time"
)

var versionPattern = regexp.MustCompile(`^[0-9]+\.[0-9]+\.[0-9]+(-[A-Za-z0-9.-]+)?$`)

type target struct{ os, arch string }

var targets = []target{{"windows", "amd64"}, {"darwin", "amd64"}, {"darwin", "arm64"}, {"linux", "amd64"}}

func main() {
	version := flag.String("version", "0.4.0-dev", "release version")
	out := flag.String("out", "dist/release", "new output directory (must not exist)")
	goTool := flag.String("go", filepath.Join(runtime.GOROOT(), "bin", "go"), "Go executable")
	flag.Parse()
	if flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "unexpected release arguments")
		os.Exit(1)
	}
	if err := buildRelease(*goTool, *version, *out); err != nil {
		fmt.Fprintln(os.Stderr, "release:", err)
		os.Exit(1)
	}
}

func command(goTool string, t target, args ...string) ([]byte, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	cmd := exec.CommandContext(ctx, goTool, args...)
	// Explicit targets and settings also keep an inherited GOFLAGS from silently
	// changing the dependencies, version injection or reproducibility contract.
	for _, pair := range os.Environ() {
		key, _, _ := strings.Cut(pair, "=")
		switch strings.ToUpper(key) {
		case "GOOS", "GOARCH", "CGO_ENABLED", "GOFLAGS", "GOEXPERIMENT", "GOAMD64", "GOARM64":
		default:
			cmd.Env = append(cmd.Env, pair)
		}
	}
	cmd.Env = append(cmd.Env, "GOOS="+t.os, "GOARCH="+t.arch, "CGO_ENABLED=0", "GOFLAGS=", "GOEXPERIMENT=", "GOAMD64=v1", "GOARM64=v8.0")
	cmd.Stderr = os.Stderr
	data, err := cmd.Output()
	if err != nil {
		return nil, fmt.Errorf("go %s: %w", strings.Join(args, " "), err)
	}
	return data, nil
}

func buildRelease(goTool, version, output string) error {
	if !versionPattern.MatchString(version) {
		return fmt.Errorf("invalid version %q", version)
	}
	if output == "" {
		return fmt.Errorf("output directory is required")
	}
	if _, err := os.Stat("go.mod"); err != nil {
		return fmt.Errorf("run from the repository root: %w", err)
	}
	out, err := filepath.Abs(output)
	if err != nil {
		return err
	}
	if _, err := os.Lstat(out); err == nil {
		return fmt.Errorf("output already exists; choose a new directory: %s", out)
	} else if !os.IsNotExist(err) {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(out), 0755); err != nil {
		return err
	}
	stage, err := os.MkdirTemp(filepath.Dir(out), ".bma-release-")
	if err != nil {
		return err
	}
	// Only this freshly created staging directory is ever removed.
	defer os.RemoveAll(stage)
	work := filepath.Join(stage, ".build")
	if err := os.Mkdir(work, 0700); err != nil {
		return err
	}
	var checksums []string
	for _, t := range targets {
		fmt.Printf("Building %s/%s\n", t.os, t.arch)
		binaryName := "bma"
		if t.os == "windows" {
			binaryName += ".exe"
		}
		binaryPath := filepath.Join(work, binaryName)
		flags := "-s -w -buildid= -X behavior-monitoring-audit/internal/report.Version=" + version
		if _, err := command(goTool, t, "build", "-mod=readonly", "-trimpath", "-buildvcs=false", "-ldflags", flags, "-o", binaryPath, "./cmd/bma"); err != nil {
			return err
		}
		info, err := buildinfo.ReadFile(binaryPath)
		if err != nil {
			return err
		}
		if info.Path != "behavior-monitoring-audit/cmd/bma" {
			return fmt.Errorf("unexpected binary entry point")
		}
		binary, err := os.ReadFile(binaryPath)
		if err != nil {
			return err
		}
		entries := []entry{{name: binaryName, mode: 0755, data: binary}}
		for _, path := range []string{"README.md", "LICENSE", "rules.yaml", "docs/QUICKSTART.md", "docs/MAC_TRIAL.md", "docs/DEMO.md", "docs/STATUS.md", "docs/RELEASE.md", "docs/MACOS_QA.md", "docs/WORKBUDDY_QA.md", "docs/DOUBAO_QA.md", "docs/AGENT_LOG_SOURCES.md", "docs/IP_RANGES.md", "docs/licenses/README.md", "docs/licenses/Apache-2.0.txt"} {
			data, err := os.ReadFile(filepath.FromSlash(path))
			if err != nil {
				return err
			}
			entries = append(entries, entry{name: path, mode: 0644, data: normalizeText(data)})
		}
		for _, path := range []string{"docs/assets/demo.gif", "docs/assets/demo.png"} {
			data, err := os.ReadFile(filepath.FromSlash(path))
			if err != nil {
				return err
			}
			entries = append(entries, entry{name: path, mode: 0644, data: data})
		}
		ranges, err := os.ReadFile("internal/destination/data/storage-ranges.json")
		if err != nil {
			return err
		}
		entries = append(entries, entry{name: "storage-ranges.json", mode: 0644, data: normalizeText(ranges)})
		notices, modules, err := dependencyNotices(goTool, t, info.Deps)
		if err != nil {
			return err
		}
		entries = append(entries, entry{name: "THIRD_PARTY_NOTICES.txt", mode: 0644, data: notices})
		manifest := struct {
			Version      string       `json:"version"`
			OS           string       `json:"os"`
			Arch         string       `json:"arch"`
			GoVersion    string       `json:"go_version"`
			Binary       string       `json:"binary"`
			BinarySHA256 string       `json:"binary_sha256"`
			Dependencies []dependency `json:"dependencies"`
		}{version, t.os, t.arch, info.GoVersion, binaryName, fmt.Sprintf("%x", sha256.Sum256(binary)), modules}
		data, err := json.MarshalIndent(manifest, "", "  ")
		if err != nil {
			return err
		}
		entries = append(entries, entry{name: "BUILD.json", mode: 0644, data: append(data, '\n')})
		name := fmt.Sprintf("bma-%s-%s-%s", version, t.os, t.arch)
		if t.os == "windows" {
			name += ".zip"
		} else {
			name += ".tar.gz"
		}
		archive, err := os.Create(filepath.Join(stage, name))
		if err != nil {
			return err
		}
		err = writeArchive(archive, entries, t.os == "windows")
		closeErr := archive.Close()
		if err != nil {
			return err
		}
		if closeErr != nil {
			return closeErr
		}
		archiveBytes, err := os.ReadFile(filepath.Join(stage, name))
		if err != nil {
			return err
		}
		checksums = append(checksums, fmt.Sprintf("%x  %s\n", sha256.Sum256(archiveBytes), name))
	}
	sort.Strings(checksums)
	if err := os.WriteFile(filepath.Join(stage, "SHA256SUMS"), []byte(strings.Join(checksums, "")), 0644); err != nil {
		return err
	}
	if err := os.RemoveAll(work); err != nil {
		return err
	}
	if err := os.Rename(stage, out); err != nil {
		return err
	}
	fmt.Printf("Release archives saved to %s\n", out)
	return nil
}

func normalizeText(data []byte) []byte { return bytes.ReplaceAll(data, []byte("\r\n"), []byte("\n")) }
