package main

import (
	"archive/tar"
	"archive/zip"
	"bytes"
	"compress/gzip"
	"errors"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
)

func TestArchivesContainExactFilesModesAndStableMetadata(t *testing.T) {
	for _, windows := range []bool{true, false} {
		files := []entry{{name: "docs/README.md", mode: 0644, data: []byte("read me\n")}, {name: "bma", mode: 0755, data: []byte("synthetic binary")}}
		var first, second bytes.Buffer
		if err := writeArchive(&first, files, windows); err != nil {
			t.Fatal(err)
		}
		files[0], files[1] = files[1], files[0]
		if err := writeArchive(&second, files, windows); err != nil {
			t.Fatal(err)
		}
		if !bytes.Equal(first.Bytes(), second.Bytes()) {
			t.Fatal("archive depends on input order")
		}
		got := map[string]string{}
		if windows {
			z, err := zip.NewReader(bytes.NewReader(first.Bytes()), int64(first.Len()))
			if err != nil {
				t.Fatal(err)
			}
			for _, f := range z.File {
				if !f.Modified.Equal(archiveTime) || (f.Name == "bma" && f.Mode().Perm() != 0755) || (f.Name != "bma" && f.Mode().Perm() != 0644) {
					t.Fatal("wrong ZIP metadata")
				}
				r, err := f.Open()
				if err != nil {
					t.Fatal(err)
				}
				data, err := io.ReadAll(r)
				_ = r.Close()
				if err != nil {
					t.Fatal(err)
				}
				got[f.Name] = string(data)
			}
		} else {
			gz, err := gzip.NewReader(bytes.NewReader(first.Bytes()))
			if err != nil {
				t.Fatal(err)
			}
			defer gz.Close()
			tr := tar.NewReader(gz)
			for {
				h, err := tr.Next()
				if err == io.EOF {
					break
				}
				if err != nil {
					t.Fatal(err)
				}
				if !h.ModTime.Equal(archiveTime) || h.Uid != 0 || h.Gid != 0 || h.Typeflag != tar.TypeReg || (h.Name == "bma" && h.Mode != 0755) || (h.Name != "bma" && h.Mode != 0644) {
					t.Fatal("wrong tar metadata")
				}
				data, err := io.ReadAll(tr)
				if err != nil {
					t.Fatal(err)
				}
				got[h.Name] = string(data)
			}
		}
		if !reflect.DeepEqual(got, map[string]string{"bma": "synthetic binary", "docs/README.md": "read me\n"}) {
			t.Fatal("archive lost content", got)
		}
		if err := writeArchive(failedWriter{}, files, windows); !errors.Is(err, io.ErrClosedPipe) {
			t.Fatal("lost sink error", err)
		}
		for _, name := range []string{".", "../secret", "/absolute", "C:/drive", `docs\bad`, "docs/../bad", ""} {
			if err := writeArchive(io.Discard, []entry{{name: name}}, windows); err == nil {
				t.Fatal("unsafe archive name accepted", name)
			}
		}
		if err := writeArchive(io.Discard, []entry{{name: "duplicate"}, {name: "duplicate"}}, windows); err == nil {
			t.Fatal("duplicate member accepted")
		}
	}
}

type failedWriter struct{}

func (failedWriter) Write([]byte) (int, error) { return 0, io.ErrClosedPipe }

func TestNoticesIncludeRootAndPackageAncestors(t *testing.T) {
	root := t.TempDir()
	pkg := filepath.Join(root, "vendor", "child", "pkg")
	if err := os.MkdirAll(pkg, 0755); err != nil {
		t.Fatal(err)
	}
	for path, text := range map[string]string{"LICENSE": "root license\r\n", "NOTICE": "root notice\n", "vendor/child/LICENSE.txt": "child license\n", "vendor/child/pkg/PATENTS": "patent grant\n", "vendor/child/pkg/README": "not a notice"} {
		if err := os.WriteFile(filepath.Join(root, filepath.FromSlash(path)), []byte(text), 0644); err != nil {
			t.Fatal(err)
		}
	}
	files, data, err := legalTexts(moduleSource{root: root, dirs: []string{pkg, pkg}})
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(files, []string{"LICENSE", "NOTICE", "vendor/child/LICENSE.txt", "vendor/child/pkg/PATENTS"}) {
		t.Fatal("notices missing or duplicated", files)
	}
	for _, want := range []string{"root license\n", "root notice\n", "child license\n", "patent grant\n"} {
		if strings.Count(string(data), want) != 1 {
			t.Fatal("notice content changed")
		}
	}
	if bytes.Contains(data, []byte("\r")) || bytes.Contains(data, []byte(root)) {
		t.Fatal("host-specific data in notices")
	}
	if _, _, err := legalTexts(moduleSource{root: root, dirs: []string{filepath.Dir(root)}}); err == nil {
		t.Fatal("outside source accepted")
	}
	if _, _, err := legalTexts(moduleSource{root: t.TempDir()}); err == nil {
		t.Fatal("missing license accepted")
	}
	if err := os.WriteFile(filepath.Join(root, "NOTICE"), nil, 0644); err != nil {
		t.Fatal(err)
	}
	if _, _, err := legalTexts(moduleSource{root: root}); err == nil {
		t.Fatal("empty notice accepted")
	}
}

func TestReleaseRejectsInvalidVersionAndExistingOutputBeforeBuilding(t *testing.T) {
	for _, version := range []string{"", "1.0", "../1.2.3", "1.2.3 -X unexpected", "1.2.3/other"} {
		if err := buildRelease("must-not-execute", version, "unused"); err == nil || !strings.Contains(err.Error(), "invalid version") {
			t.Fatal("bad version accepted", version, err)
		}
	}
	// A new output directory is mandatory: a failed release never mixes new
	// archives with stale files from another version.
	t.Chdir(t.TempDir())
	if err := os.WriteFile("go.mod", []byte("module fixture"), 0644); err != nil {
		t.Fatal(err)
	}
	if err := os.Mkdir("existing", 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile("existing/keep", []byte("original"), 0644); err != nil {
		t.Fatal(err)
	}
	if err := buildRelease("must-not-execute", "1.2.3", "existing"); err == nil || !strings.Contains(err.Error(), "already exists") {
		t.Fatal("existing output accepted", err)
	}
	data, err := os.ReadFile("existing/keep")
	if err != nil || string(data) != "original" {
		t.Fatal("existing output changed")
	}
	if err := buildRelease(filepath.Join(t.TempDir(), "missing-go"), "1.2.3", "new-release"); err == nil {
		t.Fatal("failed tool accepted")
	}
	if _, err := os.Stat("new-release"); !os.IsNotExist(err) {
		t.Fatal("partial release published", err)
	}
	leftovers, err := filepath.Glob(".bma-release-*")
	if err != nil || len(leftovers) != 0 {
		t.Fatal("staging leaked", leftovers, err)
	}
}
