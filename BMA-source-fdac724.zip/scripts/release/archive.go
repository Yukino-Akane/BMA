package main

import (
	"archive/tar"
	"archive/zip"
	"compress/gzip"
	"fmt"
	"io"
	"io/fs"
	"sort"
	"strings"
	"time"
)

type entry struct {
	name string
	mode fs.FileMode
	data []byte
}

// A fixed ZIP-compatible date and explicit modes make archives independent of
// source checkout timestamps, host OS and local timezone.
var archiveTime = time.Date(2000, 1, 1, 0, 0, 0, 0, time.UTC)

func writeArchive(w io.Writer, entries []entry, windows bool) error {
	sort.Slice(entries, func(i, j int) bool { return entries[i].name < entries[j].name })
	for i, e := range entries {
		if e.name == "." || !fs.ValidPath(e.name) || strings.ContainsAny(e.name, "\\:") || (i > 0 && entries[i-1].name == e.name) {
			return fmt.Errorf("invalid or duplicate archive name %q", e.name)
		}
	}
	if windows {
		z := zip.NewWriter(w)
		for _, e := range entries {
			header := &zip.FileHeader{Name: e.name, Method: zip.Deflate, Modified: archiveTime}
			header.SetMode(e.mode)
			file, err := z.CreateHeader(header)
			if err != nil {
				return err
			}
			if _, err := file.Write(e.data); err != nil {
				return err
			}
		}
		return z.Close()
	}
	gz := gzip.NewWriter(w)
	tw := tar.NewWriter(gz)
	for _, e := range entries {
		if err := tw.WriteHeader(&tar.Header{Name: e.name, Mode: int64(e.mode.Perm()), Size: int64(len(e.data)), ModTime: archiveTime, Typeflag: tar.TypeReg, Format: tar.FormatUSTAR}); err != nil {
			return err
		}
		if _, err := tw.Write(e.data); err != nil {
			return err
		}
	}
	if err := tw.Close(); err != nil {
		return err
	}
	return gz.Close()
}
