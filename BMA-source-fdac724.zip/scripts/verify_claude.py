"""Run the real Claude executable against a loopback fixture and audit it with BMA."""
import argparse
from collections import Counter
import ctypes
from datetime import datetime
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import ipaddress
import json
import os
import platform
from pathlib import Path
import socket
import subprocess
import sys
import threading
import time
import uuid

class CountedInput:
    """Count exact HTTP header/body bytes consumed by the fixture server."""

    def __init__(self, stream):
        self.stream = stream
        self.total = 0

    def read(self, size=-1):
        data = self.stream.read(size)
        self.total += len(data)
        return data

    def readline(self, size=-1):
        data = self.stream.readline(size)
        self.total += len(data)
        return data

    def close(self):
        self.stream.close()

def wait_until(check, description, timeout=20):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        value = check()
        if value:
            return value
        time.sleep(0.05)
    raise RuntimeError('Timed out: ' + description)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--claude', required=True, type=Path)
    p.add_argument('--bma', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--https', action='store_true', help='verify CONNECT with a local TLS endpoint and temporary CA')
    p.add_argument('--proxy-upstream', default='', help='explicit existing loopback HTTP proxy, e.g. http://127.0.0.1:7897')
    args = p.parse_args()
    if sys.platform not in ('win32', 'darwin'):
        p.error('This integration fixture supports Windows and macOS')
    identity = {'platform': sys.platform, 'release': platform.release(), 'machine': platform.machine()}
    if sys.platform == 'win32':
        identity['elevated_administrator'] = bool(ctypes.windll.shell32.IsUserAnAdmin())
    else:
        identity.update(uid=os.getuid(), euid=os.geteuid())
        os.umask(0o077)
    root = args.out.resolve()
    root.mkdir(exist_ok=False)
    workspace, config, report = (root / 'workspace', root / 'claude-config', root / 'audit')
    workspace.mkdir()
    config.mkdir()
    target = workspace / 'fixture.txt'
    initial_content = 'BMA original local fixture\n'
    fixture_content = 'BMA audited local fixture\n'
    task_prompt = 'Read fixture.txt and replace its original text with the audited local test content. Do not access other files.'
    target.write_text(initial_content)
    session = str(uuid.uuid4())
    mode = 'seed'
    requests = []
    handler_errors = []
    tool_requested = threading.Event()
    release_tool = threading.Event()
    tls_context = None
    prepared_tls_context = None
    ca_path = None
    relay = None
    if args.https:
        from claude_tls_fixture import CountingRelay, server_certificate
        prepared_tls_context, ca_path = server_certificate(root)

    class Handler(BaseHTTPRequestHandler):

        def setup(self):
            if tls_context is not None:
                self.request.settimeout(25)
                self.request = tls_context.wrap_socket(self.request, server_side=True)
            super().setup()
            self.connection.settimeout(25)
            self.rfile = CountedInput(self.rfile)

        def log_message(self, *args):
            pass

        def do_POST(self):
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if not 0 < size <= 4 * 1024 * 1024:
                    raise ValueError('request size')
                body = json.loads(self.rfile.read(size))
                if self.path.split('?')[0] != '/v1/messages':
                    raise ValueError('unexpected API path')
                content = body['messages'][-1]['content']
                tool_result = isinstance(content, list) and any((b.get('type') == 'tool_result' for b in content))
                completed_tools = sum((b.get('type') == 'tool_result' for m in body['messages'] if isinstance(m.get('content'), list) for b in m['content']))
                requests.append({'phase': mode, 'body_bytes': size, 'http_bytes_received': self.rfile.total,
                                 'tool_result': tool_result, 'completed_tools': completed_tools,
                                 'stream': body.get('stream'),
                                 'tls_version': self.connection.version() if tls_context else None})
                if len(requests) > 4:
                    raise ValueError('unexpected extra model request')
                if isinstance(content, list) and any((b.get('type') == 'tool_result' and b.get('is_error') for b in content)):
                    raise ValueError('Claude tool reported an error')
                if not body.get('stream'):
                    raise ValueError('expected streaming messages')
                call_tool = mode == 'action' and completed_tools < 2
                tool_name = 'Read' if completed_tools == 0 else 'Edit'
                if call_tool:
                    if set((t['name'] for t in body.get('tools', []))) != {'Read', 'Edit'}:
                        raise ValueError('unexpected available tools: ' + repr([t['name'] for t in body.get('tools', [])]))
                    if completed_tools == 0:
                        tool_requested.set()
                        if not release_tool.wait(20):
                            raise TimeoutError('observer did not release fixture')
                self.send_response(200)
                self.send_header('Content-Type', 'text/event-stream')
                self.send_header('Connection', 'close')
                self.end_headers()

                def emit(kind, value):
                    self.wfile.write(('event: ' + kind + '\ndata: ' + json.dumps(value) + '\n\n').encode())
                    self.wfile.flush()
                emit('message_start', {'type': 'message_start', 'message': {'id': 'msg_bma_fixture', 'type': 'message', 'role': 'assistant', 'content': [], 'model': body['model'], 'stop_reason': None, 'stop_sequence': None, 'usage': {'input_tokens': 1, 'output_tokens': 1}}})
                if call_tool:
                    block = {'type': 'tool_use', 'id': 'toolu_bma_fixture_' + tool_name.lower(), 'name': tool_name, 'input': {}}
                    tool_input = {'file_path': str(target)}
                    if tool_name == 'Edit':
                        tool_input.update(old_string=initial_content, new_string=fixture_content)
                    delta = {'type': 'input_json_delta', 'partial_json': json.dumps(tool_input)}
                else:
                    block = {'type': 'text', 'text': ''}
                    delta = {'type': 'text_delta', 'text': 'Local fixture complete.'}
                emit('content_block_start', {'type': 'content_block_start', 'index': 0, 'content_block': block})
                emit('content_block_delta', {'type': 'content_block_delta', 'index': 0, 'delta': delta})
                emit('content_block_stop', {'type': 'content_block_stop', 'index': 0})
                emit('message_delta', {'type': 'message_delta', 'delta': {'stop_reason': 'tool_use' if call_tool else 'end_turn', 'stop_sequence': None}, 'usage': {'output_tokens': 1}})
                emit('message_stop', {'type': 'message_stop'})
            except Exception as exc:
                handler_errors.append(type(exc).__name__ + ': ' + str(exc))
                self.send_error(400, 'Local fixture protocol error')
                self.close_connection = True
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    endpoint_port = server.server_port
    if args.https:
        relay = CountingRelay(server.server_address, lambda: mode)
        threading.Thread(target=relay.serve_forever, daemon=True).start()
        endpoint_port = relay.server_address[1]
    # Do not inherit model credentials, gateways, hooks or optional providers.
    env = {k: v for k, v in os.environ.items() if k.upper() in {
        'SYSTEMROOT', 'WINDIR', 'COMSPEC', 'PATH', 'PATHEXT', 'TEMP', 'TMP',
        'USERPROFILE', 'LOCALAPPDATA', 'APPDATA', 'PROGRAMFILES', 'PROGRAMFILES(X86)',
        'HOME', 'TMPDIR', 'LANG', 'LC_ALL',
    }}
    env.update(
        CLAUDE_CONFIG_DIR=str(config),
        ANTHROPIC_API_KEY='bma-local-fixture-not-a-real-key',
        # Create the initial log over plain loopback HTTP before observation.
        # Only the separately launched, audited session uses the TLS relay.
        ANTHROPIC_BASE_URL=f'http://127.0.0.1:{server.server_port}',
        CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC='1', DISABLE_AUTOUPDATER='1',
        DISABLE_TELEMETRY='1', DISABLE_ERROR_REPORTING='1', CLAUDE_CODE_AUTO_MODE_SERVER='0',
    )
    if ca_path is not None:
        env['NODE_EXTRA_CA_CERTS'] = str(ca_path)
    base = [
        str(args.claude.resolve()), '--bare', '--print', '--model', 'claude-sonnet-4-6',
        '--setting-sources', '', '--tools', 'Read,Edit', '--allowedTools', 'Read,Edit',
        '--permission-mode', 'dontAsk', '--strict-mcp-config', '--mcp-config', '{"mcpServers":{}}',
        '--disable-slash-commands', '--no-chrome', '--system-prompt',
        'This is a local integration fixture. Use only the supplied Read and Edit tools.',
    ]
    child = watcher = None
    try:
        version = subprocess.check_output([str(args.claude.resolve()), '--version'], env=env, text=True).strip()
        # Keep the input stream open until the real transcript is durable.
        # A successful one-shot CLI exit alone did not prove that on 2.1.224.
        with (root / 'seed.stdout').open('wb') as seed_out, (root / 'seed.stderr').open('wb') as seed_err:
            child = subprocess.Popen(base + ['--session-id', session, '--input-format', 'stream-json',
                '--output-format', 'stream-json', '--verbose'], cwd=workspace, env=env,
                stdin=subprocess.PIPE, stdout=seed_out, stderr=seed_err)
            initial = {'type': 'user', 'message': {'role': 'user', 'content': 'Initialize this isolated fixture and wait.'}}
            child.stdin.write((json.dumps(initial)+'\n').encode())
            child.stdin.flush()

            def persisted_seed():
                if child.poll() is not None:
                    raise RuntimeError('Claude exited before its seed transcript was persisted')
                logs = list(config.rglob(session + '.jsonl'))
                if len(logs) > 1:
                    raise RuntimeError('Multiple seed transcripts found')
                if not logs:
                    return None
                complete = logs[0].read_bytes().split(b'\n')[:-1]
                kinds = {json.loads(line).get('type') for line in complete if line}
                return logs[0] if {'user', 'assistant'} <= kinds else None

            log = wait_until(persisted_seed, 'persisted Claude seed messages', timeout=25)
            child.stdin.close()
            if child.wait(timeout=10):
                raise RuntimeError('Claude seed failed; inspect isolated seed.stderr')
        tls_context = prepared_tls_context
        mode = 'action'
        with socket.socket() as reservation:
            reservation.bind(('127.0.0.1', 0))
            proxy_port = reservation.getsockname()[1]
        child_env = dict(env, HTTP_PROXY=f'http://127.0.0.1:{proxy_port}', HTTPS_PROXY=f'http://127.0.0.1:{proxy_port}', NO_PROXY='')
        child_env['ANTHROPIC_BASE_URL'] = f'{"https" if args.https else "http"}://127.0.0.1:{endpoint_port}'
        with (root / 'claude.stdout').open('wb') as cout, (root / 'claude.stderr').open('wb') as cerr, (root / 'bma.stdout').open('wb') as aout, (root / 'bma.stderr').open('wb') as aerr:
            child = subprocess.Popen(base + ['--resume', session, '--input-format', 'stream-json',
                '--output-format', 'stream-json', '--verbose'], cwd=workspace, env=child_env,
                stdin=subprocess.PIPE, stdout=cout, stderr=cerr)
            watcher = subprocess.Popen([
                str(args.bma.resolve()), 'watch', '--process', str(child.pid),
                '--workspace', str(workspace), '--agent-log', str(log), '--agent-format', 'claude',
                '--proxy-port', str(proxy_port), '--port', '0', '--duration', '12s',
                '--proxy-upstream', args.proxy_upstream,
                '--interval', '100ms', '--no-llm', '--out', str(report),
            ], stdout=aout, stderr=aerr)

            def events():
                path = report / 'events.jsonl'
                if not path.exists():
                    return []
                data = path.read_bytes()
                return [json.loads(row) for row in data.split(b'\n')[:-1] if row]

            def ready():
                if watcher.poll() is not None:
                    raise RuntimeError('BMA exited before ready')
                return any((e['kind'] == 'watch_ready' for e in events()))
            wait_until(ready, 'file watcher readiness')
            task = {'type': 'user', 'message': {'role': 'user', 'content': task_prompt}}
            child.stdin.write((json.dumps(task)+'\n').encode())
            child.stdin.flush()

            def requested():
                if handler_errors:
                    raise RuntimeError('Local fixture rejected request: ' + repr(handler_errors))
                if child.poll() is not None:
                    raise RuntimeError('Claude exited before tool request; inspect isolated claude.stderr')
                return tool_requested.is_set()
            wait_until(requested, 'Claude local tool request', timeout=15)
            wait_until(lambda: any((e['kind'] == 'egress' and e['detail'].get('proxy') and (e['detail'].get('bytes_out', 0) > 0) for e in events())), 'real proxy byte sample', timeout=5)
            if sys.platform == 'darwin':
                wait_until(lambda: any(e['kind'] == 'network_baseline' for e in events()), 'nettop baseline', timeout=10)
            release_tool.set()
            wait_until(lambda: len(requests) == 4 and target.read_text() == fixture_content,
                       'completed real Read/Edit and final model request', timeout=15)
            wait_until(lambda: {'Read', 'Edit'} <= {
                e['detail'].get('tool') for e in events() if e['kind'] == 'claimed_action'
            }, 'persisted and collected real tool calls', timeout=10)
            child.stdin.close()
            if child.wait(timeout=15):
                raise RuntimeError('Claude action failed; inspect isolated claude.stderr')
            if watcher.wait(timeout=20):
                raise RuntimeError('BMA observation failed; inspect isolated bma.stderr')
        if handler_errors:
            raise RuntimeError(repr(handler_errors))
        if target.read_text() != fixture_content:
            raise RuntimeError('real tool did not write the fixture')
        result = json.loads((report / 'report.json').read_text(encoding='utf-8'))
        rows = result['events']
        goals = [e['detail'].get('text') for e in rows if e['kind'] == 'goal']
        if goals.count(task_prompt) != 1 or any(fixture_content.strip() in text or initial_content.strip() in text for text in goals):
            raise RuntimeError('real task goal missing, duplicated, or contaminated with tool results')
        actions = [e for e in rows if e['kind'] == 'claimed_action' and e['detail'].get('tool') in ('Read', 'Edit')]
        files = [e for e in rows if e['layer'] == 'file' and e['detail'].get('path') == str(target) and (e['kind'] in ('file_create', 'file_modify'))]
        net = [e for e in rows if e['kind'] == 'egress' and e['detail'].get('proxy') and (e['process']['pid'] == child.pid)]
        if [e['detail']['tool'] for e in actions] != ['Read', 'Edit'] or not files or (not net):
            raise RuntimeError('missing real semantic, file, or network evidence')
        if any((e['attribution'] != 'temporal' or e['process']['pid'] is not None for e in files)):
            raise RuntimeError('file activity was incorrectly attributed directly to a process')
        for e in rows:
            detail = e.get('detail') or {}
            if e['layer'] == 'net' and detail.get('remote_ip'):
                if not ipaddress.ip_address(detail['remote_ip']).is_loopback:
                    raise RuntimeError('observed a non-loopback network destination')
        proxy_bytes = sum((e['detail']['bytes_out'] for e in net))
        received_bytes = sum((r['http_bytes_received'] for r in requests if r['phase'] == 'action'))
        wire_bytes = received_bytes
        if relay is not None:
            wait_until(lambda: all(c['closed'] for c in relay.connections), 'TLS relay closing')
            if relay.errors:
                raise RuntimeError('TLS relay failed: '+repr(relay.errors))
            wire_bytes = sum(c['bytes_received'] for c in relay.connections if c['phase'] == 'action')
            if wire_bytes <= received_bytes or any(r['tls_version'] not in ('TLSv1.2', 'TLSv1.3') for r in requests if r['phase'] == 'action'):
                raise RuntimeError('TLS handshake or encrypted transport was not verified')
        if proxy_bytes != wire_bytes or len(requests) != 4:
            raise RuntimeError('proxy byte count differs from independently measured wire bytes')
        if args.proxy_upstream and any(e['detail'].get('transport_route') != 'upstream_connect'
                                      or e['detail'].get('remote_ip') for e in net):
            raise RuntimeError('upstream route missing or proxy IP mislabeled as destination IP')
        source_lines = log.read_text(encoding='utf-8').splitlines()
        for e in actions:
            detail = e['detail']
            original = json.loads(source_lines[detail['log_line'] - 1])
            blocks = original['message']['content']
            if not any((b.get('type') == 'tool_use' and b.get('name') == detail['tool'] and (b.get('id') == detail['call_id']) for b in blocks)):
                raise RuntimeError('tool evidence does not match its original log line')
            if datetime.fromisoformat(e['ts'].replace('Z', '+00:00')) != datetime.fromisoformat(original['timestamp'].replace('Z', '+00:00')):
                raise RuntimeError('original Claude timestamp was not preserved')
        preview_path = root / 'preview.json'
        preview_stdout = subprocess.check_output([str(args.bma.resolve()), 'analyze', str(report / 'report.json'), '--dry-run-llm', '--redact-goal', '--out', str(preview_path)], text=True, encoding='utf-8', timeout=15)
        preview = json.loads(preview_path.read_text(encoding='utf-8'))
        bodies = preview['analysis_preview']['request_bodies']
        if json.loads(preview_stdout) != [json.loads(body) for body in bodies]:
            raise RuntimeError('saved preview differs from command output')
        for body in bodies:
            if any((value in body for value in [initial_content.strip(), fixture_content.strip(), 'fixture.txt', str(workspace)])):
                raise RuntimeError('file content or original file path escaped redaction')
        if any((e['detail'].get('source') == 'claude' for e in result.get('events', []) if e['kind'] == 'collector_error')):
            raise RuntimeError('real Claude log produced a collection error')
        verification = {
            'claude_version': version,
            'claude_sha256': hashlib.sha256(args.claude.read_bytes()).hexdigest(),
            'bma_sha256': hashlib.sha256(args.bma.read_bytes()).hexdigest(),
            'session_log': str(log.relative_to(root)),
            'session_log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
            'execution_identity': identity,
            'actual_file_write_verified': True,
            'actual_task_goal_verified': True,
            'actual_claude_log_tool_calls': [e['detail']['tool'] for e in actions],
            'file_records': len(files),
            'source_lines_and_timestamps_verified': True,
            'preview_content_and_path_redaction_verified': True,
            'proxy_records': len(net), 'proxy_bytes_out': proxy_bytes,
            'fixture_http_bytes_received': received_bytes,
            'fixture_wire_bytes_received': wire_bytes,
            'transport': 'HTTPS via CONNECT' if args.https else 'HTTP',
            'proxy_upstream': args.proxy_upstream or None,
            'requests': requests, 'event_kinds': dict(Counter(e['kind'] for e in rows)),
            'collection_gaps': [
                {'source': e['detail'].get('source'), 'reason': e['detail'].get('reason')}
                for e in rows if e['kind'] == 'collector_error'
            ],
            'connection_endings': [
                {'kind': e['kind'], 'stage': e['detail'].get('stage'),
                 'error_code': e['detail'].get('error_code'), 'reason': e['detail'].get('reason')}
                for e in rows if e['kind'] in ('connection_closed', 'connection_failed')
            ],
            'limits': [
                'local mock model, not real model quality',
                'loopback endpoint, not external network conditions',
            ],
        }
        if identity.get('elevated_administrator'):
            verification['limits'].append('elevated Windows account, not ordinary-user verification')
        if sys.platform == 'darwin':
            private_paths = [report, *report.rglob('*')]
            if any(path.stat().st_mode & 0o077 for path in private_paths):
                raise RuntimeError('audit output has group or other permissions')
            verification['private_report_permissions_verified'] = True
            verification['nettop_bytes_out'] = sum(
                e['detail'].get('bytes_out', 0) for e in rows
                if e['kind'] == 'egress' and e['detail'].get('source') == 'nettop'
            )
            verification['limits'].append('nettop is sampled separately; short-lived connections may have no measured increment')
            if identity['euid'] == 0:
                verification['limits'].append('root account, not ordinary-user verification')
        if relay is not None:
            verification['tls_connections'] = relay.connections
            verification['tls_relay_errors'] = relay.errors
        (root / 'verification.json').write_text(json.dumps(verification, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(verification, indent=2))
    finally:
        release_tool.set()
        for process in (child, watcher):
            if process and process.poll() is None:
                process.terminate()
                process.wait(timeout=10)
        if relay is not None:
            relay.shutdown()
            relay.close_connections()
            relay.server_close()
            (root / 'tls-relay.json').write_text(json.dumps({
                'connections': relay.connections, 'errors': relay.errors,
            }, indent=2)+'\n', encoding='utf-8')
        server.shutdown()
        server.server_close()
        (root / 'fixture-requests.json').write_text(json.dumps({'requests': requests, 'errors': handler_errors}, indent=2) + '\n', encoding='utf-8')
if __name__ == '__main__':
    main()
