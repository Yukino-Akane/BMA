#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
version=${1:-0.4.0-dev}
out=${2:-dist/release}
go_tool=$(command -v go)
GOOS= GOARCH= CGO_ENABLED=0 GOFLAGS= GOEXPERIMENT= "$go_tool" run -mod=readonly ./scripts/release --version "$version" --out "$out" --go "$go_tool"
