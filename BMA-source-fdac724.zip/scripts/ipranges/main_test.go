package main

import (
	"crypto/sha256"
	"fmt"
	"testing"
)

func TestImportsOnlyServiceSpecificRangesAndRetainsRawDigest(t *testing.T) {
	a := []byte(`{"syncToken":"123","createDate":"2026-09-18-01-02-03","prefixes":[{"ip_prefix":"3.5.140.0/22","service":"S3"},{"ip_prefix":"3.5.140.0/22","service":"S3"},{"ip_prefix":"1.0.0.0/8","service":"AMAZON"}],"ipv6_prefixes":[{"ipv6_prefix":"2406:daf9:a800::/40","service":"S3"},{"ipv6_prefix":"2001:db8::/32","service":"EC2"}]}`)
	s, err := awsSource(a, "2026-09-19T00:00:00Z")
	if err != nil || len(s.Prefixes) != 2 || s.SHA256 != fmt.Sprintf("%x", sha256.Sum256(a)) || s.Revision != "123" || s.PublishedAt != "2026-09-18T01:02:03Z" {
		t.Fatal("AWS service filtering or provenance failed", s, err)
	}
	z := []byte(`{"cloud":"Public","changeNumber":418,"values":[{"name":"Storage","properties":{"systemService":"AzureStorage","addressPrefixes":["13.65.107.32/28"]}},{"name":"AzureCloud","properties":{"systemService":"","addressPrefixes":["1.0.0.0/8"]}},{"name":"Storage.WestUS","properties":{"systemService":"AzureStorage","addressPrefixes":["1.2.3.0/24"]}}]}`)
	s, err = azureSource(z, "https://download.microsoft.com/download/test/ServiceTags_Public_20260914.json", "2026-09-19T00:00:00Z")
	if err != nil || len(s.Prefixes) != 1 || s.Prefixes[0] != "13.65.107.32/28" || s.PublishedAt != "2026-09-14" || s.SHA256 != fmt.Sprintf("%x", sha256.Sum256(z)) {
		t.Fatal("Azure tag filtering or provenance failed", s, err)
	}
	for _, url := range []string{"https://attacker.example/ServiceTags_Public_20260914.json", "https://download.microsoft.com/ServiceTags_China_20260914.json", "https://download.microsoft.com/ServiceTags_Public_20260914.json?other=1"} {
		if _, err := azureSource(z, url, "2026-09-19T00:00:00Z"); err == nil {
			t.Fatal("invalid feed URL accepted")
		}
	}
	if _, err := azureSource([]byte(`{"cloud":"Public","changeNumber":1,"values":[]}`), "https://download.microsoft.com/ServiceTags_Public_20260914.json", "2026-09-19T00:00:00Z"); err == nil {
		t.Fatal("missing Storage tag accepted")
	}
}
