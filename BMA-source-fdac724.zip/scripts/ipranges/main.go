// ipranges imports explicitly downloaded official feeds. It never fetches data
// or changes an installed application's snapshot at runtime.
package main

import (
	"crypto/sha256"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"net/url"
	"os"
	"path"
	"slices"
	"strconv"
	"strings"
	"time"

	"behavior-monitoring-audit/internal/destination"
)

func main() {
	aws := flag.String("aws", "", "downloaded AWS ip-ranges.json")
	azure := flag.String("azure", "", "downloaded Azure Public service tags JSON")
	azureURL := flag.String("azure-url", "", "exact official dated download URL")
	retrieved := flag.String("retrieved-at", "", "actual retrieval time in RFC3339 UTC")
	out := flag.String("out", "", "output snapshot JSON")
	flag.Parse()
	if err := generate(*aws, *azure, *azureURL, *retrieved, *out); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func readFeed(name string) ([]byte, error) {
	f, err := os.Open(name)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	b, err := io.ReadAll(io.LimitReader(f, 16*1024*1024+1))
	if err != nil || len(b) > 16*1024*1024 {
		return nil, fmt.Errorf("unreadable feed or feed exceeds 16 MiB")
	}
	return b, nil
}

func awsSource(raw []byte, retrieved string) (destination.RangeSource, error) {
	var feed struct {
		SyncToken  string `json:"syncToken"`
		CreateDate string `json:"createDate"`
		Prefixes   []struct {
			Prefix  string `json:"ip_prefix"`
			Service string `json:"service"`
		} `json:"prefixes"`
		V6 []struct {
			Prefix  string `json:"ipv6_prefix"`
			Service string `json:"service"`
		} `json:"ipv6_prefixes"`
	}
	if err := json.Unmarshal(raw, &feed); err != nil {
		return destination.RangeSource{}, err
	}
	published, err := time.Parse("2006-01-02-15-04-05", feed.CreateDate)
	if err != nil {
		return destination.RangeSource{}, err
	}
	s := destination.RangeSource{Service: "AWS S3", URL: "https://ip-ranges.amazonaws.com/ip-ranges.json", PublishedAt: published.Format(time.RFC3339), RetrievedAt: retrieved, Revision: feed.SyncToken, SHA256: fmt.Sprintf("%x", sha256.Sum256(raw))}
	for _, p := range feed.Prefixes {
		if p.Service == "S3" {
			s.Prefixes = append(s.Prefixes, p.Prefix)
		}
	}
	for _, p := range feed.V6 {
		if p.Service == "S3" {
			s.Prefixes = append(s.Prefixes, p.Prefix)
		}
	}
	slices.Sort(s.Prefixes)
	s.Prefixes = slices.Compact(s.Prefixes)
	return s, nil
}

func azureSource(raw []byte, sourceURL, retrieved string) (destination.RangeSource, error) {
	u, err := url.Parse(sourceURL)
	if err != nil || u.Scheme != "https" || u.Host != "download.microsoft.com" || u.User != nil || u.RawQuery != "" || u.Fragment != "" {
		return destination.RangeSource{}, fmt.Errorf("expected official Azure download URL")
	}
	name := path.Base(u.Path)
	stamp := strings.TrimSuffix(strings.TrimPrefix(name, "ServiceTags_Public_"), ".json")
	published, err := time.Parse("20060102", stamp)
	if err != nil || name != "ServiceTags_Public_"+stamp+".json" {
		return destination.RangeSource{}, fmt.Errorf("expected dated Public service tag filename")
	}
	var feed struct {
		Cloud        string `json:"cloud"`
		ChangeNumber int    `json:"changeNumber"`
		Values       []struct {
			Name       string `json:"name"`
			Properties struct {
				SystemService string   `json:"systemService"`
				Prefixes      []string `json:"addressPrefixes"`
			} `json:"properties"`
		} `json:"values"`
	}
	if err := json.Unmarshal(raw, &feed); err != nil {
		return destination.RangeSource{}, err
	}
	if feed.Cloud != "Public" || feed.ChangeNumber <= 0 {
		return destination.RangeSource{}, fmt.Errorf("invalid Azure Public feed")
	}
	s := destination.RangeSource{Service: "Azure Storage", URL: sourceURL, PublishedAt: published.Format("2006-01-02"), RetrievedAt: retrieved, Revision: strconv.Itoa(feed.ChangeNumber), SHA256: fmt.Sprintf("%x", sha256.Sum256(raw))}
	count := 0
	for _, v := range feed.Values {
		if v.Name == "Storage" {
			if v.Properties.SystemService != "AzureStorage" {
				return s, fmt.Errorf("invalid Storage service identity")
			}
			count++
			s.Prefixes = append(s.Prefixes, v.Properties.Prefixes...)
		}
	}
	if count != 1 {
		return s, fmt.Errorf("expected exactly one global Storage tag")
	}
	slices.Sort(s.Prefixes)
	s.Prefixes = slices.Compact(s.Prefixes)
	return s, nil
}

func generate(awsPath, azurePath, azureURL, retrieved, out string) error {
	if out == "" {
		return fmt.Errorf("output path is required")
	}
	t, err := time.Parse(time.RFC3339, retrieved)
	if err != nil || !strings.HasSuffix(retrieved, "Z") {
		return fmt.Errorf("retrieval time must be RFC3339 UTC")
	}
	if t.After(time.Now().UTC()) {
		return fmt.Errorf("retrieval time is in the future")
	}
	a, err := readFeed(awsPath)
	if err != nil {
		return err
	}
	z, err := readFeed(azurePath)
	if err != nil {
		return err
	}
	aws, err := awsSource(a, retrieved)
	if err != nil {
		return err
	}
	azure, err := azureSource(z, azureURL, retrieved)
	if err != nil {
		return err
	}
	encoded, err := json.MarshalIndent(destination.RangeSnapshot{Sources: []destination.RangeSource{aws, azure}}, "", "  ")
	if err != nil {
		return err
	}
	if _, err := destination.ParseRangeSnapshot(encoded); err != nil {
		return err
	}
	return os.WriteFile(out, append(encoded, '\n'), 0644)
}
