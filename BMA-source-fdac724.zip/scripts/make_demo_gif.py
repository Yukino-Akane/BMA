"""Compose a captioned GIF from six real browser screenshots (maintainer only)."""

import argparse
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


STEPS = [
    ("01-overview.png", "先看一遍：这个工具怎样核对 AI 的行为", "下面是真实报告页面；案例中的行为全部为模拟。", 4000),
    ("02-task.png", "1 / 5  对照要求：只改 README，不打包、不上传", "任务目标与 Agent 自述分开记录；自述不等于操作已经执行。", 6000),
    ("03-findings.png", "2 / 5  查看线索：出现压缩包，又很快被删除", "规则提示帮助你找到值得检查的记录，不能单独证明数据泄露。", 6000),
    ("04-evidence.png", "3 / 5  点击证据：每条提示都能回到原始记录", "文件记录明确标注“仅时间相关”；这里的大小、时间和事件编号可核对。", 6000),
    ("05-network.png", "4 / 5  筛选网络：连接地址与发送字节分开看", "仅有连接不能证明上传；画面中的 60 MiB 为模拟值。", 6000),
    ("06-preview.png", "5 / 5  发送前检查：展开模型将收到的内容", "原始路径已匿名化，任务文本仍保留；本次只预览，没有请求模型。", 6000),
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("frames", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--font", required=True, type=Path, help="CJK font file for Chinese captions")
    args = parser.parse_args()
    title_font = ImageFont.truetype(str(args.font), 27)
    subtitle_font = ImageFont.truetype(str(args.font), 18)
    badge_font = ImageFont.truetype(str(args.font), 16)
    images, durations = [], []
    size = None
    for index, (filename, title, subtitle, duration) in enumerate(STEPS):
        with Image.open(args.frames / filename) as source:
            screenshot = source.convert("RGB")
        if size is None:
            size = screenshot.size
        if screenshot.size != size:
            raise ValueError("All screenshots must use the same viewport")
        width, height = size
        canvas = Image.new("RGB", (width, height + 145), "#142b3a")
        draw = ImageDraw.Draw(canvas)
        for text, font in [(title, title_font), (subtitle, subtitle_font)]:
            if draw.textlength(text, font=font) > width - 56:
                raise ValueError("Viewport is too narrow for the captions")
        draw.text((28, 14), title, font=title_font, fill="#ffffff")
        draw.text((28, 59), subtitle, font=subtitle_font, fill="#cbdce7")
        canvas.paste(screenshot, (0, 100))
        draw.text((28, height + 112), "BMA  |  模拟案例 · 未上传数据 · 未请求模型", font=badge_font, fill="#cbdce7")
        right = width - 28
        for step in range(len(STEPS)):
            x = right - (len(STEPS) - step) * 28
            draw.rounded_rectangle((x, height + 118, x + 19, height + 124), radius=3,
                                   fill="#64d3ba" if step == index else "#496171")
        images.append(canvas.quantize(colors=256, method=Image.Quantize.MEDIANCUT))
        durations.append(duration)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    images[0].save(args.output, save_all=True, append_images=images[1:], duration=durations,
                   loop=0, optimize=True, disposal=2)
    # Static companion permits a non-animated preview in documents or chat.
    images[1].convert("RGB").save(args.output.with_suffix(".png"))
    with Image.open(args.output) as rendered:
        if rendered.n_frames != len(STEPS):
            raise ValueError("GIF lost one or more screenshots")
    print(f"{args.output}: {len(STEPS)} frames, {sum(durations) / 1000:g} seconds, {args.output.stat().st_size} bytes")


if __name__ == "__main__":
    main()
