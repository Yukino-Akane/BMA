//go:build windows

package main

import "golang.org/x/sys/windows"

func identity() map[string]any {
	return map[string]any{"elevated": windows.GetCurrentProcessToken().IsElevated()}
}
