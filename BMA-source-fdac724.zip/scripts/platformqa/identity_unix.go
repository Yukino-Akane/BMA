//go:build !windows

package main

import "os"

func identity() map[string]any {
	return map[string]any{"uid": os.Getuid(), "euid": os.Geteuid(), "elevated": os.Geteuid() == 0}
}
