package main

import (
	"testing"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/report"
)

func TestFixtureRejectsExternalOrNamedEndpoints(t *testing.T) {
	for _, address := range []string{"example.com:443", "192.0.2.1:80", "localhost:80", "0.0.0.0:80", "127.0.0.1", "[::]:80"} {
		if loopbackAddress(address) == nil {
			t.Errorf("unsafe fixture endpoint accepted: %s", address)
		}
	}
	for _, address := range []string{"127.0.0.1:1234", "[::1]:1234"} {
		if err := loopbackAddress(address); err != nil {
			t.Error(err)
		}
	}
}

func TestValidationDoesNotTreatMissingOrForeignEvidenceAsSuccess(t *testing.T) {
	result := phaseResult{Name: "connect", PID: 42, Checks: map[string]bool{}}
	validate(&result, report.Report{Status: "stopped"}, "fixture.txt")
	for _, key := range []string{"file_change", "selected_process_observed", "loopback_connection", "proxy_exact_outbound", "endpoint_received_exact_payload"} {
		if result.Checks[key] {
			t.Errorf("missing evidence accepted: %s", key)
		}
	}
	r := report.Report{Status: "failed", Events: []event.Event{
		event.New("test", "net", event.Process{PID: 99}, "connection_observed", "direct", map[string]any{"remote_ip": "192.0.2.1"}),
		event.New("test", "file", event.Process{PID: 42}, "file_modify", "direct", map[string]any{"path": "fixture.txt"}),
	}}
	validate(&result, r, "fixture.txt")
	for _, key := range []string{"report_stopped", "only_selected_pid", "only_loopback_destinations", "file_attribution"} {
		if result.Checks[key] {
			t.Errorf("invalid evidence accepted: %s", key)
		}
	}
}
