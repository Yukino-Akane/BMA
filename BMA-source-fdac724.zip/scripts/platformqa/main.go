// Command platformqa exercises an BMA release with only an isolated workspace,
// an explicitly selected child PID and a loopback echo endpoint. It is a
// maintainer tool, not part of the product binary or an actual Agent session.
package main

import (
	"bufio"
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"math"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/report"
)

const payloadBytes = 32 * 64 * 1024

type fixtureConfig struct {
	Workspace string
	Endpoint  string
	Proxy     string
}

type phaseResult struct {
	Name      string           `json:"name"`
	PID       int              `json:"pid"`
	Checks    map[string]bool  `json:"checks"`
	BytesOut  uint64           `json:"proxy_bytes_out"`
	BytesIn   uint64           `json:"proxy_bytes_in"`
	NettopOut uint64           `json:"nettop_bytes_out"`
	Received  int64            `json:"endpoint_bytes_received"`
	Gaps      []map[string]any `json:"collection_gaps"`
	Error     string           `json:"error,omitempty"`
}

func main() {
	if len(os.Args) == 2 && os.Args[1] == "--fixture" {
		if err := fixture(); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		return
	}
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run(args []string) error {
	f := flag.NewFlagSet("platformqa", flag.ContinueOnError)
	bma := f.String("bma", "", "path to the BMA binary")
	out := f.String("out", "", "new output directory, must not exist")
	if err := f.Parse(args); err != nil {
		return err
	}
	if *bma == "" || *out == "" || f.NArg() != 0 {
		return fmt.Errorf("usage: platformqa --bma PATH --out NEW_DIRECTORY")
	}
	binary, err := filepath.Abs(*bma)
	if err != nil {
		return err
	}
	data, err := os.ReadFile(binary)
	if err != nil {
		return err
	}
	root, err := filepath.Abs(*out)
	if err != nil {
		return err
	}
	if err := os.Mkdir(root, 0700); err != nil {
		return err
	}
	if err := report.SecureDirectory(root); err != nil {
		return err
	}
	self, err := os.Executable()
	if err != nil {
		return err
	}
	selfData, err := os.ReadFile(self)
	if err != nil {
		return err
	}
	result := map[string]any{
		"os": runtime.GOOS, "arch": runtime.GOARCH, "go_version": runtime.Version(),
		"created_at": time.Now().UTC(), "identity": identity(),
		"bma_sha256":              fmt.Sprintf("%x", sha256.Sum256(data)),
		"qa_sha256":               fmt.Sprintf("%x", sha256.Sum256(selfData)),
		"payload_bytes_per_phase": payloadBytes,
		"limits":                  []string{"synthetic child, not a real Agent", "loopback only; no external network or TLS", "no PID reuse, counter reset, power loss or disk fault injection", "no browser file:// QA"},
	}
	var phases []phaseResult
	var failures []error
	for _, name := range []string{"direct", "connect"} {
		fmt.Println("Verifying", name)
		p, err := phase(binary, self, root, name)
		if err != nil {
			p.Error = err.Error()
			failures = append(failures, fmt.Errorf("%s: %w", name, err))
		}
		phases = append(phases, p)
	}
	result["phases"], result["passed"] = phases, len(failures) == 0
	if err := writeJSON(filepath.Join(root, "verification.json"), result); err != nil {
		return err
	}
	fmt.Println("Evidence:", filepath.Join(root, "verification.json"))
	return errors.Join(failures...)
}

func writeJSON(path string, value any) error {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(data, '\n'), 0600)
}

func loopbackAddress(value string) error {
	host, _, err := net.SplitHostPort(value)
	if err != nil || !net.ParseIP(host).IsLoopback() {
		return fmt.Errorf("fixture requires a literal loopback address")
	}
	return nil
}

// The child waits for the observer before opening its socket, and then waits
// again so the observer can establish a baseline before the fixed transfer.
func fixture() error {
	input := bufio.NewReader(os.Stdin)
	line, err := input.ReadBytes('\n')
	if err != nil {
		return err
	}
	var cfg fixtureConfig
	if err := json.Unmarshal(line, &cfg); err != nil {
		return err
	}
	if err := loopbackAddress(cfg.Endpoint); err != nil {
		return err
	}
	address := cfg.Endpoint
	if cfg.Proxy != "" {
		if err := loopbackAddress(cfg.Proxy); err != nil {
			return err
		}
		address = cfg.Proxy
	}
	file, err := os.OpenFile(filepath.Join(cfg.Workspace, "fixture.txt"), os.O_CREATE|os.O_RDWR|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	defer file.Close()
	conn, err := net.DialTimeout("tcp", address, 5*time.Second)
	if err != nil {
		return err
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(35 * time.Second))
	reader := bufio.NewReader(conn)
	if cfg.Proxy != "" {
		if _, err := fmt.Fprintf(conn, "CONNECT %s HTTP/1.1\r\nHost: %s\r\n\r\n", cfg.Endpoint, cfg.Endpoint); err != nil {
			return err
		}
		response, err := http.ReadResponse(reader, &http.Request{Method: "CONNECT"})
		if err != nil {
			return err
		}
		if response.StatusCode != 200 {
			return fmt.Errorf("proxy rejected fixture: %d", response.StatusCode)
		}
	}
	fmt.Println("connected")
	if _, err := input.ReadBytes('\n'); err != nil {
		return err
	}
	payload := bytes.Repeat([]byte{'a'}, 64*1024)
	response := make([]byte, len(payload))
	for i := 0; i < 32; i++ {
		if _, err := file.WriteAt([]byte(fmt.Sprintf("local fixture step %02d\n", i)), 0); err != nil {
			return err
		}
		if err := file.Sync(); err != nil {
			return err
		}
		if _, err := io.Copy(conn, bytes.NewReader(payload)); err != nil {
			return err
		}
		if _, err := io.ReadFull(reader, response); err != nil {
			return err
		}
		if !bytes.Equal(response, payload) {
			return fmt.Errorf("echo content mismatch")
		}
		time.Sleep(200 * time.Millisecond)
	}
	time.Sleep(2 * time.Second) // Keep counters and open file observable.
	return nil
}

type processRun struct {
	cmd  *exec.Cmd
	done chan struct{}
	err  error
}

func start(cmd *exec.Cmd) (*processRun, error) {
	if err := cmd.Start(); err != nil {
		return nil, err
	}
	p := &processRun{cmd: cmd, done: make(chan struct{})}
	go func() { p.err = cmd.Wait(); close(p.done) }()
	return p, nil
}

func (p *processRun) stop() {
	select {
	case <-p.done:
	default:
		_ = p.cmd.Process.Kill() // Only this fixture's own child.
		<-p.done
	}
}

func phase(binary, self, root, name string) (result phaseResult, err error) {
	result = phaseResult{Name: name, Checks: map[string]bool{}}
	dir := filepath.Join(root, name)
	workspace := filepath.Join(dir, "workspace")
	if err = os.MkdirAll(workspace, 0700); err != nil {
		return
	}
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return result, err
	}
	defer listener.Close()
	type echoResult struct {
		bytes int64
		err   error
	}
	echo := make(chan echoResult, 1)
	go func() {
		defer close(echo)
		conn, e := listener.Accept()
		if e != nil {
			echo <- echoResult{err: e}
			return
		}
		defer conn.Close()
		_ = conn.SetDeadline(time.Now().Add(35 * time.Second))
		n, e := io.Copy(conn, conn)
		echo <- echoResult{n, e}
	}()
	defer func() { _ = listener.Close(); <-echo }()
	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	defer cancel()
	child := exec.CommandContext(ctx, self, "--fixture")
	input, err := child.StdinPipe()
	if err != nil {
		return result, err
	}
	defer input.Close()
	var childOutput lockedBuffer
	child.Stdout = &childOutput
	childErr, err := os.Create(filepath.Join(dir, "fixture.stderr"))
	if err != nil {
		return result, err
	}
	defer childErr.Close()
	child.Stderr = childErr
	fixtureRun, err := start(child)
	if err != nil {
		return result, err
	}
	defer fixtureRun.stop()
	result.PID = child.Process.Pid
	audit := filepath.Join(dir, "audit")
	args := []string{"watch", "--process", strconv.Itoa(result.PID), "--workspace", workspace,
		"--goal", "Synthetic platform QA: edit one fixture file and echo fixed bytes over loopback", "--no-llm",
		"--port", "0", "--duration", "24s", "--interval", "1s", "--out", audit}
	if name == "connect" {
		args = append(args, "--proxy-port", "0")
	}
	watch := exec.CommandContext(ctx, binary, args...)
	var watchOutput lockedBuffer
	watch.Stdout = &watchOutput
	watchErr, err := os.Create(filepath.Join(dir, "bma.stderr"))
	if err != nil {
		return result, err
	}
	defer watchErr.Close()
	watch.Stderr = watchErr
	watchRun, err := start(watch)
	if err != nil {
		return result, err
	}
	defer func() {
		watchRun.stop()
		_ = os.WriteFile(filepath.Join(dir, "bma.stdout"), []byte(watchOutput.String()), 0600)
	}()
	err = waitFor(ctx, 8*time.Second, func() bool {
		data, _ := os.ReadFile(filepath.Join(audit, "events.jsonl"))
		return bytes.Contains(data, []byte(`"kind":"watch_ready"`))
	})
	if err != nil {
		return result, fmt.Errorf("watch readiness: %w", err)
	}
	cfg := fixtureConfig{Workspace: workspace, Endpoint: listener.Addr().String()}
	if name == "connect" {
		match := regexp.MustCompile(`可选代理：http://(127\.0\.0\.1:[0-9]+)`).FindStringSubmatch(watchOutput.String())
		if len(match) != 2 {
			return result, fmt.Errorf("proxy address missing")
		}
		cfg.Proxy = match[1]
	}
	if err := json.NewEncoder(input).Encode(cfg); err != nil {
		return result, err
	}
	if err := waitFor(ctx, 8*time.Second, func() bool { return strings.Contains(childOutput.String(), "connected") }); err != nil {
		return result, fmt.Errorf("fixture connection: %w", err)
	}
	if runtime.GOOS == "darwin" {
		// Both commands select only the explicitly spawned fixture PID.
		diagnostic(ctx, dir, "nettop", "-n", "-P", "-x", "-L", "1", "-J", "bytes_in,bytes_out", "-p", strconv.Itoa(result.PID))
		diagnostic(ctx, dir, "lsof", "-nP", "-a", "-p", strconv.Itoa(result.PID), "-F", "pcfn")
		diagnostic(ctx, dir, "sw_vers")
	}
	// Establish a baseline on the connected but idle socket.
	select {
	case <-time.After(3 * time.Second):
	case <-ctx.Done():
		return result, ctx.Err()
	}
	if _, err := io.WriteString(input, "transfer\n"); err != nil {
		return result, err
	}
	select {
	case <-fixtureRun.done:
	case <-ctx.Done():
		return result, ctx.Err()
	}
	if fixtureRun.err != nil {
		return result, fmt.Errorf("fixture failed; see fixture.stderr: %w", fixtureRun.err)
	}
	select {
	case got := <-echo:
		result.Received = got.bytes
		if got.err != nil {
			return result, got.err
		}
	case <-ctx.Done():
		return result, ctx.Err()
	}
	select {
	case <-watchRun.done:
	case <-ctx.Done():
		return result, ctx.Err()
	}
	if watchRun.err != nil {
		return result, fmt.Errorf("watch failed; see bma.stderr: %w", watchRun.err)
	}
	r, err := report.ReadJSON(filepath.Join(audit, "report.json"))
	if err != nil {
		return result, err
	}
	validate(&result, r, filepath.Join(workspace, "fixture.txt"))
	content, contentErr := os.ReadFile(filepath.Join(workspace, "fixture.txt"))
	result.Checks["actual_file_content"] = contentErr == nil && string(content) == "local fixture step 31\n"
	html, htmlErr := os.Stat(filepath.Join(audit, "report.html"))
	result.Checks["html_present"] = htmlErr == nil && html.Size() > 0
	if runtime.GOOS != "windows" {
		for _, path := range []string{audit, filepath.Join(audit, "events.jsonl"), filepath.Join(audit, "report.json"), filepath.Join(audit, "report.html")} {
			info, err := os.Stat(path)
			result.Checks["private_"+filepath.Base(path)] = err == nil && info.Mode().Perm()&0077 == 0
		}
	}
	for check, passed := range result.Checks {
		if !passed {
			err = errors.Join(err, fmt.Errorf("check failed: %s", check))
		}
	}
	return result, err
}

func validate(result *phaseResult, r report.Report, target string) {
	checks := result.Checks
	checks["report_stopped"] = r.Status == "stopped"
	checks["endpoint_received_exact_payload"] = result.Received == payloadBytes
	checks["selected_process_observed"], checks["file_change"], checks["loopback_connection"] = false, false, false
	checks["file_attribution"], checks["only_selected_pid"], checks["only_loopback_destinations"] = true, true, true
	checks["no_model_request"] = r.Analysis == nil && r.AnalysisRequest == nil
	if runtime.GOOS == "darwin" {
		checks["open_file_observed"] = false
	}
	for _, e := range r.Events {
		if e.Process.PID != 0 && e.Process.PID != result.PID {
			checks["only_selected_pid"] = false
		}
		if e.Kind == "process_observed" && e.Process.PID == result.PID && e.Process.CreatedAtMS > 0 {
			checks["selected_process_observed"] = true
		}
		if (e.Kind == "file_create" || e.Kind == "file_modify") && e.Detail["path"] == target {
			checks["file_change"] = true
			if e.Attribution != "temporal" || e.Process.PID != 0 {
				checks["file_attribution"] = false
			}
		}
		if ip, ok := e.Detail["remote_ip"].(string); ok && ip != "" {
			if !net.ParseIP(ip).IsLoopback() {
				checks["only_loopback_destinations"] = false
			} else if e.Kind == "connection_observed" && e.Process.PID == result.PID {
				checks["loopback_connection"] = true
			}
		}
		if e.Kind == "collector_error" {
			result.Gaps = append(result.Gaps, map[string]any{"source": e.Detail["source"], "reason": e.Detail["reason"]})
		}
		if e.Kind == "egress" && e.Process.PID == result.PID {
			out, in := number(e, "bytes_out"), number(e, "bytes_in")
			if e.Detail["source"] == "proxy" {
				result.BytesOut += out
				result.BytesIn += in
			}
			if e.Detail["source"] == "nettop" {
				result.NettopOut += out
			}
		}
		if runtime.GOOS == "darwin" && e.Kind == "file_open_observed" && e.Detail["path"] == target {
			checks["open_file_observed"] = true
		}
	}
	if runtime.GOOS == "darwin" {
		checks["nettop_increment_observed"] = result.NettopOut > 0
	}
	if result.Name == "connect" {
		checks["proxy_exact_outbound"] = result.BytesOut == payloadBytes
		checks["proxy_exact_inbound"] = result.BytesIn == payloadBytes
	}
}

func number(e event.Event, key string) uint64 {
	// The controlled fixture stays far below the exact integer float64 limit.
	v, ok := e.Detail[key].(float64)
	if !ok || v < 0 || v > 1<<53-1 || math.IsNaN(v) || math.Trunc(v) != v {
		return 0
	}
	return uint64(v)
}

func diagnostic(ctx context.Context, dir, name string, args ...string) {
	ctx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	data, err := exec.CommandContext(ctx, name, args...).CombinedOutput()
	_ = os.WriteFile(filepath.Join(dir, name+".txt"), data, 0600)
	if err != nil {
		_ = os.WriteFile(filepath.Join(dir, name+".error.txt"), []byte(err.Error()), 0600)
	}
}

func waitFor(ctx context.Context, timeout time.Duration, ready func() bool) error {
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	for !ready() {
		select {
		case <-time.After(50 * time.Millisecond):
		case <-ctx.Done():
			return ctx.Err()
		}
	}
	return nil
}

type lockedBuffer struct {
	sync.Mutex
	data bytes.Buffer
}

func (b *lockedBuffer) Write(p []byte) (int, error) {
	b.Lock()
	defer b.Unlock()
	return b.data.Write(p)
}
func (b *lockedBuffer) String() string { b.Lock(); defer b.Unlock(); return b.data.String() }
