"""Audit WorkBuddy's bundled CLI on macOS against a local OpenAI fixture.

This does not exercise the desktop UI or a real model. Only a new workspace,
new configuration and the explicitly launched CLI PID are observed.
"""
import argparse
from datetime import datetime, timezone
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import platform
import socket
import subprocess
import threading
import time
import uuid

from verify_claude import CountedInput, wait_until


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('node', 'cli', 'bma', 'out'):
        parser.add_argument('--' + name, required=True, type=Path)
    args = parser.parse_args()
    if platform.system() != 'Darwin':
        parser.error('Run this fixture on macOS')
    os.umask(0o077)
    root = args.out.resolve()
    root.mkdir()
    workspace, config, audit = (root / n for n in ('workspace', 'config', 'audit'))
    workspace.mkdir()
    config.mkdir()
    target = workspace / 'fixture.txt'
    before, after = 'BMA original local fixture\n', 'BMA audited local fixture\n'
    target.write_text(before)
    requests, errors = [], []
    phase = 'seed'
    session = str(uuid.uuid4())

    class Handler(BaseHTTPRequestHandler):
        def setup(self):
            super().setup()
            self.connection.settimeout(20)
            self.rfile = CountedInput(self.rfile)

        def log_message(self, *args):
            pass

        def do_POST(self):
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if not 0 < size <= 4 * 1024 * 1024:
                    raise ValueError('invalid body size')
                body = json.loads(self.rfile.read(size))
                if self.path != '/v1/chat/completions':
                    raise ValueError('unexpected endpoint')
                results = [m for m in body['messages'] if m['role'] == 'tool']
                stage = len(results)
                available = [t['function']['name'] for t in body.get('tools', [])]
                requests.append({'phase': phase, 'http_bytes_received': self.rfile.total,
                                 'body_bytes': size, 'completed_tools': stage,
                                 'available_tools': available, 'stream': body.get('stream')})
                if len(requests) > 4 or stage > 2:
                    raise ValueError('unexpected request count')
                if set(available) != ({'Read', 'Edit'} if phase == 'action' else set()):
                    raise ValueError('unexpected tool scope: ' + repr(available))
                name = ('Read', 'Edit')[stage] if phase == 'action' and stage < 2 else None
                arguments = {'file_path': str(target)}
                if name == 'Edit':
                    arguments.update(old_string=before, new_string=after)
                delta = {'role': 'assistant'}
                if name:
                    delta['tool_calls'] = [{'index': 0, 'id': 'bma_' + name,
                        'type': 'function', 'function': {'name': name,
                        'arguments': json.dumps(arguments)}}]
                else:
                    delta['content'] = 'Local fixture complete.'
                finish = 'tool_calls' if name else 'stop'
                self.send_response(200)
                self.send_header('Content-Type', 'text/event-stream')
                self.send_header('Connection', 'close')
                self.end_headers()
                for content, reason in ((delta, None), ({}, finish)):
                    chunk = {'id': 'bma-fixture', 'object': 'chat.completion.chunk',
                        'created': int(time.time()), 'model': body['model'],
                        'choices': [{'index': 0, 'delta': content, 'finish_reason': reason}]}
                    self.wfile.write(('data: ' + json.dumps(chunk) + '\n\n').encode())
                self.wfile.write(b'data: [DONE]\n\n')
                self.wfile.flush()
            except Exception as exc:
                errors.append(type(exc).__name__ + ': ' + str(exc))
                self.send_error(400, 'Local fixture protocol error')

    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    endpoint = 'http://127.0.0.1:%d/v1/chat/completions' % server.server_port
    model = {'id': 'bma-fixture', 'name': 'BMA local fixture', 'vendor': 'OpenAI',
             'apiKey': 'bma-not-a-real-key', 'url': endpoint,
             'maxInputTokens': 32000, 'maxOutputTokens': 1024,
             'supportsToolCall': True, 'supportsImages': False,
             'relatedModels': {n: 'bma-fixture' for n in ('lite', 'reasoning', 'vision', 'longContext', 'subagent')}}
    (config / 'models.json').write_text(json.dumps({'models': [model], 'availableModels': ['bma-fixture']}))
    env = {k: v for k, v in os.environ.items() if k in ('HOME', 'PATH', 'TMPDIR', 'LANG')}
    env.update(CODEBUDDY_CONFIG_DIR=str(config), WORKBUDDY_CONFIG_DIR=str(config),
               CODEBUDDY_API_KEY='bma-not-a-real-key', CODEBUDDY_BASE_URL=endpoint.rsplit('/', 1)[0],
               DISABLE_TELEMETRY='1', DISABLE_ERROR_REPORTING='1', DISABLE_AUTOUPDATER='1',
               CODEBUDDY_DISABLE_COMPILE_CACHE='1', CODEBUDDY_DISABLE_SHELL_SNAPSHOT='1',
               CODEBUDDY_DISABLE_AUTO_MEMORY='1', CODEBUDDY_DISABLE_BACKGROUND_TASKS='1',
               CODEBUDDY_DISABLE_CRON='1', CODEBUDDY_DISABLE_HOT_RELOAD='1')
    command = [str(args.node.resolve()), str(args.cli.resolve())]
    version = subprocess.check_output(command + ['--version'], env=env, cwd=workspace, timeout=20).decode().strip()
    base = command + ['--print', '--model', 'bma-fixture', '--strict-mcp-config',
                      '--mcp-config', '{"mcpServers":{}}', '--setting-sources', '',
                      '--system-prompt', 'Use only the supplied Read and Edit tools for this local test.']
    # Let the real CLI create its own session file before BMA selects it.
    with (root / 'seed.stdout').open('wb') as out, (root / 'seed.stderr').open('wb') as err:
        subprocess.run(base + ['--session-id', session, '--tools', '', 'Initialize this local test.'],
                       env=env, cwd=workspace, stdout=out, stderr=err, check=True, timeout=25)
    logs = list(config.glob('projects/**/' + session + '.jsonl'))
    if len(logs) != 1:
        raise RuntimeError('Expected one CLI-created isolated session log')
    log = logs[0]
    phase = 'action'
    with socket.socket() as reservation:
        reservation.bind(('127.0.0.1', 0))
        proxy_port = reservation.getsockname()[1]
    env.update(HTTP_PROXY='http://127.0.0.1:%d' % proxy_port,
               HTTPS_PROXY='http://127.0.0.1:%d' % proxy_port, NO_PROXY='')
    child = watcher = None
    verification = {'passed': False, 'cli_version': version, 'uid': os.getuid(),
                    'machine': platform.machine(), 'bma_sha256': hashlib.sha256(args.bma.read_bytes()).hexdigest(),
                    'cli_launcher_sha256': hashlib.sha256(args.cli.read_bytes()).hexdigest(),
                    'cli_bundle_sha256': hashlib.sha256((args.cli.parent.parent / 'dist/codebuddy.js').read_bytes()).hexdigest(),
                    'limits': ['bundled CLI, not desktop UI', 'model endpoint is a loopback fixture',
                               'external app traffic is recorded separately; encrypted content is unknown',
                               'no paid model or deliberate external file upload']}
    try:
        with (root / 'cli.stdout').open('wb') as cout, (root / 'cli.stderr').open('wb') as cerr, (root / 'bma.stdout').open('wb') as bout, (root / 'bma.stderr').open('wb') as berr:
            child = subprocess.Popen(base + ['--resume', session,
                '--tools', 'Read,Edit', '--allowedTools', 'Read,Edit',
                '--permission-mode', 'acceptEdits', '--max-turns', '3',
                '--input-format', 'stream-json', '--output-format', 'stream-json', '--verbose'],
                cwd=workspace, env=env, stdin=subprocess.PIPE, stdout=cout, stderr=cerr)
            watcher = subprocess.Popen([str(args.bma.resolve()), 'watch', '--process', str(child.pid),
                '--workspace', str(workspace), '--goal', 'Read and edit fixture.txt only.',
                '--agent-log', str(log), '--agent-format', 'workbuddy',
                '--proxy-port', str(proxy_port), '--port', '0', '--duration', '30s',
                '--interval', '100ms', '--no-llm', '--out', str(audit)],
                cwd=workspace, stdout=bout, stderr=berr)

            def ready():
                if watcher.poll() is not None:
                    raise RuntimeError('BMA exited before readiness')
                p = audit / 'events.jsonl'
                return p.exists() and '"watch_ready"' in p.read_text()

            wait_until(ready, 'file watcher readiness')
            time.sleep(2)  # Allow nettop to establish its initial baseline.
            prompt = {'type': 'user', 'message': {'role': 'user', 'content':
                'Read fixture.txt, then replace its original text with the audited local test content. Access no other files.'}}
            child.stdin.write((json.dumps(prompt) + '\n').encode())
            child.stdin.flush()
            wait_until(lambda: len(requests) >= 4 or child.poll() is not None or errors,
                       'Read/Edit fixture completion', timeout=22)
            child.stdin.close()
            verification['cli_exit'] = child.wait(timeout=12)
            verification['bma_exit'] = watcher.wait(timeout=35)
        report = json.loads((audit / 'report.json').read_text())
        events = report['events']
        local_proxy = [e for e in events if e['kind'] == 'egress'
                       and e['detail'].get('proxy') and e['detail'].get('remote_host') == '127.0.0.1:%d' % server.server_port]
        proxy_bytes = sum(e['detail']['bytes_out'] for e in local_proxy)
        action_requests = [r for r in requests if r['phase'] == 'action']
        received = sum(r['http_bytes_received'] for r in action_requests)
        actions = [e for e in events if e['kind'] == 'claimed_action' and e['detail'].get('source') == 'workbuddy']
        source_lines = log.read_text().splitlines()
        provenance = all(json.loads(source_lines[e['detail']['log_line'] - 1])['callId'] == e['detail']['call_id']
                         and json.loads(source_lines[e['detail']['log_line'] - 1])['name'] == e['detail']['tool']
                         and round(datetime.strptime(e['ts'], '%Y-%m-%dT%H:%M:%S.%fZ' if '.' in e['ts'] else '%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=timezone.utc).timestamp() * 1000)
                         == json.loads(source_lines[e['detail']['log_line'] - 1])['timestamp']
                         for e in actions)
        files = [e for e in events if e['kind'] == 'file_modify' and e['detail'].get('path') == str(target)]
        external = {}
        for e in events:
            d = e.get('detail') or {}
            if e['kind'] == 'egress' and d.get('proxy') and d.get('remote_host') != '127.0.0.1:%d' % server.server_port:
                host = d.get('remote_host', '')
                external[host] = external.get(host, 0) + d['bytes_out']
        goals = [e['detail'].get('text', '') for e in events if e['kind'] == 'goal' and e['detail'].get('source') == 'workbuddy']
        goal_verified = goals.count(prompt['message']['content']) == 1 and not any(before.strip() in g or after.strip() in g for g in goals)
        preview_path = root / 'preview.json'
        subprocess.run([str(args.bma.resolve()), 'analyze', str(audit / 'report.json'),
                        '--dry-run-llm', '--redact-goal', '--out', str(preview_path)],
                       stdout=subprocess.DEVNULL, check=True, timeout=20)
        preview = json.loads(preview_path.read_text())
        bodies = preview['analysis_preview']['request_bodies']
        redacted = bool(bodies) and not any(secret in body for body in bodies
                     for secret in (before.strip(), after.strip(), str(workspace), 'fixture.txt', prompt['message']['content']))
        private = all(p.stat().st_mode & 0o077 == 0 for p in (audit, audit / 'report.json', audit / 'report.html', log))
        verification.update(file_changed=target.read_text() == after, requests=requests,
                            errors=errors, event_kinds=sorted(set(e['kind'] for e in events)),
                            proxy_bytes_out=proxy_bytes, fixture_http_bytes_received=received,
                            external_proxy_bytes_out=external, actual_tool_calls=[e['detail']['tool'] for e in actions],
                            session_log=str(log.relative_to(root)), log_provenance_verified=provenance,
                            session_log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
                            goal_verified=goal_verified, preview_redaction_verified=redacted,
                            private_permissions_verified=private,
                            file_records=len(files), collection_gaps=[e['detail'] for e in events if e['kind'] == 'collector_error'])
        verification['passed'] = (verification['cli_exit'] == 0 and verification['bma_exit'] == 0
            and verification['file_changed'] and len(requests) == 4 and not errors
            and [r['completed_tools'] for r in action_requests] == [0, 1, 2]
            and proxy_bytes == received and received > 0 and provenance
            and goal_verified and redacted and private
            and verification['actual_tool_calls'] == ['Read', 'Edit'] and bool(files)
            and all(e['attribution'] == 'temporal' and e['process']['pid'] is None for e in files)
            and all(e['process']['pid'] == child.pid for e in local_proxy)
            and not any(e['kind'] == 'collector_error' and e['detail'].get('source') == 'workbuddy' for e in events))
        if not verification['passed']:
            raise RuntimeError('WorkBuddy fixture checks failed')
    except Exception as exc:
        verification['failure'] = type(exc).__name__ + ': ' + str(exc)
        raise
    finally:
        for proc in (child, watcher):
            if proc is not None and proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()
        server.shutdown()
        server.server_close()
        verification.update(requests=requests, errors=errors)
        (root / 'verification.json').write_text(json.dumps(verification, indent=2) + '\n')
        print(root / 'verification.json')


if __name__ == '__main__':
    main()
