module behavior-monitoring-audit

go 1.26.0

require (
	github.com/fsnotify/fsnotify v1.7.0
	github.com/shirou/gopsutil/v4 v4.25.6
	go.yaml.in/yaml/v3 v3.0.5
	golang.org/x/sys v0.28.0
)

require (
	github.com/ebitengine/purego v0.8.4 // indirect
	github.com/go-ole/go-ole v1.2.6 // indirect
	github.com/lufia/plan9stats v0.0.0-20211012122336-39d0f177ccd0 // indirect
	github.com/power-devops/perfstat v0.0.0-20210106213030-5aafc221ea8c // indirect
	github.com/tklauser/go-sysconf v0.3.12 // indirect
	github.com/tklauser/numcpus v0.6.1 // indirect
	github.com/yusufpapurcu/wmi v1.2.4 // indirect
)
