package destination

import (
	"encoding/json"
	"net/netip"
	"strings"
	"testing"
)

func TestBuiltInStorageSnapshotAndLiteralIPInputs(t *testing.T) {
	snapshot, err := ParseRangeSnapshot(rangeData)
	if err != nil || len(snapshot.Sources) != 2 {
		t.Fatal("invalid embedded source data", err)
	}
	for _, source := range snapshot.Sources {
		for _, prefix := range source.Prefixes {
			ip := netip.MustParsePrefix(prefix).Addr()
			matches, field := MatchIP("", ip.String())
			found := false
			for _, match := range matches {
				if match.Service == source.Service {
					found = true
					if match.SourceURL != source.URL || match.SHA256 != source.SHA256 || match.PublishedAt != source.PublishedAt || field != "remote_ip" {
						t.Fatal("lost source provenance")
					}
				}
			}
			if !found {
				t.Fatalf("embedded prefix not searchable: %s", prefix)
			}
		}
	}
	for _, tc := range []struct{ input, service string }{
		{"3.5.140.1", "AWS S3"}, {"3.5.140.1:443", "AWS S3"}, {"::ffff:3.5.140.1", "AWS S3"},
		{"[2406:daf9:a800::1]:443", "AWS S3"}, {"13.65.107.33", "Azure Storage"},
	} {
		matches, field := MatchIP(tc.input, "")
		if len(matches) != 1 || matches[0].Service != tc.service || field != "remote_host" {
			t.Fatalf("literal IP failed: %s %+v", tc.input, matches)
		}
	}
	for _, input := range []string{"192.0.2.1", "2001:db8::1", "127.0.0.1", "10.1.1.1", "169.254.1.1", "::1", "fe80::1%3", "3.5.140.1:0", "3.5.140.1:65536", " 3.5.140.1", "https://3.5.140.1", "bucket.s3.amazonaws.com", "api.cloudflare.com", "aggregate"} {
		if matches, _ := MatchIP(input, ""); len(matches) != 0 {
			t.Fatalf("unknown or invalid input classified: %s", input)
		}
	}
	if matches, _ := MatchIP("3.5.140.1", "invalid-recorded-ip"); len(matches) != 0 {
		t.Fatal("invalid explicit IP was silently replaced by another field")
	}
}

func TestRangeBoundariesAndSharedServicePrefixes(t *testing.T) {
	index := indexRanges(RangeSnapshot{Sources: []RangeSource{
		{Service: "AWS S3", Prefixes: []string{"203.0.113.0/24", "203.0.113.128/25", "2001:db8::/126"}},
		{Service: "Azure Storage", Prefixes: []string{"203.0.113.128/26"}},
	}})
	for _, tc := range []struct {
		ip     string
		count  int
		prefix string
	}{
		{"203.0.112.255", 0, ""}, {"203.0.113.0", 1, "203.0.113.0/24"},
		{"203.0.113.127", 1, "203.0.113.0/24"}, {"203.0.113.128", 2, "203.0.113.128/26"},
		{"203.0.113.191", 2, "203.0.113.128/26"}, {"203.0.113.192", 1, "203.0.113.128/25"},
		{"203.0.113.255", 1, "203.0.113.128/25"}, {"203.0.114.0", 0, ""},
		{"2001:db8::", 1, "2001:db8::/126"}, {"2001:db8::3", 1, "2001:db8::/126"}, {"2001:db8::4", 0, ""},
	} {
		got := index.lookup(netip.MustParseAddr(tc.ip))
		if len(got) != tc.count || (tc.count > 0 && got[0].Prefix != tc.prefix) {
			t.Fatalf("boundary %s: %+v", tc.ip, got)
		}
	}
}

func TestSnapshotRejectsInvalidSourceAndPrefix(t *testing.T) {
	for _, change := range []func(*RangeSnapshot){
		func(s *RangeSnapshot) { s.Sources[0].URL = "https://example.com/ranges.json" },
		func(s *RangeSnapshot) { s.Sources[0].SHA256 = "not-a-digest" },
		func(s *RangeSnapshot) { s.Sources[0].PublishedAt = "unknown" },
		func(s *RangeSnapshot) { s.Sources[0].RetrievedAt = "2000-01-01T00:00:00Z" },
		func(s *RangeSnapshot) { s.Sources[0].Prefixes = []string{"3.5.140.1/24"} },
		func(s *RangeSnapshot) { s.Sources[0].Prefixes = []string{"0.0.0.0/0"} },
		func(s *RangeSnapshot) { s.Sources[0].Prefixes = []string{"10.0.0.0/8"} },
		func(s *RangeSnapshot) {
			s.Sources[0].Prefixes = append(s.Sources[0].Prefixes, s.Sources[0].Prefixes[0])
		},
	} {
		var snapshot RangeSnapshot
		if err := json.Unmarshal(rangeData, &snapshot); err != nil {
			t.Fatal(err)
		}
		change(&snapshot)
		raw, _ := json.Marshal(snapshot)
		if _, err := ParseRangeSnapshot(raw); err == nil {
			t.Fatal("invalid snapshot accepted")
		}
	}
	for _, suffix := range []string{"{}", "garbage"} {
		if _, err := ParseRangeSnapshot(append(append([]byte{}, rangeData...), []byte(suffix)...)); err == nil {
			t.Fatal("trailing data accepted")
		}
	}
	if !strings.Contains(strings.Join(SnapshotSummary(), " "), "Azure Storage") {
		t.Fatal("missing source disclosure")
	}
}

func BenchmarkBuiltInIPMatch(b *testing.B) {
	for b.Loop() {
		MatchIP("", "3.5.140.1")
	}
}
