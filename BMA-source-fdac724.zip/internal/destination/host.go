// Package destination classifies address hints without making DNS requests.
// A hostname match is not proof of an HTTP request or an upload.
package destination

import (
	"net"
	"net/netip"
	"regexp"
	"strconv"
	"strings"
)

const (
	Unknown       = "unknown"
	ObjectStorage = "object_storage"
	ModelAPI      = "model_api"
)

// Hostname accepts a DNS name or host:port, not a URL, wildcard or IP address.
// Rejecting malformed names prevents substring and suffix lookalike matches.
func Hostname(address string) string {
	if strings.Contains(address, ":") {
		host, port, err := net.SplitHostPort(address)
		if err != nil {
			return ""
		}
		n, err := strconv.ParseUint(port, 10, 16)
		if err != nil || n == 0 {
			return ""
		}
		address = host
	}
	address = strings.TrimSuffix(strings.ToLower(address), ".")
	if len(address) == 0 || len(address) > 253 {
		return ""
	}
	if _, err := netip.ParseAddr(address); err == nil {
		return ""
	}
	for _, label := range strings.Split(address, ".") {
		if len(label) == 0 || len(label) > 63 || label[0] == '-' || label[len(label)-1] == '-' {
			return ""
		}
		for _, c := range label {
			if !(c >= 'a' && c <= 'z' || c >= '0' && c <= '9' || c == '-') {
				return ""
			}
		}
	}
	return address
}

// These are service-specific DNS forms, never whole cloud-provider domains.
// Region names are deliberately syntactic hints, not an online region registry.
var storagePatterns = []*regexp.Regexp{
	regexp.MustCompile(`^(?:[a-z0-9.-]+\.)?(?:s3|s3-accelerate(?:\.dualstack)?|s3(?:-fips)?[.-][a-z]{2}(?:-[a-z]+)+-[0-9]+|s3(?:-fips)?\.dualstack\.[a-z]{2}(?:-[a-z]+)+-[0-9]+)\.amazonaws\.com(?:\.cn)?$`),
	regexp.MustCompile(`^(?:[a-z0-9.-]+\.)?oss(?:-[a-z0-9-]+)?\.aliyuncs\.com$`),
	regexp.MustCompile(`^(?:[a-z0-9.-]+\.)?storage\.googleapis\.com$`),
	regexp.MustCompile(`^storage\.cloud\.google\.com$`),
	regexp.MustCompile(`^[a-z0-9-]+\.blob\.core\.windows\.net$`),
	regexp.MustCompile(`^[a-z0-9-]+(?:\.(?:eu|fedramp))?\.r2\.cloudflarestorage\.com$`),
	regexp.MustCompile(`^[a-z0-9-]+\.r2\.dev$`),
}

func Classify(address string, modelHosts []string) string {
	host := Hostname(address)
	if host == "" {
		return Unknown
	}
	for _, model := range modelHosts {
		if host == model {
			return ModelAPI
		}
	}
	for _, pattern := range storagePatterns {
		if pattern.MatchString(host) {
			return ObjectStorage
		}
	}
	return Unknown
}
