package destination

import "testing"

func TestStorageServiceHosts(t *testing.T) {
	for _, host := range []string{
		"s3.amazonaws.com", "bucket.s3.amazonaws.com:443", "BUCKET.S3.AMAZONAWS.COM.",
		"bucket.s3.us-west-2.amazonaws.com", "bucket.s3-us-west-2.amazonaws.com",
		"bucket.s3.dualstack.us-west-2.amazonaws.com", "bucket.s3.cn-north-1.amazonaws.com.cn",
		"bucket.s3-accelerate.dualstack.amazonaws.com", "bucket.s3-fips.us-gov-west-1.amazonaws.com",
		"oss.aliyuncs.com", "bucket.oss-cn-hangzhou.aliyuncs.com", "cn-beijing.oss.aliyuncs.com",
		"bucket.oss-accelerate.aliyuncs.com", "storage.googleapis.com", "bucket.storage.googleapis.com",
		"storage.cloud.google.com", "myaccount.blob.core.windows.net", "account.r2.cloudflarestorage.com",
		"account.eu.r2.cloudflarestorage.com", "pub-example.r2.dev",
	} {
		t.Run(host, func(t *testing.T) {
			if got := Classify(host, nil); got != ObjectStorage {
				t.Fatalf("got %s", got)
			}
		})
	}
}

func TestUnknownAndLookalikeAddresses(t *testing.T) {
	for _, host := range []string{
		"amazonaws.com", "bedrock-runtime.us-east-1.amazonaws.com", "ec2.us-east-1.amazonaws.com",
		"aliyuncs.com", "dashscope.aliyuncs.com", "googleapis.com", "generativelanguage.googleapis.com",
		"cloudflare.com", "api.cloudflare.com", "blob.core.windows.net", "192.0.2.1", "192.0.2.1:443",
		"2001:db8::1", "[2001:db8::1]:443", "aggregate", "",
		"bucket.s3.amazonaws.com.evil.example", "evilamazonaws.com", "notstorage.googleapis.com",
		"evilblob.core.windows.net", "blob.core.windows.net.evil.example", "bucket.oss.aliyuncs.com.evil.example",
		"cloudflare.attacker.example", "r2.dev.evil.example", "s3.attacker.example",
		"bucket..s3.amazonaws.com", "https://bucket.s3.amazonaws.com", "user@bucket.s3.amazonaws.com",
		"bucket.s3.amazonaws.com/path", "bucket.s3.amazonaws.com:0", "bucket.s3.amazonaws.com:65536",
		"bucket.s3.amazonaws.com:https", " bucket.s3.amazonaws.com", "bucket.s3.amazonaws.com..",
		"-bucket.s3.amazonaws.com", "bucket.s3.other.service.amazonaws.com",
	} {
		t.Run(host, func(t *testing.T) {
			if got := Classify(host, nil); got != Unknown {
				t.Fatalf("got %s", got)
			}
		})
	}
}

func TestModelHostsAreExactAndExplicit(t *testing.T) {
	hosts := []string{"api.example.com", "model.storage.googleapis.com"}
	for _, host := range []string{"API.EXAMPLE.COM.:443", "api.example.com", "model.storage.googleapis.com"} {
		if Classify(host, hosts) != ModelAPI {
			t.Fatalf("not classified: %s", host)
		}
	}
	for _, host := range []string{"sub.api.example.com", "api.example.com.evil.example", "other.example.com"} {
		if Classify(host, hosts) != Unknown {
			t.Fatalf("implicit trust: %s", host)
		}
	}
}
