package destination

import (
	_ "embed"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/netip"
	"net/url"
	"slices"
	"strconv"
	"strings"
	"sync"
	"time"
)

// These are dated address hints, not a current service identity registry.
//
//go:embed data/storage-ranges.json
var rangeData []byte

type RangeSource struct {
	Service     string   `json:"service"`
	URL         string   `json:"url"`
	PublishedAt string   `json:"published_at"`
	RetrievedAt string   `json:"retrieved_at"`
	Revision    string   `json:"revision"`
	SHA256      string   `json:"sha256"`
	Prefixes    []string `json:"prefixes"`
}

type RangeSnapshot struct {
	Sources []RangeSource `json:"sources"`
}

type RangeMatch struct {
	Address     string `json:"address"`
	Service     string `json:"service"`
	Prefix      string `json:"prefix"`
	SourceURL   string `json:"source_url"`
	PublishedAt string `json:"published_at"`
	RetrievedAt string `json:"retrieved_at"`
	Revision    string `json:"revision"`
	SHA256      string `json:"source_sha256"`
}

type rangeIndex struct {
	byPrefix map[netip.Prefix][]RangeMatch
	v4Bits   []int
	v6Bits   []int
}

// ParseRangeSnapshot validates the generated data before indexing or publishing
// it. A broken built-in snapshot must fail, never quietly disable IP hints.
func ParseRangeSnapshot(data []byte) (RangeSnapshot, error) {
	var snapshot RangeSnapshot
	d := json.NewDecoder(strings.NewReader(string(data)))
	d.DisallowUnknownFields()
	if err := d.Decode(&snapshot); err != nil {
		return snapshot, err
	}
	if len(snapshot.Sources) != 2 {
		return snapshot, fmt.Errorf("expected the AWS S3 and Azure Storage snapshots")
	}
	seen := map[string]bool{}
	for _, s := range snapshot.Sources {
		if seen[s.Service] || (s.Service != "AWS S3" && s.Service != "Azure Storage") {
			return snapshot, fmt.Errorf("unknown or duplicate storage service")
		}
		seen[s.Service] = true
		u, err := url.Parse(s.URL)
		if err != nil || u.Scheme != "https" || u.User != nil || u.RawQuery != "" || u.Fragment != "" || (s.Service == "AWS S3" && s.URL != "https://ip-ranges.amazonaws.com/ip-ranges.json") || (s.Service == "Azure Storage" && u.Host != "download.microsoft.com") {
			return snapshot, fmt.Errorf("invalid official snapshot URL")
		}
		layout := time.RFC3339
		if s.Service == "Azure Storage" {
			layout = "2006-01-02" // The dated download identifies a day, not a time.
		}
		published, err := time.Parse(layout, s.PublishedAt)
		if err != nil {
			return snapshot, fmt.Errorf("invalid snapshot publication time")
		}
		retrieved, err := time.Parse(time.RFC3339, s.RetrievedAt)
		if err != nil || retrieved.Before(published) || s.Revision == "" {
			return snapshot, fmt.Errorf("invalid snapshot retrieval time or revision")
		}
		hash, err := hex.DecodeString(s.SHA256)
		if err != nil || len(hash) != 32 || len(s.Prefixes) == 0 || len(s.Prefixes) > 10000 {
			return snapshot, fmt.Errorf("invalid snapshot digest or prefix count")
		}
		prefixes := map[netip.Prefix]bool{}
		for _, raw := range s.Prefixes {
			p, err := netip.ParsePrefix(raw)
			if err != nil || p != p.Masked() || p.Addr().Is4In6() || !p.Addr().IsGlobalUnicast() || p.Addr().IsPrivate() || p.Bits() == 0 || prefixes[p] {
				return snapshot, fmt.Errorf("invalid or duplicate public prefix %q", raw)
			}
			prefixes[p] = true
		}
	}
	if d.Decode(new(any)) != io.EOF {
		return snapshot, fmt.Errorf("trailing snapshot document")
	}
	return snapshot, nil
}

func indexRanges(snapshot RangeSnapshot) rangeIndex {
	index := rangeIndex{byPrefix: map[netip.Prefix][]RangeMatch{}}
	for _, s := range snapshot.Sources {
		for _, raw := range s.Prefixes {
			p := netip.MustParsePrefix(raw)
			index.byPrefix[p] = append(index.byPrefix[p], RangeMatch{Service: s.Service, Prefix: raw, SourceURL: s.URL, PublishedAt: s.PublishedAt, RetrievedAt: s.RetrievedAt, Revision: s.Revision, SHA256: s.SHA256})
			bits := &index.v6Bits
			if p.Addr().Is4() {
				bits = &index.v4Bits
			}
			if !slices.Contains(*bits, p.Bits()) {
				*bits = append(*bits, p.Bits())
			}
		}
	}
	slices.Sort(index.v4Bits)
	slices.Sort(index.v6Bits)
	slices.Reverse(index.v4Bits)
	slices.Reverse(index.v6Bits)
	return index
}

var builtinSnapshot = sync.OnceValue(func() RangeSnapshot {
	snapshot, err := ParseRangeSnapshot(rangeData)
	if err != nil {
		panic(err)
	}
	return snapshot
})

var storageIndex = sync.OnceValue(func() rangeIndex { return indexRanges(builtinSnapshot()) })

func addressIP(raw string) netip.Addr {
	if ip, err := netip.ParseAddr(raw); err == nil && ip.Zone() == "" {
		return ip.Unmap()
	}
	if ap, err := netip.ParseAddrPort(raw); err == nil && ap.Port() != 0 && ap.Addr().Zone() == "" {
		return ap.Addr().Unmap()
	}
	return netip.Addr{}
}

func (index rangeIndex) lookup(ip netip.Addr) []RangeMatch {
	if !ip.IsValid() || !ip.IsGlobalUnicast() || ip.IsPrivate() {
		return nil
	}
	bits := index.v6Bits
	if ip.Is4() {
		bits = index.v4Bits
	}
	var matches []RangeMatch
	seen := map[string]bool{}
	for _, n := range bits {
		for _, match := range index.byPrefix[netip.PrefixFrom(ip, n).Masked()] {
			// Keep the most-specific prefix for each service, but never hide
			// a different service sharing the address space.
			if !seen[match.Service] {
				match.Address = ip.String()
				matches = append(matches, match)
				seen[match.Service] = true
			}
		}
	}
	return matches
}

// MatchIP uses the recorded remote IP when supplied, otherwise a literal IP in
// the recorded target. It never resolves hostnames or accepts imported labels.
func MatchIP(host, remoteIP string) ([]RangeMatch, string) {
	raw, field := remoteIP, "remote_ip"
	if raw == "" {
		raw, field = host, "remote_host"
	}
	matches := storageIndex().lookup(addressIP(raw))
	if len(matches) == 0 {
		return nil, ""
	}
	return matches, field
}

// DescribeRanges discloses the exact dated clue in both HTML and rule JSON.
func DescribeRanges(matches []RangeMatch) string {
	var descriptions []string
	for _, m := range matches {
		descriptions = append(descriptions, m.Address+" ∈ "+m.Service+" "+m.Prefix+"（发布 "+m.PublishedAt+"；获取 "+m.RetrievedAt+"；来源 "+m.SourceURL+"；版本 "+m.Revision+"；SHA-256 "+m.SHA256+"）")
	}
	return strings.Join(descriptions, "；")
}

func SummarizeRanges(matches []RangeMatch) string {
	var summaries []string
	for _, m := range matches {
		summaries = append(summaries, m.Address+" ∈ "+m.Service+" "+m.Prefix+"（快照 "+m.PublishedAt+"）")
	}
	return strings.Join(summaries, "；")
}

// SnapshotSummary contains no address lookup and is safe to show for every
// report, including reports that have no matching connections.
func SnapshotSummary() []string {
	s := builtinSnapshot()
	result := make([]string, 0, len(s.Sources))
	for _, source := range s.Sources {
		result = append(result, source.Service+"：发布 "+source.PublishedAt+"，获取 "+source.RetrievedAt+"，"+strconv.Itoa(len(source.Prefixes))+" 个网段；"+source.URL)
	}
	return result
}
