package report

import (
	"bytes"
	"reflect"
	"strings"
	"testing"

	"behavior-monitoring-audit/internal/rules"
)

func TestPolicyMetadataRoundTripsAndRenders(t *testing.T) {
	cfg := rules.DefaultConfig()
	cfg.Policy = rules.Policy{
		ProtectedDirectories:     []string{"/tmp/protected"},
		SensitiveCategories:      []string{"synthetic-config"},
		AllowedUploadDirectories: []string{"/tmp/protected"},
		AllowedUploadTargets:     []string{"receiver.test:8443"},
	}
	cfg.Authorization = rules.Authorization{State: rules.AuthorizationAuthorized}
	r := NewWithConfig("session", "/tmp/workspace", nil, nil, cfg)
	var output bytes.Buffer
	if err := EncodeJSON(&output, r); err != nil {
		t.Fatal(err)
	}
	decoded, err := decodeJSON(bytes.NewReader(output.Bytes()), int64(output.Len()))
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(decoded.Policy, r.Policy) || decoded.Authorization != r.Authorization {
		t.Fatalf("policy metadata changed across JSON round trip: got %#v %#v want %#v %#v", decoded.Policy, decoded.Authorization, r.Policy, r.Authorization)
	}
	var html bytes.Buffer
	if err := Render(&html, r); err != nil {
		t.Fatal(err)
	}
	for _, value := range []string{"保护范围与授权记录", "authorized", "/tmp/protected", "synthetic-config", "receiver.test:8443"} {
		if !strings.Contains(html.String(), value) {
			t.Fatalf("HTML omitted policy metadata %q", value)
		}
	}
}

func TestLegacyReportWithoutPolicyDefaultsToUnknown(t *testing.T) {
	legacy := `{"tool":"bma","rule_config":{"model_api_hosts":["api.example.com"],"large_bytes":1,"entropy":1,"delete_window_sec":1,"outbound_min_bytes":1,"outbound_inbound_ratio":1,"window_sec":1}}`
	r, err := decodeJSON(strings.NewReader(legacy), int64(len(legacy)))
	if err != nil {
		t.Fatal(err)
	}
	if r.Authorization.State != rules.AuthorizationUnknown {
		t.Fatalf("legacy report authorization became %q", r.Authorization.State)
	}
	if r.Policy.ProtectedDirectories != nil || r.Policy.SensitiveCategories != nil || r.Policy.AllowedUploadDirectories != nil || r.Policy.AllowedUploadTargets != nil {
		t.Fatalf("legacy report acquired policy values: %#v", r.Policy)
	}
}
