package report

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/rules"
)

// Recover reads a bounded session journal without modifying it. The result
// is always marked incomplete: it cannot establish what happened after the
// last durable event. Model requests are restored from their separate journal.
func Recover(dir string) (Report, error) {
	metaFile, err := os.Open(filepath.Join(dir, "session.json"))
	if err != nil {
		return Report{}, err
	}
	defer metaFile.Close()
	info, err := metaFile.Stat()
	if err != nil {
		return Report{}, err
	}
	if !info.Mode().IsRegular() {
		return Report{}, fmt.Errorf("session metadata must be a regular file")
	}
	data, err := io.ReadAll(io.LimitReader(metaFile, maxMetadataBytes+1))
	if err != nil {
		return Report{}, err
	}
	if len(data) > maxMetadataBytes {
		return Report{}, fmt.Errorf("session metadata exceeds 1 MiB")
	}
	var meta journalMetadata
	if err := json.Unmarshal(data, &meta); err != nil {
		return Report{}, fmt.Errorf("invalid session metadata")
	}
	r := meta.Report
	if meta.Format != 1 || r.Tool != "bma" || r.SessionID == "" || len(r.Events) != 0 || r.Status != "recording" || r.Storage.MaxEvents < 2 || r.Storage.MaxEvents > MaxSessionEvents || r.Storage.MaxJournalBytes <= gapReserve || r.Storage.MaxJournalBytes > MaxSessionBytes {
		return Report{}, fmt.Errorf("invalid session metadata or journal limits")
	}
	r.Policy = r.Policy.Normalize()
	r.Authorization = r.Authorization.Normalize()
	r.RuleConfig.Policy = r.RuleConfig.Policy.Normalize()
	r.RuleConfig.Authorization = r.RuleConfig.Authorization.Normalize()
	if r.Policy.ProtectedDirectories == nil && r.Policy.SensitiveCategories == nil && r.Policy.AllowedUploadDirectories == nil && r.Policy.AllowedUploadTargets == nil {
		r.Policy = r.RuleConfig.Policy
	}
	if r.Authorization.State == rules.AuthorizationUnknown && r.RuleConfig.Authorization.State != rules.AuthorizationUnknown {
		r.Authorization = r.RuleConfig.Authorization
	}
	if err := r.RuleConfig.Validate(); err != nil {
		return Report{}, err
	}
	journal := filepath.Join(dir, "events.jsonl")
	before, err := os.Stat(journal)
	if err != nil {
		return Report{}, err
	}
	// Materialize Windows' lazily loaded file ID before reading. This also
	// makes replacement with a same-size file detectable in the final check.
	if !os.SameFile(before, before) {
		return Report{}, fmt.Errorf("cannot identify journal file")
	}
	events, truncated, err := event.LoadJSONLRecoverable(journal, r.Storage.MaxJournalBytes, r.Storage.MaxEvents)
	if err != nil {
		return Report{}, err
	}
	after, err := os.Stat(journal)
	if err != nil {
		return Report{}, err
	}
	if !os.SameFile(before, after) || before.Size() != after.Size() || !before.ModTime().Equal(after.ModTime()) {
		return Report{}, fmt.Errorf("journal changed during recovery; stop observation before retrying")
	}
	ids := map[string]bool{}
	for _, e := range events {
		if e.SessionID != r.SessionID || ids[e.ID] {
			return Report{}, fmt.Errorf("journal has mixed sessions or duplicate event IDs")
		}
		ids[e.ID] = true
	}
	r.Events = append(events, event.New(r.SessionID, "file", event.Process{Name: "collector"}, "collector_error", "direct", map[string]any{
		"source": "journal_recovery", "coverage": "incomplete", "recovered_events": len(events), "truncated_last_record": truncated,
		"reason": "only complete journal records restored; later activity and unrecorded request outcomes are unknown",
	}))
	r.Status = "recovered"
	r.GeneratedAt = time.Now().UTC()
	r.Analysis, r.AnalysisRequest, r.AnalysisPreview = nil, nil, nil
	r.AnalysisError = ""
	r.RecoveredRequests = nil
	requests, err := ReadRequestJournal(filepath.Join(dir, "model-requests.jsonl"), r.SessionID)
	if err != nil && !errors.Is(err, os.ErrNotExist) {
		return Report{}, err
	}
	if err == nil {
		r.RecoveredRequests = requests
	}
	r.Storage.JournalBytes = after.Size()
	r.Findings = rules.EvaluateWithConfig(r.Events, r.RuleConfig)
	r.Limitations = append(r.Limitations, "恢复报告只包含完整落盘的记录，不能证明采集完整。模型请求独立日志若存在则一并恢复；只有准备记录的批次，是否发送及结果均未知。模型结论不从请求日志重建。")
	return r, nil
}

// RecoverRequests restores a standalone analyze archive without pretending it
// contains the original observation session or any validated model findings.
func RecoverRequests(path string) (Report, error) {
	archive, err := ReadRequestJournal(path, "")
	if err != nil {
		return Report{}, err
	}
	if archive.SessionID == "" {
		return Report{}, fmt.Errorf("request journal has no complete record identifying its session")
	}
	r := New(archive.SessionID, "未知（仅恢复模型请求日志）", nil, nil)
	r.Status = "recovered"
	r.RecoveredRequests = archive
	r.Limitations = []string{"只恢复完整落盘的模型请求记录；不包含原会话事件或模型结论，不能据此判断 Agent 行为。只有准备记录的批次，是否发送及结果均未知。"}
	return r, nil
}
