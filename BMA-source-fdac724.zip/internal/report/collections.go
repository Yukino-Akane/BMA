package report

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"net/url"
	"strconv"
	"strings"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/rules"
)

const collectionPageSize = 25

var collectionKinds = []string{"rules", "model", "requests", "preview", "recovered", "gaps", "traffic", "batches", "review", "review_requests", "review_preview", "review_traffic"}

type collectionRow struct {
	Key           string   `json:"key"`
	Index         int      `json:"index"`
	Title         string   `json:"title"`
	Description   string   `json:"description"`
	Meta          string   `json:"meta"`
	Severity      string   `json:"severity"`
	EvidenceIDs   []string `json:"evidence_ids"`
	EvidenceCount int      `json:"evidence_count"`
	Body          string   `json:"body,omitempty"`
	HasBody       bool     `json:"has_body"`
}

type collectionView struct {
	Kind  string          `json:"kind"`
	Page  int             `json:"page"`
	Pages int             `json:"pages"`
	Total int             `json:"total"`
	Rows  []collectionRow `json:"rows"`
}

func findingDescription(f rules.Finding) string {
	parts := []string{ruleDescription(f.Rule)}
	if f.Conclusion != "" {
		parts = append(parts, "结论："+f.Conclusion)
	}
	if len(f.FilePaths) > 0 {
		parts = append(parts, "文件："+strings.Join(f.FilePaths, "、"))
	}
	if f.Target != "" {
		parts = append(parts, "目标："+f.Target)
	}
	if len(f.Uncertainty) > 0 {
		parts = append(parts, "不确定性："+strings.Join(f.Uncertainty, "；"))
	}
	return strings.Join(parts, " ")
}

func findingMeta(f rules.Finding) string {
	parts := []string{"规则编号：" + f.Rule}
	if f.EvidenceStrength != "" {
		parts = append(parts, "证据强度："+f.EvidenceStrength)
	}
	if f.AuthorizationState != "" {
		parts = append(parts, "授权状态："+f.AuthorizationState)
	}
	if !f.ObservedFrom.IsZero() {
		parts = append(parts, "时间："+f.ObservedFrom.Format("2006-01-02 15:04:05Z07:00"))
		if !f.ObservedTo.IsZero() && !f.ObservedTo.Equal(f.ObservedFrom) {
			parts[len(parts)-1] += " 至 " + f.ObservedTo.Format("15:04:05Z07:00")
		}
	}
	if f.Process.PID > 0 {
		parts = append(parts, fmt.Sprintf("进程：%s PID %d 启动 %d", f.Process.Name, f.Process.PID, f.Process.CreatedAtMS))
	}
	return strings.Join(parts, " · ")
}

func collectionCount(r Report, kind string) (int, bool) {
	switch kind {
	case "rules":
		return len(r.Findings), true
	case "model":
		if r.Analysis != nil {
			return len(r.Analysis.Findings), true
		}
	case "requests":
		if r.AnalysisRequest != nil {
			return len(r.AnalysisRequest.RequestBodies), true
		}
	case "preview":
		if r.AnalysisPreview != nil {
			return len(r.AnalysisPreview.RequestBodies), true
		}
	case "recovered":
		if r.RecoveredRequests != nil {
			return len(r.RecoveredRequests.Records), true
		}
	case "gaps":
		count := 0
		for _, e := range r.Events {
			if e.Kind == "collector_error" {
				count++
			}
		}
		return count, true
	case "traffic":
		if r.Analysis != nil {
			return len(r.Analysis.UnexplainedTraffic), true
		}
	case "batches":
		if r.Analysis != nil {
			return len(r.Analysis.BatchVerdicts), true
		}
	case "review":
		if r.Review != nil && r.Review.Result != nil {
			return len(r.Review.Result.Assessments), true
		}
	case "review_requests":
		if r.Review != nil && r.Review.Request != nil {
			return len(r.Review.Request.RequestBodies), true
		}
	case "review_preview":
		if r.Review != nil && r.Review.Preview != nil {
			return len(r.Review.Preview.RequestBodies), true
		}
	case "review_traffic":
		if r.Review != nil && r.Review.Result != nil {
			return len(r.Review.Result.UnexplainedTraffic), true
		}
	default:
		return 0, false
	}
	return 0, true
}

// full is used only for explicit item requests and the offline data archive.
// List pages carry brief metadata and at most three evidence links per row.
func collectionItem(r Report, kind string, index int, full bool) (collectionRow, bool) {
	if kind == "gaps" {
		position := 0
		for _, e := range r.Events {
			if e.Kind != "collector_error" {
				continue
			}
			if position == index {
				return gapRow(r, e, index, full), true
			}
			position++
		}
		return collectionRow{}, false
	}
	count, valid := collectionCount(r, kind)
	if !valid || index < 0 || index >= count {
		return collectionRow{}, false
	}
	row := collectionRow{Index: index}
	switch kind {
	case "rules":
		f := r.Findings[index]
		row.Title, row.Description = f.Summary, findingDescription(f)
		row.Body = f.Details
		row.Meta, row.Severity, row.EvidenceIDs = findingMeta(f), f.Severity, f.EvidenceIDs
	case "model":
		f := r.Analysis.Findings[index]
		row.Title, row.Meta, row.EvidenceIDs = f.Claim, fmt.Sprintf("结论 #%d · 模型自报置信度 %.2f", index+1, f.Confidence), f.EvidenceIDs
		if f.RequestBatch > 0 {
			row.Meta += fmt.Sprintf(" · 请求批次 %d", f.RequestBatch)
		}
		row.Severity = "medium"
		if f.Confidence >= .8 {
			row.Severity = "high"
		}
	case "requests":
		row.Title, row.Body = fmt.Sprintf("第 %d 批 · 尝试发送", index+1), r.AnalysisRequest.RequestBodies[index]
	case "preview":
		row.Title, row.Body = fmt.Sprintf("第 %d 批 · 预览（本次未发送）", index+1), r.AnalysisPreview.RequestBodies[index]
	case "recovered":
		record := r.RecoveredRequests.Records[index]
		label := map[string]string{"prepared": "准备发送", "completed": "完成", "failed": "失败"}[record.Kind]
		row.Title = fmt.Sprintf("第 %d 批 · %s", record.Batch, label)
		row.Meta = record.At.Format("2006-01-02 15:04:05Z07:00")
		if record.Kind == "prepared" {
			row.Description, row.Body = "端点："+record.Endpoint+" · 模型："+record.Model, record.Body
		} else {
			row.Description = "此记录仅保存处理结果，不包含模型响应正文。"
		}
	case "traffic":
		traffic := r.Analysis.UnexplainedTraffic[index]
		row.Title = "来源：" + traffic.Source
		row.Description = "模型标记需解释的网络记录；字节量由本机根据完整出站证据计算。"
		row.Meta = fmt.Sprintf("%d 出站字节", traffic.BytesOut)
		row.EvidenceIDs = traffic.EvidenceIDs
	case "batches":
		batch := r.Analysis.BatchVerdicts[index]
		row.Title = fmt.Sprintf("第 %d 批：%s", batch.Batch, verdictLabel(batch.Verdict))
		row.Meta = fmt.Sprintf("%d 条结论", batch.FindingCount)
	case "review":
		a := r.Review.Result.Assessments[index]
		row.Title, row.EvidenceIDs = a.Claim, a.EvidenceIDs
		relationship := map[string]string{"independent": "独立判断", "duplicate": "重复判断", "contradictory": "判断存在矛盾"}[a.Relationship]
		status := map[string]string{"supported": "保留", "revised": "修正", "withdrawn": "撤回", "unresolved": "尚无法确定"}[a.Status]
		row.Description = relationship + " · 模型建议：" + status
		row.Meta = fmt.Sprintf("原结论编号 %v · 模型自报置信度 %.2f", a.FindingIDs, a.Confidence)
		row.Severity = "medium"
		originals := []AnalysisFinding{}
		if r.Analysis != nil {
			for _, id := range a.FindingIDs {
				if id > 0 && id <= len(r.Analysis.Findings) {
					originals = append(originals, r.Analysis.Findings[id-1])
				}
			}
		}
		body, err := json.Marshal(struct {
			Assessment ReviewAssessment  `json:"assessment"`
			Original   []AnalysisFinding `json:"original_findings"`
		}{a, originals})
		if err == nil {
			row.Body = string(body)
		}
	case "review_requests":
		row.Title, row.Body = "跨批复核 · 尝试发送", r.Review.Request.RequestBodies[index]
	case "review_preview":
		row.Title, row.Body = "跨批复核 · 预览（本次未发送）", r.Review.Preview.RequestBodies[index]
	case "review_traffic":
		traffic := r.Review.Result.UnexplainedTraffic[index]
		row.Title = "复核后来源：" + traffic.Source
		row.Description = "仅根据复核后保留的完整网络证据计算；不同来源分别展示，不与初次分析相加。"
		row.Meta = fmt.Sprintf("%d 出站字节", traffic.BytesOut)
		row.EvidenceIDs = traffic.EvidenceIDs
	}
	return finishCollectionRow(row, full), true
}

func gapRow(r Report, e event.Event, index int, full bool) collectionRow {
	view := describeEvent(e, r.RuleConfig)
	// Include the complete event in the key so a changed gap cannot open a
	// different record even when the summary and evidence ID are unchanged.
	encoded, err := json.Marshal(e)
	if err != nil {
		encoded = []byte(fmt.Sprint(e))
	}
	digest := sha256.Sum256(encoded)
	row := finishCollectionRow(collectionRow{Index: index, Title: view.Title,
		Description: view.Description, Meta: view.Time + " · " + view.Provenance,
		EvidenceIDs: []string{e.ID}, Body: string(encoded)}, full)
	row.Key += fmt.Sprintf("%x", digest)
	return row
}

func finishCollectionRow(row collectionRow, full bool) collectionRow {
	// Keep arbitrary model prose out of the initial DOM while preserving it
	// exactly in the explicitly opened detail and the offline archive.
	if chars := []rune(row.Title); len(chars) > 240 {
		if row.Body == "" {
			row.Body = row.Title
		}
		row.Title = string(chars[:240]) + "…"
	}
	row.EvidenceCount, row.HasBody = len(row.EvidenceIDs), row.Body != ""
	// A live rule list can reorder between the list and detail requests. Bind
	// details to the displayed content rather than silently opening a new row.
	hash := sha256.New()
	for _, value := range []string{row.Title, row.Description, row.Meta, row.Severity, row.Body} {
		fmt.Fprintf(hash, "%d:%s", len(value), value)
	}
	for _, value := range row.EvidenceIDs {
		fmt.Fprintf(hash, "%d:%s", len(value), value)
	}
	row.Key = fmt.Sprintf("%x", hash.Sum(nil))
	if !full {
		row.Body = ""
		row.EvidenceIDs = row.EvidenceIDs[:min(3, len(row.EvidenceIDs))]
	}
	return row
}

func selectCollection(r Report, kind, requested string) (collectionView, bool) {
	count, valid := collectionCount(r, kind)
	if !valid {
		return collectionView{}, false
	}
	page, _ := strconv.Atoi(requested)
	pages := max(1, (count+collectionPageSize-1)/collectionPageSize)
	page = min(max(page, 1), pages)
	view := collectionView{Kind: kind, Page: page, Pages: pages, Total: count, Rows: []collectionRow{}}
	start := (page - 1) * collectionPageSize
	if kind == "gaps" {
		position := 0
		for _, e := range r.Events {
			if e.Kind != "collector_error" {
				continue
			}
			if position >= start {
				view.Rows = append(view.Rows, gapRow(r, e, position, false))
			}
			position++
			if len(view.Rows) == collectionPageSize {
				break
			}
		}
		return view, true
	}
	for index := start; index < min(count, start+collectionPageSize); index++ {
		row, _ := collectionItem(r, kind, index, false)
		view.Rows = append(view.Rows, row)
	}
	return view, true
}

func reportCollections(r Report, query url.Values) map[string]collectionView {
	result := map[string]collectionView{}
	for _, kind := range collectionKinds {
		result[kind], _ = selectCollection(r, kind, query.Get(kind+"_page"))
	}
	return result
}
