package report

import (
	"fmt"
	"math"
	"sort"
	"strconv"
	"strings"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/rules"
)

// Dashboard contains bounded metadata, never event bodies or task text.
// Alert file paths are capped projections for the local desktop view.
// Connections and gaps are historical observations, not current sockets/alarms.
type Dashboard struct {
	Status        string                      `json:"status"`
	GeneratedAt   time.Time                   `json:"generated_at"`
	LastSampleAt  *time.Time                  `json:"last_sample_at,omitempty"`
	LastSuccessAt *time.Time                  `json:"last_success_at,omitempty"`
	IntervalSec   float64                     `json:"interval_sec"`
	Covered       int                         `json:"covered_processes"`
	Health        map[string]int              `json:"health"`
	Connections   int                         `json:"connections"`
	Files         int                         `json:"files"`
	Gaps          int                         `json:"gaps"`
	FileWatching  bool                        `json:"file_watching"`
	ScopeRoots    int                         `json:"scope_roots"`
	ScopeChildren int                         `json:"scope_children"`
	Traffic       map[string]DashboardTraffic `json:"traffic"`
	Recent        []DashboardActivity         `json:"recent"`
	Alerts        []DashboardAlert            `json:"alerts"`
}
type DashboardTraffic struct {
	In  uint64 `json:"bytes_in"`
	Out uint64 `json:"bytes_out"`
}
type DashboardActivity struct {
	At      time.Time `json:"at"`
	Kind    string    `json:"kind"`
	Process string    `json:"process"`
}

// DashboardAlert is a bounded projection of a local rule finding. It keeps
// the desktop view actionable without exposing event details or request
// bodies through the polling endpoint.
type DashboardAlert struct {
	At                 time.Time `json:"at"`
	Conclusion         string    `json:"conclusion"`
	Process            string    `json:"process"`
	File               string    `json:"file"`
	Target             string    `json:"target"`
	AuthorizationState string    `json:"authorization_state"`
	EvidenceStrength   string    `json:"evidence_strength"`
	EvidenceCount      int       `json:"evidence_count"`
}

func DashboardSnapshot(r Report) Dashboard {
	d := Dashboard{Status: r.Status, GeneratedAt: r.GeneratedAt, FileWatching: len(r.WatchRoots) > 0,
		Traffic: map[string]DashboardTraffic{}, Recent: []DashboardActivity{}, Alerts: []DashboardAlert{}, Health: map[string]int{}}
	invalidTraffic := map[string]bool{}
	scope := map[string]bool{}
	for _, e := range r.Events {
		source, _ := e.Detail["source"].(string)
		switch e.Kind {
		case "collector_sample":
			at := e.TS
			d.LastSampleAt = &at
			d.IntervalSec, _ = number(e.Detail["interval_sec"])
			d.Covered, _ = integer(e.Detail["covered_processes"])
			d.ScopeRoots, _ = integer(e.Detail["scope_roots"])
			d.ScopeChildren, _ = integer(e.Detail["scope_children"])
			d.Health = dashboardHealth(e.Detail["health"])
			if value, ok := e.Detail["last_success_at"].(string); ok {
				if parsed, err := time.Parse(time.RFC3339Nano, value); err == nil {
					d.LastSuccessAt = &parsed
				}
			}
		case "scope_member_added":
			root, _ := e.Detail["root"].(bool)
			scope[fmt.Sprintf("%d/%d", e.Process.PID, e.Process.CreatedAtMS)] = root
		case "scope_member_removed":
			delete(scope, fmt.Sprintf("%d/%d", e.Process.PID, e.Process.CreatedAtMS))
		case "connection_observed":
			// Proxy observations overlap system socket observations.
			if source != "proxy" {
				d.Connections++
			}
		case "collector_error":
			d.Gaps++
		}
		if e.Layer == "file" && e.Kind != "collector_error" && e.Kind != "collector_recovered" {
			d.Files++
		}
		if e.Kind == "network_baseline" && source == "nettop" {
			if _, ok := d.Traffic[source]; !ok {
				d.Traffic[source] = DashboardTraffic{}
			}
		}
		if e.Kind == "egress" && e.Detail["metric"] == "network_bytes" && (source == "nettop" || source == "proxy") {
			incoming, inErr := strconv.ParseUint(fmt.Sprint(e.Detail["bytes_in"]), 10, 64)
			outgoing, outErr := strconv.ParseUint(fmt.Sprint(e.Detail["bytes_out"]), 10, 64)
			if inErr == nil && outErr == nil {
				t := d.Traffic[source]
				if incoming > math.MaxUint64-t.In || outgoing > math.MaxUint64-t.Out {
					invalidTraffic[source] = true
					continue
				}
				t.In += incoming
				t.Out += outgoing
				d.Traffic[source] = t
			}
		}
	}
	for _, root := range scope {
		if d.LastSampleAt != nil {
			break
		}
		if root {
			d.ScopeRoots++
		} else {
			d.ScopeChildren++
		}
	}
	for i := len(r.Events) - 1; i >= 0 && len(d.Recent) < 12; i-- {
		e := r.Events[i]
		if e.Kind == "process_io" || e.Kind == "collector_sample" {
			continue
		}
		d.Recent = append(d.Recent, DashboardActivity{At: e.TS, Kind: dashboardLabel(e.Kind), Process: dashboardLabel(e.Process.Name)})
	}
	for source := range invalidTraffic {
		delete(d.Traffic, source)
	}
	d.Alerts = dashboardAlerts(r.Findings, r.Events, r.GeneratedAt)
	return d
}

func dashboardAlerts(findings []rules.Finding, events []event.Event, fallback time.Time) []DashboardAlert {
	if len(findings) == 0 {
		return []DashboardAlert{}
	}
	eventTimes := make(map[string]time.Time, len(events))
	for _, item := range events {
		if item.ID != "" && !item.TS.IsZero() {
			eventTimes[item.ID] = item.TS
		}
	}
	ordered := append([]rules.Finding(nil), findings...)
	sort.SliceStable(ordered, func(i, j int) bool {
		return findingAlertTime(ordered[i], eventTimes).After(findingAlertTime(ordered[j], eventTimes))
	})
	alerts := make([]DashboardAlert, 0, minInt(len(ordered), 12))
	for index := 0; index < len(ordered) && len(alerts) < 12; index++ {
		finding := ordered[index]
		conclusion := finding.Conclusion
		if conclusion == "" {
			conclusion = finding.Summary
		}
		if conclusion == "" {
			continue
		}
		at := findingAlertTime(finding, eventTimes)
		if at.IsZero() {
			at = fallback
		}
		file := boundedFindingPaths(finding.FilePaths)
		process := finding.Process.Name
		if process == "" && finding.Process.PID > 0 {
			process = strconv.Itoa(finding.Process.PID)
		}
		strength := finding.EvidenceStrength
		if strength == "" {
			strength = "rule"
		}
		authorization := finding.AuthorizationState
		if authorization == "" {
			authorization = "unknown"
		}
		alerts = append(alerts, DashboardAlert{At: at, Conclusion: dashboardLabel(conclusion),
			Process: dashboardLabel(process), File: file, Target: dashboardLabel(finding.Target),
			AuthorizationState: dashboardLabel(authorization), EvidenceStrength: dashboardLabel(strength),
			EvidenceCount: len(finding.EvidenceIDs)})
	}
	return alerts
}

func findingAlertTime(finding rules.Finding, eventTimes map[string]time.Time) time.Time {
	if !finding.ObservedTo.IsZero() {
		return finding.ObservedTo
	}
	if !finding.ObservedFrom.IsZero() {
		return finding.ObservedFrom
	}
	var latest time.Time
	for _, id := range finding.EvidenceIDs {
		if at, ok := eventTimes[id]; ok && at.After(latest) {
			latest = at
		}
	}
	return latest
}

func boundedFindingPaths(paths []string) string {
	if len(paths) == 0 {
		return ""
	}
	const maxPaths = 4
	parts := make([]string, 0, minInt(len(paths), maxPaths))
	for _, path := range paths {
		if path == "" {
			continue
		}
		parts = append(parts, dashboardLabel(path))
		if len(parts) == maxPaths {
			break
		}
	}
	if len(parts) == 0 {
		return ""
	}
	joined := strings.Join(parts, "\n")
	if len(paths) > len(parts) {
		joined += "\n..."
	}
	return dashboardLabel(joined)
}

func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func number(value any) (float64, bool) {
	switch n := value.(type) {
	case float64:
		return n, true
	case int:
		return float64(n), true
	case int64:
		return float64(n), true
	default:
		return 0, false
	}
}

func integer(value any) (int, bool) {
	n, ok := number(value)
	if !ok || math.IsNaN(n) || math.IsInf(n, 0) || n < 0 || n > math.MaxInt32 || math.Trunc(n) != n {
		return 0, false
	}
	return int(n), true
}

func dashboardHealth(value any) map[string]int {
	result := map[string]int{}
	for _, state := range []string{"ok", "unsupported", "idle", "failed", "process_exited", "recovered"} {
		var raw any
		switch counts := value.(type) {
		case map[string]int:
			raw = counts[state]
		case map[string]any:
			raw = counts[state]
		}
		if n, ok := integer(raw); ok {
			result[state] = n
		}
	}
	return result
}

func dashboardLabel(value string) string {
	count := 0
	for offset := range value {
		if count == 120 {
			return value[:offset]
		}
		count++
	}
	return value
}
