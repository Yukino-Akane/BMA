package report

import (
	"bytes"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"behavior-monitoring-audit/internal/event"
)

func TestStoreLimitReservesGapAndStopsAllProducers(t *testing.T) {
	dir := t.TempDir()
	s, err := newStore(dir, New("s", "w", nil, nil), 3, 1024*1024)
	if err != nil {
		t.Fatal(err)
	}
	defer s.Finish("stopped")
	for i := 0; i < 2; i++ {
		if err := s.Add(event.New("s", "file", event.Process{}, "file_create", "temporal", nil)); err != nil {
			t.Fatal(err)
		}
	}
	if err := s.Add(event.New("s", "net", event.Process{}, "connection_observed", "direct", nil)); !errors.Is(err, ErrSessionLimit) {
		t.Fatal(err)
	}
	select {
	case <-s.Done():
	default:
		t.Fatal("store failure did not signal collection shutdown")
	}
	before, err := os.ReadFile(filepath.Join(dir, "events.jsonl"))
	if err != nil {
		t.Fatal(err)
	}
	if err := s.Add(event.New("s", "file", event.Process{}, "file_create", "temporal", nil)); !errors.Is(err, ErrSessionLimit) {
		t.Fatal(err)
	}
	if err := s.Finish("stopped"); err != nil {
		t.Fatal(err)
	}
	after, _ := os.ReadFile(filepath.Join(dir, "events.jsonl"))
	r := s.Snapshot()
	if !bytes.Equal(before, after) || len(r.Events) != 3 || r.Status != "limit_reached" || len(r.CoverageGaps()) != 1 || r.Storage.JournalBytes != int64(len(after)) {
		t.Fatal("limit discarded evidence, exceeded count, or lost stop reason")
	}
	recovered, err := Recover(dir)
	if err != nil || len(recovered.Events) != 4 || len(recovered.CoverageGaps()) != 2 {
		t.Fatalf("limit journal not recoverable: %v", err)
	}
}

func TestStoreByteAndRecordLimits(t *testing.T) {
	for _, tc := range []struct {
		name   string
		budget int64
		size   int
	}{
		{"session", gapReserve + 1024, 2048},
		{"record", MaxSessionBytes, maxEventBytes},
	} {
		t.Run(tc.name, func(t *testing.T) {
			dir := t.TempDir()
			s, err := newStore(dir, New("s", "w", nil, nil), 100, tc.budget)
			if err != nil {
				t.Fatal(err)
			}
			defer s.Finish("stopped")
			err = s.Add(event.New("s", "semantic", event.Process{}, "goal", "direct", map[string]any{"text": strings.Repeat("a", tc.size)}))
			if !errors.Is(err, ErrSessionLimit) {
				t.Fatalf("oversized record accepted: %v", err)
			}
			r := s.Snapshot()
			if len(r.Events) != 1 || r.Events[0].Kind != "collector_error" || r.Storage.JournalBytes > tc.budget {
				t.Fatal("limit marker not bounded")
			}
		})
	}
}

func TestJournalWriteFailureSignalsShutdown(t *testing.T) {
	s, err := NewStore(t.TempDir(), New("s", "w", nil, nil))
	if err != nil {
		t.Fatal(err)
	}
	s.log.Close()
	err = s.Add(event.New("s", "file", event.Process{}, "file_create", "temporal", nil))
	if err == nil || s.Err() == nil {
		t.Fatal("write failure ignored")
	}
	select {
	case <-s.Done():
	default:
		t.Fatal("write failure did not stop producers")
	}
	if r := s.Snapshot(); r.Status != "failed" || len(r.CoverageGaps()) != 1 {
		t.Fatal("write failure hidden")
	}
	if s.Finish("stopped") == nil {
		t.Fatal("close/sync failure hidden")
	}
}

func TestRecoverPartialTailPreservesSourceAndScope(t *testing.T) {
	dir := t.TempDir()
	initial := New("s", "workspace", []string{"agent"}, nil)
	initial.WatchRoots = []string{"workspace", "agent-data"}
	initial.RuleConfig.LargeBytes = 10
	s, err := NewStore(dir, initial)
	if err != nil {
		t.Fatal(err)
	}
	e := event.New("s", "file", event.Process{}, "file_create", "temporal", map[string]any{"size_bytes": 20})
	if err := s.Add(e); err != nil {
		t.Fatal(err)
	}
	if err := s.Finish("stopped"); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(dir, "events.jsonl")
	f, err := os.OpenFile(path, os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := f.WriteString(`{"id":"unfinished`); err != nil {
		t.Fatal(err)
	}
	f.Close()
	before, _ := os.ReadFile(path)
	r, err := Recover(dir)
	if err != nil {
		t.Fatal(err)
	}
	after, _ := os.ReadFile(path)
	if !bytes.Equal(before, after) || r.Status != "recovered" || len(r.Events) != 2 || r.Events[0].ID != e.ID || len(r.WatchRoots) != 2 || len(r.Findings) != 1 || r.Findings[0].EvidenceIDs[0] != e.ID {
		t.Fatal("recovery changed source or lost evidence/scope/rules")
	}
	if r.Events[1].Detail["truncated_last_record"] != true || r.AnalysisRequest != nil {
		t.Fatal("recovery did not disclose its limits")
	}
}

func TestRecoverRejectsCorruptAndMixedJournals(t *testing.T) {
	for _, name := range []string{"malformed-record", "foreign-session", "duplicate-id", "count-limit"} {
		t.Run(name, func(t *testing.T) {
			dir := t.TempDir()
			s, err := newStore(dir, New("s", "w", nil, nil), 3, 1024*1024)
			if err != nil {
				t.Fatal(err)
			}
			e := event.New("s", "file", event.Process{}, "file_create", "temporal", nil)
			if err := s.Add(e); err != nil {
				t.Fatal(err)
			}
			if err := s.Finish("stopped"); err != nil {
				t.Fatal(err)
			}
			path := filepath.Join(dir, "events.jsonl")
			original, _ := os.ReadFile(path)
			data := append([]byte{}, original...)
			switch name {
			case "malformed-record":
				data = append(data, []byte("{invalid}\n")...)
			case "foreign-session":
				data = []byte(strings.ReplaceAll(string(data), `"session_id":"s"`, `"session_id":"foreign"`))
			case "duplicate-id":
				data = append(data, original...)
			case "count-limit":
				data = bytes.Repeat(original, 4)
			}
			if err := os.WriteFile(path, data, 0600); err != nil {
				t.Fatal(err)
			}
			if _, err := Recover(dir); err == nil {
				t.Fatal("corrupt journal accepted")
			}
		})
	}
}
