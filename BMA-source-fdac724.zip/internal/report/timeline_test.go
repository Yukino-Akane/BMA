package report

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/rules"
)

func timelineFixture(count int) Report {
	events := make([]event.Event, 0, count)
	for i := 0; i < count; i++ {
		e := event.New("s", "net", event.Process{Name: "agent"}, "connection_observed", "direct", map[string]any{"remote_host": "example.invalid"})
		e.ID = fmt.Sprintf("e_%06d", i)
		events = append(events, e)
	}
	return New("s", "w", nil, events)
}

func embeddedRows(t *testing.T, html string) []eventView {
	t.Helper()
	_, rest, ok := strings.Cut(html, `<script id="timeline-data" type="application/json">`)
	if !ok {
		t.Fatal("missing timeline data")
	}
	data, _, ok := strings.Cut(rest, "</script>")
	if !ok {
		t.Fatal("missing timeline data terminator")
	}
	var rows []eventView
	if err := json.Unmarshal([]byte(data), &rows); err != nil {
		t.Fatal(err)
	}
	return rows
}

func TestTimelinePagesFiltersAndEvidenceOutsideFilter(t *testing.T) {
	r := timelineFixture(251)
	r.Events[250].Layer, r.Events[250].Kind = "file", "file_create"
	view := selectTimeline(r.Events, url.Values{"page": {"3"}}, r.RuleConfig)
	if len(view.Rows) != 51 || view.Page != 3 || view.Pages != 3 || view.Rows[0].Event.ID != "e_000200" {
		t.Fatal("page selection lost events")
	}
	view = selectTimeline(r.Events, url.Values{"kind": {"网络连接"}}, r.RuleConfig)
	if view.Matches != 250 || view.Rows[0].Title != "观察到网络连接" {
		t.Fatal("Chinese filtering failed")
	}
	view = selectTimeline(r.Events, url.Values{"layer": {"net"}, "evidence": {"e_000250"}}, r.RuleConfig)
	if view.Page != 3 || view.Matches != 251 || view.Rows[50].Event.ID != "e_000250" {
		t.Fatal("filtered cross-page evidence was hidden")
	}
	view = selectTimeline(r.Events, url.Values{"page": {"999"}, "kind": {"no match"}}, r.RuleConfig)
	if view.Page != 1 || view.Pages != 1 || len(view.Rows) != 0 {
		t.Fatal("empty page is not bounded")
	}
}

func TestApprovalRequestDisplayAndFilter(t *testing.T) {
	e := event.New("s", "semantic", event.Process{Name: "roo-log"}, "claimed_action", "direct", map[string]any{"tool": "execute_command", "stage": "approval_request"})
	r := New("s", "w", nil, []event.Event{e})
	for _, query := range []string{"请求批准", "claimed_action"} {
		view := selectTimeline(r.Events, url.Values{"kind": {query}}, r.RuleConfig)
		if view.Matches != 1 || view.Rows[0].Title != "Agent 请求批准操作" || !strings.Contains(view.Rows[0].Description, "不证明操作已经执行") || !strings.Contains(view.Rows[0].Provenance, "未经操作系统证实") {
			t.Fatal("approval request hidden or displayed as execution")
		}
	}
	var html bytes.Buffer
	if err := Render(&html, r); err != nil {
		t.Fatal(err)
	}
	rows := embeddedRows(t, html.String())
	if len(rows) != 1 || rows[0].Title != "Agent 请求批准操作" {
		t.Fatal("offline filter lacks approval title")
	}
}

func TestClineRequestAndDelegatedGoalDisplay(t *testing.T) {
	goal := event.New("s", "semantic", event.Process{Name: "cline-log"}, "goal", "direct", map[string]any{"text": "delegated task", "agent_role": "subagent"})
	call := event.New("s", "semantic", event.Process{Name: "cline-log"}, "claimed_action", "direct", map[string]any{"tool": "read_files", "stage": "tool_request"})
	r := New("s", "w", nil, []event.Event{goal, call})
	view := selectTimeline(r.Events, url.Values{"kind": {"请求调用工具"}}, r.RuleConfig)
	if view.Matches != 1 || !strings.Contains(view.Rows[0].Description, "不证明操作已经执行") {
		t.Fatal("tool request filter or provenance lost")
	}
	if !strings.Contains(describeEvent(goal, r.RuleConfig).Provenance, "可能是委派任务") {
		t.Fatal("delegated input displayed as direct user instruction")
	}
}

func TestLargeOnlineTimelineOnlyReturnsOnePage(t *testing.T) {
	r := timelineFixture(MaxSessionEvents)
	h := Handler(func() Report { return r }, "127.0.0.1:7788", "", nil)
	req := httptest.NewRequest("GET", "http://127.0.0.1:7788/?page=500", nil)
	w := httptest.NewRecorder()
	h.ServeHTTP(w, req)
	if w.Code != 200 {
		t.Fatal(w.Code)
	}
	rows := embeddedRows(t, w.Body.String())
	if !strings.Contains(w.Body.String(), `data-online="true"`) {
		t.Fatal("online mode flag changed during template escaping")
	}
	if len(rows) != 100 || rows[0].Event.ID != "e_049900" || strings.Count(w.Body.String(), `<article id=`) != 100 || w.Body.Len() > 200000 {
		t.Fatalf("timeline was not bounded: rows=%d bytes=%d", len(rows), w.Body.Len())
	}
}

func TestOfflineTimelinePreservesAllEvidenceWithoutAllCards(t *testing.T) {
	r := timelineFixture(251)
	r.Events[250].Detail["remote_host"] = `</script><script>alert(1)</script>`
	var html bytes.Buffer
	if err := Render(&html, r); err != nil {
		t.Fatal(err)
	}
	rows := embeddedRows(t, html.String())
	if len(rows) != 251 || strings.Count(html.String(), `<article id=`) != 100 {
		t.Fatal("offline evidence lost or all cards rendered")
	}
	if strings.Contains(html.String(), `</script><script>alert`) || strings.Contains(html.String(), `href="/api/report"`) {
		t.Fatal("unsafe script data or dead offline navigation")
	}
	if rows[250].Event.Detail["remote_host"] != r.Events[250].Detail["remote_host"] {
		t.Fatal("escaping altered evidence")
	}
}

func TestEventDescriptionsDoNotOverstateEvidence(t *testing.T) {
	claimed := describeEvent(event.New("s", "semantic", event.Process{Name: "agent-log"}, "claimed_action", "direct", map[string]any{"tool": "Read"}), rules.DefaultConfig())
	if !strings.Contains(claimed.Provenance, "未经操作系统证实") {
		t.Fatal("self-report presented as OS evidence")
	}
	e := event.New("s", "net", event.Process{}, "egress", "direct", map[string]any{"metric": "process_io_not_network", "bytes_out": 1000, "bytes_in": 1})
	if !strings.Contains(describeEvent(e, rules.DefaultConfig()).Description, "缺少有效网络字节量") {
		t.Fatal("IO presented as measured upload")
	}
	e = event.New("s", "file", event.Process{}, "file_create", "temporal", nil)
	if !strings.Contains(describeEvent(e, rules.DefaultConfig()).Provenance, "无法确定操作进程") {
		t.Fatal("temporal evidence attributed to process")
	}
}

func TestDestinationClassificationAndProvenanceUseReportConfig(t *testing.T) {
	cfg := rules.DefaultConfig()
	cfg.ModelAPIHosts = []string{"gateway.example.com"}
	for _, tc := range []struct{ host, source, category, provenance string }{
		{"gateway.example.com:443", "proxy_request", "配置中的模型 API", "客户端代理请求"},
		{"bucket.s3.amazonaws.com", "reverse_dns", "疑似对象存储", "不证明实际请求"},
		{"192.0.2.1", "socket_ip", "用途未知", "系统连接表"},
		{"api.openai.com", "", "用途未知", "来源未核实"},
	} {
		e := event.New("s", "net", event.Process{}, "connection_observed", "direct", map[string]any{"remote_host": tc.host, "host_source": tc.source})
		r := NewWithConfig("s", "w", nil, []event.Event{e}, cfg)
		for _, query := range []url.Values{nil, {"page": {"1"}}} {
			var html bytes.Buffer
			if err := renderPage(&html, r, false, query); err != nil {
				t.Fatal(err)
			}
			rows := embeddedRows(t, html.String())
			if len(rows) != 1 || !strings.Contains(rows[0].Description, tc.category) || !strings.Contains(rows[0].Provenance, tc.provenance) {
				t.Fatalf("wrong classification or provenance: %+v", rows)
			}
			if !strings.Contains(html.String(), "<code>gateway.example.com</code>") {
				t.Fatal("report omitted configured model hosts")
			}
		}
	}
}

func TestRangeCluesAppearInOnlineAndOfflineReportsWithoutServiceClaims(t *testing.T) {
	e := event.New("s", "net", event.Process{}, "connection_observed", "direct", map[string]any{"remote_ip": "13.65.107.33", "remote_host": "13.65.107.33", "host_source": "socket_ip"})
	r := New("s", "w", nil, []event.Event{e})
	for _, query := range []url.Values{nil, {"page": {"1"}}} {
		var html bytes.Buffer
		if err := renderPage(&html, r, false, query); err != nil {
			t.Fatal(err)
		}
		rows := embeddedRows(t, html.String())
		if len(rows) != 1 || !strings.Contains(rows[0].Description, "用途未知") || !strings.Contains(rows[0].Provenance, "Azure Storage") || !strings.Contains(rows[0].Provenance, "2026-09-14") || !strings.Contains(rows[0].AddressClues, "SHA-256") || !strings.Contains(html.String(), "内置服务网段快照") {
			t.Fatal("range provenance missing or IP confused with a service")
		}
	}
	e.Detail["direction"] = "aggregate"
	if strings.Contains(describeEvent(e, r.RuleConfig).Provenance, "Azure Storage") {
		t.Fatal("aggregate measurement assigned to an IP")
	}
}

func TestProxyFailureAndShutdownDescriptions(t *testing.T) {
	e := event.New("s", "net", event.Process{PID: 42}, "connection_failed", "direct", map[string]any{"stage": "dial", "error_code": "connection_refused", "remote_host": "storage.googleapis.com:443", "host_source": "proxy_request"})
	v := describeEvent(e, rules.DefaultConfig())
	if !strings.Contains(v.Title, "失败") || !strings.Contains(v.Description, "连接被拒绝") || !strings.Contains(v.Description, "不能据此判断证书锁定") || !strings.Contains(v.Provenance, "客户端代理请求") {
		t.Fatalf("failure explanation: %+v", v)
	}
	e.Kind = "connection_closed"
	e.Detail["reason"] = "observation_stopped"
	v = describeEvent(e, rules.DefaultConfig())
	if !strings.Contains(v.Description, "观察已停止") || strings.Contains(v.Title, "失败") {
		t.Fatalf("intentional shutdown presented as failure: %+v", v)
	}
}
