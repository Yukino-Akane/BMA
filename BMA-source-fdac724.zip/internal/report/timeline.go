package report

import (
	"fmt"
	"net/url"
	"strconv"
	"strings"

	"behavior-monitoring-audit/internal/destination"
	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/rules"
)

const timelinePageSize = 100

type eventView struct {
	Event        event.Event `json:"event"`
	Title        string      `json:"title"`
	Layer        string      `json:"layer"`
	Description  string      `json:"description"`
	Provenance   string      `json:"provenance"`
	AddressClues string      `json:"address_clues,omitempty"`
	Time         string      `json:"time"`
	Actor        string      `json:"actor"`
}

type timelineView struct {
	Rows                        []eventView
	Page, Pages, Matches, Total int
	Layer, Query                string
}

var kindLabels = map[string]string{
	"goal": "任务目标", "claimed_action": "Agent 自述操作", "collector_error": "采集缺口",
	"watch_ready": "文件监听已就绪", "path_excluded": "已排除链接路径",
	"file_create": "新建文件", "file_modify": "修改文件", "file_delete": "删除文件",
	"file_rename_from": "文件改名或移走", "file_observed": "发现已有文件", "file_open_observed": "观察到打开的文件",
	"directory_delete": "删除目录", "directory_rename_from": "目录改名或移走",
	"process_observed": "发现指定进程", "process_no_longer_observed": "暂未再观察到进程",
	"scope_member_added": "进程加入观察范围", "scope_member_removed": "进程离开可核验范围",
	"collector_status": "采集能力或进程状态变化", "collector_sample": "进程采样摘要",
	"process_io": "进程读写量（非上传量）", "connection_observed": "观察到网络连接", "egress": "网络流量记录",
	"static_indicator": "源代码线索", "network_baseline": "网络计数基线", "collector_recovered": "采样已恢复", "connection_failed": "代理连接或转发失败", "connection_closed": "代理连接结束",
}

func statusLabel(status string) string {
	labels := map[string]string{"recording": "观察中", "stopped": "已停止", "completed": "已完成", "failed": "采集失败", "limit_reached": "已达容量上限", "recovered": "已恢复（不完整）", "analyzed": "分析完成", "analysis_failed": "分析失败", "reviewed": "复核完成", "review_failed": "复核失败"}
	if label := labels[status]; label != "" {
		return label
	}
	return status
}

func verdictLabel(verdict string) string {
	labels := map[string]string{"clean": "模型未发现异常", "suspicious": "有待核实", "alarming": "建议重点核实"}
	if label := labels[verdict]; label != "" {
		return label
	}
	return verdict
}

func severityLabel(severity string) string {
	if severity == "high" {
		return "重点核实"
	}
	if severity == "medium" {
		return "留意检查"
	}
	return "提示"
}

func ruleDescription(rule string) string {
	return map[string]string{
		"net/outbound-inbound-ratio":         "只计完整落在窗口内的出站样本；跨越任一边界的入站样本全部计入分母，保守计算后仍超过阈值。未采集流量仍未知，不证明违规。",
		"net/outbound-volume":                "完整落在窗口内的出站样本已超过阈值；不把跨边界样本按时长摊分。进程总 IO 不参与这条规则。",
		"net/measurement-unusable":           "缺失或无效的字节量、测量起止时间无法用于窗口判断；保留原始记录，不把未知入站量当作零。",
		"net/measurement-wider-than-window":  "测量区间长于规则窗口。总流量仍保留，但不能把整段出站量归入结束时的窗口，也不能假设均匀传输。",
		"net/object-storage-destination":     "记录中的域名符合对象存储地址格式，且不在本次配置的模型 API 名单中。域名线索不能证明上传了项目，也不能证明接收方身份。",
		"net/storage-ip-range":               "记录中的 IP 命中随版本发布的存储服务网段快照。快照可能变化、过时或包含共享地址；不能确认事件发生时或当前的服务归属。Azure Storage 不仅包含对象存储。",
		"file/large-or-packed":               "文件达到大小或随机程度阈值，或使用压缩包扩展名。可能是正常构建产物，需结合其他证据。",
		"file/suspicious-artifact":           "发现归档、加密、快照命名或高熵文件线索；这是产物发现，不证明文件被读取或上传。",
		"file/sensitive-path":                "路径看起来包含凭证或其他敏感信息。路径变化或打开状态不能证明文件内容已被读取或上传。",
		"file/create-delete-window":          "观察到同一路径在短时间内创建并删除。这可能符合临时打包流程，但不能单独证明上传。",
		"correlation/suspected-exfiltration": "文件产物与进程聚合出站在时间上相关；目标、内容和文件到字节的对应关系未知。",
		"correlation/upload-attempt":         "显式代理观察到成功写入或失败/重试；不能据此确认特定内容发送成功或远端接收。",
		"static/network-client":              "源代码出现网络请求相关语句，不代表它已经执行。",
		"static/shell-execution":             "源代码出现运行命令或启动子进程的语句，不代表它已经执行。",
		"static/credential-access":           "源代码出现凭证相关名称，需要检查用途；不等于发现有效密钥或发生泄露。",
		"static/declared-permissions":        "配置文件出现权限声明，需确认权限是否符合插件用途。",
		"static/external-domain":             "源代码出现外部地址，不代表已经建立连接。",
		"static/install-hook":                "配置出现安装或卸载时可能执行的脚本，需要检查脚本行为。",
	}[rule]
}

func eventTitle(e event.Event) string {
	if e.Kind == "claimed_action" && e.Detail["stage"] == "approval_request" {
		return "Agent 请求批准操作"
	}
	if e.Kind == "claimed_action" && e.Detail["stage"] == "tool_request" {
		return "Agent 请求调用工具"
	}
	return kindLabels[e.Kind]
}

func describeEvent(e event.Event, cfg rules.Config) eventView {
	v := eventView{Event: e, Title: eventTitle(e), Time: e.TS.Format("15:04:05.000Z07:00"), Provenance: "直接来源记录，不等于行为违规"}
	v.Actor = e.Process.Name
	if label := map[string]string{"collector": "采集器", "user": "用户", "unattributed": "操作进程未知", "static-scanner": "代码扫描器", "agent-log": "Agent 日志", "codex-log": "Codex 日志", "claude-log": "Claude 日志", "roo-log": "Roo 日志", "cline-log": "Cline 日志", "generic-log": "Agent 日志"}[v.Actor]; label != "" {
		v.Actor = label
	}
	if e.Process.PID > 0 {
		v.Actor += fmt.Sprintf(" · PID %d", e.Process.PID)
	}
	v.Layer = map[string]string{"net": "网络", "file": "文件", "semantic": "任务与自述"}[e.Layer]
	if v.Title == "" {
		v.Title = "其他事件"
	}
	if v.Layer == "" {
		v.Layer = e.Layer
	}
	if e.Attribution == "temporal" {
		v.Provenance = "仅时间相关，无法确定操作进程"
	}
	text := func(key string) string { value, _ := e.Detail[key].(string); return value }
	switch e.Kind {
	case "goal":
		v.Description = text("text")
		if text("source") == "web" || e.Process.Name == "user" {
			v.Provenance = "用户提供的任务目标"
		} else {
			v.Provenance = "从 Agent 日志提取，可能含应用附加上下文"
			if text("agent_role") == "subagent" || text("agent_role") == "teammate" {
				v.Provenance = "来自子 Agent 会话，可能是委派任务，不等同于用户亲自下达的要求"
			}
		}
	case "claimed_action":
		if text("stage") == "tool_request" {
			v.Description = "日志中的工具调用请求：" + text("tool") + "。调用请求不证明操作已经执行。"
			v.Provenance = "Agent 自述的工具调用请求，未经操作系统证实"
			break
		}
		if text("stage") == "approval_request" {
			v.Description = "请求使用工具：" + text("tool") + "。批准请求不证明操作已经执行。"
			v.Provenance = "Agent 自述的批准请求，未经操作系统证实"
			break
		}
		v.Description = "Agent 声称调用了工具：" + text("tool")
		v.Provenance = "被观察方自述，尚未经操作系统证实"
	case "collector_error":
		v.Description = "这部分记录可能缺失，不能把没有记录当作没有发生。"
		v.Provenance = "本工具的采集状态，不是 Agent 违规证据"
		if text("source") == "filesystem_capacity" {
			v.Description = "目录监听达到本次会话的容量上限，观察已停止；已有证据保留，未观察部分不能判断。请缩小选定目录范围后开始新会话。"
		}
		if text("source") == "process_selection" {
			v.Description = "暂时没有核实到指定的当前用户进程；这段时间无法判断 Agent 的行为。"
		}
		if text("source") == "proxy_authorization" {
			v.Description = "代理无法核实连接属于指定进程，已拒绝转发；未记录未归属连接的目标或请求内容。"
		}
		if text("source") == "proxy_listener" {
			v.Description = "代理监听已停止，之后的新代理连接无法采集；已有记录仍保留。"
		}
		if text("source") == "network_bytes" {
			v.Description = "网络采样缺失、失败或计数器重置；未知区间不计为上传量，后续有效采样重新建立基线。"
		}
		if text("source") == "event_store" {
			v.Description = "事件日志达到容量上限或无法继续写入，观察已停止；查看原始证据中的具体原因。"
		}
		if text("source") == "journal_recovery" {
			v.Description = "从异常退出留下的日志恢复；未写完的尾记录、后续活动和模型请求历史可能缺失。"
		}
	case "network_baseline":
		v.Description = "首次有效计数仅建立基线，不计为本次上传；此前的流量未知。"
	case "collector_recovered":
		v.Description = "已恢复采样；恢复之前的采集缺口仍然存在。"
	case "collector_status":
		v.Provenance = "本工具的采集状态，不是 Agent 违规证据"
		v.Description = map[string]string{"unsupported": "该平台不提供这项采集能力，不计为采集失败。", "idle": "本轮没有可见活动或已核验进程，不证明没有发生网络传输。", "process_exited": "所选进程实例已退出，不会自动绑定到复用该 PID 的进程。"}[text("state")]
	case "collector_sample":
		v.Description = "本轮进程采集的时间、覆盖范围与状态计数；不是应用活动证据。"
	case "connection_failed":
		stage := map[string]string{"request_headers": "读取代理请求", "dial": "连接目标服务器", "handshake": "通知客户端连接已建立", "request_body": "转发 HTTP 请求", "response": "转发 HTTP 响应", "tunnel_outbound": "转发出站数据", "tunnel_inbound": "转发入站数据"}[text("stage")]
		if stage == "" {
			stage = "代理处理"
		}
		code := map[string]string{"timeout": "超时", "dns_error": "域名解析失败", "connection_refused": "连接被拒绝", "connection_reset": "连接被重置", "connection_closed": "连接已关闭", "incomplete_stream": "数据流提前结束", "invalid_request": "请求格式无效", "header_limit": "请求头超过容量限制", "invalid_target": "目标地址无效", "unsupported_target": "不支持此目标格式", "canceled": "操作已取消"}[text("error_code")]
		if code == "" {
			code = "读写失败"
		}
		v.Description = stage + "时失败：" + code + "。已转发字节单独记录；不能据此判断证书锁定或恶意行为。"
	case "connection_closed":
		v.Description = "代理数据流结束，不能据此判断应用请求成功。"
		if text("reason") == "observation_stopped" {
			v.Description = "观察已停止，代理关闭连接；已转发字节已单独记录。"
		}
	case "connection_observed":
		v.Description = "连接目标：" + text("remote_host") + "。此记录没有上传量测量。"
	case "egress":
		out, okOut := byteCount(e.Detail["bytes_out"])
		in, okIn := byteCount(e.Detail["bytes_in"])
		v.Description = "此记录缺少有效网络字节量，不能据此推算上传量。"
		if e.Detail["metric"] == "network_bytes" && okOut && okIn {
			v.Description = fmt.Sprintf("已记录出站 %.0f 字节、入站 %.0f 字节。", out, in)
		}
		if e.Detail["direction"] == "aggregate" {
			v.Description += "这是进程汇总，不能归属到某个连接目标。"
		}
		if e.Detail["synthetic"] == true {
			v.Description += "这是模拟数据，没有对应的真实上传。"
		}
	case "process_io":
		v.Description = "包含磁盘、网络和其他读写，不能当作上传量。"
	case "process_no_longer_observed":
		v.Description = "进程可能退出，也可能暂时无法采样；不能断言它已经结束。"
	case "static_indicator":
		v.Description = ruleDescription(text("rule"))
		v.Provenance = "源代码文本匹配，不是程序已执行的证据"
	case "file_observed":
		v.Description = "在新增目录中发现文件，创建时间未知：" + text("path")
	case "file_open_observed":
		v.Description = "采样时发现打开的文件，无法证明读取了内容：" + text("path")
	case "watch_ready":
		v.Description = "已完成所选目录的初始监听注册；后续异常会单独记录。"
	case "path_excluded":
		v.Description = "跳过符号链接或 Windows 重解析点：" + text("path")
	default:
		v.Description = text("path")
	}
	if e.Layer == "net" && (e.Kind == "connection_observed" || e.Kind == "egress" || e.Kind == "connection_failed") && e.Detail["direction"] != "aggregate" {
		category := map[string]string{destination.ModelAPI: "配置中的模型 API（不代表可信）", destination.ObjectStorage: "疑似对象存储", destination.Unknown: "用途未知"}[destination.Classify(text("remote_host"), cfg.ModelAPIHosts)]
		v.Description += " 地址分类：" + category + "。"
		switch text("host_source") {
		case "reverse_dns":
			v.Provenance += "；域名来自反向 DNS，不证明实际请求的域名或服务身份"
		case "proxy_request":
			v.Provenance += "；目标来自客户端代理请求，不解密 TLS，不验证远端服务身份"
		case "socket_ip":
			v.Provenance += "；地址来自系统连接表；仅凭 IP 无法确定实际服务用途"
		default:
			v.Provenance += "；域名来源未核实，按记录中的地址分类"
		}
		if matches, field := destination.MatchIP(text("remote_host"), text("remote_ip")); len(matches) > 0 {
			v.Provenance += "；网段线索：" + destination.SummarizeRanges(matches) + "。不确认实际服务或上传；来源见展开记录。"
			v.AddressClues = "本版本对 " + field + " 的快照匹配，不是操作系统原始证据，也不确认事件发生时或当前的归属：\n" + destination.DescribeRanges(matches)
		}
	}
	if chars := []rune(v.Description); len(chars) > 240 {
		v.Description = string(chars[:240]) + "…（完整内容见原始证据）"
	}
	return v
}

func selectTimeline(events []event.Event, query url.Values, cfg rules.Config) timelineView {
	view := timelineView{Page: 1, Total: len(events), Rows: []eventView{}, Layer: query.Get("layer"), Query: strings.ToLower(strings.TrimSpace(query.Get("kind")))}
	requested, _ := strconv.Atoi(query.Get("page"))
	if requested > 0 {
		view.Page = requested
	}
	id := query.Get("evidence")
	selected := []event.Event{}
	evidenceIndex := -1
	for _, e := range events {
		matches := (view.Layer == "" || view.Layer == e.Layer) && (view.Query == "" || strings.Contains(strings.ToLower(e.Kind+" "+eventTitle(e)), view.Query))
		if !matches && e.ID != id {
			continue
		}
		if e.ID == id {
			evidenceIndex = len(selected)
		}
		selected = append(selected, e)
	}
	view.Matches = len(selected)
	view.Pages = max(1, (len(selected)+timelinePageSize-1)/timelinePageSize)
	if evidenceIndex >= 0 {
		view.Page = evidenceIndex/timelinePageSize + 1
	}
	view.Page = min(view.Page, view.Pages)
	start := (view.Page - 1) * timelinePageSize
	for _, e := range selected[start:min(len(selected), start+timelinePageSize)] {
		view.Rows = append(view.Rows, describeEvent(e, cfg))
	}
	return view
}
