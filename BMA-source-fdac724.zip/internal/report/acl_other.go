//go:build !windows

package report

func SecureDirectory(path string) error { return nil }
