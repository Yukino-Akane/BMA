package report

import (
	"bufio"
	"crypto/sha256"
	_ "embed"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"html/template"
	"io"
	"mime"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"behavior-monitoring-audit/internal/destination"
	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/rules"
)

// Policy and Authorization are exposed from the report package so callers do
// not need to depend on the rules package just to inspect session scope.
type Policy = rules.Policy
type Authorization = rules.Authorization

type Report struct {
	Tool              string              `json:"tool"`
	Version           string              `json:"version"`
	GeneratedAt       time.Time           `json:"generated_at"`
	SessionID         string              `json:"session_id"`
	Workspace         string              `json:"workspace"`
	WatchRoots        []string            `json:"watch_roots"`
	ProcessAllowlist  []string            `json:"process_allowlist"`
	Events            []event.Event       `json:"events"`
	Findings          []rules.Finding     `json:"findings"`
	Status            string              `json:"status"`
	Limitations       []string            `json:"limitations"`
	RuleConfig        rules.Config        `json:"rule_config"`
	Policy            rules.Policy        `json:"policy"`
	Authorization     rules.Authorization `json:"authorization"`
	Analysis          *Analysis           `json:"analysis,omitempty"`
	AnalysisRequest   *AnalysisRequest    `json:"analysis_request,omitempty"`
	AnalysisPreview   *AnalysisRequest    `json:"analysis_preview,omitempty"`
	RecoveredRequests *RequestArchive     `json:"recovered_requests,omitempty"`
	AnalysisError     string              `json:"analysis_error,omitempty"`
	Review            *Review             `json:"review,omitempty"`
	ReverseDNS        bool                `json:"reverse_dns"`
	Demonstration     bool                `json:"demonstration"`
	Storage           StorageStats        `json:"storage"`
}

const (
	// These bounds cover generated artifacts, not the bounded event/request
	// journals. A report that exceeds one is rejected instead of being
	// silently truncated.
	MaxReportJSONBytes     int = 256 * 1024 * 1024
	MaxOfflineArchiveBytes int = 64 * 1024 * 1024
	MaxRenderedReportBytes int = 128 * 1024 * 1024
)

// Version is overridden by the release build. Development builds retain an
// explicit suffix so a report cannot be mistaken for a published artifact.
var Version = "0.4.0-dev"

type Analysis struct {
	Verdict              string                 `json:"verdict"`
	Findings             []AnalysisFinding      `json:"findings"`
	UnexplainedEgressIDs []string               `json:"unexplained_egress_ids"`
	UnexplainedTraffic   []TrafficEvidence      `json:"unexplained_traffic"`
	BatchVerdicts        []AnalysisBatchVerdict `json:"batch_verdicts,omitempty"`
}

// AnalysisBatchVerdict preserves each model call's result. The combined
// verdict is a conservative display summary; it does not resolve semantic
// disagreement between calls.
type AnalysisBatchVerdict struct {
	Batch        int    `json:"batch"`
	Verdict      string `json:"verdict"`
	FindingCount int    `json:"finding_count"`
}

func (a Analysis) HasBatchDisagreement() bool {
	if len(a.BatchVerdicts) < 2 {
		return false
	}
	first := a.BatchVerdicts[0].Verdict
	for _, batch := range a.BatchVerdicts[1:] {
		if batch.Verdict != first {
			return true
		}
	}
	return false
}

// TrafficEvidence is calculated locally from selected event IDs, never from a
// model-provided quantity. Sources stay separate because they may overlap.
type TrafficEvidence struct {
	Source      string   `json:"source"`
	BytesOut    uint64   `json:"bytes_out"`
	EvidenceIDs []string `json:"evidence_ids"`
}

// CoverageGaps are collection failures, not findings about Agent behavior.
func (r Report) CoverageGaps() []event.Event {
	var gaps []event.Event
	for _, e := range r.Events {
		if e.Kind == "collector_error" {
			gaps = append(gaps, e)
		}
	}
	return gaps
}

type AnalysisFinding struct {
	EvidenceIDs  []string `json:"evidence_ids"`
	Claim        string   `json:"claim"`
	Confidence   float64  `json:"confidence"`
	RequestBatch int      `json:"request_batch,omitempty"`
}

type AnalysisRequest struct {
	JournalPath      string   `json:"journal_path,omitempty"`
	Endpoint         string   `json:"endpoint"`
	Model            string   `json:"model"`
	EventCount       int      `json:"event_count"`
	BatchCount       int      `json:"batch_count,omitempty"`
	AttemptedBatches int      `json:"attempted_batches"`
	CompletedBatches int      `json:"completed_batches"`
	CoveredEvents    int      `json:"covered_events"`
	TotalEvents      int      `json:"total_events"`
	FieldTypes       []string `json:"field_types"`
	Redaction        string   `json:"redaction"`
	RequestBodies    []string `json:"request_bodies"`
}

func New(sessionID, workspace string, allowlist []string, events []event.Event) Report {
	return NewWithConfig(sessionID, workspace, allowlist, events, rules.DefaultConfig())
}

func NewWithConfig(sessionID, workspace string, allowlist []string, events []event.Event, cfg rules.Config) Report {
	cfg.Policy = cfg.Policy.Normalize()
	cfg.Authorization = cfg.Authorization.Normalize()
	return Report{Tool: "bma", Version: Version, GeneratedAt: time.Now().UTC(), SessionID: sessionID, Workspace: workspace, ProcessAllowlist: allowlist, Events: events, Findings: rules.EvaluateWithConfig(events, cfg), Status: "recording", RuleConfig: cfg, Policy: cfg.Policy, Authorization: cfg.Authorization, Limitations: []string{"连接采样可能漏掉短连接；连接方向未知。", "Windows 进程总 IO 包含文件读写，不能换算为上传量。", "代理只接受能由系统 socket 表核实为选定进程的连接；macOS nettop 聚合字节量不能归属到单一目标。", "目录变更不包含 PID，不能据此确定哪个进程操作文件。", "打开文件采样不能证明文件内容被读取；看不到已关闭的文件。", "未命中规则不代表安全。"}}
}

func WriteJSON(path string, report Report) error {
	return writeAtomicStream(path, func(w io.Writer) error { return EncodeJSON(w, report) })
}

//go:embed page.html
var page string

//go:embed client.js
var embeddedClientScript string

// Browsers normalize CRLF in inline scripts before checking their CSP hash.
// Normalize once so Windows checkouts and Unix builds use the same script.
var clientScript = strings.ReplaceAll(embeddedClientScript, "\r\n", "\n")

func WriteHTML(path string, report Report) error {
	return writeAtomicStream(path, func(w io.Writer) error { return Render(w, report) })
}

func writeAtomicStream(path string, generate func(io.Writer) error) error {
	dir := filepath.Dir(path)
	temp, err := os.CreateTemp(dir, ".bma-write-*")
	if err != nil {
		return err
	}
	tempPath := temp.Name()
	defer os.Remove(tempPath)
	if err := temp.Chmod(0600); err != nil {
		_ = temp.Close()
		return err
	}
	buffer := bufio.NewWriterSize(temp, 64*1024)
	if err := generate(buffer); err != nil {
		_ = temp.Close()
		return err
	}
	if err := buffer.Flush(); err != nil {
		_ = temp.Close()
		return err
	}
	if err := temp.Sync(); err != nil {
		_ = temp.Close()
		return err
	}
	if err := temp.Close(); err != nil {
		return err
	}
	return replaceFile(tempPath, path)
}

func Render(w io.Writer, report Report) error {
	return renderPage(w, report, false, nil)
}

type reportLimitWriter struct {
	w   io.Writer
	n   int
	max int
}

func (w *reportLimitWriter) Write(p []byte) (int, error) {
	if len(p) > w.max-w.n {
		return 0, fmt.Errorf("report output exceeds %d bytes; narrow the observation scope", w.max)
	}
	n, err := w.w.Write(p)
	w.n += n
	if err == nil && n != len(p) {
		err = io.ErrShortWrite
	}
	return n, err
}

func renderPage(w io.Writer, report Report, canAddGoal bool, query url.Values) error {
	report.Policy = report.Policy.Normalize()
	report.Authorization = report.Authorization.Normalize()
	if report.Policy.ProtectedDirectories == nil && report.Policy.SensitiveCategories == nil && report.Policy.AllowedUploadDirectories == nil && report.Policy.AllowedUploadTargets == nil {
		report.Policy = report.RuleConfig.Policy.Normalize()
	}
	if report.Authorization.State == rules.AuthorizationUnknown && report.RuleConfig.Authorization.Normalize().State != rules.AuthorizationUnknown {
		report.Authorization = report.RuleConfig.Authorization.Normalize()
	}
	timeline := selectTimeline(report.Events, query, report.RuleConfig)
	t, err := template.New("report").Funcs(template.FuncMap{
		"statusLabel": statusLabel, "severityLabel": severityLabel, "verdictLabel": verdictLabel, "ruleDescription": ruleDescription,
		"ipRangeSources": destination.SnapshotSummary,
	}).Parse(page)
	if err != nil {
		return err
	}
	limited := &reportLimitWriter{w: w, max: MaxRenderedReportBytes}
	if err := t.Execute(limited, struct {
		Report
		CanAddGoal  bool
		Online      bool
		Timeline    timelineView
		Collections map[string]collectionView
	}{report, canAddGoal, query != nil, timeline, reportCollections(report, query)}); err != nil {
		return err
	}
	return writePageArchive(limited, report, timeline, query == nil)
}

// Handler exposes the report plus one optional local-only write:
// adding the user's task goal as a semantic event. No arbitrary report fields,
// files, URLs or headers are accepted from the browser.
func Handler(snapshot func() Report, host, session string, add func(event.Event) error) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Host != host {
			http.Error(w, "invalid host", http.StatusForbidden)
			return
		}
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		hash := sha256.Sum256([]byte(clientScript))
		w.Header().Set("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; script-src 'sha256-"+base64.StdEncoding.EncodeToString(hash[:])+"'; connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'")
		if r.Method == "POST" && r.URL.Path == "/api/goal" {
			if add == nil {
				http.Error(w, "goal input is disabled for this report", http.StatusMethodNotAllowed)
				return
			}
			if r.Header.Get("Origin") != "http://"+host || (r.Header.Get("Sec-Fetch-Site") != "" && r.Header.Get("Sec-Fetch-Site") != "same-origin") {
				http.Error(w, "same-origin goal submission required", http.StatusForbidden)
				return
			}
			if snapshot().Status != "recording" {
				http.Error(w, "observation has ended", http.StatusConflict)
				return
			}
			contentType, _, err := mime.ParseMediaType(r.Header.Get("Content-Type"))
			if err != nil || contentType != "application/x-www-form-urlencoded" {
				http.Error(w, "form content type required", http.StatusUnsupportedMediaType)
				return
			}
			r.Body = http.MaxBytesReader(w, r.Body, 256*1024)
			if err := r.ParseForm(); err != nil || r.URL.RawQuery != "" || len(r.PostForm) != 1 || len(r.PostForm["text"]) != 1 {
				http.Error(w, "bounded form must contain only text", http.StatusBadRequest)
				return
			}
			text := r.PostForm.Get("text")
			if strings.TrimSpace(text) == "" || len([]rune(text)) > 16000 {
				http.Error(w, "goal must contain 1-16000 characters", http.StatusBadRequest)
				return
			}
			if err := add(event.New(session, "semantic", event.Process{Name: "user"}, "goal", "direct", map[string]any{"role": "user", "text": text, "source": "web"})); err != nil {
				http.Error(w, "goal could not be saved", http.StatusInternalServerError)
				return
			}
			http.Redirect(w, r, "/#goals", http.StatusSeeOther)
			return
		}
		if r.Method != "GET" {
			http.Error(w, "read only", http.StatusMethodNotAllowed)
			return
		}
		switch r.URL.Path {
		case "/api/dashboard":
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(DashboardSnapshot(snapshot()))
		case "/api/collection":
			view, ok := selectCollection(snapshot(), r.URL.Query().Get("group"), r.URL.Query().Get("page"))
			if !ok {
				http.Error(w, "unknown collection", http.StatusBadRequest)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(view)
		case "/api/collection-item":
			index, err := strconv.Atoi(r.URL.Query().Get("index"))
			if err != nil {
				http.Error(w, "invalid item index", http.StatusBadRequest)
				return
			}
			item, ok := collectionItem(snapshot(), r.URL.Query().Get("group"), index, true)
			if !ok {
				http.NotFound(w, r)
				return
			}
			if r.URL.Query().Get("key") != item.Key {
				http.Error(w, "record changed; refresh the list", http.StatusConflict)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(item)
		case "/":
			query := r.URL.Query()
			if len(query.Get("kind")) > 256 || len(query.Get("evidence")) > 256 || len(query.Get("layer")) > 32 {
				http.Error(w, "timeline filter is too long", http.StatusBadRequest)
				return
			}
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			current := snapshot()
			if err := renderPage(w, current, add != nil && current.Status == "recording", query); err != nil {
				fmt.Println("report rendering failed:", err)
			}
		case "/api/report":
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(snapshot())
		default:
			http.NotFound(w, r)
		}
	})
}
