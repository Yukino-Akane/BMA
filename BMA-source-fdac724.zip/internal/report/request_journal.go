package report

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"time"
)

const MaxRequestJournalBytes = 64 * 1024 * 1024
const maxRequestJournalRecords = 4096
const MaxRequestBatches = maxRequestJournalRecords / 2
const requestResultReserve = 4096
const maxRequestRecordBytes = 6*4*1024*1024 + 64*1024

// RequestRecord is an intent written before sending, or the outcome of one
// attempt. A prepared record alone cannot prove that a request left the machine.
type RequestRecord struct {
	Kind      string    `json:"kind"`
	SessionID string    `json:"session_id"`
	Batch     int       `json:"batch"`
	At        time.Time `json:"at"`
	Endpoint  string    `json:"endpoint,omitempty"`
	Model     string    `json:"model,omitempty"`
	Body      string    `json:"body,omitempty"`
}

type RequestJournal struct {
	file           *os.File
	session        string
	bytes, records int
	batch          int
	pending        bool
	failed         bool
}

func NewRequestJournal(path, session string) (*RequestJournal, error) {
	if path == "" || len(session) == 0 || len(session) > 128 {
		return nil, fmt.Errorf("request journal path and bounded session ID are required")
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return nil, fmt.Errorf("create request journal: %w", err)
	}
	return &RequestJournal{file: f, session: session}, nil
}

func (j *RequestJournal) Prepare(endpoint, model string, body []byte) error {
	if j.pending {
		return fmt.Errorf("previous request has no recorded outcome")
	}
	if len(endpoint) == 0 || len(endpoint) > 4096 || len(model) == 0 || len(model) > 512 || len(body) > 4*1024*1024 || !json.Valid(body) {
		return fmt.Errorf("invalid or oversized request body")
	}
	record := RequestRecord{Kind: "prepared", SessionID: j.session, Batch: j.batch + 1, At: time.Now().UTC(), Endpoint: endpoint, Model: model, Body: string(body)}
	if err := j.append(record, requestResultReserve, 1); err != nil {
		return err
	}
	j.batch++
	j.pending = true
	return nil
}

func (j *RequestJournal) Outcome(success bool) error {
	if !j.pending {
		return fmt.Errorf("request outcome has no prepared request")
	}
	kind := "failed"
	if success {
		kind = "completed"
	}
	if err := j.append(RequestRecord{Kind: kind, SessionID: j.session, Batch: j.batch, At: time.Now().UTC()}, 0, 0); err != nil {
		return err
	}
	j.pending = false
	return nil
}

func (j *RequestJournal) append(record RequestRecord, reserveBytes, reserveRecords int) error {
	if j.failed {
		return fmt.Errorf("request journal is no longer writable")
	}
	data, err := json.Marshal(record)
	if err != nil {
		return err
	}
	data = append(data, '\n')
	if j.records+1+reserveRecords > maxRequestJournalRecords || j.bytes+len(data)+reserveBytes > MaxRequestJournalBytes {
		return fmt.Errorf("request journal capacity exceeded; request not sent")
	}
	n, err := j.file.Write(data)
	j.bytes += n
	if err == nil && n != len(data) {
		err = io.ErrShortWrite
	}
	if err == nil {
		err = j.file.Sync()
	}
	if err != nil {
		j.failed = true
		return fmt.Errorf("persist request journal: %w", err)
	}
	j.records++
	return nil
}

func (j *RequestJournal) Close() error { return j.file.Close() }

// RequestArchive preserves journal facts without reconstructing send counts or
// model conclusions. In particular, prepared is not evidence of delivery.
type RequestArchive struct {
	JournalPath         string          `json:"journal_path"`
	SessionID           string          `json:"session_id"`
	TruncatedLastRecord bool            `json:"truncated_last_record"`
	Records             []RequestRecord `json:"records"`
}

func ReadRequestJournal(path, session string) (*RequestArchive, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	before, err := f.Stat()
	if err != nil {
		return nil, err
	}
	if !before.Mode().IsRegular() || before.Size() > MaxRequestJournalBytes || !os.SameFile(before, before) {
		return nil, fmt.Errorf("invalid request journal file or size")
	}
	archive := &RequestArchive{JournalPath: path, SessionID: session}
	reader := bufio.NewReader(io.LimitReader(f, MaxRequestJournalBytes+1))
	pending, batch, total := false, 0, 0
	for {
		line, err := reader.ReadBytes('\n')
		total += len(line)
		if total > MaxRequestJournalBytes || len(line) > maxRequestRecordBytes {
			return nil, fmt.Errorf("request journal capacity exceeded")
		}
		if err == io.EOF {
			archive.TruncatedLastRecord = len(line) != 0
			break
		}
		if err != nil {
			return nil, err
		}
		if len(archive.Records) >= maxRequestJournalRecords {
			return nil, fmt.Errorf("too many request journal records")
		}
		var record RequestRecord
		decoder := json.NewDecoder(bytes.NewReader(line))
		decoder.DisallowUnknownFields()
		if err := decoder.Decode(&record); err != nil {
			return nil, fmt.Errorf("invalid request journal record")
		}
		var extra any
		if decoder.Decode(&extra) != io.EOF || record.SessionID == "" || len(record.SessionID) > 128 || record.At.IsZero() {
			return nil, fmt.Errorf("invalid request journal record")
		}
		if archive.SessionID == "" {
			archive.SessionID = record.SessionID
		}
		if archive.SessionID != record.SessionID {
			return nil, fmt.Errorf("request journal has mixed sessions")
		}
		switch record.Kind {
		case "prepared":
			if pending || record.Batch != batch+1 || len(record.Endpoint) == 0 || len(record.Endpoint) > 4096 || len(record.Model) == 0 || len(record.Model) > 512 || len(record.Body) > 4*1024*1024 || !json.Valid([]byte(record.Body)) {
				return nil, fmt.Errorf("invalid prepared request or sequence")
			}
			batch, pending = record.Batch, true
		case "completed", "failed":
			if !pending || record.Batch != batch || record.Body != "" || record.Endpoint != "" || record.Model != "" {
				return nil, fmt.Errorf("invalid request outcome or sequence")
			}
			pending = false
		default:
			return nil, fmt.Errorf("unknown request journal record kind")
		}
		archive.Records = append(archive.Records, record)
	}
	after, err := os.Stat(path)
	if err != nil {
		return nil, err
	}
	if !os.SameFile(before, after) || before.Size() != after.Size() || !before.ModTime().Equal(after.ModTime()) {
		return nil, fmt.Errorf("request journal changed during recovery; stop analysis before retrying")
	}
	return archive, nil
}
