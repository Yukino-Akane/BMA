package report

import (
	"encoding/json"
	"fmt"
	"io"
	"os"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/rules"
)

// EncodeJSON writes the report incrementally. Each event, finding, request body
// and journal record is encoded separately using encoding/json. Its working
// buffer is proportional to the largest individual record, not the report.
// A caller writing to a non-atomic sink may receive partial output on failure.
func EncodeJSON(w io.Writer, r Report) error {
	return encodeJSON(w, r, MaxReportJSONBytes)
}

func encodeJSON(w io.Writer, r Report, maxBytes int) error {
	limited := &reportLimitWriter{w: w, max: maxBytes}
	if err := writeReportValue(limited, r); err != nil {
		return fmt.Errorf("JSON report: %w", err)
	}
	_, err := io.WriteString(limited, "\n")
	return err
}

// ReadJSON bounds input bytes even when a file grows after Stat. Bulk arrays
// are decoded one record at a time; the report objects still remain in memory.
func ReadJSON(path string) (Report, error) {
	f, err := os.Open(path)
	if err != nil {
		return Report{}, err
	}
	defer f.Close()
	info, err := f.Stat()
	if err != nil {
		return Report{}, err
	}
	if !info.Mode().IsRegular() || info.Size() > int64(MaxReportJSONBytes) {
		return Report{}, fmt.Errorf("report must be a regular JSON file of at most %d bytes", MaxReportJSONBytes)
	}
	return decodeJSON(f, int64(MaxReportJSONBytes))
}

func decodeJSON(input io.Reader, maxBytes int64) (Report, error) {
	limited := &io.LimitedReader{R: input, N: maxBytes + 1}
	decoder := json.NewDecoder(limited)
	decoder.DisallowUnknownFields()
	var r Report
	_, err := readReportObject(decoder, &r, false)
	if err == nil {
		// Require exactly one document, including bounded trailing whitespace.
		// Token avoids allocating an entire second, unwanted document.
		if _, endErr := decoder.Token(); endErr != io.EOF {
			if endErr == nil {
				endErr = fmt.Errorf("unexpected data after report")
			}
			err = endErr
		}
	}
	if limited.N == 0 {
		return Report{}, fmt.Errorf("JSON report exceeds %d bytes", maxBytes)
	}
	if err != nil {
		return Report{}, fmt.Errorf("invalid report: %w", err)
	}
	// Reports written before policy metadata was introduced remain readable;
	// absence means authorization was not recorded, never that it was denied.
	r.Policy = r.Policy.Normalize()
	r.Authorization = r.Authorization.Normalize()
	r.RuleConfig.Policy = r.RuleConfig.Policy.Normalize()
	r.RuleConfig.Authorization = r.RuleConfig.Authorization.Normalize()
	if r.Policy.ProtectedDirectories == nil && r.Policy.SensitiveCategories == nil && r.Policy.AllowedUploadDirectories == nil && r.Policy.AllowedUploadTargets == nil {
		r.Policy = r.RuleConfig.Policy
	}
	if r.Authorization.State == rules.AuthorizationUnknown && r.RuleConfig.Authorization.State != rules.AuthorizationUnknown {
		r.Authorization = r.RuleConfig.Authorization
	}
	return r, nil
}

type reportJSONField struct {
	name  string
	value any
}

func writeReportObject(w io.Writer, fields ...reportJSONField) error {
	if _, err := io.WriteString(w, "{"); err != nil {
		return err
	}
	for i, field := range fields {
		if i > 0 {
			if _, err := io.WriteString(w, ",\n"); err != nil {
				return err
			}
		}
		if err := json.NewEncoder(w).Encode(field.name); err != nil {
			return err
		}
		if _, err := io.WriteString(w, ":"); err != nil {
			return err
		}
		if err := writeReportValue(w, field.value); err != nil {
			return err
		}
	}
	_, err := io.WriteString(w, "}")
	return err
}

func writeReportSlice[T any](w io.Writer, rows []T) error {
	if rows == nil {
		_, err := io.WriteString(w, "null")
		return err
	}
	return writeJSONArray(w, len(rows), func(i int) T { return rows[i] })
}

// Split only the report's bulk collections. All record encoding and escaping
// stay with encoding/json; this is not a general-purpose JSON serializer.
func writeReportValue(w io.Writer, value any) error {
	switch r := value.(type) {
	case Report:
		fields := []reportJSONField{
			{"tool", r.Tool}, {"version", r.Version}, {"generated_at", r.GeneratedAt},
			{"session_id", r.SessionID}, {"workspace", r.Workspace}, {"watch_roots", r.WatchRoots},
			{"process_allowlist", r.ProcessAllowlist}, {"events", r.Events}, {"findings", r.Findings},
			{"status", r.Status}, {"limitations", r.Limitations}, {"rule_config", r.RuleConfig},
			{"policy", r.Policy}, {"authorization", r.Authorization},
			{"reverse_dns", r.ReverseDNS}, {"demonstration", r.Demonstration}, {"storage", r.Storage},
		}
		if r.Analysis != nil {
			fields = append(fields, reportJSONField{"analysis", r.Analysis})
		}
		if r.AnalysisRequest != nil {
			fields = append(fields, reportJSONField{"analysis_request", r.AnalysisRequest})
		}
		if r.AnalysisPreview != nil {
			fields = append(fields, reportJSONField{"analysis_preview", r.AnalysisPreview})
		}
		if r.RecoveredRequests != nil {
			fields = append(fields, reportJSONField{"recovered_requests", r.RecoveredRequests})
		}
		if r.AnalysisError != "" {
			fields = append(fields, reportJSONField{"analysis_error", r.AnalysisError})
		}
		if r.Review != nil {
			fields = append(fields, reportJSONField{"review", r.Review})
		}
		return writeReportObject(w, fields...)
	case *Review:
		fields := []reportJSONField{}
		if r.Result != nil {
			fields = append(fields, reportJSONField{"result", r.Result})
		}
		if r.Request != nil {
			fields = append(fields, reportJSONField{"request", r.Request})
		}
		if r.Preview != nil {
			fields = append(fields, reportJSONField{"preview", r.Preview})
		}
		if r.Error != "" {
			fields = append(fields, reportJSONField{"error", r.Error})
		}
		return writeReportObject(w, fields...)
	case *ReviewResult:
		return writeReportObject(w, reportJSONField{"verdict", r.Verdict}, reportJSONField{"assessments", r.Assessments},
			reportJSONField{"unexplained_egress_ids", r.UnexplainedEgressIDs}, reportJSONField{"unexplained_traffic", r.UnexplainedTraffic},
			reportJSONField{"included_events", r.IncludedEvents}, reportJSONField{"total_events", r.TotalEvents})
	case []ReviewAssessment:
		return writeReportSlice(w, r)
	case *Analysis:
		fields := []reportJSONField{
			{"verdict", r.Verdict}, {"findings", r.Findings},
			{"unexplained_egress_ids", r.UnexplainedEgressIDs}, {"unexplained_traffic", r.UnexplainedTraffic},
		}
		if len(r.BatchVerdicts) > 0 {
			fields = append(fields, reportJSONField{"batch_verdicts", r.BatchVerdicts})
		}
		return writeReportObject(w, fields...)
	case *AnalysisRequest:
		fields := []reportJSONField{
			{"endpoint", r.Endpoint}, {"model", r.Model}, {"event_count", r.EventCount},
			{"attempted_batches", r.AttemptedBatches}, {"completed_batches", r.CompletedBatches},
			{"covered_events", r.CoveredEvents}, {"total_events", r.TotalEvents},
			{"field_types", r.FieldTypes}, {"redaction", r.Redaction}, {"request_bodies", r.RequestBodies},
		}
		if r.JournalPath != "" {
			fields = append(fields, reportJSONField{"journal_path", r.JournalPath})
		}
		if r.BatchCount != 0 {
			fields = append(fields, reportJSONField{"batch_count", r.BatchCount})
		}
		return writeReportObject(w, fields...)
	case *RequestArchive:
		return writeReportObject(w, reportJSONField{"journal_path", r.JournalPath}, reportJSONField{"session_id", r.SessionID},
			reportJSONField{"truncated_last_record", r.TruncatedLastRecord}, reportJSONField{"records", r.Records})
	case []event.Event:
		return writeReportSlice(w, r)
	case []rules.Finding:
		return writeReportSlice(w, r)
	case []AnalysisFinding:
		return writeReportSlice(w, r)
	case []TrafficEvidence:
		return writeReportSlice(w, r)
	case []AnalysisBatchVerdict:
		return writeReportSlice(w, r)
	case []RequestRecord:
		return writeReportSlice(w, r)
	case []string:
		return writeReportSlice(w, r)
	default:
		return json.NewEncoder(w).Encode(value)
	}
}
