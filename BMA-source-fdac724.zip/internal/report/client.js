(() => {
  if (!document.getElementById('report-content')) return;
  const pageSize = 100;
  const collectionSize = 25;
  const collectionArchive = JSON.parse(document.getElementById('collection-data').textContent);
  const collectionRequests = new Set();
  const online = document.body.dataset.online === 'true' && location.protocol !== 'file:';
  const status = document.getElementById('refresh-status');
  const layer = document.getElementById('filter-layer');
  const kind = document.getElementById('filter-kind');
  const previous = document.getElementById('previous-page');
  const next = document.getElementById('next-page');
  let rows = JSON.parse(document.getElementById('timeline-data').textContent);
  let byID = new Map(rows.map(row => [row.event.id, row]));
  let currentPage = Number(document.getElementById('timeline-state').dataset.page);
  let refreshTimer, filterTimer, controller, sequence = 0;
  layer.value = document.getElementById('timeline-state').dataset.layer;
  kind.value = document.getElementById('timeline-state').dataset.query;

  function evidenceID() {
    let id;
    try { id = decodeURIComponent(location.hash.slice(1)); } catch { return ''; }
    return ['', 'findings', 'timeline', 'goals'].includes(id) ? '' : id;
  }
  function counts(page, pages, matches, total) {
    currentPage = page;
    document.getElementById('page-status').textContent = `第 ${page} / ${pages} 页`;
    document.getElementById('filter-count').textContent = `匹配 ${matches} / ${total} 条事件，每页最多 ${pageSize} 条`;
    previous.disabled = page <= 1;
    next.disabled = page >= pages;
  }
  function textNode(tag, text, className) {
    const node = document.createElement(tag);
    node.textContent = text;
    if (className) node.className = className;
    return node;
  }
  function renderRow(row) {
    const e = row.event;
    const article = document.createElement('article');
    article.id = e.id;
    article.dataset.layer = e.layer;
    article.dataset.kind = e.kind;
    const heading = document.createElement('div');
    heading.append(textNode('span', row.layer, 'badge'), ' ', textNode('b', row.title), ' · ' + row.time);
    const details = document.createElement('details');
    details.append(textNode('summary', `展开原始证据 ${e.id} · ${e.kind}`), document.createElement('pre'));
    article.append(heading, textNode('p', row.description, 'path'),
      textNode('p', `${row.actor} · ${row.provenance}`), details);
    return article;
  }
  function fillEvidence(details) {
    const row = byID.get(details.parentElement.id);
    if (row && !details.querySelector('pre').textContent) {
      details.querySelector('pre').textContent = JSON.stringify(row.event, null, 2);
      if (row.address_clues) {
        details.append(textNode('p', '网段快照来源（本版本解释，非原始事件）'), textNode('pre', row.address_clues));
      }
    }
  }
  document.addEventListener('toggle', event => {
    if (event.target.matches('#event-list details') && event.target.open) fillEvidence(event.target);
  }, true);
  function scrollEvidence() {
    const article = document.getElementById(evidenceID());
    if (!article || !article.matches('#event-list article')) return;
    const details = article.querySelector('details');
    fillEvidence(details);
    details.open = true;
    article.scrollIntoView({block: 'center'});
  }
  function renderOffline(page, reveal) {
    const id = evidenceID();
    const query = kind.value.trim().toLowerCase();
    const selected = rows.filter(row => row.event.id === id ||
      ((!layer.value || row.event.layer === layer.value) &&
       (!query || (row.event.kind + ' ' + row.title).toLowerCase().includes(query))));
    const index = selected.findIndex(row => row.event.id === id);
    if (reveal && index >= 0) page = Math.floor(index / pageSize) + 1;
    const pages = Math.max(1, Math.ceil(selected.length / pageSize));
    page = Math.min(Math.max(1, page), pages);
    const visible = selected.slice((page - 1) * pageSize, page * pageSize);
    document.getElementById('event-list').replaceChildren(...visible.map(renderRow));
    if (!visible.length) document.getElementById('event-list').append(textNode('section', '当前筛选没有事件，可清除筛选后重试。'));
    counts(page, pages, selected.length, rows.length);
    if (reveal) scrollEvidence();
  }
  function editingGoal() {
    const goal = document.getElementById('goal-text');
    return goal && (goal.value || document.activeElement === goal);
  }
  async function load(page = currentPage, reveal = false, automatic = false) {
    if (!online) { renderOffline(page, reveal); return; }
    if (automatic && (editingGoal() || document.querySelector('.collection details[open]') || document.activeElement?.matches('.collection-target') || collectionRequests.size)) { status.textContent = '正在编辑或查看详情，刷新已暂停'; return; }
    const request = ++sequence;
    controller?.abort();
    const requestController = new AbortController();
    controller = requestController;
    const timeout = setTimeout(() => requestController.abort(), 10000);
    const query = new URLSearchParams({page: String(page), layer: layer.value, kind: kind.value});
    if (evidenceID()) query.set('evidence', evidenceID());
    document.querySelectorAll('.collection').forEach(node => query.set(node.dataset.kind + '_page', node.dataset.page));
    const open = [...document.querySelectorAll('#event-list details[open]')].map(node => node.parentElement.id);
    try {
      const response = await fetch('/?' + query, {cache: 'no-store', credentials: 'omit', signal: requestController.signal});
      if (!response.ok) throw new Error('refresh');
      const doc = new DOMParser().parseFromString(await response.text(), 'text/html');
      if (request !== sequence || query.get('kind') !== kind.value || query.get('layer') !== layer.value) return;
      if (automatic && (editingGoal() || document.querySelector('.collection details[open]') || document.activeElement?.matches('.collection-target') || collectionRequests.size)) { status.textContent = '正在编辑或查看详情，刷新已暂停'; return; }
      const incoming = JSON.parse(doc.getElementById('timeline-data').textContent);
      for (const id of ['report-content', 'event-list', 'finding-list', 'timeline-state']) {
        if (!doc.getElementById(id)) throw new Error('invalid report');
      }
      for (const id of ['report-content', 'event-list', 'finding-list', 'timeline-state']) {
        document.getElementById(id).replaceWith(doc.getElementById(id));
      }
      rows = incoming;
      byID = new Map(rows.map(row => [row.event.id, row]));
      const state = document.getElementById('timeline-state').dataset;
      counts(Number(state.page), Number(state.pages), Number(state.matches), Number(state.total));
      open.forEach(id => {
        const details = document.getElementById(id)?.querySelector('details');
        if (details) { fillEvidence(details); details.open = true; }
      });
      if (reveal) scrollEvidence();
      status.textContent = '页面已更新 · ' + new Date().toLocaleTimeString();
      document.body.dataset.live = doc.body.dataset.live;
      if (doc.body.dataset.live !== 'true') {
        document.getElementById('goals')?.remove();
        status.textContent = '静态报告，可筛选和翻页';
      }
    } catch {
      if (request === sequence) status.textContent = '暂时无法更新，保留当前报告；观察结束后可打开保存的 HTML';
    } finally { clearTimeout(timeout); }
  }
  function changeFilter() { clearTimeout(filterTimer); filterTimer = setTimeout(() => load(1, Boolean(evidenceID())), 200); }
  layer.addEventListener('change', changeFilter);
  kind.addEventListener('input', changeFilter);
  document.getElementById('clear-filter').addEventListener('click', () => {
    layer.value = ''; kind.value = ''; clearTimeout(filterTimer); load(1, Boolean(evidenceID()));
  });
  function changePage(offset) {
    if (evidenceID()) history.replaceState(null, '', location.href.split('#')[0]);
    load(currentPage + offset).then(() => document.getElementById('timeline').scrollIntoView());
  }
  previous.addEventListener('click', () => changePage(-1));
  next.addEventListener('click', () => changePage(1));
  window.addEventListener('hashchange', () => { if (evidenceID()) load(currentPage, true); });
  document.addEventListener('click', event => {
    const link = event.target.closest('a[href^="#"]');
    if (link && link.hash === location.hash && evidenceID()) load(currentPage, true);
  });
  function evidenceLinks(ids) {
    const fragment = document.createDocumentFragment();
    ids.forEach(id => {
      const link = textNode('a', id);
      link.setAttribute('href', '#' + encodeURIComponent(id));
      fragment.append(link, ' ');
    });
    return fragment;
  }
  function collectionRow(row) {
    const article = document.createElement('article');
    article.className = row.severity;
    article.append(textNode('h3', row.title));
    if (row.description) article.append(textNode('p', row.description));
    if (row.meta) article.append(textNode('small', row.meta));
    if (row.evidence_ids?.length) {
      const refs = textNode('p', '证据：');
      refs.append(evidenceLinks(row.evidence_ids.slice(0, 3)));
      article.append(refs);
    }
    if (row.has_body || row.evidence_count) {
      const details = document.createElement('details');
      details.dataset.item = row.index;
      details.dataset.key = row.key;
      details.append(textNode('summary', '展开完整记录' + (row.evidence_count ? ` · ${row.evidence_count} 条证据` : '')),
        textNode('div', '', 'collection-detail'));
      article.append(details);
    }
    return article;
  }
  function paintCollection(node, view) {
    node.dataset.page = view.page;
    node.dataset.pages = view.pages;
    node.dataset.total = view.total;
    node.querySelector('.collection-target').value = view.page;
    node.querySelector('.collection-target').max = view.pages;
    node.querySelector('.collection-status').textContent = `共 ${view.total} 条 · 第 ${view.page} / ${view.pages} 页 · 每页最多 ${collectionSize} 条`;
    node.querySelector('[data-collection-step="-1"]').disabled = view.page <= 1;
    node.querySelector('[data-collection-step="1"]').disabled = view.page >= view.pages;
    node.querySelector('.collection-rows').replaceChildren(...view.rows.map(collectionRow));
    if (!view.rows.length) node.querySelector('.collection-rows').append(textNode('p', '暂无记录。没有记录不代表没有发生。'));
  }
  async function collectionJSON(path, request) {
    const timeout = setTimeout(() => request.abort(), 10000);
    collectionRequests.add(request);
    try {
      const response = await fetch(path, {cache:'no-store', credentials:'omit', signal:request.signal});
      if (!response.ok) throw new Error('collection changed or unavailable');
      return await response.json();
    } finally { clearTimeout(timeout); collectionRequests.delete(request); }
  }
  async function changeCollection(node, requested) {
    // A page refresh started before this user action must not replace the
    // newly selected collection page when its older response arrives.
    sequence++;
    controller?.abort();
    node.request?.abort();
    const request = new AbortController();
    node.request = request;
    const group = node.dataset.kind;
    try {
      let view;
      if (online) {
        view = await collectionJSON('/api/collection?' + new URLSearchParams({group, page:requested}), request);
      } else {
        const all = collectionArchive[group] || [];
        const pages = Math.max(1, Math.ceil(all.length / collectionSize));
        const page = Math.max(1, Math.min(requested, pages));
        view = {page, pages, total:all.length, rows:all.slice((page-1)*collectionSize, page*collectionSize)};
      }
      if (!node.isConnected || node.request !== request) return;
      paintCollection(node, view);
      node.scrollIntoView({block:'start'});
    } catch {
      if (node.isConnected && node.request === request) node.querySelector('.collection-status').textContent = '暂时无法翻页，当前记录已保留。';
    }
  }
  function showCollectionDetail(target, row) {
    target.replaceChildren();
    if (row.body) target.append(textNode('pre', row.body));
    const ids = row.evidence_ids || [];
    if (ids.length) {
      const refs = document.createElement('p');
      const label = textNode('span', '');
      const back = textNode('button', '上一页证据');
      const forward = textNode('button', '下一页证据');
      back.type = forward.type = 'button';
      let page = 1;
      const pages = Math.ceil(ids.length / pageSize);
      function draw() {
        label.textContent = ` 第 ${page} / ${pages} 页 · 共 ${ids.length} 条证据 `;
        refs.replaceChildren(evidenceLinks(ids.slice((page-1)*pageSize, page*pageSize)));
        back.disabled = page <= 1; forward.disabled = page >= pages;
      }
      back.addEventListener('click', () => { page--; draw(); });
      forward.addEventListener('click', () => { page++; draw(); });
      target.append(back, label, forward, refs);
      draw();
    }
  }
  async function openCollectionDetail(details) {
    details.request?.abort();
    const target = details.querySelector('.collection-detail');
    if (!details.open) { target.replaceChildren(); return; }
    const request = new AbortController();
    details.request = request;
    const group = details.closest('.collection').dataset.kind;
    const index = Number(details.dataset.item);
    target.replaceChildren(textNode('p', '正在加载…'));
    try {
      const row = online
        ? await collectionJSON('/api/collection-item?' + new URLSearchParams({group, index, key:details.dataset.key}), request)
        : collectionArchive[group]?.[index];
      if (!details.isConnected || !details.open || details.request !== request) return;
      if (!row) throw new Error('missing record');
      showCollectionDetail(target, row);
    } catch {
      if (details.isConnected && details.open && details.request === request) target.replaceChildren(textNode('p', '记录可能已更新，或暂时无法读取。请刷新列表后重试；原始数据仍保留在报告中。'));
    }
  }
  document.addEventListener('toggle', event => {
    if (event.target.matches('.collection details')) openCollectionDetail(event.target);
  }, true);
  document.addEventListener('click', event => {
    const button = event.target.closest('[data-collection-step]');
    if (button) {
      const node = button.closest('.collection');
      changeCollection(node, Number(node.dataset.page) + Number(button.dataset.collectionStep));
    }
  });
  document.addEventListener('submit', event => {
    if (!event.target.matches('.collection-navigation')) return;
    event.preventDefault();
    const node = event.target.closest('.collection');
    changeCollection(node, Number(node.querySelector('.collection-target').value));
  });
  const initial = document.getElementById('timeline-state').dataset;
  counts(Number(initial.page), Number(initial.pages), Number(initial.matches), Number(initial.total));
  if (evidenceID()) load(currentPage, true);
  async function refresh() {
    if (document.body.dataset.live !== 'true') return;
    await load(currentPage, false, true);
    refreshTimer = setTimeout(refresh, 3000);
  }
  if (online && document.body.dataset.live === 'true') refreshTimer = setTimeout(refresh, 3000);
  window.addEventListener('pagehide', () => { clearTimeout(refreshTimer); clearTimeout(filterTimer); controller?.abort(); collectionRequests.forEach(request => request.abort()); });
})();
