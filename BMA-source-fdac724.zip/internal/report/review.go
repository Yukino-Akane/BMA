package report

// Review preserves a separate assessment of the first-pass findings. Original
// findings and their request provenance remain in Analysis for inspection.
type Review struct {
	Result  *ReviewResult    `json:"result,omitempty"`
	Request *AnalysisRequest `json:"request,omitempty"`
	Preview *AnalysisRequest `json:"preview,omitempty"`
	Error   string           `json:"error,omitempty"`
}

type ReviewResult struct {
	Verdict              string             `json:"verdict"`
	Assessments          []ReviewAssessment `json:"assessments"`
	UnexplainedEgressIDs []string           `json:"unexplained_egress_ids"`
	UnexplainedTraffic   []TrafficEvidence  `json:"unexplained_traffic"`
	IncludedEvents       int                `json:"included_events"`
	TotalEvents          int                `json:"total_events"`
}

type ReviewAssessment struct {
	FindingIDs   []int    `json:"finding_ids"`
	Relationship string   `json:"relationship"`
	Status       string   `json:"status"`
	Claim        string   `json:"claim"`
	EvidenceIDs  []string `json:"evidence_ids"`
	Confidence   float64  `json:"confidence"`
}

func (r ReviewResult) HasUnresolved() bool {
	for _, a := range r.Assessments {
		if a.Status == "unresolved" {
			return true
		}
	}
	return false
}
