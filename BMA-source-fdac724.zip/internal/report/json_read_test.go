package report

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"reflect"
	"strings"
	"testing"
)

func TestReadJSONRejectsInvalidContainersWithoutPartialReport(t *testing.T) {
	for _, input := range []string{
		`{"events":[],"events":[]}`,
		`{"events":[],"event\u0073":[]}`,
		`{"unknown":{"large":"not silently skipped"}}`,
		`{"events":[{"id":"first"}],"findings":{}}`,
		`{"events":[{"id":"first"},{"id":42}]}`,
		`{"events":[{"id":"first","unrecognized":true}]}`,
		`{"analysis":{"verdict":"clean","verdict":"alarming"}}`,
		`{"review":{"result":{"assessments":[],"assessments":[]}}}`,
		`{"analysis_request":{"request_bodies":"not an array"}}`,
		`{"recovered_requests":{"records":[{}],"unknown":[]}}`,
		`{"events":[{"id":"first"}],"review":false}`,
		`{"events":[{"id":"first"}],"review":{`,
		`{"events":[{"id":"first"}]} {"second":true}`,
	} {
		r, err := decodeJSON(strings.NewReader(input), int64(len(input)))
		if err == nil || !reflect.DeepEqual(r, Report{}) {
			t.Fatalf("invalid input accepted or partial data escaped: %s", input)
		}
	}
	// Dynamic event details are intentionally allowed; report structures are not
	// a reason to discard newly observed OS or Agent metadata inside detail.
	input := `{"events":[{"id":"first","detail":{"future_os_key":{"nested":[1,true,null]}}}],"analysis":null,"review":{"result":null,"preview":{"request_bodies":[]}},"watch_roots":null}`
	got, err := decodeJSON(strings.NewReader(input), int64(len(input)))
	if err != nil || got.Analysis != nil || got.Review == nil || got.Review.Result != nil || got.Review.Preview.RequestBodies == nil || got.Events[0].Detail["future_os_key"] == nil {
		t.Fatal("valid null, empty collection or dynamic metadata rejected", err)
	}
}

type readProgressProbe struct {
	source *strings.Reader
	read   int
	check  func(int) error
}

func (p *readProgressProbe) Read(b []byte) (int, error) {
	if err := p.check(p.read); err != nil {
		return 0, err
	}
	// Short reads exercise token boundaries without depending on the decoder's
	// private buffer layout or the garbage collector's timing.
	n, err := p.source.Read(b[:min(len(b), 97)])
	p.read += n
	return n, err
}

func TestLargeEventCollectionDecodesBeforeEndOfInput(t *testing.T) {
	input := `{"events":[` + strings.Repeat(`{},`, 19999) + `{}]}`
	var r Report
	observed := false
	p := &readProgressProbe{source: strings.NewReader(input), check: func(n int) error {
		if n > len(input)/2 && n < len(input)-1000 {
			if len(r.Events) < 1000 {
				return errors.New("input buffered before decoding records")
			}
			observed = true
		}
		return nil
	}}
	d := json.NewDecoder(p)
	if _, err := readReportObject(d, &r, false); err != nil || !observed || len(r.Events) != 20000 {
		t.Fatal("collection did not stream", err)
	}
}

func TestNestedCollectionErrorsStopBeforeRemainingInput(t *testing.T) {
	for _, tc := range []struct{ prefix, badRow, suffix string }{
		{`{"events":[`, `{"id":42}`, `]}`},
		{`{"findings":[`, `{"summary":42}`, `]}`},
		{`{"analysis":{"findings":[`, `{"claim":42}`, `]}}`},
		{`{"analysis":{"unexplained_traffic":[`, `{"source":42}`, `]}}`},
		{`{"analysis":{"batch_verdicts":[`, `{"verdict":42}`, `]}}`},
		{`{"analysis_request":{"request_bodies":[`, `42`, `]}}`},
		{`{"recovered_requests":{"records":[`, `{"kind":42}`, `]}}`},
		{`{"review":{"result":{"assessments":[`, `{"claim":42}`, `]}}}`},
	} {
		input := tc.prefix + tc.badRow + "," + strings.Repeat(`{},`, 19999) + `{}` + tc.suffix
		p := &readProgressProbe{source: strings.NewReader(input), check: func(n int) error {
			if n > 1000 {
				return errors.New("invalid record did not stop input consumption")
			}
			return nil
		}}
		got, err := decodeJSON(p, int64(len(input)))
		var typeError *json.UnmarshalTypeError
		if !errors.As(err, &typeError) || p.read > 1000 || !reflect.DeepEqual(got, Report{}) {
			t.Fatalf("nested collection was buffered or partially accepted: %s %v", tc.prefix, err)
		}
	}
}

func TestReadJSONPropagatesReadFailureAndStopsOnUnknownField(t *testing.T) {
	r, err := decodeJSON(io.MultiReader(strings.NewReader(`{"events":[{"id":"partial"},`), brokenReportReader{}), 10000)
	if !errors.Is(err, io.ErrClosedPipe) || !reflect.DeepEqual(r, Report{}) {
		t.Fatal("read failure hidden or partial report returned", err)
	}
	// Unknown fields must be rejected before decoding their potentially huge
	// value; only a small decoder read-ahead is permitted.
	p := &readProgressProbe{source: strings.NewReader(`{"unknown":"` + strings.Repeat("x", 100000) + `"}`), check: func(n int) error {
		if n > 1000 {
			return errors.New("unknown field value was read")
		}
		return nil
	}}
	_, err = decodeJSON(p, 200000)
	if err == nil || !strings.Contains(err.Error(), "unknown report field") || p.read > 1000 {
		t.Fatal("unknown value buffered", err, p.read)
	}
}

type brokenReportReader struct{}

func (brokenReportReader) Read([]byte) (int, error) { return 0, io.ErrClosedPipe }

func BenchmarkReportJSONRead(b *testing.B) {
	row := []byte(`{"detail":{"text":"` + strings.Repeat("x", 8192) + `"}},`)
	data := append([]byte(`{"events":[`), bytes.Repeat(row, 4096)...)
	data[len(data)-1] = ']'
	data = append(data, '}')
	for _, mode := range []string{"streamed", "whole_value"} {
		b.Run(mode, func(b *testing.B) {
			b.SetBytes(int64(len(data)))
			b.ReportAllocs()
			for b.Loop() {
				var r Report
				var err error
				if mode == "streamed" {
					r, err = decodeJSON(bytes.NewReader(data), int64(len(data)))
				} else {
					d := json.NewDecoder(bytes.NewReader(data))
					d.DisallowUnknownFields()
					err = d.Decode(&r)
				}
				if err != nil || len(r.Events) != 4096 {
					b.Fatal("benchmark input invalid", err)
				}
			}
		})
	}
}
