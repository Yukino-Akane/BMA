package report

import (
	"bytes"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/rules"
)

func TestInlineScriptCSPMatchesBrowserNormalizedText(t *testing.T) {
	h := Handler(func() Report { return New("s", "w", nil, nil) }, "127.0.0.1:7788", "", nil)
	w := httptest.NewRecorder()
	h.ServeHTTP(w, httptest.NewRequest("GET", "http://127.0.0.1:7788/", nil))
	_, tail, ok := strings.Cut(w.Body.String(), "<script>")
	if !ok {
		t.Fatal("missing inline script")
	}
	script, _, ok := strings.Cut(tail, "</script>")
	if !ok {
		t.Fatal("missing script terminator")
	}
	browserText := strings.ReplaceAll(script, "\r\n", "\n")
	hash := sha256.Sum256([]byte(browserText))
	if strings.Contains(script, "\r") || !strings.Contains(w.Header().Get("Content-Security-Policy"), "'sha256-"+base64.StdEncoding.EncodeToString(hash[:])+"'") {
		t.Fatal("browser-normalized inline script does not match CSP")
	}
}

func TestModelFindingShowsItsRequestBatch(t *testing.T) {
	r := New("s", "w", nil, nil)
	r.Analysis = &Analysis{Verdict: "suspicious", Findings: []AnalysisFinding{{Claim: "Fixture finding", Confidence: .8, EvidenceIDs: []string{"e_fixture"}, RequestBatch: 7}}}
	row, ok := collectionItem(r, "model", 0, false)
	if !ok || !strings.Contains(row.Meta, "请求批次 7") {
		t.Fatal("finding request provenance missing")
	}
	var html bytes.Buffer
	if err := Render(&html, r); err != nil || !strings.Contains(html.String(), "请求批次 7") {
		t.Fatal("offline report lost request provenance", err)
	}
}

func TestLongReviewClaimPreservesOriginalFindingsInDetail(t *testing.T) {
	r := New("s", "w", nil, nil)
	original := AnalysisFinding{Claim: "Original interpretation", EvidenceIDs: []string{"e_fixture"}, RequestBatch: 7}
	r.Analysis = &Analysis{Findings: []AnalysisFinding{original}}
	a := ReviewAssessment{FindingIDs: []int{1}, Claim: strings.Repeat("复核", 200), EvidenceIDs: original.EvidenceIDs}
	r.Review = &Review{Result: &ReviewResult{Assessments: []ReviewAssessment{a}}}
	row, ok := collectionItem(r, "review", 0, true)
	var detail struct {
		Assessment ReviewAssessment  `json:"assessment"`
		Original   []AnalysisFinding `json:"original_findings"`
	}
	if !ok || len([]rune(row.Title)) > 241 || json.Unmarshal([]byte(row.Body), &detail) != nil || detail.Assessment.Claim != a.Claim || len(detail.Original) != 1 || detail.Original[0].RequestBatch != 7 {
		t.Fatal("long review lost original evidence or batch provenance")
	}
}

func collectionFixture() Report {
	r := timelineFixture(251)
	ids := make([]string, len(r.Events))
	for i, e := range r.Events {
		ids[i] = e.ID
	}
	for i := 0; i < 5000; i++ {
		r.Findings = append(r.Findings, rules.Finding{Severity: "medium", Rule: "file/large-or-packed", Summary: fmt.Sprintf("Finding %d", i), EvidenceIDs: ids})
	}
	r.Analysis = &Analysis{Verdict: "suspicious"}
	r.AnalysisRequest = &AnalysisRequest{}
	r.AnalysisPreview = &AnalysisRequest{}
	r.RecoveredRequests = &RequestArchive{}
	for i := 0; i < 60; i++ {
		gap := event.New("s", "semantic", event.Process{Name: "collector"}, "collector_error", "direct", map[string]any{"source": "synthetic", "coverage": "incomplete"})
		gap.ID = fmt.Sprintf("e_gap_%03d", i)
		r.Events = append(r.Events, gap)
	}
	for i := 0; i < 60; i++ {
		body := fmt.Sprintf(`{"batch":%d,"text":"%s</script><script>unsafe()</script>"}`, i, strings.Repeat("x", 4096))
		r.AnalysisRequest.RequestBodies = append(r.AnalysisRequest.RequestBodies, body)
		r.AnalysisPreview.RequestBodies = append(r.AnalysisPreview.RequestBodies, body)
		r.RecoveredRequests.Records = append(r.RecoveredRequests.Records, RequestRecord{Batch: i + 1, Kind: "prepared", Body: body})
		r.Analysis.Findings = append(r.Analysis.Findings, AnalysisFinding{Claim: fmt.Sprintf("Model finding %d", i), Confidence: .5, EvidenceIDs: ids})
		r.Analysis.UnexplainedTraffic = append(r.Analysis.UnexplainedTraffic, TrafficEvidence{Source: fmt.Sprintf("source-%02d", i), BytesOut: uint64(i + 1), EvidenceIDs: ids})
		r.Analysis.BatchVerdicts = append(r.Analysis.BatchVerdicts, AnalysisBatchVerdict{Batch: i + 1, Verdict: "suspicious", FindingCount: i})
	}
	r.Review = &Review{Result: &ReviewResult{Verdict: "suspicious", UnexplainedTraffic: r.Analysis.UnexplainedTraffic, IncludedEvents: len(r.Events), TotalEvents: len(r.Events)}, Request: r.AnalysisRequest, Preview: r.AnalysisPreview, Error: "synthetic review error"}
	for i, f := range r.Analysis.Findings {
		r.Review.Result.Assessments = append(r.Review.Result.Assessments, ReviewAssessment{FindingIDs: []int{i + 1}, Relationship: "independent", Status: "unresolved", Claim: f.Claim, EvidenceIDs: f.EvidenceIDs, Confidence: .5})
	}
	return r
}

func TestCollectionPagesBoundMetadataAndLoadExactDetails(t *testing.T) {
	r := collectionFixture()
	h := Handler(func() Report { return r }, "127.0.0.1:7788", "", nil)
	for _, kind := range collectionKinds {
		t.Run(kind, func(t *testing.T) {
			w := httptest.NewRecorder()
			h.ServeHTTP(w, httptest.NewRequest("GET", "http://127.0.0.1:7788/api/collection?group="+kind+"&page=2", nil))
			var view collectionView
			if err := json.Unmarshal(w.Body.Bytes(), &view); err != nil {
				t.Fatal(err)
			}
			if w.Code != 200 || len(view.Rows) != 25 || view.Rows[0].Index != 25 || view.Page != 2 || w.Body.Len() > 40000 {
				t.Fatal("unbounded or wrong page", w.Code, w.Body.Len())
			}
			for _, row := range view.Rows {
				if row.Body != "" || len(row.EvidenceIDs) > 3 {
					t.Fatal("full detail leaked into list")
				}
			}
			row := view.Rows[0]
			w = httptest.NewRecorder()
			h.ServeHTTP(w, httptest.NewRequest("GET", "http://127.0.0.1:7788/api/collection-item?"+url.Values{"group": {kind}, "index": {"25"}, "key": {row.Key}}.Encode(), nil))
			var full collectionRow
			if err := json.Unmarshal(w.Body.Bytes(), &full); err != nil {
				t.Fatal(err)
			}
			if w.Code != 200 || full.Key != row.Key || len(full.EvidenceIDs) != row.EvidenceCount {
				t.Fatal("detail missing evidence")
			}
			if kind == "requests" && full.Body != r.AnalysisRequest.RequestBodies[25] {
				t.Fatal("request body altered")
			}
		})
	}
}

func TestOnlineCollectionsExcludeBodiesAndOfflineArchivePreservesAll(t *testing.T) {
	r := collectionFixture()
	var online bytes.Buffer
	if err := renderPage(&online, r, false, url.Values{"rules_page": {"200"}, "requests_page": {"3"}}); err != nil {
		t.Fatal(err)
	}
	if online.Len() > 250000 || strings.Contains(online.String(), strings.Repeat("x", 100)) || !strings.Contains(online.String(), "Finding 4999") || strings.Contains(online.String(), "Finding 0</h3>") {
		t.Fatal("online page did not bound collections", online.Len())
	}
	var offline bytes.Buffer
	if err := Render(&offline, r); err != nil {
		t.Fatal(err)
	}
	_, tail, ok := strings.Cut(offline.String(), `<script id="collection-data" type="application/json">`)
	if !ok {
		t.Fatal("missing offline archive")
	}
	data, _, ok := strings.Cut(tail, "</script>")
	if !ok {
		t.Fatal("missing archive terminator")
	}
	var archive map[string][]collectionRow
	if err := json.Unmarshal([]byte(data), &archive); err != nil {
		t.Fatal(err)
	}
	if len(archive["rules"]) != 5000 || len(archive["requests"]) != 60 || archive["requests"][59].Body != r.AnalysisRequest.RequestBodies[59] || len(archive["rules"][4999].EvidenceIDs) != 251 {
		t.Fatal("offline records lost")
	}
	if strings.Contains(offline.String(), "</script><script>unsafe") || strings.Contains(offline.String(), "Finding 4999</h3>") || strings.Contains(offline.String(), "<pre>{") {
		t.Fatal("unsafe archive or full DOM rendered")
	}
}

func TestCollectionDetailsRejectStaleIndexAndUnsafeRequests(t *testing.T) {
	r := collectionFixture()
	row, _ := collectionItem(r, "rules", 0, false)
	r.Findings[0], r.Findings[1] = r.Findings[1], r.Findings[0]
	h := Handler(func() Report { return r }, "127.0.0.1:7788", "", nil)
	for _, tc := range []struct {
		path, method, host string
		code               int
	}{
		{"/api/collection-item?group=rules&index=0&key=" + row.Key, "GET", "127.0.0.1:7788", 409},
		{"/api/collection-item?group=requests&index=-1", "GET", "127.0.0.1:7788", 404},
		{"/api/collection-item?group=requests&index=99999999999999999999", "GET", "127.0.0.1:7788", 400},
		{"/api/collection?group=../../secret", "GET", "127.0.0.1:7788", 400},
		{"/api/collection?group=requests", "POST", "127.0.0.1:7788", 405},
		{"/api/collection?group=requests", "GET", "other.invalid", 403},
	} {
		w := httptest.NewRecorder()
		req := httptest.NewRequest(tc.method, "http://127.0.0.1:7788"+tc.path, nil)
		req.Host = tc.host
		h.ServeHTTP(w, req)
		if w.Code != tc.code {
			t.Fatalf("%s: got %d want %d", tc.path, w.Code, tc.code)
		}
	}
	for _, page := range []string{"-1", "0", "bad", "99999999999999999999999", "99999"} {
		v, _ := selectCollection(r, "requests", page)
		if v.Page < 1 || v.Page > 3 || len(v.Rows) > collectionPageSize {
			t.Fatal("unbounded page")
		}
	}
}
