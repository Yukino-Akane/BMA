package report

import (
	"encoding/json"
	"math"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/rules"
)

func TestDashboardSeparatesSourcesAndCoverage(t *testing.T) {
	makeEvent := func(kind, layer string, detail map[string]any) event.Event {
		return event.New("s", layer, event.Process{PID: 123, Name: "fixture"}, kind, "direct", detail)
	}
	events := []event.Event{
		makeEvent("connection_observed", "net", nil),
		makeEvent("connection_observed", "net", map[string]any{"source": "proxy"}),
		makeEvent("collector_error", "file", map[string]any{"error": "private-error"}),
		makeEvent("collector_recovered", "file", nil),
		makeEvent("file_change", "file", map[string]any{"path": "private-path"}),
		makeEvent("process_io", "net", map[string]any{"bytes_out": 9999}),
		makeEvent("goal", "semantic", map[string]any{"text": "private-goal"}),
	}
	for _, source := range []string{"nettop", "proxy"} {
		events = append(events, makeEvent("egress", "net", map[string]any{"source": source, "metric": "network_bytes", "bytes_in": uint64(12), "bytes_out": json.Number("34")}))
	}
	events = append(events, makeEvent("egress", "net", map[string]any{"source": "proxy", "metric": "network_bytes", "bytes_in": -1, "bytes_out": 100}))
	r := New("s", "", []string{"123"}, events)
	d := DashboardSnapshot(r)
	if d.Connections != 1 || d.Gaps != 1 || d.Files != 1 || d.FileWatching {
		t.Fatalf("bad coverage: %+v", d)
	}
	if d.Traffic["nettop"].Out != 34 || d.Traffic["proxy"].Out != 34 || d.Traffic["proxy"].In != 12 {
		t.Fatalf("bad traffic: %+v", d.Traffic)
	}
	data, _ := json.Marshal(d)
	if strings.Contains(string(data), "private-") {
		t.Fatal("dashboard leaked event bodies")
	}
	for i := 0; i < 100; i++ {
		r.Events = append(r.Events, makeEvent("connection_observed", "net", nil))
	}
	if len(DashboardSnapshot(r).Recent) != 12 {
		t.Fatal("recent activity must be bounded")
	}
	r.WatchRoots = []string{"explicit"}
	if !DashboardSnapshot(r).FileWatching {
		t.Fatal("selected file scope lost")
	}
}

func TestDashboardBoundsLabelsAndRejectsOverflow(t *testing.T) {
	e := event.New("s", "net", event.Process{Name: strings.Repeat("名", 10000)}, "egress", "direct",
		map[string]any{"metric": "network_bytes", "source": "proxy", "bytes_in": uint64(1), "bytes_out": uint64(math.MaxUint64)})
	r := New("s", "", nil, []event.Event{e, e})
	d := DashboardSnapshot(r)
	if _, ok := d.Traffic["proxy"]; ok {
		t.Fatal("overflow must not appear as a measured total")
	}
	data, err := json.Marshal(d)
	if err != nil || len(data) > 2048 {
		t.Fatalf("unbounded dashboard: %d, %v", len(data), err)
	}
}

func TestDashboardEndpointUsesHostAndMethodBoundary(t *testing.T) {
	r := New("s", "", []string{"123"}, nil)
	h := Handler(func() Report { return r }, "127.0.0.1:7788", "s", nil)
	for _, tc := range []struct {
		method, host string
		code         int
	}{
		{"GET", "127.0.0.1:7788", 200}, {"GET", "attacker.invalid", 403}, {"POST", "127.0.0.1:7788", 405},
	} {
		w := httptest.NewRecorder()
		h.ServeHTTP(w, httptest.NewRequest(tc.method, "http://"+tc.host+"/api/dashboard", nil))
		if w.Code != tc.code {
			t.Fatalf("%+v: %d", tc, w.Code)
		}
		if tc.code == 200 {
			var d Dashboard
			if err := json.Unmarshal(w.Body.Bytes(), &d); err != nil {
				t.Fatal(err)
			}
			if len(d.Traffic) != 0 || d.Recent == nil {
				t.Fatal("empty dashboard implies missing samples, not measured zero")
			}
		}
	}
}

func TestDashboardScopeTracksProcessInstances(t *testing.T) {
	root := event.Process{PID: 10, CreatedAtMS: 100}
	child := event.Process{PID: 11, CreatedAtMS: 101}
	reused := event.Process{PID: 11, CreatedAtMS: 200}
	events := []event.Event{
		event.New("s", "net", root, "scope_member_added", "direct", map[string]any{"root": true}),
		event.New("s", "net", child, "scope_member_added", "direct", map[string]any{"root": false}),
		event.New("s", "net", reused, "scope_member_added", "direct", map[string]any{"root": false}),
		event.New("s", "net", child, "scope_member_removed", "direct", nil),
	}
	d := DashboardSnapshot(New("s", "", nil, events))
	if d.ScopeRoots != 1 || d.ScopeChildren != 1 {
		t.Fatalf("reused PID miscounted: %+v", d)
	}
}

func TestDashboardUsesCollectorSampleTimes(t *testing.T) {
	at := time.Date(2026, 9, 23, 1, 2, 3, 0, time.UTC)
	sample := event.New("s", "net", event.Process{Name: "collector"}, "collector_sample", "direct", map[string]any{
		"interval_sec": 5.0, "covered_processes": 3, "scope_roots": 1, "scope_children": 2,
		"health": map[string]int{"ok": 4, "failed": 1}, "last_success_at": at.Add(-time.Second).Format(time.RFC3339Nano),
	})
	sample.TS = at
	d := DashboardSnapshot(New("s", "", nil, []event.Event{sample}))
	if d.LastSampleAt == nil || !d.LastSampleAt.Equal(at) || d.LastSuccessAt == nil || d.IntervalSec != 5 || d.Covered != 3 || d.Health["failed"] != 1 {
		t.Fatalf("sample metadata missing: %+v", d)
	}
}

func TestDashboardCountsConfiguredRootsWhenRootIsUnverified(t *testing.T) {
	at := time.Date(2026, 9, 23, 1, 2, 3, 0, time.UTC)
	sample := event.New("s", "net", event.Process{Name: "collector"}, "collector_sample", "direct", map[string]any{
		"interval_sec": 2.0, "covered_processes": 0, "scope_roots": 1, "scope_children": 0,
		"health": map[string]int{"failed": 1},
	})
	sample.TS = at
	rootFailure := event.New("s", "net", event.Process{PID: 123, CreatedAtMS: 456}, "collector_error", "direct", map[string]any{"source": "process_scope", "state": "failed"})
	d := DashboardSnapshot(New("s", "", nil, []event.Event{rootFailure, sample}))
	if d.ScopeRoots != 1 || d.Covered != 0 || d.Gaps != 1 || d.Health["failed"] != 1 {
		t.Fatalf("configured root or failure was hidden: %+v", d)
	}
}

func TestDashboardSampleRoundTripAndRecentActivity(t *testing.T) {
	at := time.Now().UTC()
	activity := event.New("s", "net", event.Process{Name: "fixture"}, "connection_observed", "direct", nil)
	sample := event.New("s", "net", event.Process{Name: "collector"}, "collector_sample", "direct", map[string]any{
		"interval_sec": 2.0, "covered_processes": 2, "scope_roots": 1, "scope_children": 1,
		"health": map[string]int{"ok": 3, "unsupported": 2, "failed": 0}, "last_success_at": at.Format(time.RFC3339Nano),
	})
	sample.TS = at
	r := New("s", "", nil, []event.Event{activity, sample})
	encoded, err := json.Marshal(r)
	if err != nil {
		t.Fatal(err)
	}
	var decoded Report
	if err := json.Unmarshal(encoded, &decoded); err != nil {
		t.Fatal(err)
	}
	for _, report := range []Report{r, decoded} {
		d := DashboardSnapshot(report)
		if d.Health["unsupported"] != 2 || d.Covered != 2 || d.ScopeRoots != 1 || d.ScopeChildren != 1 || len(d.Recent) != 1 || d.Recent[0].Kind != "connection_observed" {
			t.Fatalf("bad sample projection: %+v", d)
		}
		report.GeneratedAt = at.Add(time.Hour)
		later := DashboardSnapshot(report)
		if later.LastSampleAt == nil || !later.LastSampleAt.Equal(at) {
			t.Fatal("request time replaced sample time")
		}
	}
}

func TestDashboardHealthIsBoundedAndRejectsInvalidCounts(t *testing.T) {
	counts := dashboardHealth(map[string]any{"failed": 2.0, "idle": -1.0, "ok": math.Inf(1), "private-event-body": 123.0, "unsupported": 1.5})
	if len(counts) != 1 || counts["failed"] != 2 {
		t.Fatalf("unbounded or invalid state metadata: %v", counts)
	}
}

func TestDashboardProjectsBoundedFindingAlerts(t *testing.T) {
	at := time.Date(2026, 9, 24, 1, 2, 3, 0, time.UTC)
	finding := rules.Finding{
		Summary:            "观察到上传尝试",
		Conclusion:         "观察到上传尝试",
		EvidenceStrength:   "observed_network_write",
		AuthorizationState: "unknown",
		Target:             "receiver.test:8080",
		FilePaths:          []string{"/tmp/fixture/a.env", "/tmp/fixture/b.zip"},
		EvidenceIDs:        []string{"network-1", "file-1"},
		Process:            event.Process{PID: 42, Name: "fixture", CreatedAtMS: 7},
		ObservedFrom:       at,
		ObservedTo:         at.Add(time.Second),
		Details:            "request body must never appear in the dashboard",
	}
	r := New("s", "", nil, nil)
	r.Findings = []rules.Finding{finding}
	d := DashboardSnapshot(r)
	if len(d.Alerts) != 1 {
		t.Fatalf("expected one alert, got %+v", d.Alerts)
	}
	alert := d.Alerts[0]
	if alert.Conclusion != "观察到上传尝试" || alert.Process != "fixture" || alert.File != "/tmp/fixture/a.env\n/tmp/fixture/b.zip" ||
		alert.Target != "receiver.test:8080" || alert.AuthorizationState != "unknown" || alert.EvidenceStrength != "observed_network_write" || alert.EvidenceCount != 2 || !alert.At.Equal(at.Add(time.Second)) {
		t.Fatalf("finding projection lost actionable metadata: %+v", alert)
	}
	data, err := json.Marshal(d)
	if err != nil || strings.Contains(string(data), "request body") || strings.Contains(string(data), "network-1") {
		t.Fatalf("dashboard exposed finding internals: %s", data)
	}
}

func TestDashboardAlertFallsBackToEvidenceEventTime(t *testing.T) {
	at := time.Date(2026, 9, 24, 2, 3, 4, 0, time.UTC)
	evidence := event.New("s", "net", event.Process{Name: "fixture", PID: 7, CreatedAtMS: 8}, "egress", "direct", nil)
	evidence.TS = at
	r := New("s", "", nil, []event.Event{evidence})
	r.GeneratedAt = at.Add(time.Hour)
	r.Findings = []rules.Finding{{Summary: "疑似数据外传", EvidenceIDs: []string{evidence.ID}}}
	d := DashboardSnapshot(r)
	if len(d.Alerts) != 1 || !d.Alerts[0].At.Equal(at) {
		t.Fatalf("dashboard did not use cited evidence time: %+v", d.Alerts)
	}
}
