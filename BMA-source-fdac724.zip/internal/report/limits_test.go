package report

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestReportWriterRejectsOverflowAndPreservesWriteFailure(t *testing.T) {
	var output bytes.Buffer
	w := reportLimitWriter{w: &output, max: 8}
	if n, err := w.Write([]byte("12345678")); err != nil || n != 8 {
		t.Fatal("exact limit rejected", n, err)
	}
	if n, err := w.Write([]byte("9")); err == nil || n != 0 || output.String() != "12345678" {
		t.Fatal("overflow was written", n, err)
	}
	w = reportLimitWriter{w: failingReportWriter{}, max: 100}
	if _, err := w.Write([]byte("data")); !errors.Is(err, io.ErrClosedPipe) {
		t.Fatal("underlying error lost", err)
	}
}

type failingReportWriter struct{}

func (failingReportWriter) Write([]byte) (int, error) { return 0, io.ErrClosedPipe }

func TestManyCoverageGapsArchiveAndStaleDetails(t *testing.T) {
	r := timelineFixture(5000)
	for i := range r.Events {
		r.Events[i].Kind = "collector_error"
	}
	r.Findings = nil
	var encoded bytes.Buffer
	if err := writeCollectionArchive(&encoded, r, MaxOfflineArchiveBytes); err != nil {
		t.Fatal(err)
	}
	var archive map[string][]collectionRow
	if err := json.Unmarshal(encoded.Bytes(), &archive); err != nil {
		t.Fatal(err)
	}
	if len(archive["gaps"]) != 5000 || archive["gaps"][4999].EvidenceIDs[0] != r.Events[4999].ID {
		t.Fatal("gap archive omitted records")
	}
	view, _ := selectCollection(r, "gaps", "200")
	if view.Total != 5000 || len(view.Rows) != 25 || view.Rows[24].Index != 4999 {
		t.Fatal("last gap page is incorrect")
	}
	row := view.Rows[24]
	r.Events[4999].Detail["reason"] = "changed"
	h := Handler(func() Report { return r }, "127.0.0.1:7788", "", nil)
	w := httptest.NewRecorder()
	h.ServeHTTP(w, httptest.NewRequest("GET", "http://127.0.0.1:7788/api/collection-item?group=gaps&index=4999&key="+row.Key, nil))
	if w.Code != 409 {
		t.Fatal("changed gap detail accepted", w.Code)
	}
	var html bytes.Buffer
	if err := Render(&html, r); err != nil {
		t.Fatal(err)
	}
	markup, _, _ := strings.Cut(html.String(), `<script id="timeline-data"`)
	if strings.Contains(markup, `href="#e_004999"`) || !strings.Contains(markup, "共 5000 条") {
		t.Fatal("all gap evidence links rendered on first page")
	}
}

func TestStreamedArchiveEnforcesExactCapacity(t *testing.T) {
	r := collectionFixture()
	var full bytes.Buffer
	if err := writeCollectionArchive(&full, r, MaxOfflineArchiveBytes); err != nil {
		t.Fatal(err)
	}
	for _, limit := range []int{full.Len(), full.Len() - 1, 128} {
		var output bytes.Buffer
		err := writeCollectionArchive(&output, r, limit)
		if limit == full.Len() {
			if err != nil || !bytes.Equal(output.Bytes(), full.Bytes()) {
				t.Fatal("exact capacity rejected or content changed", err)
			}
		} else if err == nil || output.Len() > limit {
			t.Fatal("archive exceeded capacity", limit, output.Len(), err)
		}
	}
	if err := writeCollectionArchive(failingReportWriter{}, r, MaxOfflineArchiveBytes); !errors.Is(err, io.ErrClosedPipe) {
		t.Fatal("archive lost sink error", err)
	}
}

func TestHTMLStreamingFailureKeepsExistingReport(t *testing.T) {
	r := timelineFixture(101)
	// Outside the first rendered page: failure occurs while writing archive
	// data, after markup and 100 valid event records have already been written.
	r.Events[100].Detail["invalid"] = make(chan int)
	dir := t.TempDir()
	path := filepath.Join(dir, "report.html")
	if err := os.WriteFile(path, []byte("previous report"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := WriteHTML(path, r); err == nil {
		t.Fatal("invalid event was silently encoded")
	}
	data, err := os.ReadFile(path)
	if err != nil || string(data) != "previous report" {
		t.Fatal("stream failure replaced the previous report", err)
	}
	files, err := os.ReadDir(dir)
	if err != nil || len(files) != 1 {
		t.Fatal("temporary export leaked", err)
	}
}

func TestJSONArrayStopsBuildingRowsAfterWriteFailure(t *testing.T) {
	var output bytes.Buffer
	w := &reportLimitWriter{w: &output, max: 8}
	visited := 0
	err := writeJSONArray(w, 10000, func(int) string {
		visited++
		return "longer than budget"
	})
	if err == nil || visited != 1 {
		t.Fatal("continued producing data after limit", visited, err)
	}
}
