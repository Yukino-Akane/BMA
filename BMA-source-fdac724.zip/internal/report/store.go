package report

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sync"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/rules"
)

const (
	MaxSessionEvents       = 50000
	MaxSessionBytes  int64 = 64 * 1024 * 1024
	maxEventBytes          = 4 * 1024 * 1024
	maxMetadataBytes       = 1024 * 1024
	gapReserve             = 4096
)

var ErrSessionLimit = errors.New("session event storage limit reached; observation stopped")

type StorageStats struct {
	MaxEvents       int   `json:"max_events"`
	MaxJournalBytes int64 `json:"max_journal_bytes"`
	JournalBytes    int64 `json:"journal_bytes"`
}

type journalMetadata struct {
	Format int    `json:"format"`
	Report Report `json:"report"`
}

type Store struct {
	mu          sync.Mutex
	report      Report
	log         *os.File
	done        chan struct{}
	stopOnce    sync.Once
	terminalErr error
	closed      bool
	lastSync    time.Time
}

func NewStore(dir string, initial Report) (*Store, error) {
	return newStore(dir, initial, MaxSessionEvents, MaxSessionBytes)
}

func newStore(dir string, initial Report, maxEvents int, maxBytes int64) (*Store, error) {
	if len(initial.Events) != 0 || initial.SessionID == "" {
		return nil, fmt.Errorf("new journal requires an empty report with a session ID")
	}
	if maxEvents < 2 || maxBytes <= gapReserve {
		return nil, fmt.Errorf("journal limits must reserve space for a collection gap")
	}
	initial.Storage = StorageStats{MaxEvents: maxEvents, MaxJournalBytes: maxBytes}
	initial.Status = "recording"
	metadata, err := json.Marshal(journalMetadata{Format: 1, Report: initial})
	if err != nil {
		return nil, err
	}
	metadata = append(metadata, '\n')
	if len(metadata) > maxMetadataBytes {
		return nil, fmt.Errorf("session metadata exceeds 1 MiB")
	}
	log, err := os.OpenFile(filepath.Join(dir, "events.jsonl"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return nil, err
	}
	meta, err := os.OpenFile(filepath.Join(dir, "session.json"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		log.Close()
		return nil, err
	}
	_, writeErr := meta.Write(metadata)
	err = errors.Join(writeErr, meta.Sync(), meta.Close())
	if err != nil {
		log.Close()
		return nil, err
	}
	return &Store{report: initial, log: log, done: make(chan struct{}), lastSync: time.Now()}, nil
}

func (s *Store) Done() <-chan struct{} { return s.done }

func (s *Store) Err() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.terminalErr
}

func (s *Store) Add(e event.Event) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.terminalErr != nil {
		return s.terminalErr
	}
	if s.closed {
		return os.ErrClosed
	}
	if e.SessionID != s.report.SessionID {
		return s.failLocked(fmt.Errorf("event belongs to another session"), "invalid_session")
	}
	data, err := json.Marshal(e)
	if err != nil {
		return s.failLocked(err, "event_encoding")
	}
	data = append(data, '\n')
	if len(s.report.Events) >= s.report.Storage.MaxEvents-1 {
		return s.failLocked(ErrSessionLimit, "event_count_limit")
	}
	if len(data) > maxEventBytes {
		return s.failLocked(ErrSessionLimit, "single_event_byte_limit")
	}
	if s.report.Storage.JournalBytes+int64(len(data)) > s.report.Storage.MaxJournalBytes-gapReserve {
		return s.failLocked(ErrSessionLimit, "journal_byte_limit")
	}
	if err := s.appendLocked(data, e); err != nil {
		return s.failLocked(err, "journal_write")
	}
	if time.Since(s.lastSync) >= time.Second {
		if err := s.log.Sync(); err != nil {
			return s.failLocked(err, "journal_sync")
		}
		s.lastSync = time.Now()
	}
	return nil
}

func (s *Store) appendLocked(data []byte, e event.Event) error {
	n, err := s.log.Write(data)
	s.report.Storage.JournalBytes += int64(n)
	if err != nil {
		return err
	}
	if n != len(data) {
		return io.ErrShortWrite
	}
	s.report.Events = append(s.report.Events, e)
	return nil
}

func (s *Store) failLocked(err error, reason string) error {
	s.terminalErr = err
	s.report.Status = "failed"
	if errors.Is(err, ErrSessionLimit) {
		s.report.Status = "limit_reached"
	}
	gap := event.New(s.report.SessionID, "file", event.Process{Name: "collector"}, "collector_error", "direct", map[string]any{
		"source": "event_store", "reason": reason, "coverage": "incomplete", "recorded_events": len(s.report.Events),
		"max_events": s.report.Storage.MaxEvents, "max_journal_bytes": s.report.Storage.MaxJournalBytes, "max_event_bytes": maxEventBytes,
	})
	// Reserve one record for the stop reason. After an I/O failure, do not
	// append behind a potentially partial write; keep the gap in the report.
	if errors.Is(err, ErrSessionLimit) {
		data, _ := json.Marshal(gap)
		if writeErr := s.appendLocked(append(data, '\n'), gap); writeErr != nil {
			s.terminalErr = errors.Join(err, writeErr)
			s.report.Events = append(s.report.Events, gap)
		}
	} else {
		s.report.Events = append(s.report.Events, gap)
	}
	s.stopOnce.Do(func() { close(s.done) })
	return s.terminalErr
}

func (s *Store) Snapshot() Report {
	s.mu.Lock()
	result := s.report
	result.Events = append([]event.Event{}, s.report.Events...)
	s.mu.Unlock()
	result.Findings = rules.EvaluateWithConfig(result.Events, result.RuleConfig)
	result.GeneratedAt = time.Now().UTC()
	return result
}

func (s *Store) Finish(status string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed {
		return nil
	}
	s.closed = true
	if s.terminalErr == nil {
		s.report.Status = status
	}
	err := errors.Join(s.log.Sync(), s.log.Close())
	if err != nil {
		s.report.Status = "failed"
	}
	s.stopOnce.Do(func() { close(s.done) })
	return err
}
