package report

import (
	"bytes"
	"io"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"

	"behavior-monitoring-audit/internal/event"
)

func TestReportEscapesEvidenceAndShowsDisclosure(t *testing.T) {
	e := event.New("s", "semantic", event.Process{Name: "agent"}, "goal", "direct", map[string]any{"text": "<script>alert(1)</script>"})
	r := New("s", "workspace", []string{"agent"}, []event.Event{e})
	r.Analysis = &Analysis{Verdict: "suspicious", Findings: []AnalysisFinding{{Claim: "<script>evil</script>", EvidenceIDs: []string{e.ID}, Confidence: 0.9}}}
	r.AnalysisRequest = &AnalysisRequest{Endpoint: "https://example.invalid/v1/chat/completions", EventCount: 1, FieldTypes: []string{"detail.path"}, Redaction: "strict"}
	r.AnalysisRequest.RequestBodies = []string{`{"text":"<script>request</script>"}`}
	r.AnalysisPreview = &AnalysisRequest{RequestBodies: []string{`{"text":"<script>preview</script>"}`}}
	var html bytes.Buffer
	if err := Render(&html, r); err != nil {
		t.Fatal(err)
	}
	if strings.Contains(html.String(), "<script>alert") || strings.Contains(html.String(), "<script>evil") || strings.Count(html.String(), "<script>") != 1 {
		t.Fatal("unescaped evidence became HTML")
	}
	for _, expected := range []string{"#" + e.ID, "https://example.invalid/v1/chat/completions", "detail.path"} {
		if !strings.Contains(html.String(), expected) {
			t.Errorf("missing %q", expected)
		}
	}
}

func TestCoverageGapIsProminentAndLinked(t *testing.T) {
	e := event.New("s", "semantic", event.Process{Name: "agent-log"}, "collector_error", "direct", map[string]any{"coverage": "incomplete"})
	r := New("s", "w", nil, []event.Event{e})
	var html bytes.Buffer
	if err := Render(&html, r); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(html.String(), "采集存在缺口") || !strings.Contains(html.String(), "href=\"#"+e.ID+"\"") {
		t.Fatal("coverage gap was hidden")
	}
	if len(r.Findings) != 0 {
		t.Fatal("collection failure became a behavioral accusation")
	}
}

func TestModelTrafficRendersSeparateTotalsAndEvidence(t *testing.T) {
	e := event.New("s", "net", event.Process{}, "egress", "direct", nil)
	r := New("s", "w", nil, []event.Event{e})
	r.Analysis = &Analysis{Verdict: "suspicious", UnexplainedEgressIDs: []string{e.ID}, UnexplainedTraffic: []TrafficEvidence{
		{Source: "proxy", BytesOut: 123, EvidenceIDs: []string{e.ID}},
		{Source: "nettop", BytesOut: 456, EvidenceIDs: []string{e.ID}},
	}}
	var html bytes.Buffer
	if err := Render(&html, r); err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{"模型标记需解释的网络记录", "123 出站字节", "456 出站字节", "分别展示、不相加", "href=\"#" + e.ID + "\""} {
		if !strings.Contains(html.String(), want) {
			t.Errorf("missing %q", want)
		}
	}
	if strings.Contains(html.String(), "579 出站字节") {
		t.Fatal("displayed double-counted total")
	}
}

func TestModelBatchDisagreementIsPreserved(t *testing.T) {
	a := Analysis{Verdict: "alarming", BatchVerdicts: []AnalysisBatchVerdict{
		{Batch: 1, Verdict: "clean"}, {Batch: 2, Verdict: "alarming"},
	}}
	if !a.HasBatchDisagreement() {
		t.Fatal("batch disagreement was not detected")
	}
	r := New("s", "w", nil, nil)
	r.Analysis = &a
	var html bytes.Buffer
	if err := Render(&html, r); err != nil || !strings.Contains(html.String(), "不同请求批次给出了不同判断") || !strings.Contains(html.String(), "第 1 批") {
		t.Fatal("report did not preserve batch disagreement")
	}
}

func TestServerRejectsForeignHostsAndWrites(t *testing.T) {
	h := Handler(func() Report { return New("s", "w", nil, nil) }, "127.0.0.1:7788", "", nil)
	for _, test := range []struct {
		method, host, path string
		status             int
	}{
		{"GET", "attacker.example", "/api/report", 403},
		{"POST", "127.0.0.1:7788", "/", 405},
		{"GET", "127.0.0.1:7788", "/api/report", 200},
		{"GET", "127.0.0.1:7788", "/missing", 404},
	} {
		r := httptest.NewRequest(test.method, "http://"+test.host+test.path, nil)
		w := httptest.NewRecorder()
		h.ServeHTTP(w, r)
		if w.Code != test.status {
			t.Fatalf("%+v: %d", test, w.Code)
		}
	}
}

func TestGoalEndpointAcceptsOnlyBoundedLocalInput(t *testing.T) {
	var events []event.Event
	status := "recording"
	h := Handler(func() Report { r := New("s", "w", nil, events); r.Status = status; return r }, "127.0.0.1:7788", "s", func(e event.Event) error { events = append(events, e); return nil })
	for _, tc := range []struct {
		name, body, origin, site, query string
		code                            int
	}{
		{"valid", "text=edit+README", "http://127.0.0.1:7788", "same-origin", "", 303},
		{"foreign origin", "text=forged", "https://attacker.example", "cross-site", "", 403},
		{"missing origin", "text=forged", "", "", "", 403},
		{"null origin", "text=forged", "null", "", "", 403},
		{"fetch site", "text=forged", "http://127.0.0.1:7788", "cross-site", "", 403},
		{"unknown field", "text=x&path=secret", "http://127.0.0.1:7788", "", "", 400},
		{"duplicate field", "text=x&text=y", "http://127.0.0.1:7788", "", "", 400},
		{"query", "text=x", "http://127.0.0.1:7788", "", "?text=y", 400},
		{"empty", "text=+", "http://127.0.0.1:7788", "", "", 400},
		{"too long", url.Values{"text": {strings.Repeat("a", 16001)}}.Encode(), "http://127.0.0.1:7788", "", "", 400},
		{"body bound", "text=x&padding=" + strings.Repeat("a", 256*1024), "http://127.0.0.1:7788", "", "", 400},
	} {
		t.Run(tc.name, func(t *testing.T) {
			req := httptest.NewRequest("POST", "http://127.0.0.1:7788/api/goal"+tc.query, strings.NewReader(tc.body))
			req.Header.Set("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
			req.Header.Set("Origin", tc.origin)
			req.Header.Set("Sec-Fetch-Site", tc.site)
			w := httptest.NewRecorder()
			h.ServeHTTP(w, req)
			if w.Code != tc.code {
				t.Fatalf("status=%d want=%d", w.Code, tc.code)
			}
			if tc.code == 303 && w.Header().Get("Location") != "/#goals" {
				t.Fatal("missing report redirect")
			}
		})
	}
	if len(events) != 1 || events[0].Detail["text"] != "edit README" || events[0].Detail["source"] != "web" {
		t.Fatal("unauthorized goal entered report")
	}
	status = "stopped"
	req := httptest.NewRequest("POST", "http://127.0.0.1:7788/api/goal", strings.NewReader("text=late"))
	req.Header.Set("Origin", "http://127.0.0.1:7788")
	w := httptest.NewRecorder()
	h.ServeHTTP(w, req)
	if w.Code != 409 || len(events) != 1 {
		t.Fatal("ended session accepted a goal")
	}
}

func TestGoalFormOnlyAppearsOnWritableLiveReport(t *testing.T) {
	r := New("s", "w", nil, nil)
	for _, writable := range []bool{false, true} {
		var add func(event.Event) error
		if writable {
			add = func(event.Event) error { return nil }
		}
		h := Handler(func() Report { return r }, "127.0.0.1:7788", "s", add)
		req := httptest.NewRequest("GET", "http://127.0.0.1:7788/", nil)
		w := httptest.NewRecorder()
		h.ServeHTTP(w, req)
		if strings.Contains(w.Body.String(), `action="/api/goal"`) != writable {
			t.Fatal("incorrect live form state")
		}
	}
	var html bytes.Buffer
	if err := Render(&html, r); err != nil {
		t.Fatal(err)
	}
	if strings.Contains(html.String(), `action="/api/goal"`) {
		t.Fatal("offline report has a writable form")
	}
}
func TestStoreJournalsAndFinalizes(t *testing.T) {
	s, err := NewStore(t.TempDir(), New("s", "w", nil, []event.Event{}))
	if err != nil {
		t.Fatal(err)
	}
	e := event.New("s", "file", event.Process{}, "file_create", "temporal", map[string]any{"path": "a.zip"})
	if err := s.Add(e); err != nil {
		t.Fatal(err)
	}
	if err := s.Finish("stopped"); err != nil {
		t.Fatal(err)
	}
	snapshot := s.Snapshot()
	if snapshot.Status != "stopped" || len(snapshot.Findings) != 1 || snapshot.Findings[0].EvidenceIDs[0] != e.ID {
		t.Fatalf("bad snapshot: %+v", snapshot)
	}
}

func TestReportWritesAreAtomicAndPrivate(t *testing.T) {
	dir := t.TempDir()
	jsonPath := filepath.Join(dir, "report.json")
	htmlPath := filepath.Join(dir, "report.html")
	r := New("s", "w", nil, nil)
	if err := WriteJSON(jsonPath, r); err != nil {
		t.Fatal(err)
	}
	if err := WriteHTML(htmlPath, r); err != nil {
		t.Fatal(err)
	}
	for _, path := range []string{jsonPath, htmlPath} {
		info, err := os.Stat(path)
		if err != nil {
			t.Fatal(err)
		}
		if runtime.GOOS != "windows" && info.Mode().Perm() != 0600 {
			t.Fatalf("%s permissions=%o", path, info.Mode().Perm())
		}
	}
	if leftovers, err := filepath.Glob(filepath.Join(dir, ".bma-write-*")); err != nil || len(leftovers) != 0 {
		t.Fatalf("temporary report files leaked: %v", leftovers)
	}
}

func TestAtomicReplacementPreservesDestinationOnFailure(t *testing.T) {
	dir := t.TempDir()
	target := filepath.Join(dir, "report.json")
	if err := os.WriteFile(target, []byte("old"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := writeAtomicStream(target, func(w io.Writer) error { _, err := io.WriteString(w, "new"); return err }); err != nil {
		t.Fatal(err)
	}
	data, _ := os.ReadFile(target)
	if string(data) != "new" {
		t.Fatal("existing report was not replaced")
	}
	protected := filepath.Join(dir, "directory")
	if err := os.Mkdir(protected, 0700); err != nil {
		t.Fatal(err)
	}
	if err := writeAtomicStream(protected, func(w io.Writer) error { _, err := io.WriteString(w, "must fail"); return err }); err == nil {
		t.Fatal("replaced a directory with report data")
	}
	if info, err := os.Stat(protected); err != nil || !info.IsDir() {
		t.Fatal("failed write removed existing destination")
	}
}

func TestFailedAnalysisStillDisclosesEndpoint(t *testing.T) {
	r := New("s", "w", nil, nil)
	r.AnalysisError = "provider failed"
	r.AnalysisRequest = &AnalysisRequest{Endpoint: "https://example.invalid/v1", AttemptedBatches: 1, BatchCount: 2, EventCount: 100, TotalEvents: 200}
	var html bytes.Buffer
	if err := Render(&html, r); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(html.String(), "https://example.invalid/v1") || !strings.Contains(html.String(), "请求失败不代表数据未离开本机") {
		t.Fatal("failed analysis hid its transmission")
	}
}
