//go:build !windows

package report

import "os"

func replaceFile(source, target string) error { return os.Rename(source, target) }
