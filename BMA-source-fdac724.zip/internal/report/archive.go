package report

import (
	"encoding/json"
	"fmt"
	"io"
)

// Encode one row at a time. encoding/json escapes HTML-sensitive characters,
// so event or model text cannot terminate the inert JSON script elements.
// The encoder's working buffer grows with the largest row, not the archive.
func writeJSONArray[T any](w io.Writer, count int, row func(int) T) error {
	if _, err := io.WriteString(w, "["); err != nil {
		return err
	}
	encoder := json.NewEncoder(w)
	for i := 0; i < count; i++ {
		if i > 0 {
			if _, err := io.WriteString(w, ","); err != nil {
				return err
			}
		}
		if err := encoder.Encode(row(i)); err != nil {
			return err
		}
	}
	_, err := io.WriteString(w, "]")
	return err
}

func writeCollectionArchive(w io.Writer, r Report, maxBytes int) error {
	limited := &reportLimitWriter{w: w, max: maxBytes}
	if err := writeCollections(limited, r); err != nil {
		return fmt.Errorf("offline collection archive: %w", err)
	}
	return nil
}

func writeCollections(w io.Writer, r Report) error {
	if _, err := io.WriteString(w, "{"); err != nil {
		return err
	}
	for i, kind := range collectionKinds {
		if i > 0 {
			if _, err := io.WriteString(w, ","); err != nil {
				return err
			}
		}
		if err := json.NewEncoder(w).Encode(kind); err != nil {
			return err
		}
		if _, err := io.WriteString(w, ":"); err != nil {
			return err
		}
		count, _ := collectionCount(r, kind)
		cursor := 0
		if err := writeJSONArray(w, count, func(index int) collectionRow {
			if kind == "gaps" {
				// Walk the event slice once, without a second slice of all gaps.
				for r.Events[cursor].Kind != "collector_error" {
					cursor++
				}
				e := r.Events[cursor]
				cursor++
				return gapRow(r, e, index, true)
			}
			row, _ := collectionItem(r, kind, index, true)
			return row
		}); err != nil {
			return err
		}
	}
	_, err := io.WriteString(w, "}")
	return err
}

func writePageArchive(w io.Writer, r Report, timeline timelineView, offline bool) error {
	if _, err := io.WriteString(w, `<script id="timeline-data" type="application/json">`); err != nil {
		return err
	}
	count := len(timeline.Rows)
	if offline {
		count = len(r.Events)
	}
	if err := writeJSONArray(w, count, func(i int) eventView {
		if offline {
			return describeEvent(r.Events[i], r.RuleConfig)
		}
		return timeline.Rows[i]
	}); err != nil {
		return err
	}
	if _, err := io.WriteString(w, `</script><script id="collection-data" type="application/json">`); err != nil {
		return err
	}
	if offline {
		if err := writeCollectionArchive(w, r, MaxOfflineArchiveBytes); err != nil {
			return err
		}
	} else if _, err := io.WriteString(w, "{}"); err != nil {
		return err
	}
	if _, err := io.WriteString(w, "</script><script>"); err != nil {
		return err
	}
	// This is the fixed embedded program, never report or model content.
	if _, err := io.WriteString(w, clientScript); err != nil {
		return err
	}
	_, err := io.WriteString(w, "</script></body></html>")
	return err
}
