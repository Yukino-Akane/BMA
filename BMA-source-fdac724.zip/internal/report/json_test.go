package report

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/rules"
)

func TestStreamedJSONPreservesCompleteSchema(t *testing.T) {
	full := collectionFixture()
	full.WatchRoots = []string{"root"}
	full.ProcessAllowlist = []string{"fixture"}
	full.ReverseDNS, full.Demonstration = true, true
	full.AnalysisError = "synthetic error <&>"
	full.Analysis.UnexplainedEgressIDs = []string{"e_fixture"}
	full.Storage = StorageStats{MaxEvents: 50000, MaxJournalBytes: 64000, JournalBytes: 123}
	full.AnalysisRequest.JournalPath = "fixture/requests.jsonl"
	full.AnalysisRequest.Endpoint = "https://example.invalid"
	full.AnalysisRequest.Model = "fixture"
	full.AnalysisRequest.BatchCount = 60
	full.AnalysisRequest.EventCount = 123
	full.AnalysisRequest.AttemptedBatches = 60
	full.AnalysisRequest.CompletedBatches = 59
	full.AnalysisRequest.CoveredEvents = 100
	full.AnalysisRequest.TotalEvents = 120
	full.AnalysisRequest.FieldTypes = []string{"kind"}
	full.AnalysisRequest.Redaction = "strict"
	full.AnalysisPreview = full.AnalysisRequest
	full.RecoveredRequests.JournalPath = "fixture/archive.jsonl"
	full.RecoveredRequests.SessionID = full.SessionID
	full.RecoveredRequests.TruncatedLastRecord = true
	empty := New("s", "w", nil, []event.Event{})
	empty.Findings = []rules.Finding{}
	empty.Analysis = &Analysis{Findings: []AnalysisFinding{}, UnexplainedTraffic: []TrafficEvidence{}, BatchVerdicts: []AnalysisBatchVerdict{}}
	empty.AnalysisRequest = &AnalysisRequest{RequestBodies: []string{}}
	empty.RecoveredRequests = &RequestArchive{Records: []RequestRecord{}}
	for _, r := range []Report{New("s", "w", nil, nil), empty, full} {
		var output bytes.Buffer
		if err := EncodeJSON(&output, r); err != nil {
			t.Fatal(err)
		}
		standard, err := json.Marshal(r)
		if err != nil {
			t.Fatal(err)
		}
		// Comparing parsed JSON catches lost fields, null/empty changes, omitted
		// optional fields and escaping, independently of insignificant whitespace.
		var got, want any
		if err := json.Unmarshal(output.Bytes(), &got); err != nil {
			t.Fatal(err)
		}
		if err := json.Unmarshal(standard, &want); err != nil {
			t.Fatal(err)
		}
		if !reflect.DeepEqual(got, want) {
			t.Fatal("streamed JSON changed the report schema or values")
		}
		decoded, err := decodeJSON(bytes.NewReader(output.Bytes()), int64(output.Len()))
		if err != nil {
			t.Fatal("streamed read rejected current schema", err)
		}
		var standardReport Report
		if err := json.Unmarshal(standard, &standardReport); err != nil {
			t.Fatal(err)
		}
		if !reflect.DeepEqual(decoded, standardReport) {
			t.Fatal("streamed read lost a field or changed null, empty, or numeric values")
		}
	}
}

func TestJSONStreamingCapacityAndSinkFailures(t *testing.T) {
	r := timelineFixture(3)
	var full bytes.Buffer
	if err := EncodeJSON(&full, r); err != nil {
		t.Fatal(err)
	}
	for _, limit := range []int{full.Len(), full.Len() - 1, 32} {
		var output bytes.Buffer
		err := encodeJSON(&output, r, limit)
		if limit == full.Len() {
			if err != nil || !bytes.Equal(output.Bytes(), full.Bytes()) {
				t.Fatal("exact capacity", err)
			}
		} else if err == nil || output.Len() > limit {
			t.Fatal("capacity not enforced", err)
		}
	}
	if err := EncodeJSON(failingReportWriter{}, r); !errors.Is(err, io.ErrClosedPipe) {
		t.Fatal("lost write error", err)
	}
	if err := EncodeJSON(shortReportWriter{}, r); !errors.Is(err, io.ErrShortWrite) {
		t.Fatal("lost short write", err)
	}
	// Capacity exhaustion must stop before even attempting to encode later
	// evidence; a full-report Marshal would fail on the invalid value instead.
	r.Events[2].Detail["invalid"] = make(chan int)
	if err := encodeJSON(io.Discard, r, 32); err == nil || !strings.Contains(err.Error(), "exceeds") {
		t.Fatal("encoded records past budget", err)
	}
}

type shortReportWriter struct{}

func (shortReportWriter) Write(p []byte) (int, error) { return len(p) - 1, nil }

func TestJSONFailurePreservesPreviousFile(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "report.json")
	if err := os.WriteFile(path, []byte("previous"), 0600); err != nil {
		t.Fatal(err)
	}
	r := timelineFixture(101)
	r.Events[100].Detail["invalid"] = make(chan int)
	if err := WriteJSON(path, r); err == nil {
		t.Fatal("invalid report accepted")
	}
	data, err := os.ReadFile(path)
	if err != nil || string(data) != "previous" {
		t.Fatal("previous file changed", err)
	}
	files, err := os.ReadDir(dir)
	if err != nil || len(files) != 1 {
		t.Fatal("temporary export leaked", err)
	}
}

func TestReadJSONCapacityAndDocumentBoundary(t *testing.T) {
	r := timelineFixture(2)
	var full bytes.Buffer
	if err := EncodeJSON(&full, r); err != nil {
		t.Fatal(err)
	}
	for _, tc := range []struct {
		input string
		limit int
		valid bool
	}{
		{full.String(), full.Len(), true},
		{full.String(), full.Len() - 1, false},
		{full.String() + " ", full.Len(), false},
		{full.String() + "{}", full.Len() + 2, false},
		{full.String() + "broken", full.Len() + 6, false},
		{"null", 20, false}, {"[]", 20, false}, {"{", 20, false},
	} {
		got, err := decodeJSON(strings.NewReader(tc.input), int64(tc.limit))
		if (err == nil) != tc.valid {
			t.Fatalf("valid=%v limit=%d: %v", tc.valid, tc.limit, err)
		}
		if tc.valid && (got.SessionID != r.SessionID || len(got.Events) != 2) {
			t.Fatal("round trip lost evidence")
		}
	}
	path := filepath.Join(t.TempDir(), "report.json")
	if err := WriteJSON(path, r); err != nil {
		t.Fatal(err)
	}
	if got, err := ReadJSON(path); err != nil || len(got.Events) != 2 {
		t.Fatal("file round trip", err)
	}
	f, err := os.OpenFile(path, os.O_WRONLY, 0600)
	if err != nil {
		t.Fatal(err)
	}
	err = f.Truncate(int64(MaxReportJSONBytes) + 1)
	_ = f.Close()
	if err != nil {
		t.Fatal(err)
	}
	if _, err := ReadJSON(path); err == nil || !strings.Contains(err.Error(), "at most") {
		t.Fatal("oversized file read", err)
	}
}
