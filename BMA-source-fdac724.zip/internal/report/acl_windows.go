//go:build windows

package report

import (
	"fmt"
	"os/exec"
	"os/user"
)

func SecureDirectory(path string) error {
	current, err := user.Current()
	if err != nil || current.Username == "" {
		return fmt.Errorf("cannot resolve current Windows user")
	}
	// icacls is part of Windows. Passing arguments directly avoids shell
	// interpretation while removing inherited access from this new directory.
	grant := current.Username + ":(OI)(CI)F"
	command := exec.Command("icacls", path, "/inheritance:r", "/grant:r", grant)
	if err := command.Run(); err != nil {
		return fmt.Errorf("secure report directory ACL: %w", err)
	}
	return nil
}
