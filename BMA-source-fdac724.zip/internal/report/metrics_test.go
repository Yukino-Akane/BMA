package report

import (
	"behavior-monitoring-audit/internal/event"
	"math"
	"testing"
)

func TestNetworkMetricsKeepSourcesSeparateAndExcludeIO(t *testing.T) {
	events := []event.Event{
		event.New("s", "net", event.Process{}, "process_io", "direct", map[string]any{"bytes_out": float64(9999), "metric": "network_bytes"}),
		event.New("s", "net", event.Process{}, "egress", "direct", map[string]any{"bytes_out": uint64(123), "bytes_in": uint64(5), "metric": "network_bytes", "proxy": true}),
		event.New("s", "net", event.Process{}, "egress", "direct", map[string]any{"bytes_out": float64(123), "bytes_in": float64(5), "metric": "network_bytes", "direction": "aggregate"}),
	}
	r := New("s", "w", nil, events)
	rows := r.NetworkMetrics()
	if len(rows) != 2 {
		t.Fatal("network sources were combined")
	}
	for _, row := range rows {
		if row.BytesOut != 123 || row.BytesIn != 5 || row.Records != 1 {
			t.Fatal("IO contaminated measured bytes")
		}
	}
	for _, value := range []any{nil, "100", float64(-1), math.NaN(), math.Inf(1), 0.5} {
		if _, ok := byteCount(value); ok {
			t.Fatal("accepted invalid byte measurement")
		}
	}
	if len(New("s", "w", nil, nil).NetworkMetrics()) != 0 {
		t.Fatal("missing measurement fabricated zero")
	}
}
