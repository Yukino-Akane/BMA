package report

import (
	"encoding/json"
	"fmt"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/rules"
)

// Only the report's containers are traversed here. The standard decoder keeps
// responsibility for JSON syntax, escaping and typed decoding of each record.
// No complete event/finding/request array is passed to Decoder.Decode.
func readReportObject(d *json.Decoder, target any, optional bool) (bool, error) {
	start, err := d.Token()
	if err != nil {
		return false, err
	}
	if optional && start == nil {
		return false, nil
	}
	if start != json.Delim('{') {
		return false, fmt.Errorf("report container must be a JSON object")
	}
	fields := reportReadFields(target)
	for d.More() {
		key, err := d.Token()
		if err != nil {
			return false, err
		}
		name, ok := key.(string)
		if !ok {
			return false, fmt.Errorf("report field name must be a string")
		}
		value, exists := fields[name]
		if !exists {
			return false, fmt.Errorf("unknown report field %q", name)
		}
		if value == nil {
			return false, fmt.Errorf("duplicate report field %q", name)
		}
		fields[name] = nil
		if err := readReportValue(d, value); err != nil {
			return false, fmt.Errorf("field %s: %w", name, err)
		}
	}
	end, err := d.Token()
	if err != nil {
		return false, err
	}
	if end != json.Delim('}') {
		return false, fmt.Errorf("report object did not end")
	}
	return true, nil
}

func readOptionalReportObject[T any](d *json.Decoder, target **T) error {
	value := new(T)
	present, err := readReportObject(d, value, true)
	if err != nil {
		return err
	}
	if present {
		*target = value
	} else {
		*target = nil
	}
	return nil
}

func readReportSlice[T any](d *json.Decoder, target *[]T) error {
	start, err := d.Token()
	if err != nil {
		return err
	}
	if start == nil {
		*target = nil
		return nil
	}
	if start != json.Delim('[') {
		return fmt.Errorf("report collection must be a JSON array")
	}
	*target = []T{}
	for d.More() {
		var row T
		if err := d.Decode(&row); err != nil {
			return err
		}
		*target = append(*target, row)
	}
	end, err := d.Token()
	if err != nil {
		return err
	}
	if end != json.Delim(']') {
		return fmt.Errorf("report collection did not end")
	}
	return nil
}

func readReportValue(d *json.Decoder, target any) error {
	switch r := target.(type) {
	case **Analysis:
		return readOptionalReportObject(d, r)
	case **AnalysisRequest:
		return readOptionalReportObject(d, r)
	case **RequestArchive:
		return readOptionalReportObject(d, r)
	case **Review:
		return readOptionalReportObject(d, r)
	case **ReviewResult:
		return readOptionalReportObject(d, r)
	case *[]event.Event:
		return readReportSlice(d, r)
	case *[]rules.Finding:
		return readReportSlice(d, r)
	case *[]AnalysisFinding:
		return readReportSlice(d, r)
	case *[]TrafficEvidence:
		return readReportSlice(d, r)
	case *[]AnalysisBatchVerdict:
		return readReportSlice(d, r)
	case *[]RequestRecord:
		return readReportSlice(d, r)
	case *[]ReviewAssessment:
		return readReportSlice(d, r)
	case *[]string:
		return readReportSlice(d, r)
	default:
		return d.Decode(target)
	}
}

func reportReadFields(target any) map[string]any {
	switch r := target.(type) {
	case *Report:
		return map[string]any{
			"tool": &r.Tool, "version": &r.Version, "generated_at": &r.GeneratedAt,
			"session_id": &r.SessionID, "workspace": &r.Workspace, "watch_roots": &r.WatchRoots,
			"process_allowlist": &r.ProcessAllowlist, "events": &r.Events, "findings": &r.Findings,
			"status": &r.Status, "limitations": &r.Limitations, "rule_config": &r.RuleConfig,
			"policy": &r.Policy, "authorization": &r.Authorization,
			"reverse_dns": &r.ReverseDNS, "demonstration": &r.Demonstration, "storage": &r.Storage,
			"analysis": &r.Analysis, "analysis_request": &r.AnalysisRequest, "analysis_preview": &r.AnalysisPreview,
			"recovered_requests": &r.RecoveredRequests, "analysis_error": &r.AnalysisError, "review": &r.Review,
		}
	case *Analysis:
		return map[string]any{"verdict": &r.Verdict, "findings": &r.Findings,
			"unexplained_egress_ids": &r.UnexplainedEgressIDs, "unexplained_traffic": &r.UnexplainedTraffic, "batch_verdicts": &r.BatchVerdicts}
	case *AnalysisRequest:
		return map[string]any{"endpoint": &r.Endpoint, "model": &r.Model, "event_count": &r.EventCount,
			"attempted_batches": &r.AttemptedBatches, "completed_batches": &r.CompletedBatches,
			"covered_events": &r.CoveredEvents, "total_events": &r.TotalEvents,
			"field_types": &r.FieldTypes, "redaction": &r.Redaction, "request_bodies": &r.RequestBodies,
			"journal_path": &r.JournalPath, "batch_count": &r.BatchCount}
	case *RequestArchive:
		return map[string]any{"journal_path": &r.JournalPath, "session_id": &r.SessionID,
			"truncated_last_record": &r.TruncatedLastRecord, "records": &r.Records}
	case *Review:
		return map[string]any{"result": &r.Result, "request": &r.Request, "preview": &r.Preview, "error": &r.Error}
	case *ReviewResult:
		return map[string]any{"verdict": &r.Verdict, "assessments": &r.Assessments,
			"unexplained_egress_ids": &r.UnexplainedEgressIDs, "unexplained_traffic": &r.UnexplainedTraffic,
			"included_events": &r.IncludedEvents, "total_events": &r.TotalEvents}
	default:
		panic("unsupported report container")
	}
}
