package report

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestRequestJournalRecoveryPreservesUncertainOutcome(t *testing.T) {
	dir := t.TempDir()
	s, err := NewStore(dir, New("s", "w", nil, nil))
	if err != nil {
		t.Fatal(err)
	}
	if err := s.Finish("stopped"); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(dir, "model-requests.jsonl")
	j, err := NewRequestJournal(path, "s")
	if err != nil {
		t.Fatal(err)
	}
	for batch := 0; batch < 3; batch++ {
		if err := j.Prepare("https://example.invalid/v1", "fixture", []byte(`{"text":"<script>private</script>"}`)); err != nil {
			t.Fatal(err)
		}
		if batch < 2 {
			if err := j.Outcome(batch == 0); err != nil {
				t.Fatal(err)
			}
		}
	}
	if err := j.Close(); err != nil {
		t.Fatal(err)
	}
	f, err := os.OpenFile(path, os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := f.WriteString(`{"kind":"completed"`); err != nil {
		t.Fatal(err)
	}
	f.Close()
	before, _ := os.ReadFile(path)
	r, err := Recover(dir)
	if err != nil {
		t.Fatal(err)
	}
	after, _ := os.ReadFile(path)
	if !bytes.Equal(before, after) || r.Analysis != nil || r.AnalysisRequest != nil || r.RecoveredRequests == nil {
		t.Fatal("recovery modified evidence or invented analysis")
	}
	a := r.RecoveredRequests
	if !a.TruncatedLastRecord || len(a.Records) != 5 || a.Records[4].Kind != "prepared" || a.Records[4].Batch != 3 {
		t.Fatalf("lost pending request: %+v", a)
	}
	var html bytes.Buffer
	if err := Render(&html, r); err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{"恢复的模型请求日志", "结果未知", "最后一条记录未写完", "第 3 批", "准备发送"} {
		if !strings.Contains(html.String(), want) {
			t.Errorf("missing %q", want)
		}
	}
	if strings.Contains(html.String(), "<script>private") || strings.Contains(html.String(), "本报告没有模型请求记录") {
		t.Fatal("unsafe or contradictory recovery report")
	}
}

func TestRequestJournalRefusesOverwriteAndWriteFailure(t *testing.T) {
	path := filepath.Join(t.TempDir(), "requests.jsonl")
	j, err := NewRequestJournal(path, "s")
	if err != nil {
		t.Fatal(err)
	}
	defer j.Close()
	if err := j.Prepare("https://example.invalid", "fixture", []byte(`{}`)); err != nil {
		t.Fatal(err)
	}
	before, _ := os.ReadFile(path)
	if other, err := NewRequestJournal(path, "s"); err == nil {
		other.Close()
		t.Fatal("overwrote journal")
	}
	after, _ := os.ReadFile(path)
	if !bytes.Equal(before, after) {
		t.Fatal("existing journal changed")
	}
	j.file.Close()
	if err := j.Outcome(true); err == nil || !j.failed {
		t.Fatal("write failure ignored")
	}
	if err := j.Outcome(false); err == nil {
		t.Fatal("failed journal remained writable")
	}
}

func TestRequestJournalReservesOutcomeCapacity(t *testing.T) {
	for _, limit := range []string{"bytes", "records"} {
		t.Run(limit, func(t *testing.T) {
			j, err := NewRequestJournal(filepath.Join(t.TempDir(), "requests.jsonl"), "s")
			if err != nil {
				t.Fatal(err)
			}
			defer j.Close()
			if limit == "bytes" {
				j.bytes = MaxRequestJournalBytes - requestResultReserve - 256
			} else {
				j.records = maxRequestJournalRecords - 2
			}
			if err := j.Prepare("https://example.invalid", "fixture", []byte(`{}`)); err != nil {
				t.Fatal(err)
			}
			if err := j.Outcome(true); err != nil {
				t.Fatal("reserved outcome could not be written", err)
			}
			before := j.bytes
			if err := j.Prepare("https://example.invalid", "fixture", []byte(`{}`)); err == nil {
				t.Fatal("capacity exceeded")
			}
			if j.bytes != before {
				t.Fatal("rejected preparation wrote partial record")
			}
		})
	}
}

func TestReadRequestJournalRejectsInvalidEvidence(t *testing.T) {
	prepared := RequestRecord{Kind: "prepared", SessionID: "s", Batch: 1, At: time.Now().UTC(), Endpoint: "https://example.invalid", Model: "fixture", Body: `{}`}
	completed := RequestRecord{Kind: "completed", SessionID: "s", Batch: 1, At: prepared.At}
	for _, name := range []string{"corrupt", "foreign-session", "outcome-first", "duplicate-prepared", "duplicate-outcome", "skipped-batch", "outcome-body", "oversized-body", "record-limit", "file-limit", "extra-json", "unknown-field"} {
		t.Run(name, func(t *testing.T) {
			p, c := prepared, completed
			records := []RequestRecord{p, c}
			switch name {
			case "foreign-session":
				c.SessionID = "other"
				records[1] = c
			case "outcome-first":
				records = []RequestRecord{c}
			case "duplicate-prepared":
				records = []RequestRecord{p, p}
			case "duplicate-outcome":
				records = []RequestRecord{p, c, c}
			case "skipped-batch":
				p.Batch = 2
				records = []RequestRecord{p}
			case "outcome-body":
				c.Body = `{}`
				records[1] = c
			case "oversized-body":
				p.Body = `"` + strings.Repeat("x", 4*1024*1024) + `"`
				records = []RequestRecord{p}
			case "record-limit":
				records = nil
				for i := 1; i <= maxRequestJournalRecords/2+1; i++ {
					p.Batch = i
					c.Batch = i
					records = append(records, p, c)
				}
			}
			var data bytes.Buffer
			for _, r := range records {
				if err := json.NewEncoder(&data).Encode(r); err != nil {
					t.Fatal(err)
				}
			}
			if name == "corrupt" {
				data.WriteString("{bad}\n")
			}
			if name == "extra-json" {
				data.WriteString("{} {}\n")
			}
			if name == "unknown-field" {
				data.Reset()
				raw, _ := json.Marshal(p)
				data.Write(raw[:len(raw)-1])
				data.WriteString(",\"secret\":true}\n")
			}
			path := filepath.Join(t.TempDir(), "requests.jsonl")
			if err := os.WriteFile(path, data.Bytes(), 0600); err != nil {
				t.Fatal(err)
			}
			if name == "file-limit" {
				if err := os.Truncate(path, MaxRequestJournalBytes+1); err != nil {
					t.Fatal(err)
				}
			}
			if _, err := ReadRequestJournal(path, "s"); err == nil {
				t.Fatal("invalid evidence accepted")
			}
		})
	}
}
