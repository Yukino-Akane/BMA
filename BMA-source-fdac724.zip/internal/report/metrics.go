package report

import (
	"math"
	"sort"
)

type NetworkMetric struct {
	Source            string
	BytesOut, BytesIn float64
	Records           int
}

// Sources stay separate: proxy bytes may overlap process-wide measurements.
// No records means unknown traffic, not a measurement of zero.
func (r Report) NetworkMetrics() []NetworkMetric {
	groups := map[string]*NetworkMetric{}
	for _, e := range r.Events {
		if e.Layer != "net" || e.Kind != "egress" || e.Detail["metric"] != "network_bytes" {
			continue
		}
		out, okOut := byteCount(e.Detail["bytes_out"])
		in, okIn := byteCount(e.Detail["bytes_in"])
		if !okOut || !okIn {
			continue
		}
		source := "导入的网络记录"
		if e.Detail["proxy"] == true {
			source = "本地代理转发"
		}
		if e.Detail["direction"] == "aggregate" {
			source = "进程网络聚合"
		}
		if e.Detail["synthetic"] == true {
			source = "模拟数据"
		}
		if groups[source] == nil {
			groups[source] = &NetworkMetric{Source: source}
		}
		row := groups[source]
		row.BytesOut += out
		row.BytesIn += in
		row.Records++
	}
	var result []NetworkMetric
	for _, row := range groups {
		result = append(result, *row)
	}
	sort.Slice(result, func(i, j int) bool { return result[i].Source < result[j].Source })
	return result
}

func byteCount(value any) (float64, bool) {
	var n float64
	switch v := value.(type) {
	case uint64:
		n = float64(v)
	case uint32:
		n = float64(v)
	case int:
		n = float64(v)
	case int64:
		n = float64(v)
	case float64:
		n = v
	default:
		return 0, false
	}
	return n, n >= 0 && !math.IsNaN(n) && !math.IsInf(n, 0) && math.Trunc(n) == n
}
