package llm

import (
	"encoding/json"
	"fmt"
	"net"
	"net/url"
	pathpkg "path"
	"path/filepath"
	"strings"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/redact"
	"behavior-monitoring-audit/internal/report"
	"behavior-monitoring-audit/internal/rules"
)

// outboundAuthorization is deliberately kept local to the LLM boundary. A
// report's authorization metadata controls whether this optional analysis
// request may leave the machine; it does not turn model output into evidence.
type outboundAuthorization struct {
	policy rules.Policy
	state  rules.AuthorizationState
}

func (a outboundAuthorization) authorized() bool {
	return a.state == rules.AuthorizationAuthorized
}

func (a outboundAuthorization) checksPayload() bool {
	return a.state == rules.AuthorizationAuthorized || a.state == rules.AuthorizationUnknown
}

func authorizeOutboundAnalysis(endpoint string, r report.Report) (outboundAuthorization, error) {
	policy := r.Policy.Normalize()
	if policyEmpty(policy) {
		// Reports created before policy fields were added may still carry the
		// configuration copy. This fallback does not invent an authorization
		// record; an absent state remains unknown.
		policy = r.RuleConfig.Policy.Normalize()
	}
	authorization := r.Authorization.Normalize()
	if authorization.State == rules.AuthorizationUnknown {
		configured := r.RuleConfig.Authorization.Normalize()
		if configured.State != rules.AuthorizationUnknown {
			authorization = configured
		}
	}
	if err := policy.ValidateAuthorization(authorization); err != nil {
		return outboundAuthorization{}, fmt.Errorf("invalid outbound analysis policy: %w", err)
	}
	if authorization.State == rules.AuthorizationDenied {
		return outboundAuthorization{policy: policy, state: authorization.State}, fmt.Errorf("LLM analysis is blocked by recorded authorization state %q", authorization.State)
	}
	if len(policy.AllowedUploadDirectories) == 0 || len(policy.AllowedUploadTargets) == 0 {
		return outboundAuthorization{}, fmt.Errorf("LLM analysis requires at least one allowed upload directory and target")
	}
	state := authorization.State
	switch state {
	case rules.AuthorizationUnknown, rules.AuthorizationAuthorized:
		target, err := endpointHostPort(endpoint)
		if err != nil {
			return outboundAuthorization{}, err
		}
		if !allowedEndpointTarget(target, policy.AllowedUploadTargets) {
			return outboundAuthorization{}, fmt.Errorf("LLM endpoint %q is outside the authorized upload targets", target)
		}
		// Unknown records may proceed only within the explicitly configured
		// scope; unknown does not make an arbitrary endpoint safe.
		return outboundAuthorization{policy: policy, state: state}, nil
	default:
		return outboundAuthorization{}, fmt.Errorf("invalid outbound authorization state %q", state)
	}
}

func policyEmpty(policy rules.Policy) bool {
	return len(policy.ProtectedDirectories) == 0 && len(policy.SensitiveCategories) == 0 &&
		len(policy.AllowedUploadDirectories) == 0 && len(policy.AllowedUploadTargets) == 0
}

func endpointHostPort(raw string) (string, error) {
	parsed, err := url.Parse(raw)
	if err != nil || parsed.Hostname() == "" {
		return "", fmt.Errorf("cannot determine LLM endpoint host")
	}
	port := parsed.Port()
	if port == "" {
		switch strings.ToLower(parsed.Scheme) {
		case "http":
			port = "80"
		case "https":
			port = "443"
		default:
			return "", fmt.Errorf("LLM endpoint has no recognized default port")
		}
	}
	host := strings.TrimSuffix(strings.ToLower(parsed.Hostname()), ".")
	if host == "" {
		return "", fmt.Errorf("LLM endpoint host is empty")
	}
	return net.JoinHostPort(host, port), nil
}

func allowedEndpointTarget(endpoint string, targets []string) bool {
	for _, raw := range targets {
		candidate, err := policyTargetHostPort(raw)
		if err == nil && candidate == endpoint {
			return true
		}
	}
	return false
}

func policyTargetHostPort(raw string) (string, error) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return "", fmt.Errorf("empty upload target")
	}
	if !strings.Contains(raw, "://") {
		raw = "//" + raw
	}
	parsed, err := url.Parse(raw)
	if err != nil || parsed.Hostname() == "" {
		return "", fmt.Errorf("invalid upload target")
	}
	port := parsed.Port()
	if port == "" {
		switch strings.ToLower(parsed.Scheme) {
		case "http":
			port = "80"
		case "https":
			port = "443"
		default:
			return "", fmt.Errorf("upload target has no port")
		}
	}
	host := strings.TrimSuffix(strings.ToLower(parsed.Hostname()), ".")
	return net.JoinHostPort(host, port), nil
}

// validateAuthorizedPayloads runs after redaction and JSON serialization. It
// is intentionally a second boundary check: checking only report.Events would
// miss an accidental change to the model payload construction.
func validateAuthorizedPayloads(policy rules.Policy, bodies [][]byte, batches [][]event.Event) error {
	if len(bodies) != len(batches) {
		return fmt.Errorf("authorized LLM payload count does not match planned batches")
	}
	for i, body := range bodies {
		if err := validateAuthorizedPayload(policy, body, batches[i]); err != nil {
			return fmt.Errorf("authorized LLM batch %d rejected: %w", i+1, err)
		}
	}
	return nil
}

func validateAuthorizedPayload(policy rules.Policy, body []byte, expected []event.Event) error {
	var payload Payload
	if err := json.Unmarshal(body, &payload); err != nil {
		return fmt.Errorf("request body is not valid JSON: %w", err)
	}
	if len(payload.Messages) < 2 {
		return fmt.Errorf("request body has no evidence message")
	}
	var envelope struct {
		Events []event.Event `json:"goal_and_events"`
	}
	if err := json.Unmarshal([]byte(payload.Messages[1].Content), &envelope); err != nil {
		return fmt.Errorf("evidence message is not valid JSON: %w", err)
	}
	if len(envelope.Events) != len(expected) {
		return fmt.Errorf("serialized evidence count changed from %d to %d", len(expected), len(envelope.Events))
	}
	expectedByID := make(map[string]event.Event, len(expected))
	for _, original := range expected {
		if original.ID == "" {
			return fmt.Errorf("planned evidence has an empty ID")
		}
		expectedByID[original.ID] = original
	}
	seen := make(map[string]bool, len(envelope.Events))
	for _, clean := range envelope.Events {
		original, ok := expectedByID[clean.ID]
		if !ok || seen[clean.ID] {
			return fmt.Errorf("serialized evidence contains an unexpected or duplicate event ID %q", clean.ID)
		}
		seen[clean.ID] = true
		if err := validateEventPaths(policy, original, clean, body); err != nil {
			return err
		}
	}
	if len(seen) != len(expectedByID) {
		return fmt.Errorf("serialized evidence omitted an event")
	}
	return nil
}

func validateEventPaths(policy rules.Policy, original, clean event.Event, body []byte) error {
	for key, rawValue := range original.Detail {
		if !pathField(key) {
			continue
		}
		rawPath, ok := rawValue.(string)
		if !ok || rawPath == "" {
			continue
		}
		if !absolutePath(rawPath) || !pathInAllowedRoots(rawPath, policy.AllowedUploadDirectories) {
			return fmt.Errorf("event %s path field %q is outside authorized directories", original.ID, key)
		}
		// A root path is a single slash, which appears throughout ordinary JSON.
		// Its serialized path field is checked against redact.Path below.
		if rawPath != "/" && (strings.Contains(string(body), rawPath) || strings.Contains(string(body), strings.ReplaceAll(rawPath, `\`, `\\`))) {
			return fmt.Errorf("event %s path field %q was not redacted", original.ID, key)
		}
		cleanValue, present := clean.Detail[key]
		if !present {
			continue
		}
		cleanPath, ok := cleanValue.(string)
		if !ok || cleanPath != redact.Path(rawPath) {
			return fmt.Errorf("event %s path field %q does not match the redacted payload", original.ID, key)
		}
	}
	for key, value := range clean.Detail {
		if !pathField(key) {
			continue
		}
		if text, ok := value.(string); ok && absolutePath(text) {
			return fmt.Errorf("event %s serialized path field %q remains absolute", clean.ID, key)
		}
	}
	return nil
}

func pathField(key string) bool {
	lower := strings.ToLower(strings.TrimSpace(key))
	return lower == "path" || lower == "watch_root" || strings.HasSuffix(lower, "_path") ||
		strings.HasSuffix(lower, "_directory") || strings.HasSuffix(lower, "_dir")
}

func absolutePath(value string) bool {
	if filepath.IsAbs(value) {
		return true
	}
	// Keep Windows reports valid when they are inspected on another host.
	return len(value) >= 3 && ((value[0] >= 'A' && value[0] <= 'Z') || (value[0] >= 'a' && value[0] <= 'z')) && value[1] == ':' && (value[2] == '/' || value[2] == '\\')
}

func pathInAllowedRoots(path string, roots []string) bool {
	if !absolutePath(path) {
		return false
	}
	if windowsAbsolutePath(path) {
		candidate := normalizeWindowsPath(path)
		for _, root := range roots {
			cleanRoot := normalizeWindowsPath(root)
			if windowsAbsolutePath(root) && (candidate == cleanRoot || strings.HasPrefix(candidate, cleanRoot+"/")) {
				return true
			}
		}
		return false
	}
	cleanPath := canonicalBoundaryPath(path)
	for _, root := range roots {
		if !absolutePath(root) {
			continue
		}
		cleanRoot := canonicalBoundaryPath(root)
		rel, err := filepath.Rel(cleanRoot, cleanPath)
		if err == nil && rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
			return true
		}
	}
	return false
}

func windowsAbsolutePath(value string) bool {
	return len(value) >= 3 && ((value[0] >= 'A' && value[0] <= 'Z') || (value[0] >= 'a' && value[0] <= 'z')) && value[1] == ':' && (value[2] == '/' || value[2] == '\\')
}

func normalizeWindowsPath(value string) string {
	return strings.ToLower(strings.TrimSuffix(pathpkg.Clean(strings.ReplaceAll(value, `\`, "/")), "/"))
}

func canonicalBoundaryPath(value string) string {
	clean := filepath.Clean(value)
	if resolved, err := filepath.EvalSymlinks(clean); err == nil {
		return filepath.Clean(resolved)
	}
	parent := filepath.Dir(clean)
	if resolved, err := filepath.EvalSymlinks(parent); err == nil {
		return filepath.Join(resolved, filepath.Base(clean))
	}
	return clean
}
