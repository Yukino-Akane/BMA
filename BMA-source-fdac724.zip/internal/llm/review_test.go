package llm

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/report"
)

func reviewFixture() report.Report {
	goal := event.New("s", "semantic", event.Process{}, "goal", "direct", map[string]any{"text": "secret-goal-phrase"})
	file := event.New("s", "file", event.Process{}, "file_create", "temporal", map[string]any{"path": "/private-project/archive.zip", "size_bytes": 50})
	network := measuredEvent("proxy", 50)
	claim := event.New("s", "semantic", event.Process{}, "claimed_action", "direct", map[string]any{"tool": "upload", "args": "never-send-raw-command"})
	claim.TS = goal.TS.Add(24 * time.Hour)
	gap := event.New("s", "semantic", event.Process{}, "collector_error", "direct", map[string]any{"source": "fixture", "error": "never-send-raw-error"})
	other := event.New("s", "net", event.Process{}, "connection_observed", "direct", nil)
	r := report.New("s", "w", nil, []event.Event{goal, file, network, claim, gap, other})
	r.Analysis = &report.Analysis{Verdict: "suspicious", Findings: []report.AnalysisFinding{
		{Claim: "secret-goal-phrase /private-project/archive.zip token=hidden-secret", EvidenceIDs: []string{file.ID}, Confidence: .8, RequestBatch: 1},
		{Claim: "Second interpretation", EvidenceIDs: []string{network.ID}, Confidence: .7, RequestBatch: 2},
	}, BatchVerdicts: []report.AnalysisBatchVerdict{{Batch: 1, Verdict: "suspicious", FindingCount: 1}, {Batch: 2, Verdict: "suspicious", FindingCount: 1}}}
	return r
}

func reviewResponse(t *testing.T, r report.Report) string {
	t.Helper()
	data, err := json.Marshal(map[string]any{"verdict": "suspicious", "assessments": []any{map[string]any{
		"finding_ids": []int{1, 2}, "relationship": "contradictory", "status": "revised", "claim": "The available evidence supports a revised interpretation; cause remains uncertain.", "confidence": .7, "evidence_ids": []string{r.Events[1].ID, r.Events[2].ID, r.Events[3].ID},
	}}, "unexplained_egress_ids": []string{r.Events[2].ID}})
	if err != nil {
		t.Fatal(err)
	}
	return string(data)
}

func TestReviewJoinsDistantEvidenceAndExactlyMatchesPreviewAndJournal(t *testing.T) {
	r := reviewFixture()
	payload, preview, err := ReviewPayload(r, "fixture", false, 5)
	if err != nil || preview.EventCount != 5 || preview.TotalEvents != 6 || preview.BatchCount != 1 || preview.AttemptedBatches != 0 {
		t.Fatal("wrong review coverage", err)
	}
	var input struct {
		Events []event.Event    `json:"goal_and_events"`
		Prior  []reviewProposal `json:"prior_findings"`
	}
	if err := json.Unmarshal([]byte(payload.Messages[1].Content), &input); err != nil {
		t.Fatal(err)
	}
	if len(input.Events) != 5 || input.Events[3].ID != r.Events[3].ID || len(input.Prior) != 2 || input.Prior[1].RequestBatch != 2 {
		t.Fatal("distant self-report or proposals missing")
	}
	for _, secret := range []string{"private-project", "hidden-secret", "never-send-"} {
		if strings.Contains(preview.RequestBodies[0], secret) {
			t.Fatal("raw data leaked")
		}
	}
	path := filepath.Join(t.TempDir(), "review.jsonl")
	calls := 0
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		calls++
		body, _ := io.ReadAll(req.Body)
		archive, err := report.ReadRequestJournal(path, "s")
		if err != nil || len(archive.Records) != 1 || archive.Records[0].Kind != "prepared" || archive.Records[0].Body != string(body) {
			t.Error("review not durably prepared before send", err)
		}
		if string(body) != preview.RequestBodies[0] {
			t.Error("review differs from preview")
		}
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]string{"content": reviewResponse(t, r)}}}})
	}))
	defer server.Close()
	r = scopeReportForEndpoint(server.URL, r)
	before, _ := json.Marshal(r)
	result, meta, err := Reconcile(context.Background(), server.URL, "fixture-key-not-saved", r, "fixture", false, 5, path)
	if err != nil || calls != 1 || meta.AttemptedBatches != 1 || meta.CompletedBatches != 1 || meta.CoveredEvents != 5 || meta.TotalEvents != 6 || result.IncludedEvents != 5 || result.TotalEvents != 6 {
		t.Fatal("review failed or lied about coverage", err)
	}
	if len(result.Assessments) != 1 || result.Assessments[0].Status != "revised" || len(result.UnexplainedTraffic) != 1 || result.UnexplainedTraffic[0].BytesOut != 50 {
		t.Fatal("review lost resolution or local quantities")
	}
	archive, err := report.ReadRequestJournal(path, "s")
	if err != nil || len(archive.Records) != 2 || archive.Records[1].Kind != "completed" {
		t.Fatal("review outcome not saved", err)
	}
	raw, _ := os.ReadFile(path)
	if strings.Contains(string(raw), "fixture-key-not-saved") {
		t.Fatal("authorization persisted")
	}
	after, _ := json.Marshal(r)
	if string(before) != string(after) {
		t.Fatal("review changed original analysis or evidence")
	}
}

func TestReviewPrivacyAndLimitsRejectBeforeTransmission(t *testing.T) {
	r := reviewFixture()
	_, preview, err := ReviewPayload(r, "fixture", true, 5)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(preview.RequestBodies[0], "secret-goal-phrase") || strings.Contains(preview.RequestBodies[0], "Second interpretation") || !strings.Contains(preview.RequestBodies[0], "[redacted-prior-claim]") {
		t.Fatal("hidden goal leaked through prior prose")
	}
	calls := 0
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) { calls++; w.WriteHeader(500) }))
	defer server.Close()
	for _, mutate := range []func(*report.Report){
		func(r *report.Report) { r.Analysis.Findings[0].EvidenceIDs = []string{"missing"} },
		func(r *report.Report) { r.Analysis.Findings[0].RequestBatch = 999 },
		func(r *report.Report) { r.Events[1].SessionID = "other" },
		func(r *report.Report) { r.Analysis.Findings[0].Claim = strings.Repeat("x", 4*1024*1024) },
	} {
		r := reviewFixture()
		mutate(&r)
		r = scopeReportForEndpoint(server.URL, r)
		path := filepath.Join(t.TempDir(), "requests.jsonl")
		_, meta, err := Reconcile(context.Background(), server.URL, "fixture", r, "fixture", false, 5, path)
		if err == nil || calls != 0 || meta.AttemptedBatches != 0 {
			t.Fatal("invalid review made request", err)
		}
		if _, err := os.Stat(path); !os.IsNotExist(err) {
			t.Fatal("invalid plan created journal")
		}
	}
	for _, limit := range []int{0, 4, 1001} {
		_, _, err := ReviewPayload(r, "fixture", false, limit)
		if err == nil {
			t.Fatal("evidence clipped to fit limit", limit)
		}
	}
	r = scopeReportForEndpoint(server.URL, r)
	_, meta, err := Reconcile(context.Background(), server.URL, "fixture", r, "fixture", false, 5, filepath.Join(t.TempDir(), "missing", "requests.jsonl"))
	if err == nil || calls != 0 || meta.AttemptedBatches != 0 || meta.EventCount != 0 || len(meta.RequestBodies) != 0 {
		t.Fatal("journal failure sent a request", err)
	}
}

func TestReviewRejectsUnsupportedResolutions(t *testing.T) {
	r := reviewFixture()
	base := reviewResponse(t, r)
	for _, tc := range []struct {
		name   string
		change func(map[string]any, map[string]any)
	}{
		{"omitted finding", func(v, a map[string]any) { a["finding_ids"] = []int{1} }},
		{"invented finding", func(v, a map[string]any) { a["finding_ids"] = []int{1, 3} }},
		{"repeated finding", func(v, a map[string]any) { a["finding_ids"] = []int{1, 1} }},
		{"missing original evidence", func(v, a map[string]any) { a["evidence_ids"] = []string{r.Events[1].ID} }},
		{"invented evidence", func(v, a map[string]any) { a["evidence_ids"] = []string{"invented"} }},
		{"duplicate evidence", func(v, a map[string]any) {
			a["evidence_ids"] = []string{r.Events[1].ID, r.Events[1].ID, r.Events[2].ID}
		}},
		{"missing confidence", func(v, a map[string]any) { delete(a, "confidence") }},
		{"both contradictions supported", func(v, a map[string]any) { a["status"] = "supported" }},
		{"invalid relationship", func(v, a map[string]any) { a["relationship"] = "safe" }},
		{"clean unresolved", func(v, a map[string]any) { v["verdict"] = "clean"; a["status"] = "unresolved" }},
		{"withdrawn traffic", func(v, a map[string]any) { v["verdict"] = "clean"; a["status"] = "withdrawn" }},
		{"file as traffic", func(v, a map[string]any) { v["unexplained_egress_ids"] = []string{r.Events[1].ID} }},
		{"invented local quantity", func(v, a map[string]any) { v["unexplained_traffic"] = []any{} }},
		{"invented provenance", func(v, a map[string]any) { a["request_batch"] = 123 }},
		{"omitted assessment list", func(v, a map[string]any) { delete(v, "assessments") }},
	} {
		t.Run(tc.name, func(t *testing.T) {
			var value map[string]any
			_ = json.Unmarshal([]byte(base), &value)
			a := value["assessments"].([]any)[0].(map[string]any)
			tc.change(value, a)
			data, _ := json.Marshal(value)
			if _, err := parseReview(string(data), r.Analysis.Findings, r.Events[:5], false); err == nil {
				t.Fatal("unsupported review accepted")
			}
		})
	}
	if _, err := parseReview(base+"{}", r.Analysis.Findings, r.Events[:5], false); err == nil {
		t.Fatal("trailing document accepted")
	}
	if _, err := parseReview(base, r.Analysis.Findings, r.Events[:5], true); err == nil {
		t.Fatal("hidden claims semantically grouped")
	}
	for _, status := range []string{"unresolved", "withdrawn"} {
		var value map[string]any
		_ = json.Unmarshal([]byte(base), &value)
		a := value["assessments"].([]any)[0].(map[string]any)
		a["status"] = status
		if status == "withdrawn" {
			value["verdict"] = "clean"
			value["unexplained_egress_ids"] = []string{}
		}
		data, _ := json.Marshal(value)
		got, err := parseReview(string(data), r.Analysis.Findings, r.Events[:5], false)
		if err != nil || got.HasUnresolved() != (status == "unresolved") {
			t.Fatal("valid disposition rejected", status, err)
		}
	}
}

func TestFailedReviewStillDisclosesAttemptAndJournal(t *testing.T) {
	r := reviewFixture()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]string{"content": `{"verdict":"clean","assessments":[],"unexplained_egress_ids":[]}`}}}})
	}))
	defer server.Close()
	r = scopeReportForEndpoint(server.URL, r)
	path := filepath.Join(t.TempDir(), "requests.jsonl")
	_, meta, err := Reconcile(context.Background(), server.URL, "fixture", r, "fixture", false, 5, path)
	if err == nil || meta.AttemptedBatches != 1 || meta.CompletedBatches != 0 || meta.CoveredEvents != 0 || meta.EventCount != 5 || len(meta.RequestBodies) != 1 {
		t.Fatal("failed review hid transmission", err)
	}
	archive, err := report.ReadRequestJournal(path, "s")
	if err != nil || len(archive.Records) != 2 || archive.Records[1].Kind != "failed" {
		t.Fatal("invalid response recorded as completed", err)
	}
}
