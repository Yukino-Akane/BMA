package llm

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/report"
	"behavior-monitoring-audit/internal/rules"
)

func scopeReportForEndpoint(endpoint string, r report.Report) report.Report {
	parsed, _ := url.Parse(endpoint)
	target := parsed.Host
	if parsed.Port() == "" {
		if parsed.Scheme == "http" {
			target += ":80"
		} else {
			target += ":443"
		}
	}
	policy := rules.Policy{AllowedUploadDirectories: []string{"/"}, AllowedUploadTargets: []string{target}}
	r.Policy = policy
	r.Authorization = rules.Authorization{State: rules.AuthorizationUnknown}
	r.RuleConfig.Policy = policy
	r.RuleConfig.Authorization = r.Authorization
	return r
}

func scopedReport(endpoint string, events []event.Event, state rules.AuthorizationState, roots []string) report.Report {
	r := report.New("s", "/workspace", nil, events)
	parsed, _ := url.Parse(endpoint)
	target := parsed.Host
	if parsed.Port() == "" {
		if parsed.Scheme == "http" {
			target += ":80"
		} else {
			target += ":443"
		}
	}
	policy := rules.Policy{AllowedUploadDirectories: roots, AllowedUploadTargets: []string{target}}
	r.Policy = policy
	r.Authorization = rules.Authorization{State: state}
	r.RuleConfig.Policy = policy
	r.RuleConfig.Authorization = r.Authorization
	return r
}

func validAnalysisResponse() string {
	return `{"choices":[{"message":{"content":"{\"verdict\":\"clean\",\"findings\":[],\"unexplained_egress_ids\":[]}"}}]}`
}

func TestAuthorizationDeniedBlocksBeforeJournalOrNetwork(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { calls.Add(1) }))
	defer server.Close()
	eventValue := event.New("s", "net", event.Process{}, "connection_observed", "direct", nil)
	r := scopedReport(server.URL, []event.Event{eventValue}, rules.AuthorizationDenied, []string{"/workspace"})
	path := filepath.Join(t.TempDir(), "requests.jsonl")
	_, meta, err := Analyze(context.Background(), server.URL, "fixture", r, "fixture", false, path)
	if err == nil || !strings.Contains(err.Error(), "blocked") || calls.Load() != 0 || meta.AttemptedBatches != 0 {
		t.Fatalf("denied analysis escaped guard: err=%v calls=%d meta=%+v", err, calls.Load(), meta)
	}
	if _, statErr := os.Stat(path); !os.IsNotExist(statErr) {
		t.Fatalf("denied analysis created journal: %v", statErr)
	}
}

func TestAuthorizationDeniedTakesPrecedenceOverMissingScope(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(http.ResponseWriter, *http.Request) {
		t.Fatal("denied analysis reached the endpoint")
	}))
	defer server.Close()
	r := report.New("s", "/workspace", nil, nil)
	r.Authorization = rules.Authorization{State: rules.AuthorizationDenied}
	r.RuleConfig.Authorization = r.Authorization
	_, _, err := Analyze(context.Background(), server.URL, "fixture", r, "fixture", false, filepath.Join(t.TempDir(), "requests.jsonl"))
	if err == nil || !strings.Contains(err.Error(), "blocked by recorded authorization state") {
		t.Fatalf("denied state was hidden by missing scope error: %v", err)
	}
}

func TestAuthorizationUnknownRequiresCompleteScopeAndPreservesState(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		_, _ = io.WriteString(w, validAnalysisResponse())
	}))
	defer server.Close()
	e := event.New("s", "net", event.Process{}, "connection_observed", "direct", nil)
	missing := report.New("s", "/workspace", nil, []event.Event{e})
	_, _, err := Analyze(context.Background(), server.URL, "fixture", missing, "fixture", false, filepath.Join(t.TempDir(), "requests.jsonl"))
	if err == nil || calls.Load() != 0 {
		t.Fatalf("missing scope was sent: err=%v calls=%d", err, calls.Load())
	}
	mismatch := scopedReport(server.URL, []event.Event{e}, rules.AuthorizationUnknown, []string{"/workspace"})
	mismatch.Policy.AllowedUploadTargets = []string{"other.invalid:443"}
	mismatch.RuleConfig.Policy = mismatch.Policy
	_, _, err = Analyze(context.Background(), server.URL, "fixture", mismatch, "fixture", false, filepath.Join(t.TempDir(), "requests.jsonl"))
	if err == nil || !strings.Contains(err.Error(), "outside the authorized upload targets") || calls.Load() != 0 {
		t.Fatalf("unknown target mismatch was sent: err=%v calls=%d", err, calls.Load())
	}
	path := filepath.Join(t.TempDir(), "requests.jsonl")
	r := scopedReport(server.URL, []event.Event{e}, rules.AuthorizationUnknown, []string{"/workspace"})
	_, meta, err := Analyze(context.Background(), server.URL, "fixture", r, "fixture", false, path)
	if err != nil || calls.Load() != 1 || meta.CompletedBatches != 1 {
		t.Fatalf("scoped unknown analysis failed: err=%v calls=%d meta=%+v", err, calls.Load(), meta)
	}
}

func TestAuthorizedEndpointAndPathBoundariesBlockBeforeJournal(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { calls.Add(1) }))
	defer server.Close()
	outside := event.New("s", "file", event.Process{}, "file_create", "direct", map[string]any{"path": "/private/secret.zip"})
	r := scopedReport(server.URL, []event.Event{outside}, rules.AuthorizationAuthorized, []string{"/workspace"})
	path := filepath.Join(t.TempDir(), "requests.jsonl")
	_, _, err := Analyze(context.Background(), server.URL, "fixture", r, "fixture", false, path)
	if err == nil || !strings.Contains(err.Error(), "outside authorized directories") || calls.Load() != 0 {
		t.Fatalf("out-of-scope path was sent: err=%v calls=%d", err, calls.Load())
	}
	if _, statErr := os.Stat(path); !os.IsNotExist(statErr) {
		t.Fatalf("out-of-scope path created journal: %v", statErr)
	}

	other := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { calls.Add(1) }))
	defer other.Close()
	targetMismatch := scopedReport(other.URL, []event.Event{event.New("s", "net", event.Process{}, "connection_observed", "direct", nil)}, rules.AuthorizationAuthorized, []string{"/workspace"})
	targetMismatch.Policy.AllowedUploadTargets = []string{"allowed.invalid:443"}
	targetMismatch.RuleConfig.Policy = targetMismatch.Policy
	path = filepath.Join(t.TempDir(), "requests.jsonl")
	_, _, err = Analyze(context.Background(), other.URL, "fixture", targetMismatch, "fixture", false, path)
	if err == nil || !strings.Contains(err.Error(), "outside the authorized upload targets") || calls.Load() != 0 {
		t.Fatalf("target mismatch was sent: err=%v calls=%d", err, calls.Load())
	}
}

func TestAuthorizedScopeAllowsRedactedInRangePath(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		_, _ = io.WriteString(w, validAnalysisResponse())
	}))
	defer server.Close()
	root := t.TempDir()
	pathValue := filepath.Join(root, "archive.zip")
	e := event.New("s", "file", event.Process{}, "file_create", "direct", map[string]any{"path": pathValue, "watch_root": root})
	r := scopedReport(server.URL, []event.Event{e}, rules.AuthorizationAuthorized, []string{root})
	requestPath := filepath.Join(t.TempDir(), "requests.jsonl")
	_, meta, err := Analyze(context.Background(), server.URL, "fixture", r, "fixture", false, requestPath)
	if err != nil || calls.Load() != 1 || meta.CompletedBatches != 1 {
		t.Fatalf("in-range authorized analysis failed: err=%v calls=%d meta=%+v", err, calls.Load(), meta)
	}
	archive, err := report.ReadRequestJournal(requestPath, "s")
	if err != nil || len(archive.Records) != 2 {
		t.Fatalf("authorized request journal missing: %v", err)
	}
	if strings.Contains(archive.Records[0].Body, pathValue) {
		t.Fatal("authorized request journal retained raw path")
	}
}

func TestAuthorizedRootPathIsNotMistakenForUnredactedPayload(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		_, _ = io.WriteString(w, validAnalysisResponse())
	}))
	defer server.Close()
	e := event.New("s", "file", event.Process{}, "file_open_observed", "direct", map[string]any{"path": "/"})
	r := scopedReport(server.URL, []event.Event{e}, rules.AuthorizationAuthorized, []string{"/"})
	_, meta, err := Analyze(context.Background(), server.URL, "fixture", r, "fixture", false, filepath.Join(t.TempDir(), "requests.jsonl"))
	if err != nil || calls.Load() != 1 || meta.CompletedBatches != 1 {
		t.Fatalf("redacted root path was rejected: err=%v calls=%d meta=%+v", err, calls.Load(), meta)
	}
}

func TestReconcileAuthorizationGuardRunsBeforeJournal(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { calls.Add(1) }))
	defer server.Close()
	e := event.New("s", "file", event.Process{}, "file_create", "direct", map[string]any{"path": "/private/secret.zip"})
	r := scopedReport(server.URL, []event.Event{e}, rules.AuthorizationAuthorized, []string{"/workspace"})
	r.Analysis = &report.Analysis{Verdict: "suspicious", Findings: []report.AnalysisFinding{{Claim: "artifact", EvidenceIDs: []string{e.ID}, Confidence: .5, RequestBatch: 1}}, BatchVerdicts: []report.AnalysisBatchVerdict{{Batch: 1, Verdict: "suspicious", FindingCount: 1}}}
	path := filepath.Join(t.TempDir(), "requests.jsonl")
	_, meta, err := Reconcile(context.Background(), server.URL, "fixture", r, "fixture", false, 4, path)
	if err == nil || !strings.Contains(err.Error(), "outside authorized directories") || calls.Load() != 0 || meta.AttemptedBatches != 0 {
		t.Fatalf("reconcile out-of-scope path escaped guard: err=%v calls=%d meta=%+v", err, calls.Load(), meta)
	}
	if _, statErr := os.Stat(path); !os.IsNotExist(statErr) {
		t.Fatalf("reconcile guard created journal: %v", statErr)
	}
}

func TestPolicyPayloadCheckUsesSerializedEventIDs(t *testing.T) {
	root := t.TempDir()
	e := event.New("s", "file", event.Process{}, "file_create", "direct", map[string]any{"path": filepath.Join(root, "one.zip")})
	r := scopedReport("https://example.invalid/v1", []event.Event{e}, rules.AuthorizationAuthorized, []string{root})
	payload, _ := RequestPayload(r, "fixture", false)
	body, err := json.Marshal(payload)
	if err != nil {
		t.Fatal(err)
	}
	if err := validateAuthorizedPayload(r.Policy, body, []event.Event{e}); err != nil {
		t.Fatal(err)
	}
	if err := validateAuthorizedPayload(r.Policy, body, []event.Event{event.New("s", "net", event.Process{}, "connection_observed", "direct", nil)}); err == nil {
		t.Fatal("accepted serialized payload with mismatched event ID")
	}
}
