package llm

import (
	"encoding/json"
	"fmt"
	"io"
	"strings"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/report"
)

func parseReview(content string, findings []report.AnalysisFinding, events []event.Event, claimsHidden bool) (report.ReviewResult, error) {
	// Pointer fields distinguish a required zero/empty value from an omitted
	// or null field. Local provenance and quantities are never model writable.
	var wire struct {
		Verdict     string `json:"verdict"`
		Assessments *[]struct {
			FindingIDs   []int    `json:"finding_ids"`
			Relationship string   `json:"relationship"`
			Status       string   `json:"status"`
			Claim        string   `json:"claim"`
			EvidenceIDs  []string `json:"evidence_ids"`
			Confidence   *float64 `json:"confidence"`
		} `json:"assessments"`
		UnexplainedIDs *[]string `json:"unexplained_egress_ids"`
	}
	decoder := json.NewDecoder(strings.NewReader(content))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&wire); err != nil {
		return report.ReviewResult{}, fmt.Errorf("LLM did not return valid review JSON")
	}
	if _, err := decoder.Token(); err != io.EOF {
		return report.ReviewResult{}, fmt.Errorf("unexpected content after review JSON")
	}
	if wire.Assessments == nil || wire.UnexplainedIDs == nil || (wire.Verdict != "clean" && wire.Verdict != "suspicious" && wire.Verdict != "alarming") {
		return report.ReviewResult{}, fmt.Errorf("review omitted required fields or returned an invalid verdict")
	}
	known := map[string]bool{}
	for _, e := range events {
		known[e.ID] = true
	}
	seenFindings := map[int]bool{}
	activeEvidence := map[string]bool{}
	active := 0
	result := report.ReviewResult{Verdict: wire.Verdict, Assessments: []report.ReviewAssessment{}, UnexplainedEgressIDs: *wire.UnexplainedIDs}
	for _, a := range *wire.Assessments {
		if len(a.FindingIDs) == 0 || len(a.EvidenceIDs) == 0 || strings.TrimSpace(a.Claim) == "" || a.Confidence == nil || *a.Confidence < 0 || *a.Confidence > 1 {
			return report.ReviewResult{}, fmt.Errorf("review assessment has missing evidence, claim or confidence")
		}
		switch a.Relationship {
		case "independent":
			if len(a.FindingIDs) != 1 {
				return report.ReviewResult{}, fmt.Errorf("independent assessment must cover one finding")
			}
		case "duplicate", "contradictory":
			if len(a.FindingIDs) < 2 || claimsHidden {
				return report.ReviewResult{}, fmt.Errorf("related assessment requires multiple visible prior claims")
			}
		default:
			return report.ReviewResult{}, fmt.Errorf("invalid assessment relationship")
		}
		switch a.Status {
		case "supported", "revised", "unresolved":
			active++
		case "withdrawn":
		default:
			return report.ReviewResult{}, fmt.Errorf("invalid assessment status")
		}
		if a.Relationship == "contradictory" && a.Status == "supported" {
			return report.ReviewResult{}, fmt.Errorf("contradictory findings cannot both be confirmed")
		}
		cited := map[string]bool{}
		for _, id := range a.EvidenceIDs {
			if !known[id] || cited[id] {
				return report.ReviewResult{}, fmt.Errorf("review cited unknown or duplicate evidence")
			}
			cited[id] = true
			if a.Status != "withdrawn" {
				activeEvidence[id] = true
			}
		}
		for _, id := range a.FindingIDs {
			if id < 1 || id > len(findings) || seenFindings[id] {
				return report.ReviewResult{}, fmt.Errorf("review referenced an unknown or repeated finding")
			}
			seenFindings[id] = true
			grounded := false
			for _, evidenceID := range findings[id-1].EvidenceIDs {
				grounded = grounded || cited[evidenceID]
			}
			if !grounded {
				return report.ReviewResult{}, fmt.Errorf("review did not cite original evidence for finding %d", id)
			}
		}
		result.Assessments = append(result.Assessments, report.ReviewAssessment{FindingIDs: a.FindingIDs, Relationship: a.Relationship, Status: a.Status, Claim: a.Claim, EvidenceIDs: a.EvidenceIDs, Confidence: *a.Confidence})
	}
	if len(seenFindings) != len(findings) {
		return report.ReviewResult{}, fmt.Errorf("review did not account for every original finding")
	}
	if (wire.Verdict == "clean") != (active == 0) {
		return report.ReviewResult{}, fmt.Errorf("review verdict contradicts remaining assessments")
	}
	for _, id := range result.UnexplainedEgressIDs {
		if !activeEvidence[id] {
			return report.ReviewResult{}, fmt.Errorf("review network selection must be cited by a non-withdrawn assessment")
		}
	}
	var err error
	result.UnexplainedTraffic, err = quantifiedTraffic(result.UnexplainedEgressIDs, events)
	if err != nil {
		return report.ReviewResult{}, err
	}
	return result, nil
}
