package llm

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/report"
)

func TestAnalyzeSendsRedactedPayloadAndValidatesEvidence(t *testing.T) {
	e := event.New("s", "file", event.Process{Name: "agent"}, "goal", "direct", map[string]any{"path": `/Users/Alice/secret.txt`, "text": "API_KEY=sk-secretvalue"})
	r := report.New("s", "C:/private/project", []string{"agent"}, []event.Event{e})
	var body string
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		data, _ := io.ReadAll(req.Body)
		body = string(data)
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]string{"content": `{"verdict":"clean","findings":[],"unexplained_egress_ids":[]}`}}}})
	}))
	defer server.Close()
	r = scopeReportForEndpoint(server.URL, r)
	analysis, meta, err := Analyze(context.Background(), server.URL, "test-key", r, "small", false, filepath.Join(t.TempDir(), "requests.jsonl"))
	if err != nil {
		t.Fatal(err)
	}
	if analysis.Verdict != "clean" || strings.Contains(body, "sk-secretvalue") || strings.Contains(body, "/Users/Alice") {
		t.Fatalf("analysis=%#v body=%s", analysis, body)
	}
	if len(meta.RequestBodies) != 1 || meta.RequestBodies[0] != body || strings.Contains(meta.RequestBodies[0], "test-key") {
		t.Fatal("request archive differs from submitted body or contains credentials")
	}
}

func TestPayloadRecomputesDestinationClassAndKeepsSource(t *testing.T) {
	events := []event.Event{}
	for _, host := range []string{"gateway.example.com:443", "bucket.s3.amazonaws.com", "api.googleapis.com"} {
		events = append(events, event.New("s", "net", event.Process{}, "connection_observed", "direct", map[string]any{"remote_host": host, "host_source": "reverse_dns", "object_storage_candidate": true, "destination_class": "spoofed"}))
	}
	r := report.New("s", "w", nil, events)
	r.RuleConfig.ModelAPIHosts = []string{"gateway.example.com"}
	p, meta := RequestPayload(r, "test", false)
	var data struct {
		Events []event.Event `json:"goal_and_events"`
	}
	if err := json.Unmarshal([]byte(p.Messages[1].Content), &data); err != nil {
		t.Fatal(err)
	}
	for i, want := range []string{"model_api", "object_storage", "unknown"} {
		if data.Events[i].Detail["destination_class"] != want || data.Events[i].Detail["host_source"] != "reverse_dns" {
			t.Fatalf("wrong destination evidence: %+v", data.Events[i])
		}
		if _, ok := data.Events[i].Detail["object_storage_candidate"]; ok {
			t.Fatal("unverified imported flag reached model")
		}
	}
	if !strings.Contains(strings.Join(meta.FieldTypes, ","), "detail.destination_class") {
		t.Fatal("classification missing from disclosure")
	}
}

func TestModelRangeCluesAreDerivedLocallyWithDatedProvenance(t *testing.T) {
	var events []event.Event
	for _, ip := range []string{"3.5.140.1", "13.65.107.33", "192.0.2.1"} {
		events = append(events, event.New("s", "net", event.Process{}, "connection_observed", "direct", map[string]any{"remote_ip": ip, "ip_range_matches": []string{"forged-secret"}, "ip_range_match_field": "forged-secret"}))
	}
	events = append(events, event.New("s", "net", event.Process{}, "egress", "direct", map[string]any{"remote_ip": "3.5.140.1", "remote_host": "bucket.s3.amazonaws.com", "direction": "aggregate"}))
	r := report.New("s", "w", nil, events)
	p, meta := RequestPayload(r, "fixture", false)
	var body struct {
		Events []event.Event `json:"goal_and_events"`
	}
	if err := json.Unmarshal([]byte(p.Messages[1].Content), &body); err != nil {
		t.Fatal(err)
	}
	for i, service := range []string{"AWS S3", "Azure Storage"} {
		matches, ok := body.Events[i].Detail["ip_range_matches"].([]any)
		if !ok || len(matches) != 1 {
			t.Fatal("missing local clue")
		}
		match := matches[0].(map[string]any)
		if match["service"] != service || match["source_sha256"] == "" || match["published_at"] == "" || match["source_url"] == "" || body.Events[i].Detail["ip_range_match_field"] != "remote_ip" || body.Events[i].Detail["destination_class"] != "unknown" {
			t.Fatal("IP clue became verified service", match)
		}
	}
	for _, e := range body.Events[2:] {
		if _, ok := e.Detail["ip_range_matches"]; ok {
			t.Fatal("unknown or aggregate event received a service address")
		}
	}
	if strings.Contains(p.Messages[1].Content, "forged-secret") || !strings.Contains(strings.Join(meta.FieldTypes, ","), "detail.ip_range_matches") {
		t.Fatal("imported metadata trusted or disclosure missing")
	}
}

func TestModelPayloadKeepsLifetimeAndMeasurementInterval(t *testing.T) {
	e := event.New("s", "net", event.Process{PID: 42, Name: "agent", Path: "C:/private/agent.exe", CreatedAtMS: 1789831861000}, "egress", "direct", map[string]any{"source": "nettop", "direction": "aggregate", "metric": "network_bytes", "sample_start": "2026-09-19T10:00:00Z", "sample_end": "2026-09-19T10:00:02Z", "window_sec": float64(2), "bytes_out": uint64(10), "bytes_in": uint64(20)})
	r := report.New("s", "w", nil, []event.Event{e})
	p, _ := RequestPayload(r, "test", false)
	var data struct {
		Events []event.Event `json:"goal_and_events"`
	}
	if err := json.Unmarshal([]byte(p.Messages[1].Content), &data); err != nil {
		t.Fatal(err)
	}
	clean := data.Events[0]
	if clean.Process.CreatedAtMS != e.Process.CreatedAtMS || clean.Process.Path != "" || clean.Detail["sample_start"] != e.Detail["sample_start"] || clean.Detail["source"] != "nettop" {
		t.Fatalf("measurement context lost or path leaked: %+v", clean)
	}
}

func TestApprovalRequestPayloadRetainsMeaningAndOmitsArguments(t *testing.T) {
	e := event.New("s", "semantic", event.Process{Name: "roo-log"}, "claimed_action", "direct", map[string]any{
		"tool": "execute_command", "stage": "approval_request", "source": "roo", "trust": "self_reported", "time_source": "agent_log", "log_record": 7, "args": "private-command",
	})
	p, _ := RequestPayload(report.New("s", "w", nil, []event.Event{e}), "test", false)
	var data struct {
		Events []event.Event `json:"goal_and_events"`
	}
	if err := json.Unmarshal([]byte(p.Messages[1].Content), &data); err != nil {
		t.Fatal(err)
	}
	d := data.Events[0].Detail
	if d["stage"] != "approval_request" || d["trust"] != "self_reported" || d["source"] != "roo" || d["log_record"] != float64(7) || strings.Contains(p.Messages[1].Content, "private-command") {
		t.Fatal("approval semantics lost or arguments exposed")
	}
	if !strings.Contains(p.Messages[0].Content, "不证明获准或实际执行") {
		t.Fatal("model not informed of approval evidence limits")
	}
}

func TestClinePayloadKeepsDelegationAndRequestStage(t *testing.T) {
	e := event.New("s", "semantic", event.Process{Name: "cline-log"}, "claimed_action", "direct", map[string]any{
		"tool": "read_files", "stage": "tool_request", "agent_role": "subagent", "time_source": "observed", "source": "cline", "log_record": 2, "input": "private-arguments",
	})
	p, _ := RequestPayload(report.New("s", "w", nil, []event.Event{e}), "test", false)
	var data struct {
		Events []event.Event `json:"goal_and_events"`
	}
	if err := json.Unmarshal([]byte(p.Messages[1].Content), &data); err != nil {
		t.Fatal(err)
	}
	d := data.Events[0].Detail
	if d["stage"] != "tool_request" || d["agent_role"] != "subagent" || d["time_source"] != "observed" || strings.Contains(p.Messages[1].Content, "private-arguments") {
		t.Fatal("Cline source meaning lost or arguments exposed")
	}
	if !strings.Contains(p.Messages[0].Content, "轮次边界") || !strings.Contains(p.Messages[0].Content, "任务委派") {
		t.Fatal("missing Cline persistence/delegation limits")
	}
}

func TestProxyFailurePayloadKeepsSafeDiagnosisAndConnectionLink(t *testing.T) {
	e := event.New("s", "net", event.Process{PID: 42, CreatedAtMS: 100}, "connection_failed", "direct", map[string]any{"source": "proxy", "proxy": true, "stage": "request_body", "error_code": "io_error", "connection_event_id": "e_connection", "remote_host": "api.openai.com:443", "reason": "transfer_failed", "error": "private raw request", "request_headers": "Bearer private-token"})
	p, _ := RequestPayload(report.New("s", "w", nil, []event.Event{e}), "test", false)
	var data struct {
		Events []event.Event `json:"goal_and_events"`
	}
	if err := json.Unmarshal([]byte(p.Messages[1].Content), &data); err != nil {
		t.Fatal(err)
	}
	d := data.Events[0].Detail
	if d["connection_event_id"] != "e_connection" || d["error_code"] != "io_error" || d["stage"] != "request_body" || d["destination_class"] != "model_api" || d["proxy"] != true || strings.Contains(p.Messages[1].Content, "private") {
		t.Fatal("proxy diagnosis missing or raw request leaked")
	}
}

func TestEveryBatchDisclosesCollectionGapsWithoutRawErrors(t *testing.T) {
	gap := event.New("s", "semantic", event.Process{Name: "agent-log"}, "collector_error", "direct", map[string]any{"coverage": "incomplete", "error": "private-error-body"})
	goal := event.New("s", "semantic", event.Process{Name: "user"}, "goal", "direct", map[string]any{"text": "edit README"})
	action := event.New("s", "semantic", event.Process{Name: "agent-log"}, "claimed_action", "direct", map[string]any{"tool": "Read", "args": "private-arguments"})
	file := event.New("s", "file", event.Process{}, "file_create", "temporal", nil)
	r := report.New("s", "w", nil, []event.Event{goal, gap, action, file})
	batches, _, err := RequestPayloadBatches(r, "test", false, 3)
	if err != nil || len(batches) != 2 {
		t.Fatalf("batches=%d error=%v", len(batches), err)
	}
	for _, batch := range batches {
		var payload struct {
			Count int `json:"collection_error_count"`
		}
		if err := json.Unmarshal([]byte(batch.Messages[1].Content), &payload); err != nil {
			t.Fatal(err)
		}
		if payload.Count != 1 || strings.Contains(batch.Messages[1].Content, "private-") {
			t.Fatal("collection gap missing or raw content leaked")
		}
	}
	var submitted []Payload
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		var p Payload
		if err := json.NewDecoder(req.Body).Decode(&p); err != nil {
			t.Error(err)
		}
		submitted = append(submitted, p)
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]string{"content": `{"verdict":"clean","findings":[],"unexplained_egress_ids":[]}`}}}})
	}))
	defer server.Close()
	r = scopeReportForEndpoint(server.URL, r)
	_, meta, err := AnalyzeBatched(context.Background(), server.URL, "fixture-key", r, "test", false, 3, filepath.Join(t.TempDir(), "requests.jsonl"))
	if err != nil || len(submitted) != len(batches) || len(meta.RequestBodies) != len(batches) {
		t.Fatalf("actual batches=%d error=%v", len(submitted), err)
	}
	for i := range batches {
		if submitted[i].Messages[1].Content != batches[i].Messages[1].Content {
			t.Fatal("actual request lost collection gaps present in preview")
		}
	}
}

func TestRejectsUnsupportedModelClaims(t *testing.T) {
	e := event.New("s", "net", event.Process{}, "connection_observed", "direct", nil)
	for _, content := range []string{
		`{"verdict":"clean"}`,
		`{"verdict":"suspicious","findings":[],"unexplained_egress_ids":[]}`,
		`{"verdict":"clean","findings":[],"unexplained_bytes_out":50}`,
		`{"verdict":"alarming","findings":[{"claim":"x","confidence":0.5,"evidence_ids":["missing"]}],"unexplained_egress_ids":[]}`,
		`{"verdict":"clean","findings":[],"unexplained_egress_ids":[],"arbitrary":"yes"}`,
	} {
		if _, err := parseAnalysis(content, []event.Event{e}); err == nil {
			t.Fatalf("accepted unsupported output %s", content)
		}
	}
	valid := `{"verdict":"suspicious","findings":[{"claim":"Needs investigation","confidence":0.5,"evidence_ids":["` + e.ID + `"]}],"unexplained_egress_ids":[]}`
	if _, err := parseAnalysis(valid, []event.Event{e}); err != nil {
		t.Fatal(err)
	}
}

func TestRedirectDoesNotForwardAuditData(t *testing.T) {
	called := false
	target := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { called = true }))
	defer target.Close()
	redirect := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { http.Redirect(w, r, target.URL, 307) }))
	defer redirect.Close()
	_, _, err := Analyze(context.Background(), redirect.URL, "test", scopeReportForEndpoint(redirect.URL, report.New("s", "w", nil, nil)), "test", false, filepath.Join(t.TempDir(), "requests.jsonl"))
	if err == nil || called {
		t.Fatal("redirect must be rejected without forwarding data")
	}
}

func TestAnalyzeBatchesAndMergesReports(t *testing.T) {
	count := 0
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		count++
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"choices":[{"message":{"content":"{\"verdict\":\"clean\",\"findings\":[],\"unexplained_egress_ids\":[]}"}}]}`))
	}))
	defer server.Close()
	events := []event.Event{}
	for i := 0; i < 5; i++ {
		events = append(events, event.New("s", "net", event.Process{Name: "agent"}, "connection_observed", "direct", nil))
	}
	r := report.New("s", "w", nil, events)
	r = scopeReportForEndpoint(server.URL, r)
	_, meta, err := AnalyzeBatched(context.Background(), server.URL, "key", r, "small", false, 2, filepath.Join(t.TempDir(), "requests.jsonl"))
	if err != nil || count != 4 || meta.BatchCount != 4 || meta.EventCount != 8 || meta.CoveredEvents != 5 {
		t.Fatalf("count=%d batches=%d events=%d covered=%d err=%v", count, meta.BatchCount, meta.EventCount, meta.CoveredEvents, err)
	}
}

func TestRequestBatchesRepeatGoalForReconciliation(t *testing.T) {
	goal := event.New("s", "semantic", event.Process{}, "goal", "direct", map[string]any{"text": "README only"})
	values := []event.Event{goal}
	for i := 0; i < 4; i++ {
		values = append(values, event.New("s", "net", event.Process{}, "connection_observed", "direct", nil))
	}
	r := report.New("s", "w", nil, values)
	payloads, meta, err := RequestPayloadBatches(r, "small", false, 3)
	if err != nil || len(payloads) != 3 || meta.BatchCount != 3 {
		t.Fatalf("payloads=%d batches=%d err=%v", len(payloads), meta.BatchCount, err)
	}
	for _, payload := range payloads {
		if !strings.Contains(payload.Messages[1].Content, goal.ID) {
			t.Fatalf("goal missing from batch: %s", payload.Messages[1].Content)
		}
	}
}

func TestBatchFailurePreservesAttemptAndCoverage(t *testing.T) {
	count := 0
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		count++
		if count == 2 {
			w.WriteHeader(500)
			return
		}
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]string{"content": `{"verdict":"clean","findings":[],"unexplained_egress_ids":[]}`}}}})
	}))
	defer server.Close()
	events := []event.Event{}
	for i := 0; i < 5; i++ {
		events = append(events, event.New("s", "net", event.Process{}, "connection_observed", "direct", nil))
	}
	_, meta, err := AnalyzeBatched(context.Background(), server.URL, "key", scopeReportForEndpoint(server.URL, report.New("s", "w", nil, events)), "test", false, 2, filepath.Join(t.TempDir(), "requests.jsonl"))
	if err == nil || meta.AttemptedBatches != 2 || meta.CompletedBatches != 1 || meta.EventCount != 4 || meta.CoveredEvents != 2 || meta.TotalEvents != 5 || len(meta.RequestBodies) != 2 {
		t.Fatalf("wrong disclosure: %+v %v", meta, err)
	}
}

func TestOversizedPayloadIsNotSentOrRecordedAsAttempt(t *testing.T) {
	goal := event.New("s", "semantic", event.Process{}, "goal", "direct", map[string]any{"text": strings.Repeat("a", 4*1024*1024)})
	r := report.New("s", "w", nil, []event.Event{goal})
	if _, _, err := RequestPayloadBatches(r, "test", false, 200); err == nil {
		t.Fatal("oversized preview accepted")
	}
	called := false
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) { called = true }))
	defer server.Close()
	r = scopeReportForEndpoint(server.URL, r)
	_, meta, err := Analyze(context.Background(), server.URL, "fixture-key", r, "test", false, filepath.Join(t.TempDir(), "requests.jsonl"))
	if err == nil || called || meta.AttemptedBatches != 0 || len(meta.RequestBodies) != 0 {
		t.Fatal("oversized request sent or falsely recorded as attempted")
	}
}

func TestBatchCapacityCannotDropTaskGoals(t *testing.T) {
	goal := event.New("s", "semantic", event.Process{}, "goal", "direct", map[string]any{"text": "readme"})
	r := report.New("s", "w", nil, []event.Event{goal, event.New("s", "net", event.Process{}, "connection_observed", "direct", nil)})
	if _, _, err := RequestPayloadBatches(r, "test", false, 1); err == nil {
		t.Fatal("accepted batch that cannot carry its task goal")
	}
}
