package llm

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/report"
)

func TestRequestJournalPrecedesEachNetworkAttempt(t *testing.T) {
	path := filepath.Join(t.TempDir(), "requests.jsonl")
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		batch := int(calls.Add(1))
		body, _ := io.ReadAll(req.Body)
		archive, err := report.ReadRequestJournal(path, "s")
		if err != nil {
			t.Error(err)
			w.WriteHeader(500)
			return
		}
		if len(archive.Records) != batch*2-1 || archive.Records[len(archive.Records)-1].Kind != "prepared" || archive.Records[len(archive.Records)-1].Body != string(body) {
			t.Error("request reached server without exact prior preparation")
		}
		if batch == 2 {
			w.WriteHeader(500)
			return
		}
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]string{"content": `{"verdict":"clean","findings":[],"unexplained_egress_ids":[]}`}}}})
	}))
	defer server.Close()
	events := []event.Event{}
	for i := 0; i < 3; i++ {
		events = append(events, event.New("s", "net", event.Process{}, "connection_observed", "direct", nil))
	}
	_, meta, err := AnalyzeBatched(context.Background(), server.URL, "synthetic-key-never-archive", scopeReportForEndpoint(server.URL, report.New("s", "w", nil, events)), "fixture", false, 2, path)
	if err == nil || calls.Load() != 2 || meta.CompletedBatches != 1 || meta.AttemptedBatches != 2 {
		t.Fatal("failed batch did not stop analysis")
	}
	a, err := report.ReadRequestJournal(path, "s")
	if err != nil {
		t.Fatal(err)
	}
	if len(a.Records) != 4 || a.Records[1].Kind != "completed" || a.Records[3].Kind != "failed" {
		t.Fatal("wrong durable outcomes")
	}
	raw, _ := os.ReadFile(path)
	if strings.Contains(string(raw), "synthetic-key-never-archive") {
		t.Fatal("API key persisted")
	}
}

func TestUnwritableJournalPreventsNetworkAttempt(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { calls.Add(1); w.WriteHeader(500) }))
	defer server.Close()
	dir := t.TempDir()
	for _, path := range []string{dir, filepath.Join(dir, "missing", "requests.jsonl")} {
		_, meta, err := Analyze(context.Background(), server.URL, "fixture", scopeReportForEndpoint(server.URL, report.New("s", "w", nil, nil)), "fixture", false, path)
		if err == nil || meta.AttemptedBatches != 0 {
			t.Fatal("journal error ignored")
		}
	}
	if calls.Load() != 0 {
		t.Fatal("sent request without durable archive")
	}
}

func TestRequestJournalSurvivesKilledAnalysis(t *testing.T) {
	if os.Getenv("BMA_JOURNAL_TEST_CHILD") == "1" {
		endpoint := os.Getenv("BMA_JOURNAL_TEST_ENDPOINT")
		_, _, err := Analyze(context.Background(), endpoint, "synthetic-key", scopeReportForEndpoint(endpoint, report.New("s", "w", nil, nil)), "fixture", false, os.Getenv("BMA_JOURNAL_TEST_PATH"))
		if err != nil {
			t.Fatal(err)
		}
		return
	}
	path := filepath.Join(t.TempDir(), "requests.jsonl")
	arrived := make(chan []byte, 1)
	release := make(chan struct{})
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		body, _ := io.ReadAll(r.Body)
		arrived <- body
		<-release
	}))
	defer server.Close()
	defer close(release)
	cmd := exec.Command(os.Args[0], "-test.run=^TestRequestJournalSurvivesKilledAnalysis$")
	cmd.Env = append(os.Environ(), "BMA_JOURNAL_TEST_CHILD=1", "BMA_JOURNAL_TEST_ENDPOINT="+server.URL, "BMA_JOURNAL_TEST_PATH="+path)
	var output bytes.Buffer
	cmd.Stdout, cmd.Stderr = &output, &output
	if err := cmd.Start(); err != nil {
		t.Fatal(err)
	}
	defer func() { cmd.Process.Kill(); cmd.Wait() }()
	var body []byte
	select {
	case body = <-arrived:
	case <-time.After(15 * time.Second):
		t.Fatal("child did not reach pending HTTP request")
	}
	if err := cmd.Process.Kill(); err != nil {
		t.Fatal(err)
	}
	if err := cmd.Wait(); err == nil {
		t.Fatal("child unexpectedly completed")
	}
	a, err := report.ReadRequestJournal(path, "s")
	if err != nil {
		t.Fatal(err)
	}
	if a.TruncatedLastRecord || len(a.Records) != 1 || a.Records[0].Kind != "prepared" || a.Records[0].Body != string(body) {
		t.Fatal("process termination lost request or invented outcome")
	}
	r, err := report.RecoverRequests(path)
	if err != nil || r.Analysis != nil || r.AnalysisRequest != nil || r.Status != "recovered" {
		t.Fatal("recovery invented analysis", err)
	}
}
