package llm

import (
	"context"
	"encoding/json"
	"math"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/report"
)

func measuredEvent(source string, count any) event.Event {
	return event.New("s", "net", event.Process{}, "egress", "direct", map[string]any{"source": source, "metric": "network_bytes", "bytes_out": count})
}

func modelSelection(t *testing.T, cited, selected []string) string {
	t.Helper()
	content, err := json.Marshal(map[string]any{
		"verdict":                "suspicious",
		"findings":               []report.AnalysisFinding{{Claim: "Needs investigation", Confidence: 0.8, EvidenceIDs: cited}},
		"unexplained_egress_ids": selected,
	})
	if err != nil {
		t.Fatal(err)
	}
	return string(content)
}

func TestQuantifiedEvidenceMustBeCitedMeasuredAndUnique(t *testing.T) {
	for _, name := range []string{"uncited", "connection", "file-size", "io", "synthetic", "unknown-source", "temporal", "fraction", "negative", "string", "missing", "nan", "infinity", "rounded", "zero", "duplicate-selection", "unknown-id", "duplicate-input", "extra-total"} {
		t.Run(name, func(t *testing.T) {
			e := measuredEvent("proxy", uint64(100))
			other := event.New("s", "file", event.Process{}, "file_create", "temporal", map[string]any{"size_bytes": 1000})
			cited, selected := []string{e.ID}, []string{e.ID}
			switch name {
			case "uncited":
				cited = []string{other.ID}
			case "connection":
				e.Kind = "connection_closed"
			case "file-size":
				e.Layer = "file"
			case "io":
				e.Detail["metric"] = "process_io"
			case "synthetic":
				e.Detail["synthetic"] = true
			case "unknown-source":
				e.Detail["source"] = "unknown"
			case "temporal":
				e.Attribution = "temporal"
			case "fraction":
				e.Detail["bytes_out"] = 1.5
			case "negative":
				e.Detail["bytes_out"] = -1
			case "string":
				e.Detail["bytes_out"] = "100"
			case "missing":
				delete(e.Detail, "bytes_out")
			case "nan":
				e.Detail["bytes_out"] = math.NaN()
			case "infinity":
				e.Detail["bytes_out"] = math.Inf(1)
			case "rounded":
				e.Detail["bytes_out"] = float64(1 << 53)
			case "zero":
				e.Detail["bytes_out"] = 0
			case "duplicate-selection":
				selected = append(selected, e.ID)
			case "unknown-id":
				selected = []string{"missing"}
			case "duplicate-input":
				other = e
			}
			content := modelSelection(t, cited, selected)
			if name == "extra-total" {
				content = strings.TrimSuffix(content, "}") + `,"unexplained_bytes_out":50}`
			}
			if _, err := parseAnalysis(content, []event.Event{e, other}); err == nil {
				t.Fatal("unsupported quantity accepted")
			}
		})
	}
}

func TestQuantitiesComputedBySourceWithoutCrossSourceTotal(t *testing.T) {
	events := []event.Event{measuredEvent("proxy", uint64(100)), measuredEvent("proxy", json.Number("50")), measuredEvent("nettop", float64(150))}
	ids := []string{events[0].ID, events[1].ID, events[2].ID}
	a, err := parseAnalysis(modelSelection(t, ids, ids), events)
	if err != nil {
		t.Fatal(err)
	}
	if len(a.UnexplainedTraffic) != 2 || a.UnexplainedTraffic[0].Source != "nettop" || a.UnexplainedTraffic[0].BytesOut != 150 || a.UnexplainedTraffic[1].Source != "proxy" || a.UnexplainedTraffic[1].BytesOut != 150 || len(a.UnexplainedTraffic[1].EvidenceIDs) != 2 {
		t.Fatalf("source totals lost or combined: %+v", a.UnexplainedTraffic)
	}
	data, _ := json.Marshal(a)
	if strings.Contains(string(data), "unexplained_bytes_out") {
		t.Fatal("ambiguous combined total survived")
	}
}

func TestQuantitiesRejectOverflowAndPreserveExactIntegers(t *testing.T) {
	for _, n := range []any{uint64(math.MaxUint64), json.Number("18446744073709551615")} {
		e := measuredEvent("proxy", n)
		got, err := quantifiedTraffic([]string{e.ID}, []event.Event{e})
		if err != nil || len(got) != 1 || got[0].BytesOut != math.MaxUint64 {
			t.Fatal("exact integer lost", err)
		}
		second := measuredEvent("proxy", uint64(1))
		if _, err := quantifiedTraffic([]string{e.ID, second.ID}, []event.Event{e, second}); err == nil {
			t.Fatal("overflow accepted")
		}
	}
}

func TestQuantitiesMergeAcrossBatchesWithSourceSeparation(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		var payload Payload
		if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
			t.Error(err)
			w.WriteHeader(500)
			return
		}
		var data struct {
			Events []event.Event `json:"goal_and_events"`
		}
		if err := json.Unmarshal([]byte(payload.Messages[1].Content), &data); err != nil || len(data.Events) != 2 {
			t.Error("missing batch evidence")
			w.WriteHeader(500)
			return
		}
		ids := []string{data.Events[0].ID, data.Events[1].ID}
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]string{"content": modelSelection(t, ids, ids)}}}})
	}))
	defer server.Close()
	events := []event.Event{measuredEvent("proxy", 10), measuredEvent("nettop", 30), measuredEvent("proxy", 20)}
	a, meta, err := AnalyzeBatched(context.Background(), server.URL, "fixture", scopeReportForEndpoint(server.URL, report.New("s", "w", nil, events)), "fixture", false, 2, filepath.Join(t.TempDir(), "requests.jsonl"))
	if err != nil {
		t.Fatal(err)
	}
	if calls.Load() != 2 || meta.CompletedBatches != 2 || len(a.UnexplainedTraffic) != 2 || a.UnexplainedTraffic[0].BytesOut != 30 || a.UnexplainedTraffic[1].BytesOut != 30 || len(a.UnexplainedEgressIDs) != 3 {
		t.Fatal("incorrect cross-batch arithmetic", a, meta.CompletedBatches)
	}
	// Each batch fits uint64; only the combined report overflows. It must fail
	// without erasing the disclosure of the two successful requests.
	events = []event.Event{measuredEvent("proxy", uint64(math.MaxUint64)), measuredEvent("nettop", uint64(1)), measuredEvent("proxy", uint64(1))}
	a, meta, err = AnalyzeBatched(context.Background(), server.URL, "fixture", scopeReportForEndpoint(server.URL, report.New("s", "w", nil, events)), "fixture", false, 2, filepath.Join(t.TempDir(), "requests.jsonl"))
	if err == nil || a.Verdict != "" || meta.CompletedBatches != 2 || len(meta.RequestBodies) != 2 {
		t.Fatal("cross-batch overflow accepted or request disclosure lost", a, meta.CompletedBatches, err)
	}
}

func TestDuplicateAndForeignSessionEvidenceRejectedBeforeSending(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { calls.Add(1); w.WriteHeader(500) }))
	defer server.Close()
	for _, name := range []string{"duplicate", "foreign", "empty"} {
		t.Run(name, func(t *testing.T) {
			e := measuredEvent("proxy", 1)
			events := []event.Event{e}
			switch name {
			case "duplicate":
				events = append(events, e)
			case "foreign":
				events[0].SessionID = "other"
			case "empty":
				events[0].ID = ""
			}
			r := report.New("s", "w", nil, events)
			if _, _, err := RequestPayloadBatches(r, "fixture", false, 1); err == nil {
				t.Fatal("invalid preview accepted")
			}
			if _, _, err := AnalyzeBatched(context.Background(), server.URL, "fixture", r, "fixture", false, 1, filepath.Join(t.TempDir(), "requests.jsonl")); err == nil {
				t.Fatal("invalid input accepted")
			}
		})
	}
	if calls.Load() != 0 {
		t.Fatal("invalid input sent")
	}
}
