package llm

import (
	"encoding/json"
	"fmt"
	"math"
	"sort"
	"strconv"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/report"
)

// The model chooses whole observations. Arithmetic and source separation are
// local so a plausible model-generated number cannot become measured evidence.
func quantifiedTraffic(ids []string, events []event.Event) ([]report.TrafficEvidence, error) {
	known := make(map[string]event.Event, len(events))
	for _, e := range events {
		if e.ID == "" {
			return nil, fmt.Errorf("analysis event has no evidence ID")
		}
		if _, exists := known[e.ID]; exists {
			return nil, fmt.Errorf("analysis contains duplicate evidence IDs")
		}
		known[e.ID] = e
	}
	groups := map[string]*report.TrafficEvidence{}
	seen := map[string]bool{}
	for _, id := range ids {
		if seen[id] {
			return nil, fmt.Errorf("unexplained network evidence contains duplicate IDs")
		}
		seen[id] = true
		e, exists := known[id]
		source, _ := e.Detail["source"].(string)
		out, valid := exactByteCount(e.Detail["bytes_out"])
		if !exists || e.Layer != "net" || e.Kind != "egress" || e.Attribution != "direct" || e.Detail["metric"] != "network_bytes" || e.Detail["synthetic"] == true || (source != "proxy" && source != "nettop") || !valid || out == 0 {
			return nil, fmt.Errorf("unexplained network evidence requires measured outbound-byte increments with a known source")
		}
		group := groups[source]
		if group == nil {
			group = &report.TrafficEvidence{Source: source}
			groups[source] = group
		}
		if out > math.MaxUint64-group.BytesOut {
			return nil, fmt.Errorf("selected outbound-byte total exceeds integer capacity")
		}
		group.BytesOut += out
		group.EvidenceIDs = append(group.EvidenceIDs, id)
	}
	result := make([]report.TrafficEvidence, 0, len(groups))
	for _, group := range groups {
		sort.Strings(group.EvidenceIDs)
		result = append(result, *group)
	}
	sort.Slice(result, func(i, j int) bool { return result[i].Source < result[j].Source })
	return result, nil
}

func exactByteCount(value any) (uint64, bool) {
	switch n := value.(type) {
	case uint64:
		return n, true
	case uint32:
		return uint64(n), true
	case int:
		return uint64(n), n >= 0
	case int64:
		return uint64(n), n >= 0
	case float64:
		// Imported JSON decoded as float64 must stay within its exact integer
		// range; a rounded value cannot substantiate an exact byte count.
		if !math.IsNaN(n) && !math.IsInf(n, 0) && n >= 0 && n <= 1<<53-1 && math.Trunc(n) == n {
			return uint64(n), true
		}
	case json.Number:
		number, err := strconv.ParseUint(string(n), 10, 64)
		return number, err == nil
	}
	return 0, false
}
