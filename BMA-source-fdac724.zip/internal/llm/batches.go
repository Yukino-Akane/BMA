package llm

import (
	"fmt"
	"sort"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/report"
)

// Use original evidence in overlapping windows, not generated summaries.
// Windows follow recorded timestamps; self-reported clocks remain unverified.
// Explicit event references get a joint batch even across distant windows.
func planBatches(events []event.Event, max int) ([][]event.Event, error) {
	goals, others := []event.Event{}, []event.Event{}
	byID := make(map[string]event.Event, len(events))
	for _, e := range events {
		byID[e.ID] = e
		if e.Layer == "semantic" && e.Kind == "goal" {
			goals = append(goals, e)
		} else {
			others = append(others, e)
		}
	}
	sort.SliceStable(others, func(i, j int) bool { return others[i].TS.Before(others[j].TS) })
	if len(others) == 0 {
		return [][]event.Event{goals}, nil
	}
	capacity := max - len(goals)
	stride := capacity - capacity/2
	var batches [][]event.Event
	placements := make(map[string][]int, len(events))
	add := func(items []event.Event) error {
		if len(batches) >= report.MaxRequestBatches {
			return fmt.Errorf("reconciliation exceeds %d request batches; increase events per call or reduce the report scope", report.MaxRequestBatches)
		}
		batch := append(append([]event.Event{}, goals...), items...)
		for _, e := range batch {
			placements[e.ID] = append(placements[e.ID], len(batches))
		}
		batches = append(batches, batch)
		return nil
	}
	for start := 0; start < len(others); start += stride {
		end := min(start+capacity, len(others))
		if err := add(others[start:end]); err != nil {
			return nil, err
		}
		if end == len(others) {
			break
		}
	}
	var related []event.Event
	queued := map[string]bool{}
	flush := func() error {
		if len(related) == 0 {
			return nil
		}
		if err := add(related); err != nil {
			return err
		}
		related, queued = nil, map[string]bool{}
		return nil
	}
	for _, e := range others {
		for _, key := range []string{"created_event_id", "connection_event_id"} {
			id, _ := e.Detail[key].(string)
			reference, ok := byID[id]
			if !ok || shareBatch(placements[e.ID], placements[id]) {
				continue
			}
			needed := 0
			for _, item := range []event.Event{reference, e} {
				if !queued[item.ID] {
					needed++
				}
			}
			if len(related)+needed > capacity {
				if err := flush(); err != nil {
					return nil, err
				}
			}
			for _, item := range []event.Event{reference, e} {
				if !queued[item.ID] {
					queued[item.ID] = true
					related = append(related, item)
				}
			}
		}
	}
	if err := flush(); err != nil {
		return nil, err
	}
	return batches, nil
}

func shareBatch(left, right []int) bool {
	for i, j := 0, 0; i < len(left) && j < len(right); {
		if left[i] == right[j] {
			return true
		}
		if left[i] < right[j] {
			i++
		} else {
			j++
		}
	}
	return false
}

type batchContext struct {
	TotalEvents                int    `json:"total_events"`
	IncludedEvents             int    `json:"included_events"`
	ClaimedActionsInReport     int    `json:"claimed_actions_in_report"`
	ClaimedActionsInBatch      int    `json:"claimed_actions_in_batch"`
	ClaimedActionsOutsideBatch int    `json:"claimed_actions_outside_batch"`
	SelfReportCoverage         string `json:"self_report_coverage"`
}

func contextForBatch(r report.Report, events []event.Event) batchContext {
	c := batchContext{TotalEvents: len(r.Events), IncludedEvents: len(events), SelfReportCoverage: "unverified"}
	for _, e := range r.Events {
		if e.Layer == "semantic" && e.Kind == "claimed_action" {
			c.ClaimedActionsInReport++
		}
		if e.Layer == "semantic" && e.Kind == "collector_error" {
			c.SelfReportCoverage = "incomplete"
		}
	}
	for _, e := range events {
		if e.Layer == "semantic" && e.Kind == "claimed_action" {
			c.ClaimedActionsInBatch++
		}
	}
	c.ClaimedActionsOutsideBatch = c.ClaimedActionsInReport - c.ClaimedActionsInBatch
	return c
}
