package llm

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/report"
)

func TestReconciliationJoinsTimeRelatedEvidenceAndMatchesPreview(t *testing.T) {
	base := time.Date(2026, 9, 19, 10, 0, 0, 0, time.UTC)
	goal := event.New("s", "semantic", event.Process{}, "goal", "direct", map[string]any{"text": "Only edit README"})
	claim := event.New("s", "semantic", event.Process{}, "claimed_action", "direct", map[string]any{"tool": "read_files", "args": "private-arguments"})
	file := event.New("s", "file", event.Process{}, "file_create", "temporal", map[string]any{"path": "/private-project/archive.zip", "size_bytes": 40})
	net := measuredEvent("proxy", 40)
	first := event.New("s", "net", event.Process{}, "connection_observed", "direct", nil)
	second := event.New("s", "net", event.Process{}, "connection_observed", "direct", nil)
	first.TS, second.TS = base, base.Add(time.Second)
	claim.TS, file.TS, net.TS = base.Add(4*time.Second), base.Add(5*time.Second), base.Add(6*time.Second)
	// Import order separates the claim/file/network trio in ordinary chunks.
	events := []event.Event{goal, claim, first, file, second, net}
	r := report.New("s", "w", nil, events)
	_, preview, err := RequestPayloadBatches(r, "fixture", false, 4)
	if err != nil {
		t.Fatal(err)
	}
	var submitted []string
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		body, _ := io.ReadAll(req.Body)
		submitted = append(submitted, string(body))
		var payload Payload
		var content struct {
			Events []event.Event `json:"goal_and_events"`
		}
		if json.Unmarshal(body, &payload) != nil || json.Unmarshal([]byte(payload.Messages[1].Content), &content) != nil {
			t.Error("invalid submitted request")
			w.WriteHeader(500)
			return
		}
		ids := map[string]bool{}
		for _, e := range content.Events {
			ids[e.ID] = true
		}
		response := `{"verdict":"clean","findings":[],"unexplained_egress_ids":[]}`
		if ids[claim.ID] && ids[file.ID] && ids[net.ID] {
			response = modelSelection(t, []string{claim.ID, file.ID, net.ID}, []string{net.ID})
		}
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]string{"content": response}}}})
	}))
	defer server.Close()
	r = scopeReportForEndpoint(server.URL, r)
	a, meta, err := AnalyzeBatched(context.Background(), server.URL, "fixture", r, "fixture", false, 4, filepath.Join(t.TempDir(), "requests.jsonl"))
	if err != nil || len(a.Findings) != 1 || len(a.Findings[0].EvidenceIDs) != 3 || a.Findings[0].RequestBatch != 2 || len(a.UnexplainedTraffic) != 1 || a.UnexplainedTraffic[0].BytesOut != 40 || meta.CoveredEvents != len(events) {
		t.Fatal("related evidence never reached one model call or quantity was duplicated", err)
	}
	if len(submitted) != len(preview.RequestBodies) || len(submitted) != len(meta.RequestBodies) {
		t.Fatal("preview/actual batch count differs")
	}
	for i := range submitted {
		if submitted[i] != preview.RequestBodies[i] || submitted[i] != meta.RequestBodies[i] || strings.Contains(submitted[i], "private-") {
			t.Fatal("preview differs from actual request or raw data leaked")
		}
	}
	if r.Events[1].ID != claim.ID || r.Events[2].ID != first.ID {
		t.Fatal("batch planning reordered the source report")
	}
}

func TestReconciliationKeepsAdjacentPairsAndDistantReferences(t *testing.T) {
	base := time.Date(2026, 9, 19, 10, 0, 0, 0, time.UTC)
	events := []event.Event{}
	for i := 0; i < 10; i++ {
		e := event.New("s", "file", event.Process{}, "file_modify", "temporal", nil)
		e.TS = base.Add(time.Duration(i) * time.Hour)
		events = append(events, e)
	}
	events[9].Kind = "file_delete"
	events[9].Detail = map[string]any{"created_event_id": events[0].ID}
	events[8].Detail = map[string]any{"connection_event_id": events[1].ID}
	for _, capacity := range []int{2, 3, 4, 7} {
		batches, err := planBatches(events, capacity)
		if err != nil {
			t.Fatal(err)
		}
		joint := func(a, b string) bool {
			for _, batch := range batches {
				seen := map[string]bool{}
				for _, e := range batch {
					if seen[e.ID] {
						t.Fatal("duplicate evidence inside a batch")
					}
					seen[e.ID] = true
				}
				if len(batch) > capacity {
					t.Fatal("request exceeded configured event capacity")
				}
				if seen[a] && seen[b] {
					return true
				}
			}
			return false
		}
		for i := 1; i < len(events); i++ {
			if !joint(events[i-1].ID, events[i].ID) {
				t.Fatal("chronological neighbor pair split across all requests")
			}
		}
		if !joint(events[0].ID, events[9].ID) || !joint(events[1].ID, events[8].ID) {
			t.Fatal("distant explicit references never reconciled together")
		}
	}
}

func TestBatchContextNeverClaimsCompleteSelfReportCoverage(t *testing.T) {
	claim := event.New("s", "semantic", event.Process{}, "claimed_action", "direct", map[string]any{"tool": "Read"})
	activity := event.New("s", "net", event.Process{}, "connection_observed", "direct", nil)
	gap := event.New("s", "semantic", event.Process{}, "collector_error", "direct", map[string]any{"error": "private-error"})
	for _, fixture := range []struct {
		events   []event.Event
		coverage string
		outside  int
	}{
		{[]event.Event{activity}, "unverified", 0},
		{[]event.Event{claim, activity}, "unverified", 1},
		{[]event.Event{claim, activity, gap}, "incomplete", 1},
	} {
		p, _ := requestPayloadForEvents(report.New("s", "w", nil, fixture.events), []event.Event{activity}, "fixture", false)
		var content struct {
			Context batchContext `json:"batch_context"`
		}
		if err := json.Unmarshal([]byte(p.Messages[1].Content), &content); err != nil {
			t.Fatal(err)
		}
		if content.Context.SelfReportCoverage != fixture.coverage || content.Context.ClaimedActionsOutsideBatch != fixture.outside || content.Context.ClaimedActionsInBatch != 0 || strings.Contains(p.Messages[1].Content, "private-error") {
			t.Fatal("missing/outside self-report interpreted as complete or leaked")
		}
	}
}

func TestInfeasibleReconciliationPlanMakesNoRequests(t *testing.T) {
	called := false
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) { called = true }))
	defer server.Close()
	events := []event.Event{}
	for i := 0; i < report.MaxRequestBatches+2; i++ {
		events = append(events, event.New("s", "net", event.Process{}, "connection_observed", "direct", nil))
	}
	for _, fixture := range []struct {
		events   []event.Event
		capacity int
	}{
		{events[:2], 1},
		{events, 2},
	} {
		r := scopeReportForEndpoint(server.URL, report.New("s", "w", nil, fixture.events))
		if _, _, err := RequestPayloadBatches(r, "fixture", false, fixture.capacity); err == nil {
			t.Fatal("infeasible preview accepted")
		}
		_, meta, err := AnalyzeBatched(context.Background(), server.URL, "fixture", r, "fixture", false, fixture.capacity, filepath.Join(t.TempDir(), "requests.jsonl"))
		if err == nil || called || meta.AttemptedBatches != 0 {
			t.Fatal("infeasible plan sent requests")
		}
	}
}

func TestRelatedReferencesArePackedWithinEventBudget(t *testing.T) {
	events := []event.Event{}
	for i := 0; i < 150; i++ {
		e := event.New("s", "net", event.Process{}, "connection_closed", "direct", nil)
		e.TS = time.Unix(int64(i), 0)
		if i > 30 {
			e.Detail = map[string]any{"connection_event_id": events[0].ID}
		}
		events = append(events, e)
	}
	batches, err := planBatches(events, 10)
	if err != nil || len(batches) > 50 {
		t.Fatal("related context created one request per edge", err, len(batches))
	}
	paired := map[string]bool{}
	for _, batch := range batches {
		if len(batch) > 10 {
			t.Fatal("packed context exceeds event budget")
		}
		anchor := false
		for _, e := range batch {
			anchor = anchor || e.ID == events[0].ID
		}
		if anchor {
			for _, e := range batch {
				paired[e.ID] = true
			}
		}
	}
	for _, e := range events[31:] {
		if !paired[e.ID] {
			t.Fatal("packed context separated an explicit reference")
		}
	}
}

func TestModelCannotInventRequestProvenanceOrCiteOutsideBatch(t *testing.T) {
	events := []event.Event{}
	for i := 0; i < 3; i++ {
		events = append(events, event.New("s", "file", event.Process{}, "file_modify", "temporal", nil))
	}
	valid := modelSelection(t, []string{events[0].ID}, []string{})
	if _, err := parseAnalysis(valid, events); err != nil {
		t.Fatal("invalid control response", err)
	}
	spoofed := strings.Replace(valid, `"confidence":0.8`, `"request_batch":999,"confidence":0.8`, 1)
	if _, err := parseAnalysis(spoofed, events); err == nil {
		t.Fatal("model-controlled request provenance accepted")
	}
	if _, err := parseAnalysis(modelSelection(t, []string{events[0].ID, events[0].ID}, []string{}), events); err == nil {
		t.Fatal("duplicate finding references accepted")
	}
	// A known report ID is still invalid if absent from this particular request.
	calls := 0
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		calls++
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]string{"content": modelSelection(t, []string{events[2].ID}, []string{})}}}})
	}))
	defer server.Close()
	_, meta, err := AnalyzeBatched(context.Background(), server.URL, "fixture", scopeReportForEndpoint(server.URL, report.New("s", "w", nil, events)), "fixture", false, 2, filepath.Join(t.TempDir(), "requests.jsonl"))
	if err == nil || !strings.Contains(err.Error(), "unknown evidence") || calls != 1 || meta.CompletedBatches != 0 || meta.AttemptedBatches != 1 {
		t.Fatal("model cited report evidence it was never sent", err)
	}
}
