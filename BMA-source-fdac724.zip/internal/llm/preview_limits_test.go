package llm

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"strings"
	"testing"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/report"
)

func TestPreviewOutputMatchesRequestsAndReturnsWriteErrors(t *testing.T) {
	r := report.New("s", "w", nil, []event.Event{event.New("s", "semantic", event.Process{}, "goal", "direct", map[string]any{"text": "synthetic <&>"})})
	payloads, meta, err := RequestPayloadBatches(r, "fixture", false, 3)
	if err != nil {
		t.Fatal(err)
	}
	var output bytes.Buffer
	if err := WritePreview(&output, payloads); err != nil {
		t.Fatal(err)
	}
	var bodies []json.RawMessage
	if err := json.Unmarshal(output.Bytes(), &bodies); err != nil {
		t.Fatal(err)
	}
	if len(bodies) != len(meta.RequestBodies) {
		t.Fatal("missing requests")
	}
	for i, body := range bodies {
		if string(body) != meta.RequestBodies[i] {
			t.Fatal("preview differs from actual request")
		}
	}
	if err := WritePreview(previewFailureWriter{}, payloads); !errors.Is(err, io.ErrClosedPipe) {
		t.Fatal("lost sink error", err)
	}
	if err := WritePreview(previewShortWriter{}, payloads); !errors.Is(err, io.ErrShortWrite) {
		t.Fatal("lost short write", err)
	}
}

type previewFailureWriter struct{}

func (previewFailureWriter) Write([]byte) (int, error) { return 0, io.ErrClosedPipe }

type previewShortWriter struct{}

func (previewShortWriter) Write(p []byte) (int, error) { return len(p) - 1, nil }

func TestPreviewCapacityCountsAllOverlappingBatches(t *testing.T) {
	values := []event.Event{event.New("s", "semantic", event.Process{}, "goal", "direct", map[string]any{"text": strings.Repeat("fixture ", 100)})}
	for i := 0; i < 6; i++ {
		values = append(values, event.New("s", "net", event.Process{}, "connection_observed", "direct", nil))
	}
	r := report.New("s", "w", nil, values)
	_, baseline, err := RequestPayloadBatches(r, "fixture", false, 3)
	if err != nil || len(baseline.RequestBodies) < 2 {
		t.Fatal("expected multiple overlapping batches", err)
	}
	total := 0
	for _, body := range baseline.RequestBodies {
		total += len(body)
	}
	for _, limit := range []int{total, total - 1, len(baseline.RequestBodies[0])} {
		payloads, meta, err := requestPayloadBatches(r, "fixture", false, 3, limit)
		if limit < total {
			if err == nil || payloads != nil || len(meta.RequestBodies) != 0 || !strings.Contains(err.Error(), "preview exceeds") {
				t.Fatal("oversized preview returned partial payloads", err)
			}
			continue
		}
		if err != nil || len(payloads) != baseline.BatchCount {
			t.Fatal("exact preview capacity rejected", err)
		}
		for i := range payloads {
			encoded, err := marshalRequest(payloads[i])
			if err != nil || string(encoded) != baseline.RequestBodies[i] || meta.RequestBodies[i] != baseline.RequestBodies[i] {
				t.Fatal("bounded preview changed the actual payload", err)
			}
		}
	}
}
