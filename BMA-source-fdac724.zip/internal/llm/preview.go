package llm

import (
	"bufio"
	"fmt"
	"io"
)

// WritePreview emits one request at a time, without another full preview JSON
// allocation. The payload byte budget excludes array separators and whitespace.
// A failed output stream can contain a partial array; callers must return error.
func WritePreview(w io.Writer, payloads []Payload) error {
	buffer := bufio.NewWriterSize(w, 64*1024)
	if _, err := buffer.WriteString("[\n"); err != nil {
		return err
	}
	used := 0
	for i, payload := range payloads {
		body, err := marshalRequest(payload)
		if err != nil {
			return err
		}
		if len(body) > MaxPreviewBytes-used {
			return fmt.Errorf("model request preview exceeds %d bytes", MaxPreviewBytes)
		}
		used += len(body)
		if i > 0 {
			if _, err := buffer.WriteString(",\n"); err != nil {
				return err
			}
		}
		if _, err := buffer.Write(body); err != nil {
			return err
		}
	}
	if _, err := buffer.WriteString("\n]\n"); err != nil {
		return err
	}
	return buffer.Flush()
}
