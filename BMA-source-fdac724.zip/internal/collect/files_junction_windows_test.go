package collect

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
	"testing"

	"behavior-monitoring-audit/internal/event"
)

func TestWindowsJunctionIsExcludedFromDirectoryDiscovery(t *testing.T) {
	root, outside := t.TempDir(), t.TempDir()
	if err := os.WriteFile(filepath.Join(outside, "outside.bin"), []byte("private fixture"), 0600); err != nil {
		t.Fatal(err)
	}
	link := filepath.Join(root, "junction")
	command := exec.Command("cmd.exe", "/d", "/c", "mklink", "/J", link, outside)
	command.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	if output, err := command.CombinedOutput(); err != nil {
		t.Skipf("junction creation unavailable: %v %s", err, output)
	}
	// Remove only the junction itself before TempDir cleanup, never its target.
	defer func() {
		if err := os.Remove(link); err != nil {
			t.Error(err)
		}
	}()
	var events []event.Event
	f, err := newFileCollector("s", []string{root}, func(e event.Event) error { events = append(events, e); return nil })
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	if err := f.addTree(context.Background(), f.roots[0], ".", true); err != nil {
		t.Fatal(err)
	}
	if len(events) != 1 || events[0].Kind != "path_excluded" || events[0].Detail["path"] != link || len(f.directories) != 1 || len(f.watch.WatchList()) != 1 {
		t.Fatal("junction traversed or exclusion missing")
	}
	if _, err := os.Stat(filepath.Join(outside, "outside.bin")); err != nil {
		t.Fatal("outside fixture modified", err)
	}
}
