package collect

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"os"
	"testing"
)

func TestCollectorOutputLimitCannotBeBypassedByCopy(t *testing.T) {
	var output collectorOutput
	_, err := io.Copy(&output, io.LimitReader(bytes.NewReader(make([]byte, maxCollectorOutput+1)), maxCollectorOutput+1))
	if err == nil || output.buffer.Len() > maxCollectorOutput {
		t.Fatalf("output cap bypassed: %d %v", output.buffer.Len(), err)
	}
}

func TestBoundedCollectorCommand(t *testing.T) {
	if os.Getenv("BMA_COLLECTOR_OUTPUT_HELPER") == "1" {
		fmt.Fprint(os.Stdout, "scoped result")
		return
	}
	t.Setenv("BMA_COLLECTOR_OUTPUT_HELPER", "1")
	out, err := boundedCommandOutput(context.Background(), os.Args[0], "-test.run=^TestBoundedCollectorCommand$")
	if err != nil || !bytes.Contains(out, []byte("scoped result")) {
		t.Fatalf("%q %v", out, err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if out, err := boundedCommandOutput(ctx, os.Args[0], "-test.run=^TestBoundedCollectorCommand$"); err == nil || out != nil {
		t.Fatal("canceled collection returned output")
	}
}
