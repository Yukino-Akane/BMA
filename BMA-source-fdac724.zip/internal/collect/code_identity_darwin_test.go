//go:build darwin

package collect

import (
	"bufio"
	"context"
	"os/exec"
	"strconv"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
	"github.com/shirou/gopsutil/v4/process"
)

func TestLiveRootCodeIdentity(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, "/bin/sleep", "30")
	if err := cmd.Start(); err != nil {
		t.Fatal(err)
	}
	defer func() { _ = cmd.Process.Kill(); _ = cmd.Wait() }()
	// Only metadata of a synthetic process is inspected.
	output, err := exec.CommandContext(ctx, "/usr/bin/codesign", "-d", "--verbose=4", "/bin/sleep").CombinedOutput()
	if err != nil {
		t.Fatal(err)
	}
	identity := CodeIdentity{}
	for _, line := range strings.Split(string(output), "\n") {
		key, value, _ := strings.Cut(line, "=")
		switch key {
		case "Identifier":
			identity.Identifier, identity.BundleID = value, value
		case "CDHash":
			identity.CDHash = value
		case "TeamIdentifier":
			if value != "not set" {
				identity.TeamID = value
			}
		}
	}
	if err := verifyCodeIdentity(ctx, cmd.Process.Pid, identity); err != nil {
		t.Fatalf("valid live code rejected: %v", err)
	}
	p, _ := process.NewProcess(int32(cmd.Process.Pid))
	created, err := p.CreateTimeWithContext(ctx)
	if err != nil {
		t.Fatal(err)
	}
	w := &Watcher{RootProcesses: map[int]int64{cmd.Process.Pid: created}}
	if err := w.SetRootCodeIdentities(map[int]CodeIdentity{cmd.Process.Pid: identity}); err != nil {
		t.Fatal(err)
	}
	proc := event.Process{PID: cmd.Process.Pid, CreatedAtMS: created}
	records := map[int]processSnapshot{cmd.Process.Pid: {identity: proc}}
	roots, failures := w.verifiedRoots(ctx, records)
	if len(roots) != 1 || len(failures) != 0 {
		t.Fatalf("valid root rejected: %v", failures)
	}
	if err := w.verifyScopeIdentity(ctx, records, proc); err != nil {
		t.Fatal(err)
	}
	identity.CDHash = strings.Repeat("0", 40)
	w.RootCode[cmd.Process.Pid] = identity
	roots, failures = w.verifiedRoots(ctx, records)
	if len(roots) != 0 || len(failures) != 1 {
		t.Fatal("incorrect signature authorized root")
	}
	if err := w.verifyScopeIdentity(ctx, records, proc); err == nil {
		t.Fatal("post-sample/proxy verification accepted wrong signature")
	}
	identity.Identifier = `x" or always or identifier "x`
	if _, err := codeIdentityRequirement(identity); err == nil {
		t.Fatal("accepted requirement injection")
	}
}

func TestRootCodeRejectsExecWithinSameProcessInstance(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, "/bin/sh", "-c", "printf 'ready\\n'; read line; exec /bin/sleep 30")
	input, err := cmd.StdinPipe()
	if err != nil {
		t.Fatal(err)
	}
	output, err := cmd.StdoutPipe()
	if err != nil {
		t.Fatal(err)
	}
	if err := cmd.Start(); err != nil {
		t.Fatal(err)
	}
	defer func() { _ = cmd.Process.Kill(); _ = cmd.Wait() }()
	if _, err := bufio.NewReader(output).ReadString('\n'); err != nil {
		t.Fatal(err)
	}
	signature, err := exec.CommandContext(ctx, "/usr/bin/codesign", "-d", "--verbose=4", strconv.Itoa(cmd.Process.Pid)).CombinedOutput()
	if err != nil {
		t.Fatal(err)
	}
	identity := CodeIdentity{}
	for _, line := range strings.Split(string(signature), "\n") {
		key, value, _ := strings.Cut(line, "=")
		if key == "Identifier" {
			identity.BundleID = value
			identity.Identifier = value
		}
		if key == "CDHash" {
			identity.CDHash = value
		}
	}
	proc, err := process.NewProcess(int32(cmd.Process.Pid))
	if err != nil {
		t.Fatal(err)
	}
	created, err := proc.CreateTimeWithContext(ctx)
	if err != nil {
		t.Fatal(err)
	}
	expected := event.Process{PID: cmd.Process.Pid, CreatedAtMS: created}
	if err := verifyCodeIdentity(ctx, cmd.Process.Pid, identity); err != nil {
		t.Fatal(err)
	}
	if _, err := input.Write([]byte("go\n")); err != nil {
		t.Fatal(err)
	}
	for verifyCodeIdentity(ctx, cmd.Process.Pid, identity) == nil {
		select {
		case <-ctx.Done():
			t.Fatal("exec did not invalidate original code identity")
		case <-time.After(10 * time.Millisecond):
		}
	}
	if err := verifyProcessIdentity(ctx, expected); err != nil {
		t.Fatalf("fixture did not preserve process instance: %v", err)
	}
}
