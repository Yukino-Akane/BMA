package collect

import (
	"context"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/report"
)

func TestProxyCountsLiveTunnelAndFlushesTailExactlyOnce(t *testing.T) {
	backend, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer backend.Close()
	go func() {
		c, err := backend.Accept()
		if err != nil {
			return
		}
		defer c.Close()
		io.Copy(c, c)
	}()
	events := make(chan event.Event, 32)
	p, listener, err := StartProxy("s", 0, "", 20*time.Millisecond, func(e event.Event) error { events <- e; return nil }, func(context.Context, net.Addr, net.Addr) (event.Process, error) {
		return event.Process{PID: 42, CreatedAtMS: 100}, nil
	})
	if err != nil {
		t.Fatal(err)
	}
	defer p.Close()
	client := connectFixture(t, listener, backend.Addr().String())
	if status, err := readProxyHeaders(client); err != nil || !strings.Contains(status, "200") {
		t.Fatalf("CONNECT: %q %v", status, err)
	}
	client.Write([]byte("hello"))
	if _, err := io.ReadFull(client, make([]byte, 5)); err != nil {
		t.Fatal(err)
	}
	var rows []event.Event
	var out, in uint64
	deadline := time.After(5 * time.Second)
	for out != 5 || in != 5 {
		select {
		case e := <-events:
			rows = append(rows, e)
			if e.Kind == "connection_closed" || e.Kind == "connection_failed" {
				t.Fatal("connection closed before live count")
			}
			if e.Kind == "egress" {
				out += e.Detail["bytes_out"].(uint64)
				in += e.Detail["bytes_in"].(uint64)
			}
			if out > 5 || in > 5 {
				t.Fatal("live bytes counted twice")
			}
		case <-deadline:
			t.Fatal("active tunnel bytes were not recorded")
		}
	}
	live := report.New("s", "w", nil, rows).NetworkMetrics()
	if len(live) != 1 || live[0].BytesOut != 5 || live[0].BytesIn != 5 {
		t.Fatalf("live report missing transfer: %+v", live)
	}
	select {
	case e := <-events:
		t.Fatalf("idle connection produced repeated events: %+v", e)
	case <-time.After(80 * time.Millisecond):
	}
	client.Write([]byte("tail"))
	if _, err := io.ReadFull(client, make([]byte, 4)); err != nil {
		t.Fatal(err)
	}
	if err := p.Close(); err != nil {
		t.Fatal(err)
	}
	rows = append(rows, proxyTerminalEvents(t, events)...)
	metrics := report.New("s", "w", nil, rows).NetworkMetrics()
	if len(metrics) != 1 || metrics[0].BytesOut != 9 || metrics[0].BytesIn != 9 {
		t.Fatalf("tail lost or lifetime total double counted: %+v", metrics)
	}
	for _, e := range rows {
		if e.Kind == "egress" {
			a, errA := time.Parse(time.RFC3339Nano, e.Detail["sample_start"].(string))
			b, errB := time.Parse(time.RFC3339Nano, e.Detail["sample_end"].(string))
			if errA != nil || errB != nil || a.After(b) || b.After(e.TS) {
				t.Fatal("invalid measurement interval")
			}
		}
	}
}

type pausedWriteConn struct {
	net.Conn
	entered, release chan struct{}
}

func (c *pausedWriteConn) Write(data []byte) (int, error) {
	close(c.entered)
	<-c.release
	return c.Conn.Write(data)
}

func TestProxyBlockedWriteRetainsStartBeforeSamplingBoundary(t *testing.T) {
	writer, reader := net.Pipe()
	defer writer.Close()
	defer reader.Close()
	entered, release := make(chan struct{}), make(chan struct{})
	conn := &pausedWriteConn{Conn: writer, entered: entered, release: release}
	events := make(chan event.Event, 2)
	transfer := &proxyTransfer{proxy: &Proxy{session: "s", emit: func(e event.Event) error { events <- e; return nil }}, periodStart: time.Now()}
	done := make(chan error, 1)
	go func() {
		_, err := (&proxyWriter{conn: conn, transfer: transfer, outbound: true}).Write([]byte("hello"))
		done <- err
	}()
	<-entered
	// Hold the write across a clock tick before the sampling boundary.
	time.Sleep(20 * time.Millisecond)
	transfer.flush(false)
	boundary := transfer.periodStart
	go io.Copy(io.Discard, reader)
	close(release)
	select {
	case err := <-done:
		if err != nil {
			t.Fatal(err)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("blocked write did not finish")
	}
	transfer.flush(true)
	e := <-events
	start, err := time.Parse(time.RFC3339Nano, e.Detail["sample_start"].(string))
	if err != nil || !start.Before(boundary) || e.Detail["bytes_out"] != uint64(5) {
		t.Fatalf("blocked write assigned to newer interval: %+v", e.Detail)
	}
}

func TestProxyHTTPResponseAppearsBeforeStreamCompletes(t *testing.T) {
	release := make(chan struct{})
	backend := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		io.WriteString(w, "first")
		w.(http.Flusher).Flush()
		<-release
		io.WriteString(w, "last")
	}))
	defer backend.Close()
	defer close(release)
	events := make(chan event.Event, 32)
	p, listener, err := StartProxy("s", 0, "", 20*time.Millisecond, func(e event.Event) error { events <- e; return nil }, func(context.Context, net.Addr, net.Addr) (event.Process, error) {
		return event.Process{PID: 42, CreatedAtMS: 100}, nil
	})
	if err != nil {
		t.Fatal(err)
	}
	defer p.Close()
	proxyURL, _ := url.Parse("http://" + listener.Addr().String())
	transport := &http.Transport{Proxy: http.ProxyURL(proxyURL)}
	defer transport.CloseIdleConnections()
	client := &http.Client{Transport: transport, Timeout: 5 * time.Second}
	res, err := client.Get(backend.URL)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Body.Close()
	if _, err := io.ReadFull(res.Body, make([]byte, 5)); err != nil {
		t.Fatal(err)
	}
	deadline := time.After(5 * time.Second)
	for {
		select {
		case e := <-events:
			if e.Kind == "connection_closed" || e.Kind == "connection_failed" {
				t.Fatal("HTTP stream finished before measurement")
			}
			if e.Kind == "egress" && e.Detail["bytes_in"].(uint64) >= 5 {
				return
			}
		case <-deadline:
			t.Fatal("HTTP response was invisible until connection close")
		}
	}
}
