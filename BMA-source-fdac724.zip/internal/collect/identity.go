package collect

import (
	"context"
	"fmt"

	"behavior-monitoring-audit/internal/event"
	"github.com/shirou/gopsutil/v4/process"
)

func identityKey(p event.Process) string {
	return fmt.Sprintf("%d/%d", p.PID, p.CreatedAtMS)
}

// Use a fresh gopsutil Process: CreateTime is cached on each Process object.
// Bracketing a sample narrows PID reuse races; it is not an atomic OS snapshot.
func verifyProcessIdentity(ctx context.Context, expected event.Process) error {
	p, err := process.NewProcessWithContext(ctx, int32(expected.PID))
	if err != nil {
		return err
	}
	created, err := p.CreateTimeWithContext(ctx)
	if err != nil {
		return err
	}
	if created <= 0 || created != expected.CreatedAtMS {
		return fmt.Errorf("process start time changed while collecting evidence")
	}
	return nil
}

func (w *Watcher) sampleStatus(proc event.Process, source string, err error) []event.Event {
	return w.observeHealth(proc, source, err)
}
