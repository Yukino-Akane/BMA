package collect

import (
	"bufio"
	"context"
	"fmt"
	"io"
	"net"
	"os"
	"strconv"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
)

func TestProxyCountsExplicitCONNECTTraffic(t *testing.T) {
	backend, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer backend.Close()
	go func() {
		conn, err := backend.Accept()
		if err != nil {
			return
		}
		defer conn.Close()
		buf := make([]byte, 5)
		_, _ = io.ReadFull(conn, buf)
		_, _ = conn.Write([]byte("world"))
	}()
	events := make(chan event.Event, 4)
	watcher, err := NewWatcher("s", t.TempDir(), nil, []string{strconv.Itoa(os.Getpid())}, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	proxy, listener, err := StartProxy("s", 0, "", time.Minute, func(e event.Event) error { events <- e; return nil }, watcher.ResolveProxyPeer)
	if err != nil {
		t.Fatal(err)
	}
	defer proxy.Close()
	client, err := net.Dial("tcp", listener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	if _, err := fmt.Fprintf(client, "CONNECT %s HTTP/1.1\r\nHost: %s\r\n\r\n", backend.Addr(), backend.Addr()); err != nil {
		t.Fatal(err)
	}
	status, err := readProxyHeaders(client)
	if err != nil || !strings.Contains(status, "200 Connection Established") {
		t.Fatalf("proxy response=%q err=%v", status, err)
	}
	if _, err := client.Write([]byte("hello")); err != nil {
		t.Fatal(err)
	}
	data := make([]byte, 5)
	if _, err := io.ReadFull(client, data); err != nil || string(data) != "world" {
		t.Fatalf("backend response=%q err=%v", data, err)
	}
	_ = client.Close()
	deadline := time.After(2 * time.Second)
	for {
		select {
		case e := <-events:
			if e.Kind != "egress" {
				continue
			}
			if e.Detail["host_source"] != "proxy_request" || e.Detail["remote_host"] != backend.Addr().String() {
				t.Fatalf("proxy lost destination provenance: %+v", e.Detail)
			}
			if e.Kind != "egress" || e.Process.PID != os.Getpid() || e.Attribution != "direct" || e.Detail["proxy"] != true || e.Detail["bytes_out"].(uint64) != 5 || e.Detail["bytes_in"].(uint64) != 5 {
				t.Fatalf("bad proxy event: %#v", e)
			}
			return
		case <-deadline:
			t.Fatal("missing proxy event")
		}
	}
}

func TestProxyRejectsUnselectedProcessBeforeForwarding(t *testing.T) {
	w, err := NewWatcher("s", t.TempDir(), nil, []string{"bma-test-not-running"}, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	p, listener, err := StartProxy("s", 0, "", time.Minute, func(event.Event) error { return nil }, w.ResolveProxyPeer)
	if err != nil {
		t.Fatal(err)
	}
	defer p.Close()
	conn, err := net.Dial("tcp", listener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(5 * time.Second))
	fmt.Fprint(conn, "CONNECT 127.0.0.1:9 HTTP/1.1\r\nHost: 127.0.0.1:9\r\n\r\n")
	status, err := readProxyHeaders(conn)
	if err != nil || !strings.Contains(status, "403") {
		t.Fatalf("expected selected-process rejection: %q %v", status, err)
	}
}

func TestProxyShutdownFlushesInFlightBytes(t *testing.T) {
	backend, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer backend.Close()
	received := make(chan struct{})
	go func() {
		c, err := backend.Accept()
		if err != nil {
			return
		}
		defer c.Close()
		buf := make([]byte, 5)
		io.ReadFull(c, buf)
		close(received)
		io.Copy(io.Discard, c)
	}()
	events := make(chan event.Event, 8)
	p, listener, err := StartProxy("s", 0, "", time.Minute, func(e event.Event) error { events <- e; return nil }, func(context.Context, net.Addr, net.Addr) (event.Process, error) {
		return event.Process{PID: 42, Name: "fixture", CreatedAtMS: 1}, nil
	})
	if err != nil {
		t.Fatal(err)
	}
	defer p.Close()
	client, err := net.Dial("tcp", listener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer client.Close()
	fmt.Fprintf(client, "CONNECT %s HTTP/1.1\r\nHost: %s\r\n\r\n", backend.Addr(), backend.Addr())
	if _, err := readProxyHeaders(client); err != nil {
		t.Fatal(err)
	}
	client.Write([]byte("hello"))
	select {
	case <-received:
	case <-time.After(3 * time.Second):
		t.Fatal("no upstream data")
	}
	closed := make(chan error, 1)
	go func() { closed <- p.Close() }()
	select {
	case err := <-closed:
		if err != nil {
			t.Fatal(err)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("proxy shutdown leaked active tunnel")
	}
	for {
		select {
		case e := <-events:
			if e.Kind != "egress" {
				continue
			}
			if e.Detail["bytes_out"] != uint64(5) {
				t.Fatalf("lost final bytes: %v", e.Detail)
			}
			return
		default:
			t.Fatal("shutdown returned before evidence was written")
		}
	}
}

func readProxyHeaders(conn io.Reader) (string, error) {
	reader, ok := conn.(*bufio.Reader)
	if !ok {
		reader = bufio.NewReader(conn)
	}
	var lines []string
	for {
		line, err := reader.ReadString('\n')
		if err != nil {
			return "", err
		}
		lines = append(lines, line)
		if line == "\r\n" {
			return strings.Join(lines, ""), nil
		}
	}
}
