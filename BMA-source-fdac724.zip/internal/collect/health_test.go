package collect

import (
	"context"
	"errors"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
)

func TestCollectorHealthTransitionAndSummary(t *testing.T) {
	h := CollectorHealth{}
	proc := event.Process{PID: 7, CreatedAtMS: 70}
	h.begin()
	if got := h.observe("s", proc, "network", healthFailed, "sample_failed"); len(got) != 1 || got[0].Kind != "collector_error" {
		t.Fatalf("failure transition: %+v", got)
	}
	if got := h.observe("s", proc, "network", healthFailed, "sample_failed"); len(got) != 0 {
		t.Fatalf("repeated failure: %+v", got)
	}
	h.finish("s", time.Now().UTC(), 2*time.Second, 1, 1, 0)
	h.begin()
	if got := h.observe("s", proc, "network", healthOK, "sample_succeeded"); len(got) != 1 || got[0].Kind != "collector_recovered" {
		t.Fatalf("recovery transition: %+v", got)
	}
	sample := h.finish("s", time.Now().UTC(), 2*time.Second, 1, 1, 0)
	if sample.Kind != "collector_sample" || sample.Detail["interval_sec"] != float64(2) {
		t.Fatalf("sample summary: %+v", sample)
	}
}

func TestDarwinIOCapabilityIsUnsupported(t *testing.T) {
	state, reason := collectorErrorState(errCollectorUnsupported)
	if state != healthUnsupported || reason != "platform_unsupported" {
		t.Fatalf("unexpected status: %s %s", state, reason)
	}
}

func TestUnverifiableRootCodeIsReportedAsFailure(t *testing.T) {
	w := &Watcher{SessionID: "s", RootProcesses: map[int]int64{123: 456}, health: CollectorHealth{}}
	w.health.begin()
	identity := CodeIdentity{BundleID: "com.example.app", Identifier: "com.example.app", TeamID: "TEAM123", CDHash: "0123456789abcdef"}
	w.RootCode = map[int]CodeIdentity{123: identity}
	events := w.rootHealth(context.Background(), nil, map[int]error{123: errors.New("signature unavailable")})
	if len(events) != 1 || events[0].Kind != "collector_error" || events[0].Detail["source"] != "process_scope" {
		t.Fatalf("unverified selected root was not disclosed: %+v", events)
	}
}

func TestHealthClassificationAndSuccessfulSampleClock(t *testing.T) {
	h := CollectorHealth{}
	p := event.Process{PID: 9, CreatedAtMS: 90}
	at := time.Date(2026, 9, 23, 1, 0, 0, 0, time.UTC)
	for _, tc := range []struct {
		state healthState
		kind  string
	}{
		{healthUnsupported, "collector_status"}, {healthIdle, "collector_status"},
		{healthExited, "collector_status"}, {healthFailed, "collector_error"}, {healthOK, "collector_recovered"},
	} {
		h.begin()
		events := h.observe("s", p, "source", tc.state, "fixture")
		if len(events) != 1 || events[0].Kind != tc.kind {
			t.Fatalf("%s: %+v", tc.state, events)
		}
		sample := h.finish("s", at, time.Second, 1, 1, 0)
		if sample.Detail["health"].(map[string]int)[string(tc.state)] != 1 {
			t.Fatal("missing current state")
		}
		if tc.state == healthFailed && h.lastSuccess.Equal(at) {
			t.Fatal("failed sample advanced successful time")
		}
		at = at.Add(time.Second)
	}
	successful := h.lastSuccess
	h.begin()
	h.observe("s", event.Process{Name: "collector"}, "process_selection", healthIdle, "none")
	h.finish("s", at, time.Second, 0, 1, 0)
	if !h.lastSuccess.Equal(successful) {
		t.Fatal("empty scope presented as successful process sampling")
	}
	if len(h.previous) != 1 {
		t.Fatal("inactive process state leaked")
	}
}
