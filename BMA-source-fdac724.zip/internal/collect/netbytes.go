package collect

import (
	"time"

	"behavior-monitoring-audit/internal/event"
)

type NetworkSample struct {
	PID      int
	Process  string
	BytesIn  uint64
	BytesOut uint64
}

type networkCounter struct {
	In, Out uint64
	At      time.Time
}

// networkEvents accepts only process identities rechecked after sampling.
// Missing samples and command failures clear the baseline so a later delta
// cannot put traffic from an unknown interval into the current rule window.
func (w *Watcher) networkEvents(selected map[int]event.Process, samples []NetworkSample, sampleErr error, at time.Time) []event.Event {
	next := map[string]networkCounter{}
	result := []event.Event{}
	failed := func(proc event.Process, reason string) {
		result = append(result, w.health.observe(w.SessionID, proc, "network_bytes", healthFailed, reason)...)
	}
	counts := map[int]int{}
	byPID := map[int]NetworkSample{}
	for _, sample := range samples {
		if _, ok := selected[sample.PID]; !ok {
			continue
		}
		counts[sample.PID]++
		byPID[sample.PID] = sample
	}
	for pid, proc := range selected {
		key := identityKey(proc)
		if sampleErr != nil {
			failed(proc, "sample_failed")
			continue
		}
		if proc.CreatedAtMS <= 0 {
			failed(proc, "identity_unverified")
			continue
		}
		if counts[pid] == 0 {
			// nettop omits processes with no network activity. This is an idle
			// observation; clear the baseline so future traffic cannot bridge it.
			result = append(result, w.observeHealth(proc, "network_bytes", errNoNetworkActivity)...)
			continue
		}
		if counts[pid] != 1 {
			failed(proc, "sample_missing_or_ambiguous")
			continue
		}
		sample := byPID[pid]
		current := networkCounter{In: sample.BytesIn, Out: sample.BytesOut, At: at}
		previous, exists := w.lastNetwork[key]
		next[key] = current
		if !exists {
			result = append(result, w.observeHealth(proc, "network_bytes", nil)...)
			result = append(result, event.New(w.SessionID, "net", proc, "network_baseline", "direct", map[string]any{"source": "nettop", "reason": "first_valid_sample", "sample_at": at.Format(time.RFC3339Nano)}))
			continue
		}
		if !at.After(previous.At) || current.In < previous.In || current.Out < previous.Out {
			failed(proc, "counter_reset_or_invalid_interval")
			continue
		}
		result = append(result, w.observeHealth(proc, "network_bytes", nil)...)
		in, out := current.In-previous.In, current.Out-previous.Out
		if in == 0 && out == 0 {
			continue
		}
		e := event.New(w.SessionID, "net", proc, "egress", "direct", map[string]any{"bytes_in": in, "bytes_out": out, "metric": "network_bytes", "direction": "aggregate", "source": "nettop", "sample_start": previous.At.Format(time.RFC3339Nano), "sample_end": at.Format(time.RFC3339Nano), "window_sec": at.Sub(previous.At).Seconds()})
		e.TS = at
		result = append(result, e)
	}
	w.lastNetwork = next
	return result
}
