package collect

import (
	"behavior-monitoring-audit/internal/event"
	"context"
	"testing"
	"time"
)

func TestProcessOnlyHasNoImplicitFileScope(t *testing.T) {
	w, err := NewWatcher("s", "", nil, []string{"bma-missing-fixture"}, time.Millisecond*10)
	if err != nil {
		t.Fatal(err)
	}
	if w.Workspace != "" || len(w.Roots) != 0 {
		t.Fatal("unexpected implicit workspace")
	}
	var events []event.Event
	w.Emit = func(e event.Event) error { events = append(events, e); return nil }
	ctx, cancel := context.WithTimeout(context.Background(), time.Millisecond*100)
	defer cancel()
	if err = w.Run(ctx); err != nil {
		t.Fatal(err)
	}
	for _, e := range events {
		if e.Layer == "file" {
			t.Fatalf("unexpected file collection: %+v", e)
		}
	}
	root := t.TempDir()
	w, err = NewWatcher("s", "", []string{root}, []string{"fixture"}, time.Second)
	if err != nil || len(w.Roots) != 1 {
		t.Fatalf("explicit watch-dir failed: %v", err)
	}
}
