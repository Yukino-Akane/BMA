//go:build !darwin

package collect

import "context"

const networkBytesAvailable = false

func sampleNetworkBytes(ctx context.Context, pids map[int]bool) ([]NetworkSample, error) {
	return nil, nil
}
