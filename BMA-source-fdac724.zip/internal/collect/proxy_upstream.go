package collect

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"time"
)

var errUpstreamRejected = errors.New("upstream rejected CONNECT")
var errUpstreamResponse = errors.New("invalid upstream CONNECT response")

// This option connects to an existing local HTTP proxy. No environment proxy
// discovery, credentials or system configuration changes are involved.
func parseProxyUpstream(raw string) (string, error) {
	if raw == "" {
		return "", nil
	}
	u, err := url.Parse(raw)
	if err != nil || u.Scheme != "http" || u.User != nil || u.Host == "" || u.Path != "" || u.RawQuery != "" || u.ForceQuery || u.Fragment != "" || u.Opaque != "" || !validHostPort(u.Host) {
		return "", fmt.Errorf("proxy upstream must be http://LOOPBACK_IP:PORT without credentials, path, query or fragment")
	}
	ip := net.ParseIP(u.Hostname())
	if ip == nil || !ip.IsLoopback() {
		return "", fmt.Errorf("proxy upstream must use a literal loopback IP")
	}
	port, _ := strconv.Atoi(u.Port()) // validHostPort checked the range above.
	return net.JoinHostPort(ip.String(), strconv.Itoa(port)), nil
}

// Use CONNECT for both HTTP and HTTPS destinations. Target DNS resolution and
// routing stay with the existing proxy; a failed handshake never dials directly.
// The proxy negotiation is excluded from target payload byte counts.
func (p *Proxy) dialUpstream(host string) (_ net.Conn, err error) {
	conn, err := p.dialSocket(p.upstream)
	if err != nil {
		return nil, err
	}
	defer func() {
		if err != nil {
			conn.Close()
			p.forget(conn)
		}
	}()
	if err = conn.SetDeadline(time.Now().Add(15 * time.Second)); err != nil {
		return nil, err
	}
	req := &http.Request{Method: http.MethodConnect, URL: &url.URL{Opaque: host}, Host: host, Header: make(http.Header)}
	if err = req.Write(conn); err != nil {
		return nil, err
	}
	limited := &io.LimitedReader{R: conn, N: 64 * 1024}
	reader := bufio.NewReader(limited)
	response, readErr := http.ReadResponse(reader, req)
	if readErr != nil {
		var network net.Error
		if errors.As(readErr, &network) && network.Timeout() {
			return nil, readErr
		}
		return nil, errUpstreamResponse
	}
	if response.StatusCode != http.StatusOK {
		return nil, errUpstreamRejected
	}
	// Do not read or close response.Body: after 200 the stream is the tunnel.
	limited.N = 1<<63 - 1
	if err = conn.SetDeadline(time.Time{}); err != nil {
		return nil, err
	}
	return &proxyBufferedConn{Conn: conn, reader: reader}, nil
}

// ReadResponse can prefetch initial tunnel bytes with the response headers.
// Preserve them and the TCP half-close used by bidirectional streaming.
type proxyBufferedConn struct {
	net.Conn
	reader *bufio.Reader
}

func (c *proxyBufferedConn) Read(p []byte) (int, error) { return c.reader.Read(p) }
func (c *proxyBufferedConn) CloseWrite() error {
	return c.Conn.(*net.TCPConn).CloseWrite()
}

func (p *Proxy) routeDetail(detail map[string]any) map[string]any {
	if p.upstream != "" {
		detail["transport_route"] = "upstream_connect"
		detail["upstream_proxy"] = p.upstream
	}
	return detail
}
