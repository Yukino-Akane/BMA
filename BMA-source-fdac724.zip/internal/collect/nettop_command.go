package collect

import (
	"context"
	"fmt"
	"sort"
	"strconv"
)

// macOS nettop rejects more than 20 repeated -p options with exit status 64.
const maxNettopPIDs = 20

func sampleNettopBatches(ctx context.Context, pids map[int]bool, run func(context.Context, string, ...string) ([]byte, error)) ([]NetworkSample, error) {
	args, err := nettopArguments(pids)
	if err != nil {
		return nil, err
	}
	const prefix = 7
	var result []NetworkSample
	for start := prefix; start < len(args); start += 2 * maxNettopPIDs {
		end := min(start+2*maxNettopPIDs, len(args))
		batchArgs := append(append([]string{}, args[:prefix]...), args[start:end]...)
		batch := make(map[int]bool)
		for i := start + 1; i < end; i += 2 {
			pid, _ := strconv.Atoi(args[i])
			batch[pid] = true
		}
		output, err := run(ctx, "/usr/bin/nettop", batchArgs...)
		if err != nil {
			return nil, err // Partial batches must not advance any counter baseline.
		}
		samples, err := ParseNettop(string(output), batch)
		if err != nil {
			return nil, err
		}
		result = append(result, samples...)
	}
	return result, nil
}

// Never run nettop without explicit PID filters: its default is all processes.
// -n also prevents name resolution without the separate reverse-DNS opt-in.
func nettopArguments(pids map[int]bool) ([]string, error) {
	var selected []int
	for pid, enabled := range pids {
		if !enabled {
			continue
		}
		if pid <= 0 {
			return nil, fmt.Errorf("nettop requires positive selected PIDs")
		}
		selected = append(selected, pid)
	}
	if len(selected) == 0 {
		return nil, fmt.Errorf("nettop requires selected PIDs")
	}
	sort.Ints(selected)
	args := []string{"-n", "-P", "-x", "-L", "1", "-J", "bytes_in,bytes_out"}
	for _, pid := range selected {
		args = append(args, "-p", strconv.Itoa(pid))
	}
	return args, nil
}
