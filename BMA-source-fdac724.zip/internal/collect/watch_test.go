package collect

import (
	"bufio"
	"context"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
)

func TestWatchProcessLifecycle(t *testing.T) {
	if os.Getenv("BMA_PROCESS_LIFECYCLE_HELPER") == "1" {
		fmt.Fprintln(os.Stdout, "ready")
		io.Copy(io.Discard, os.Stdin)
		os.Exit(0)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestWatchProcessLifecycle$")
	cmd.Env = append(os.Environ(), "BMA_PROCESS_LIFECYCLE_HELPER=1")
	stdin, err := cmd.StdinPipe()
	if err != nil {
		t.Fatal(err)
	}
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		t.Fatal(err)
	}
	if err := cmd.Start(); err != nil {
		t.Fatal(err)
	}
	defer cmd.Process.Kill()
	defer cmd.Wait()
	if line, err := bufio.NewReader(stdout).ReadString('\n'); err != nil || strings.TrimSpace(line) != "ready" {
		t.Fatalf("helper: %q %v", line, err)
	}
	w, err := NewWatcher("s", t.TempDir(), nil, []string{strconv.Itoa(cmd.Process.Pid)}, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	var observed event.Process
	for _, e := range w.sample(ctx) {
		if e.Kind == "process_observed" {
			observed = e.Process
		}
	}
	if observed.PID != cmd.Process.Pid || observed.CreatedAtMS <= 0 {
		t.Fatalf("process identity not captured: %+v", observed)
	}
	stdin.Close()
	if err := cmd.Wait(); err != nil {
		t.Fatal(err)
	}
	stopped, gap := false, false
	for _, e := range w.sample(ctx) {
		if e.Kind == "process_no_longer_observed" {
			stopped = e.Process == observed
		}
		if e.Kind == "collector_status" && e.Detail["source"] == "process_selection" {
			gap = true
		}
	}
	if !stopped || !gap || len(w.processInfo) != 0 || len(w.lastNetwork) != 0 {
		t.Fatalf("process exit not disclosed/cleared: stopped=%v gap=%v", stopped, gap)
	}
}

func TestLiveFileCapture(t *testing.T) {
	root := t.TempDir()
	w, err := NewWatcher("s", root, nil, []string{"bma-test-no-matching-process"}, 20*time.Millisecond)
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	var mu sync.Mutex
	events := []event.Event{}
	created := make(chan struct{}, 1)
	deleted := make(chan struct{}, 1)
	w.Emit = func(e event.Event) error {
		mu.Lock()
		events = append(events, e)
		mu.Unlock()
		if e.Kind == "file_create" {
			select {
			case created <- struct{}{}:
			default:
			}
		}
		if e.Kind == "file_delete" {
			select {
			case deleted <- struct{}{}:
			default:
			}
		}
		return nil
	}
	done := make(chan error, 1)
	go func() { done <- w.Run(ctx) }()
	// Repeated unique creations avoid a timing assumption about watcher startup.
	ticker := time.NewTicker(100 * time.Millisecond)
	defer ticker.Stop()
	var file string
	for count := 0; ; count++ {
		select {
		case <-ticker.C:
			f, err := os.CreateTemp(root, "observed-*.zip")
			if err != nil {
				t.Fatal(err)
			}
			file = f.Name()
			f.Close()
		case <-created:
			goto captured
		case err := <-done:
			t.Fatalf("watcher stopped before creation: %v", err)
		case <-ctx.Done():
			t.Fatal("creation capture timed out")
		}
	}
captured:
	if err := os.Remove(file); err != nil {
		t.Fatal(err)
	}
	select {
	case <-deleted:
	case <-ctx.Done():
		t.Fatal("deletion capture timed out")
	}
	cancel()
	if err := <-done; err != nil {
		t.Fatal(err)
	}
	mu.Lock()
	defer mu.Unlock()
	found := false
	for _, e := range events {
		if strings.HasPrefix(e.Kind, "file_") && (e.Attribution != "temporal" || e.Process.PID != 0) {
			t.Fatal("filesystem event invented process attribution")
		}
		if e.Kind == "file_delete" && e.Detail["created_event_id"] != "" {
			found = true
		}
	}
	if !found {
		t.Fatal("missing file lifetime evidence")
	}
}

func TestFileEntropyAndRenameSemantics(t *testing.T) {
	root := t.TempDir()
	p := filepath.Join(root, "artifact.bin")
	data := make([]byte, 16384)
	for i := range data {
		data[i] = byte(i)
	}
	if err := os.WriteFile(p, data, 0600); err != nil {
		t.Fatal(err)
	}
	f, err := newFileCollector("s", []string{root}, func(event.Event) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	info, err := os.Stat(p)
	if err != nil {
		t.Fatal(err)
	}
	e := f.fileEvent(f.roots[0], "artifact.bin", "file_create", info)
	if e.Detail["entropy"].(float64) != 8 || e.Detail["size_bytes"].(int64) != 16384 {
		t.Fatalf("bad metadata: %+v", e.Detail)
	}
	rename := f.fileEvent(f.roots[0], "artifact.bin", "file_rename_from", nil)
	if rename.Kind != "file_rename_from" {
		t.Fatal("rename cannot prove deletion")
	}
}
