package collect

import (
	"context"
	"errors"
	"syscall"
	"time"

	"behavior-monitoring-audit/internal/event"
	"github.com/shirou/gopsutil/v4/process"
)

type healthState string

const (
	healthOK          healthState = "ok"
	healthUnsupported healthState = "unsupported"
	healthIdle        healthState = "idle"
	healthFailed      healthState = "failed"
	healthExited      healthState = "process_exited"
)

var errCollectorUnsupported = errors.New("collector unsupported on this platform")
var errNoNetworkActivity = errors.New("no_network_activity")

type healthObservation struct {
	State     healthState
	Reason    string
	Recovered bool
}

// CollectorHealth tracks process-instance/source transitions. Each sample
// publishes a bounded aggregate; inactive process/source state is discarded.
type CollectorHealth struct {
	previous    map[string]healthObservation
	current     map[string]healthObservation
	lastSuccess time.Time
}

func (h *CollectorHealth) begin() { h.current = make(map[string]healthObservation) }

func (h *CollectorHealth) observe(session string, proc event.Process, source string, state healthState, reason string) []event.Event {
	if h.previous == nil {
		h.previous = make(map[string]healthObservation)
	}
	if h.current == nil {
		h.begin()
	}
	key := identityKey(proc) + "/" + source
	previous, existed := h.previous[key]
	recovered := existed && previous.State == healthFailed && (state == healthOK || state == healthIdle)
	value := healthObservation{State: state, Reason: reason, Recovered: recovered}
	h.previous[key], h.current[key] = value, value
	if existed && previous.State == state && previous.Reason == reason {
		return nil
	}
	kind := "collector_status"
	if state == healthFailed {
		kind = "collector_error"
	} else if recovered {
		kind = "collector_recovered"
	} else if state == healthOK {
		return nil
	}
	detail := map[string]any{"source": source, "state": string(state), "reason": reason}
	if state == healthFailed {
		detail["coverage"] = "incomplete"
	}
	return []event.Event{event.New(session, "net", proc, kind, "direct", detail)}
}

func (h *CollectorHealth) forgetProcess(proc event.Process) {
	keyPrefix := identityKey(proc) + "/"
	for key := range h.current {
		if len(key) >= len(keyPrefix) && key[:len(keyPrefix)] == keyPrefix {
			delete(h.current, key)
			delete(h.previous, key)
		}
	}
}

func (h *CollectorHealth) finish(session string, at time.Time, interval time.Duration, covered, roots, children int) event.Event {
	counts := map[string]int{"ok": 0, "unsupported": 0, "idle": 0, "failed": 0, "process_exited": 0, "recovered": 0}
	for _, value := range h.current {
		counts[string(value.State)]++
		if value.Recovered {
			counts["recovered"]++
		}
	}
	// Unsupported capabilities are not failed attempts. Idle means sampling
	// succeeded with no visible activity, not evidence of zero network traffic.
	if covered > 0 && counts["failed"] == 0 {
		h.lastSuccess = at
	}
	detail := map[string]any{"health": counts, "interval_sec": interval.Seconds(), "covered_processes": covered, "scope_roots": roots, "scope_children": children}
	if !h.lastSuccess.IsZero() {
		detail["last_success_at"] = h.lastSuccess.Format(time.RFC3339Nano)
	}
	e := event.New(session, "net", event.Process{Name: "collector"}, "collector_sample", "direct", detail)
	e.TS = at
	h.previous = h.current
	return e
}

func collectorErrorState(err error) (healthState, string) {
	switch {
	case err == nil:
		return healthOK, "sample_succeeded"
	case errors.Is(err, errCollectorUnsupported):
		return healthUnsupported, "platform_unsupported"
	case errors.Is(err, errNoNetworkActivity):
		return healthIdle, "no_network_activity"
	case errors.Is(err, process.ErrorProcessNotRunning), errors.Is(err, syscall.ESRCH):
		return healthExited, "process_exited"
	default:
		return healthFailed, "sample_failed"
	}
}

func (w *Watcher) observeHealth(proc event.Process, source string, err error) []event.Event {
	state, reason := collectorErrorState(err)
	return w.health.observe(w.SessionID, proc, source, state, reason)
}

func (w *Watcher) verifiedRoots(ctx context.Context, records map[int]processSnapshot) (map[int]int64, map[int]error) {
	active := make(map[int]int64, len(w.RootProcesses))
	problems := make(map[int]error)
	for pid, created := range w.RootProcesses {
		record, ok := records[pid]
		if !ok || record.identity.CreatedAtMS != created {
			err := verifyProcessIdentity(ctx, event.Process{PID: pid, CreatedAtMS: created})
			if err == nil {
				err = errors.New("root metadata unavailable")
			}
			problems[pid] = err
			continue
		}
		if identity, exists := w.RootCode[pid]; exists {
			if identity.BundleID != "" && identity.BundleID != identity.Identifier {
				problems[pid] = errors.New("root bundle and signing identifiers differ")
				continue
			}
			if err := verifyCodeIdentity(ctx, pid, identity); err != nil {
				problems[pid] = err
				continue
			}
		}
		active[pid] = created
	}
	return active, problems
}

func (w *Watcher) rootHealth(ctx context.Context, selected map[int]event.Process, problems map[int]error) []event.Event {
	var out []event.Event
	for pid, created := range w.RootProcesses {
		proc := event.Process{PID: pid, CreatedAtMS: created}
		state, reason := healthOK, "root_identity_verified"
		if err := problems[pid]; err != nil {
			state, reason = collectorErrorState(err)
			if state != healthExited {
				state, reason = healthFailed, "root_code_identity_unverified"
			}
		} else if selected[pid].CreatedAtMS != created {
			err := verifyProcessIdentity(ctx, proc)
			state, reason = collectorErrorState(err)
			if state != healthExited {
				state, reason = healthFailed, "root_identity_or_ancestry_unverified"
			}
		}
		out = append(out, w.health.observe(w.SessionID, proc, "process_scope", state, reason)...)
	}
	return out
}
