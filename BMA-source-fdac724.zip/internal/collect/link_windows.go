package collect

import (
	"os"
	"syscall"
)

func isLink(info os.FileInfo) bool {
	if info.Mode()&os.ModeSymlink != 0 {
		return true
	}
	attributes, ok := info.Sys().(*syscall.Win32FileAttributeData)
	return ok && attributes.FileAttributes&syscall.FILE_ATTRIBUTE_REPARSE_POINT != 0
}

func openSample(root *os.Root, name string) (*os.File, error) { return root.Open(name) }
