package collect

import (
	"os"
	"strings"
	"testing"
)

func TestNettopNativeMacSample(t *testing.T) {
	data, err := os.ReadFile("testdata/nettop-macos26.4.csv")
	if err != nil {
		t.Fatal(err)
	}
	values, err := ParseNettop(string(data), map[int]bool{6128: true})
	if err != nil || len(values) != 1 || values[0].PID != 6128 || values[0].Process != "platformqa" || values[0].BytesOut != 0 {
		t.Fatalf("native sample: %+v %v", values, err)
	}
}

func TestNettopCountersAndIdentity(t *testing.T) {
	data := ",bytes_out,bytes_in,\r\n\"com.example, agent.42\",18446744073709551615,1024,\r\nOther.99,1,2,\r\n"
	values, err := ParseNettop(data, map[int]bool{42: true, 99: false})
	if err != nil || len(values) != 1 || values[0].BytesOut != ^uint64(0) || values[0].BytesIn != 1024 || values[0].Process != "com.example, agent" {
		t.Fatalf("counters or scope: %+v %v", values, err)
	}
	values, err = ParseNettop(",bytes_in,bytes_out,\n", map[int]bool{42: true})
	if err != nil || len(values) != 0 {
		t.Fatalf("empty selection sample: %v %v", values, err)
	}
}

func TestNettopMalformedTailRejectsWholeSample(t *testing.T) {
	header := ",bytes_in,bytes_out,\n"
	for _, tail := range []string{"Agent.42,1,2", "Agent.42,1,2,extra", "Agent.42,-1,2,", "Agent.42,1,2KiB,", "Agent.42,1,18446744073709551616,", "Agent,1,2,", "Agent.0,1,2,", "Agent.42,\"broken", "bytes_in,bytes_out,pid,process"} {
		values, err := ParseNettop(header+"Agent.42,1,2,\n"+tail, map[int]bool{42: true})
		if err == nil || values != nil {
			t.Fatalf("accepted malformed tail %q: %v %v", tail, values, err)
		}
		if strings.Contains(err.Error(), tail) {
			t.Fatal("raw sample leaked into error")
		}
	}
	for _, data := range []string{"", "bytes_in,bytes_out,pid,process\n1,2,42,Agent\n", ",bytes_in,bytes_in,\n", ",bytes_in,bytes_out,unexpected\n"} {
		if _, err := ParseNettop(data, map[int]bool{42: true}); err == nil {
			t.Fatalf("invalid schema accepted %q", data)
		}
	}
}
