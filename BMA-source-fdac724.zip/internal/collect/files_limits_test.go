package collect

import (
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/redact"
)

func TestDirectoryRegistrationBudgetCountsChurnWithoutDoubleCharging(t *testing.T) {
	root := t.TempDir()
	f, err := newFileCollector("s", []string{root}, func(event.Event) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	// Model earlier registrations that may remain held by the OS after renames.
	f.registrations = MaxWatchDirectories - 1
	for i := 0; i < 2; i++ {
		if err := f.addTree(context.Background(), f.roots[0], ".", false); err != nil {
			t.Fatal(err)
		}
	}
	if f.registrations != MaxWatchDirectories || len(f.directories) != 1 || len(f.watch.WatchList()) != 1 {
		t.Fatal("existing directory charged twice or last slot was not usable")
	}
	f.removeTree(root)
	if f.registrations != MaxWatchDirectories {
		t.Fatal("removal refunded potentially retained backend resources")
	}
	err = f.addTree(context.Background(), f.roots[0], ".", false)
	if !errors.Is(err, ErrFileWatchLimit) || len(f.watch.WatchList()) != 0 || len(f.directories) != 0 {
		t.Fatal("registration exceeded lifetime budget", err)
	}
}

func TestLiveDirectoryCapacityStopsAfterReady(t *testing.T) {
	root := t.TempDir()
	ready := make(chan struct{})
	f, err := newFileCollector("s", []string{root}, func(e event.Event) error {
		if e.Kind == "watch_ready" {
			close(ready)
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	f.registrations = MaxWatchDirectories - 1
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	done := make(chan error, 1)
	go func() { done <- f.Run(ctx, 10*time.Millisecond) }()
	select {
	case <-ready:
	case err := <-done:
		t.Fatal("watch ended before ready", err)
	case <-ctx.Done():
		<-done
		t.Fatal("watch did not become ready")
	}
	if err := os.Mkdir(filepath.Join(root, "late-child"), 0700); err != nil {
		cancel()
		<-done
		t.Fatal(err)
	}
	if err := <-done; !errors.Is(err, ErrFileWatchLimit) {
		t.Fatal("live growth did not stop observation on capacity", err)
	}
	if f.registrations != MaxWatchDirectories || len(f.directories) != 1 {
		t.Fatal("over-budget child was registered")
	}
}

func TestDirectoryPathBudgetStopsBeforeNativeRegistrationAndRedacts(t *testing.T) {
	root := t.TempDir()
	f, err := newFileCollector("s", []string{root}, func(event.Event) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	f.registeredPathBytes = maxWatchPathBytes - len(root)
	if err := f.addTree(context.Background(), f.roots[0], ".", false); err != nil {
		t.Fatal("exact path budget rejected", err)
	}
	child := filepath.Join(root, "child")
	if err := os.Mkdir(child, 0700); err != nil {
		t.Fatal(err)
	}
	err = f.addTree(context.Background(), f.roots[0], "child", false)
	if !errors.Is(err, ErrFileWatchLimit) || len(f.watch.WatchList()) != 1 || f.registeredPathBytes != maxWatchPathBytes {
		t.Fatal("path capacity exceeded", err)
	}
	e := fileFailureEvent("s", "filesystem_stopped", "", err)
	d := redact.Events([]event.Event{e}, false)[0].Detail
	if d["source"] != "filesystem_capacity" || d["resource"] != "directory_path_bytes" || d["limit"] != maxWatchPathBytes || d["used"] != maxWatchPathBytes || d["requested"] != len(child) || d["error"] != nil {
		t.Fatal("safe model capacity disclosure missing")
	}
}

func TestStreamingDirectoryDiscoveryAndCancellation(t *testing.T) {
	root := t.TempDir()
	const count = directoryReadBatch*2 + 17
	for i := 0; i < count; i++ {
		if err := os.WriteFile(filepath.Join(root, fmt.Sprintf("file-%04d", i)), []byte("fixture"), 0600); err != nil {
			t.Fatal(err)
		}
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	seen := map[string]bool{}
	stopAfterFirst := false
	f, err := newFileCollector("s", []string{root}, func(e event.Event) error {
		if e.Kind != "file_observed" || e.Detail["creation_time"] != "unknown" || e.Detail["size_bytes"] != int64(7) {
			t.Fatal("discovery changed event semantics")
		}
		path := e.Detail["path"].(string)
		if seen[path] {
			t.Fatal("duplicate file in streamed enumeration")
		}
		seen[path] = true
		if stopAfterFirst {
			cancel()
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	if err := f.addTree(ctx, f.roots[0], ".", true); err != nil || len(seen) != count {
		t.Fatal("batched enumeration lost files", err, len(seen))
	}
	seen = map[string]bool{}
	stopAfterFirst = true
	if err := f.addTree(ctx, f.roots[0], ".", true); !errors.Is(err, context.Canceled) || len(seen) != 1 {
		t.Fatal("enumeration continued after cancellation", err)
	}
}

func TestRegisteredChildReplacementStopsBeforeDiscovery(t *testing.T) {
	root := t.TempDir()
	child := filepath.Join(root, "child")
	if err := os.Mkdir(child, 0700); err != nil {
		t.Fatal(err)
	}
	count := 0
	f, err := newFileCollector("s", []string{root}, func(event.Event) error { count++; return nil })
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	if err := f.addTree(context.Background(), f.roots[0], ".", false); err != nil {
		t.Fatal(err)
	}
	if err := os.Rename(child, child+"-old"); err != nil {
		t.Fatal(err)
	}
	if err := os.Mkdir(child, 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(child, "replacement.bin"), []byte("unobserved replacement"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := f.addTree(context.Background(), f.roots[0], "child", true); err == nil || count != 0 || f.registrations != 2 {
		t.Fatal("replacement registered or imported under original identity")
	}
}
