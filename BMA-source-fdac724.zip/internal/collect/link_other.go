//go:build !windows

package collect

import (
	"os"
	"syscall"
)

func isLink(info os.FileInfo) bool { return info.Mode()&os.ModeSymlink != 0 }

func openSample(root *os.Root, name string) (*os.File, error) {
	return root.OpenFile(name, os.O_RDONLY|syscall.O_NONBLOCK, 0)
}
