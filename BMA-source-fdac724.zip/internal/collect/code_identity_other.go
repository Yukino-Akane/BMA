//go:build !darwin

package collect

import (
	"context"
	"fmt"
)

func verifyCodeIdentity(context.Context, int, CodeIdentity) error {
	return fmt.Errorf("code identity verification is only supported on macOS")
}
