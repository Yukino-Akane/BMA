package collect

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"

	"behavior-monitoring-audit/internal/event"
)

// Each successful registration consumes the session budget even if the path
// later disappears. Some backends retain renamed watches and cannot remove
// them using the old path; counting only current paths would be unbounded.
const MaxWatchDirectories = 2048
const maxWatchPathBytes = 4 * 1024 * 1024
const directoryReadBatch = 256

var ErrFileWatchLimit = errors.New("filesystem observation capacity reached; observation stopped")

type fileWatchLimitError struct {
	resource               string
	limit, used, requested int
}

func (e *fileWatchLimitError) Error() string {
	return fmt.Sprintf("%v: %s limit=%d used=%d requested=%d", ErrFileWatchLimit, e.resource, e.limit, e.used, e.requested)
}

func (e *fileWatchLimitError) Unwrap() error { return ErrFileWatchLimit }

func fileFailureEvent(session, source, path string, err error) event.Event {
	detail := map[string]any{"source": source, "path": path, "error": err.Error(), "coverage": "incomplete"}
	var limit *fileWatchLimitError
	if errors.As(err, &limit) {
		detail["source"], detail["reason"] = "filesystem_capacity", "watch_limit"
		detail["resource"], detail["limit"], detail["used"], detail["requested"] = limit.resource, limit.limit, limit.used, limit.requested
	}
	return event.New(session, "file", event.Process{Name: "collector"}, "collector_error", "direct", detail)
}

// Standard-library ReadDir(n) bounds memory even when one directory contains
// millions of files. The pending directory stack is bounded by registrations;
// only the root and the directory currently being read have open handles.
func (f *fileCollector) addTree(ctx context.Context, root *fileRoot, relative string, discover bool) error {
	handle, err := root.open()
	if err != nil {
		return err
	}
	defer handle.Close()
	info, err := fileInfo(handle, relative)
	if err != nil {
		return f.gap("directory_scan", filepath.Join(root.path, relative), err)
	}
	walk, err := f.visit(ctx, root, handle, relative, info, discover)
	if err != nil || !walk {
		return err
	}
	pending := []string{relative}
	scheduled := map[string]bool{relative: true}
	for len(pending) > 0 {
		if err := ctx.Err(); err != nil {
			return err
		}
		rel := pending[len(pending)-1]
		pending[len(pending)-1] = ""
		pending = pending[:len(pending)-1]
		if err := f.readDirectory(ctx, root, handle, rel, discover, &pending, scheduled); err != nil {
			return err
		}
	}
	return nil
}

func (f *fileCollector) readDirectory(ctx context.Context, root *fileRoot, handle *os.Root, relative string, discover bool, pending *[]string, scheduled map[string]bool) error {
	path := filepath.Join(root.path, relative)
	expected := f.directories[path]
	info, err := fileInfo(handle, relative)
	if err != nil || expected == nil || !os.SameFile(info, expected) {
		return fmt.Errorf("registered directory changed before enumeration: %s", path)
	}
	dir, err := openSample(handle, relative)
	if err != nil {
		return f.gap("directory_scan", path, err)
	}
	defer dir.Close()
	opened, err := dir.Stat()
	if err != nil || !opened.IsDir() || !os.SameFile(opened, expected) {
		return fmt.Errorf("registered directory changed while opening: %s", path)
	}
	for {
		if err := ctx.Err(); err != nil {
			return err
		}
		if err := root.validate(); err != nil {
			return err
		}
		current, err := fileInfo(handle, relative)
		if err != nil || !os.SameFile(current, expected) {
			return fmt.Errorf("registered directory changed during enumeration: %s", path)
		}
		entries, readErr := dir.ReadDir(directoryReadBatch)
		for _, entry := range entries {
			if err := ctx.Err(); err != nil {
				return err
			}
			rel := filepath.Join(relative, entry.Name())
			info, err := entry.Info()
			if err != nil {
				if err := f.gap("directory_scan", filepath.Join(root.path, rel), err); err != nil {
					return err
				}
				continue
			}
			walk, err := f.visit(ctx, root, handle, rel, info, discover)
			if err != nil {
				return err
			}
			if walk && !scheduled[rel] {
				scheduled[rel] = true
				*pending = append(*pending, rel)
			}
		}
		if errors.Is(readErr, io.EOF) {
			return nil
		}
		if readErr != nil {
			return f.gap("directory_scan", path, readErr)
		}
	}
}

func (f *fileCollector) visit(ctx context.Context, root *fileRoot, handle *os.Root, rel string, info os.FileInfo, discover bool) (bool, error) {
	if err := ctx.Err(); err != nil {
		return false, err
	}
	path := filepath.Join(root.path, rel)
	if isLink(info) {
		return false, f.emit(event.New(f.session, "file", event.Process{Name: "collector"}, "path_excluded", "direct", map[string]any{"path": path, "reason": "symbolic_link_or_reparse_point"}))
	}
	if _, err := fileInfo(handle, rel); err != nil {
		return false, f.gap("filesystem_boundary", path, err)
	}
	if !info.IsDir() {
		if discover && info.Mode().IsRegular() {
			e := f.fileEvent(root, rel, "file_observed", info)
			e.Detail["sampling"], e.Detail["creation_time"] = "new_directory_scan", "unknown"
			return false, f.emit(e)
		}
		return false, nil
	}
	if previous := f.directories[path]; previous != nil {
		if !os.SameFile(previous, info) {
			return false, fmt.Errorf("registered directory identity changed: %s", path)
		}
		return true, nil
	}
	if f.registrations >= MaxWatchDirectories {
		return false, &fileWatchLimitError{resource: "directory_registrations", limit: MaxWatchDirectories, used: f.registrations, requested: 1}
	}
	if len(path) > maxWatchPathBytes-f.registeredPathBytes {
		return false, &fileWatchLimitError{resource: "directory_path_bytes", limit: maxWatchPathBytes, used: f.registeredPathBytes, requested: len(path)}
	}
	if err := root.validate(); err != nil {
		return false, err
	}
	before, err := os.Lstat(path)
	if err != nil || isLink(before) || !os.SameFile(info, before) {
		return false, fmt.Errorf("watch directory changed during registration: %s", path)
	}
	if err := f.watch.Add(path); err != nil {
		return false, f.gap("watch_directory", path, err)
	}
	f.registrations++
	f.registeredPathBytes += len(path)
	after, err := os.Lstat(path)
	if err != nil || isLink(after) || !os.SameFile(info, after) {
		_ = f.watch.Remove(path)
		return false, fmt.Errorf("watch directory changed during registration: %s", path)
	}
	f.directories[path] = info
	return true, nil
}
