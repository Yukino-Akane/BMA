package collect

import (
	"context"
	"fmt"
	"os"
	"strconv"
	"strings"

	"behavior-monitoring-audit/internal/event"
	"github.com/shirou/gopsutil/v4/process"
)

type processSnapshot struct {
	p           *process.Process
	identity    event.Process
	parent      int32
	identityErr error
}

// Read only process identity and ancestry metadata, never arguments or environment.
// Both sampling and proxy authorization use this same current-user scope.
func (w *Watcher) processSnapshot(ctx context.Context, items []*process.Process, user string) map[int]processSnapshot {
	records := make(map[int]processSnapshot)
	for _, p := range items {
		if ctx.Err() != nil {
			break
		}
		if p.Pid <= 0 || (len(w.RootProcesses) > 0 && p.Pid == int32(os.Getpid())) {
			continue
		}
		name, nameErr := p.NameWithContext(ctx)
		if nameErr != nil {
			continue
		}
		if len(w.RootProcesses) == 0 && !w.Names[strings.ToLower(name)] && !w.Names[strconv.Itoa(int(p.Pid))] {
			continue
		}
		owner, ownerErr := p.UsernameWithContext(ctx)
		if ownerErr != nil || owner != user {
			continue
		}
		created, createErr := p.CreateTimeWithContext(ctx)
		if createErr != nil || created <= 0 {
			// Preserve legacy name/PID selection's identity-failure disclosure.
			// Tree-mode roots have their own per-root missing-identity gaps.
			if len(w.RootProcesses) == 0 {
				if createErr == nil {
					createErr = fmt.Errorf("process start time unavailable")
				}
				records[int(p.Pid)] = processSnapshot{p: p, identity: event.Process{PID: int(p.Pid), Name: name}, identityErr: createErr}
			}
			continue
		}
		var parent int32
		if len(w.RootProcesses) > 0 {
			var err error
			parent, err = p.PpidWithContext(ctx)
			if err != nil {
				continue
			}
		}
		exe, _ := p.ExeWithContext(ctx)
		records[int(p.Pid)] = processSnapshot{p: p, identity: event.Process{PID: int(p.Pid), Name: name, Path: exe, CreatedAtMS: created}, parent: parent}
	}
	return records
}

// Recheck the live chain around evidence collection. This narrows, but cannot
// eliminate, races without an atomic OS process-tree snapshot.
func (w *Watcher) verifyScopeIdentity(ctx context.Context, records map[int]processSnapshot, proc event.Process) error {
	if len(w.RootProcesses) == 0 {
		return verifyProcessIdentity(ctx, proc)
	}
	seen := make(map[int]bool)
	pid := proc.PID
	for pid > 0 && !seen[pid] {
		seen[pid] = true
		record, ok := records[pid]
		if !ok {
			break
		}
		if err := verifyProcessIdentity(ctx, record.identity); err != nil {
			return err
		}
		if created, root := w.RootProcesses[pid]; root {
			if created == record.identity.CreatedAtMS {
				if expected, ok := w.RootCode[pid]; ok {
					return verifyCodeIdentity(ctx, pid, expected)
				}
				return nil
			}
			break
		}
		fresh, err := process.NewProcessWithContext(ctx, int32(pid))
		if err != nil {
			return err
		}
		parent, err := fresh.PpidWithContext(ctx)
		if err != nil {
			return err
		}
		if parent != record.parent {
			break
		}
		pid = int(parent)
	}
	return fmt.Errorf("process ancestry no longer verifies against the selected root identity")
}

// Rebuild from live ancestry, not cached PIDs. An orphan or unverifiable parent
// removes the branch until a live chain to an unchanged root can be verified.
func (w *Watcher) expandVerifiedScope(records map[int]processSnapshot, active map[int]int64) map[string]bool {
	// Keep rejected explicit roots in the exclusion set. Otherwise a root with
	// a failed signature could re-enter as a descendant of another valid root.
	roots := make(map[int]int64, len(w.RootProcesses))
	for pid := range w.RootProcesses {
		roots[pid] = active[pid] // zero can never match a verified start time
	}
	return expandProcessScope(records, roots)
}

func expandProcessScope(records map[int]processSnapshot, roots map[int]int64) map[string]bool {
	selected := make(map[string]bool)
	children := make(map[int][]int)
	queue := make([]int, 0, len(roots))
	for pid, record := range records {
		children[int(record.parent)] = append(children[int(record.parent)], pid)
	}
	for pid, created := range roots {
		if record, ok := records[pid]; ok && record.identity.CreatedAtMS == created {
			selected[identityKey(record.identity)] = true
			queue = append(queue, pid)
		}
	}
	for i := 0; i < len(queue); i++ {
		parent := records[queue[i]]
		for _, pid := range children[queue[i]] {
			record := records[pid]
			key := identityKey(record.identity)
			// A reused parent PID must not adopt an older process. Explicit root
			// PIDs also cannot re-enter as descendants with a different identity.
			if created, root := roots[pid]; root && created != record.identity.CreatedAtMS {
				continue
			}
			if selected[key] || record.identity.CreatedAtMS < parent.identity.CreatedAtMS {
				continue
			}
			selected[key] = true
			queue = append(queue, pid)
		}
	}
	return selected
}

func (w *Watcher) scopeEvents(selected map[int]event.Process) []event.Event {
	var out []event.Event
	current := make(map[string]event.Process, len(selected))
	for _, proc := range selected {
		key := identityKey(proc)
		current[key] = proc
		if _, existed := w.scopeMembers[key]; !existed {
			root := w.RootProcesses[proc.PID] == proc.CreatedAtMS
			detail := map[string]any{"root": root}
			if code, ok := w.RootCode[proc.PID]; root && ok {
				if code.BundleID != "" {
					detail["bundle_id"] = code.BundleID
				}
				detail["signing_id"] = code.Identifier
				detail["team_id"], detail["cdhash"] = code.TeamID, code.CDHash
			}
			out = append(out, event.New(w.SessionID, "net", proc, "scope_member_added", "direct", detail))
		}
	}
	for key, proc := range w.scopeMembers {
		if _, exists := current[key]; !exists {
			out = append(out, event.New(w.SessionID, "net", proc, "scope_member_removed", "direct", map[string]any{"reason": "identity_or_ancestry_no_longer_verified"}))
		}
	}
	w.scopeMembers = current
	return out
}
