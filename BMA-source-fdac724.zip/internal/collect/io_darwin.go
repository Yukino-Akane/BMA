//go:build darwin

package collect

import (
	"context"
	"github.com/shirou/gopsutil/v4/process"
)

// gopsutil v4.25.6 explicitly does not implement Darwin IOCounters. This is a
// capability declaration, not an error-string match or a sampling failure.
func processIOCounters(context.Context, *process.Process) (*process.IOCountersStat, error) {
	return nil, errCollectorUnsupported
}
