package collect

import (
	"bufio"
	"context"
	"fmt"
	"io"
	"net"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
	"github.com/shirou/gopsutil/v4/process"
)

func scopeRecord(pid int, parent int32, created int64) processSnapshot {
	return processSnapshot{identity: event.Process{PID: pid, Name: "fixture", CreatedAtMS: created}, parent: parent}
}

// A real root launches a child after observation starts. Only the child owns
// the loopback socket, so this also checks shared proxy scope authorization.
func TestLiveProcessScopeAndProxy(t *testing.T) {
	mode := os.Getenv("BMA_SCOPE_TEST_HELPER")
	if mode == "child" {
		conn, err := net.Dial("tcp", os.Getenv("BMA_SCOPE_TEST_ADDRESS"))
		if err != nil {
			os.Exit(2)
		}
		defer conn.Close()
		fmt.Fprintln(os.Stdout, os.Getpid())
		io.Copy(io.Discard, os.Stdin)
		return
	}
	if mode == "root" {
		fmt.Fprintln(os.Stdout, "ready")
		reader := bufio.NewReader(os.Stdin)
		if _, err := reader.ReadString('\n'); err != nil {
			return
		}
		cmd := exec.Command(os.Args[0], "-test.run=^TestLiveProcessScopeAndProxy$")
		cmd.Env = append(os.Environ(), "BMA_SCOPE_TEST_HELPER=child")
		cmd.Stdout, cmd.Stderr = os.Stdout, os.Stderr
		input, err := cmd.StdinPipe()
		if err != nil {
			os.Exit(3)
		}
		if err := cmd.Start(); err != nil {
			os.Exit(4)
		}
		io.Copy(io.Discard, reader)
		input.Close()
		cmd.Wait()
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 25*time.Second)
	defer cancel()
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer listener.Close()
	listener.(*net.TCPListener).SetDeadline(time.Now().Add(20 * time.Second))
	cmd := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestLiveProcessScopeAndProxy$")
	cmd.Env = append(os.Environ(), "BMA_SCOPE_TEST_HELPER=root", "BMA_SCOPE_TEST_ADDRESS="+listener.Addr().String())
	input, err := cmd.StdinPipe()
	if err != nil {
		t.Fatal(err)
	}
	output, err := cmd.StdoutPipe()
	if err != nil {
		t.Fatal(err)
	}
	if err := cmd.Start(); err != nil {
		t.Fatal(err)
	}
	defer func() { input.Close(); cmd.Wait() }()
	reader := bufio.NewReader(output)
	if line, err := reader.ReadString('\n'); err != nil || strings.TrimSpace(line) != "ready" {
		t.Fatalf("root: %q %v", line, err)
	}
	root, err := process.NewProcess(int32(cmd.Process.Pid))
	if err != nil {
		t.Fatal(err)
	}
	created, err := root.CreateTime()
	if err != nil {
		t.Fatal(err)
	}
	w, err := NewWatcher("s", "", nil, []string{strconv.Itoa(cmd.Process.Pid)}, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	if err := w.SetRootProcesses(map[int]int64{cmd.Process.Pid: created}); err != nil {
		t.Fatal(err)
	}
	w.sample(ctx)
	if len(w.scopeMembers) != 1 {
		t.Fatalf("initial root missing: %v", w.scopeMembers)
	}
	fmt.Fprintln(input, "spawn")
	line, err := reader.ReadString('\n')
	if err != nil {
		t.Fatal(err)
	}
	childPID, err := strconv.Atoi(strings.TrimSpace(line))
	if err != nil {
		t.Fatal(err)
	}
	conn, err := listener.Accept()
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	added := false
	for _, e := range w.sample(ctx) {
		if e.Kind == "scope_member_added" && e.Process.PID == childPID {
			added = true
		}
	}
	if !added {
		t.Fatal("new child did not join observation")
	}
	peer, err := w.ResolveProxyPeer(ctx, conn.RemoteAddr(), conn.LocalAddr())
	if err != nil || peer.PID != childPID {
		t.Fatalf("child socket denied or misattributed: %+v %v", peer, err)
	}
	// A stale root identity must reject the entire branch in both paths.
	stale, err := NewWatcher("s", "", nil, []string{strconv.Itoa(cmd.Process.Pid)}, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	if err := stale.SetRootProcesses(map[int]int64{cmd.Process.Pid: created + 1}); err != nil {
		t.Fatal(err)
	}
	stale.sample(ctx)
	if len(stale.scopeMembers) != 0 {
		t.Fatal("stale root admitted members")
	}
	if _, err := stale.ResolveProxyPeer(ctx, conn.RemoteAddr(), conn.LocalAddr()); err == nil {
		t.Fatal("stale root authorized child socket")
	}
}

func TestProcessScopeDynamicTreeAndReuse(t *testing.T) {
	roots := map[int]int64{10: 100, 20: 200}
	rows := map[int]processSnapshot{10: scopeRecord(10, 1, 100), 20: scopeRecord(20, 1, 200), 11: scopeRecord(11, 10, 101), 12: scopeRecord(12, 11, 102), 99: scopeRecord(99, 1, 500)}
	check := func(want ...int) {
		t.Helper()
		got := expandProcessScope(rows, roots)
		if len(got) != len(want) {
			t.Fatalf("members: %+v, expected PIDs %v", got, want)
		}
		for _, pid := range want {
			if !got[identityKey(rows[pid].identity)] {
				t.Fatalf("missing PID %d", pid)
			}
		}
	}
	check(10, 11, 12, 20)
	rows[13] = scopeRecord(13, 12, 103)
	check(10, 11, 12, 13, 20)
	// Reused root is forbidden even when it now descends from another root.
	rows[10] = scopeRecord(10, 20, 300)
	check(20)
	rows[10] = scopeRecord(10, 1, 100)
	// A reused intermediate PID cannot adopt descendants older than itself.
	rows[11] = scopeRecord(11, 10, 400)
	check(10, 11, 20)
	delete(rows, 11)
	check(10, 20)
	// Cycles not anchored to a root must neither enter the scope nor hang.
	rows[11] = scopeRecord(11, 12, 101)
	rows[12] = scopeRecord(12, 11, 101)
	check(10, 20)
}

func TestProcessScopeTransitionsAndPartialRootLoss(t *testing.T) {
	w, err := NewWatcher("s", "", nil, []string{"10", "20"}, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	if err := w.SetRootProcesses(map[int]int64{10: 100, 20: 200}); err != nil {
		t.Fatal(err)
	}
	a, b, child := scopeRecord(10, 1, 100).identity, scopeRecord(20, 1, 200).identity, scopeRecord(11, 10, 101).identity
	initial := map[int]event.Process{10: a, 20: b, 11: child}
	if events := w.scopeEvents(initial); len(events) != 3 {
		t.Fatalf("initial: %+v", events)
	}
	if events := w.scopeEvents(initial); len(events) != 0 {
		t.Fatalf("duplicate additions: %+v", events)
	}
	events := w.scopeEvents(map[int]event.Process{20: b})
	removed, gaps := 0, 0
	for _, e := range events {
		if e.Kind == "scope_member_removed" {
			removed++
		}
		if e.Kind == "collector_status" {
			gaps++
		}
	}
	if removed != 2 || gaps != 0 {
		t.Fatalf("partial loss: %+v", events)
	}
	if events := w.scopeEvents(map[int]event.Process{20: b}); len(events) != 0 {
		t.Fatalf("repeated gap: %+v", events)
	}
	if events := w.scopeEvents(initial); len(events) != 2 {
		t.Fatalf("rejoined membership: %+v", events)
	}
}

func TestRootIdentityValidation(t *testing.T) {
	w, err := NewWatcher("s", "", nil, []string{"10"}, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	for _, roots := range []map[int]int64{nil, {10: 0}, {-1: 100}, {20: 100}} {
		if err := w.SetRootProcesses(roots); err == nil {
			t.Fatalf("accepted invalid roots: %v", roots)
		}
	}
	roots := map[int]int64{10: 100}
	if err := w.SetRootProcesses(roots); err != nil {
		t.Fatal(err)
	}
	roots[10] = 999
	if w.RootProcesses[10] != 100 {
		t.Fatal("caller mutated locked identity")
	}
}

func TestRootCodeIdentityMustMatchRootProcess(t *testing.T) {
	w, err := NewWatcher("s", "", nil, []string{"10"}, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	if err := w.SetRootProcesses(map[int]int64{10: 100}); err != nil {
		t.Fatal(err)
	}
	valid := CodeIdentity{BundleID: "com.example.app", Identifier: "com.example.app", TeamID: "TEAM123", CDHash: strings.Repeat("a", 40)}
	if err := w.SetRootCodeIdentities(map[int]CodeIdentity{11: valid}); err == nil {
		t.Fatal("accepted code identity without matching root")
	}
	if err := w.SetRootCodeIdentities(map[int]CodeIdentity{10: {BundleID: "com.example.app", Identifier: "com.example.other", CDHash: "0123"}}); err == nil {
		t.Fatal("accepted mismatched bundle/signing identifier")
	}
	if err := w.SetRootCodeIdentities(map[int]CodeIdentity{10: valid}); err != nil {
		t.Fatal(err)
	}
	valid.BundleID = "" // standalone executables have signing IDs, not app bundles
	if err := w.SetRootCodeIdentities(map[int]CodeIdentity{10: valid}); err != nil {
		t.Fatal(err)
	}
}

// Opt-in metadata-only check against an already running app. Never calls
// sample(), Connections(), OpenFiles() or nettop, and never controls the app.
func TestInstalledAppScopeMetadata(t *testing.T) {
	rootText, markerText := os.Getenv("BMA_QA_ROOT_PID"), os.Getenv("BMA_QA_MARKER_PID")
	if rootText == "" || markerText == "" {
		t.Skip("explicit app root and synthetic marker required")
	}
	rootPID, err := strconv.Atoi(rootText)
	if err != nil {
		t.Fatal(err)
	}
	markerPID, err := strconv.Atoi(markerText)
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	root, err := process.NewProcess(int32(rootPID))
	if err != nil {
		t.Fatal(err)
	}
	created, err := root.CreateTimeWithContext(ctx)
	if err != nil {
		t.Fatal(err)
	}
	self, err := process.NewProcess(int32(os.Getpid()))
	if err != nil {
		t.Fatal(err)
	}
	owner, err := self.UsernameWithContext(ctx)
	if err != nil {
		t.Fatal(err)
	}
	w, err := NewWatcher("metadata-only", "", nil, []string{rootText}, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	if err := w.SetRootProcesses(map[int]int64{rootPID: created}); err != nil {
		t.Fatal(err)
	}
	all, err := process.ProcessesWithContext(ctx)
	if err != nil {
		t.Fatal(err)
	}
	records := w.processSnapshot(ctx, all, owner)
	active, problems := w.verifiedRoots(ctx, records)
	if len(problems) != 0 {
		t.Fatal("root metadata unavailable")
	}
	members := expandProcessScope(records, active)
	marker, ok := records[markerPID]
	if !ok || !members[identityKey(marker.identity)] {
		t.Fatal("synthetic marker is outside the real app tree")
	}
	if err := w.verifyScopeIdentity(ctx, records, marker.identity); err != nil {
		t.Fatal(err)
	}
	t.Logf("metadata-only verified: roots=%d descendants=%d synthetic_marker=true; no socket/file/log collection", len(active), len(members)-len(active))
}

func TestFailedCodeRootCannotReenterThroughAnotherRoot(t *testing.T) {
	w := &Watcher{RootProcesses: map[int]int64{10: 100, 11: 110}}
	records := map[int]processSnapshot{10: scopeRecord(10, 1, 100), 11: scopeRecord(11, 10, 110), 12: scopeRecord(12, 11, 120)}
	selected := w.expandVerifiedScope(records, map[int]int64{10: 100})
	if len(selected) != 1 || !selected[identityKey(records[10].identity)] {
		t.Fatalf("rejected root branch re-entered: %v", selected)
	}
}
