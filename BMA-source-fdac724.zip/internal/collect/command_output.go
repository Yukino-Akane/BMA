package collect

import (
	"bytes"
	"context"
	"fmt"
	"os/exec"
	"path/filepath"
	"time"
)

const maxCollectorOutput = 4 * 1024 * 1024

type collectorOutput struct{ buffer bytes.Buffer }

func (b *collectorOutput) Write(data []byte) (int, error) {
	if len(data) > maxCollectorOutput-b.buffer.Len() {
		return 0, fmt.Errorf("collector output exceeds byte limit")
	}
	return b.buffer.Write(data)
}

func boundedCommandOutput(ctx context.Context, path string, args ...string) ([]byte, error) {
	ctx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, path, args...)
	var output collectorOutput
	cmd.Stdout = &output
	if err := cmd.Run(); err != nil {
		return nil, fmt.Errorf("%s collection failed: %w", filepath.Base(path), err)
	}
	return output.buffer.Bytes(), nil
}
