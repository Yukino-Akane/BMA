//go:build !darwin

package collect

import (
	"context"
	"github.com/shirou/gopsutil/v4/process"
)

func processIOCounters(ctx context.Context, p *process.Process) (*process.IOCountersStat, error) {
	return p.IOCountersWithContext(ctx)
}
