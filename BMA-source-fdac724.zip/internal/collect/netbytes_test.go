package collect

import (
	"context"
	"errors"
	"os"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
	"github.com/shirou/gopsutil/v4/process"
)

func newCounterWatcher() *Watcher {
	return &Watcher{SessionID: "test", lastNetwork: map[string]networkCounter{}, health: CollectorHealth{}}
}

func TestNetworkCountersSeparateProcessLifetimes(t *testing.T) {
	w := newCounterWatcher()
	p := event.Process{PID: 42, Name: "verified-agent", CreatedAtMS: 100}
	selected := map[int]event.Process{42: p}
	at := time.Unix(1000, 0)
	apply := func(in, out uint64) []event.Event {
		at = at.Add(2 * time.Second)
		return w.networkEvents(selected, []NetworkSample{{PID: 42, Process: "untrusted-nettop-name", BytesIn: in, BytesOut: out}, {PID: 99, BytesOut: 99999999}}, nil, at)
	}
	events := apply(100, 1000)
	if len(events) != 1 || events[0].Kind != "network_baseline" {
		t.Fatalf("first sample counted as traffic: %+v", events)
	}
	events = apply(110, 1020)
	if len(events) != 1 || events[0].Process != p || events[0].Detail["bytes_out"] != uint64(20) || events[0].Detail["bytes_in"] != uint64(10) || events[0].Detail["window_sec"] != float64(2) {
		t.Fatalf("incorrect delta: %+v", events)
	}
	if _, ok := events[0].Detail["remote_host"]; ok {
		t.Fatal("aggregate traffic invented a destination")
	}
	p.CreatedAtMS = 200
	selected[42] = p
	events = apply(10000, 99999999)
	if len(events) != 1 || events[0].Kind != "network_baseline" {
		t.Fatalf("PID reuse inherited previous process traffic: %+v", events)
	}
	if len(w.lastNetwork) != 1 {
		t.Fatal("dead process counter retained")
	}
	events = apply(10005, 100000000)
	if len(events) != 1 || events[0].Detail["bytes_out"] != uint64(1) {
		t.Fatalf("new lifetime delta wrong: %+v", events)
	}
}

func TestNetworkGapsClearBaselineAndRecoverWithoutInventedBytes(t *testing.T) {
	for _, mode := range []string{"missing", "error", "duplicate", "reset", "clock"} {
		t.Run(mode, func(t *testing.T) {
			w := newCounterWatcher()
			p := event.Process{PID: 42, CreatedAtMS: 100}
			selected := map[int]event.Process{42: p}
			at := time.Unix(1000, 0)
			initial := []NetworkSample{{PID: 42, BytesIn: 100, BytesOut: 100}}
			w.networkEvents(selected, initial, nil, at)
			samples, err, nextAt := initial, error(nil), at.Add(time.Second)
			switch mode {
			case "missing":
				samples = nil
			case "error":
				err = errors.New("private command output")
			case "duplicate":
				samples = append(samples, samples[0])
			case "reset":
				samples = []NetworkSample{{PID: 42, BytesIn: 1, BytesOut: 2}}
			case "clock":
				nextAt = at
			}
			events := w.networkEvents(selected, samples, err, nextAt)
			want := "collector_error"
			if mode == "missing" {
				want = "collector_status"
			}
			if len(events) != 1 || events[0].Kind != want || events[0].Process != p {
				t.Fatalf("gap missing: %+v", events)
			}
			// Repeated collection failures should not flood the journal.
			if mode == "missing" || mode == "error" || mode == "duplicate" {
				if events := w.networkEvents(selected, samples, err, nextAt.Add(time.Second)); len(events) != 0 {
					t.Fatalf("duplicate gap: %+v", events)
				}
			}
			events = w.networkEvents(selected, []NetworkSample{{PID: 42, BytesIn: 150, BytesOut: 200}}, nil, at.Add(5*time.Second))
			recovered := false
			for _, e := range events {
				if e.Kind == "collector_recovered" {
					recovered = true
				}
				if e.Kind == "egress" && mode != "reset" && mode != "clock" {
					t.Fatal("traffic bridged unknown interval")
				}
			}
			if mode != "missing" && !recovered {
				t.Fatalf("recovery missing: %+v", events)
			}
			w.networkEvents(nil, nil, nil, at.Add(6*time.Second))
			if len(w.lastNetwork) != 0 {
				t.Fatal("unselected process state leaked")
			}
		})
	}
}

func TestProcessSelectionGapTransitions(t *testing.T) {
	w := newCounterWatcher()
	if e := w.selectionEvents(0); len(e) != 1 || e[0].Kind != "collector_status" {
		t.Fatal("initial absence undisclosed")
	}
	if len(w.selectionEvents(0)) != 0 {
		t.Fatal("repeated absence flooded events")
	}
	if e := w.selectionEvents(1); len(e) != 0 {
		t.Fatal("healthy process selection should not be a failure")
	}
	if len(w.selectionEvents(2)) != 0 {
		t.Fatal("healthy selection reported a gap")
	}
	if len(w.selectionEvents(0)) != 1 {
		t.Fatal("later absence undisclosed")
	}
}

func TestFreshProcessIdentityAndEnumerationFailure(t *testing.T) {
	p, err := process.NewProcess(int32(os.Getpid()))
	if err != nil {
		t.Fatal(err)
	}
	created, err := p.CreateTime()
	if err != nil {
		t.Fatal(err)
	}
	expected := event.Process{PID: os.Getpid(), CreatedAtMS: created}
	if err := verifyProcessIdentity(context.Background(), expected); err != nil {
		t.Fatal(err)
	}
	expected.CreatedAtMS++
	if err := verifyProcessIdentity(context.Background(), expected); err == nil {
		t.Fatal("wrong creation time accepted")
	}
	w := newCounterWatcher()
	w.lastNetwork["old"] = networkCounter{Out: 10}
	w.lastIO = map[string][2]uint64{"old": {1, 2}}
	e := w.samplingFailure("processes", errors.New("enumeration failed"))
	if len(w.lastNetwork) != 0 || len(w.lastIO) != 0 || len(e) != 1 || e[0].Kind != "collector_error" {
		t.Fatal("enumeration failure kept stale counters")
	}
}

func TestPermissionFailuresAreReportedOnTransition(t *testing.T) {
	w := newCounterWatcher()
	p := event.Process{PID: 42, CreatedAtMS: 100}
	for _, source := range []string{"process_connections", "process_io", "open_files_best_effort"} {
		w.health = CollectorHealth{}
		if e := w.sampleStatus(p, source, errors.New("access denied")); len(e) != 1 || e[0].Process != p || e[0].Kind != "collector_error" {
			t.Fatal("failure lacks process provenance")
		}
		if len(w.sampleStatus(p, source, errors.New("access denied"))) != 0 {
			t.Fatal("repeated failure flooded journal")
		}
		if e := w.sampleStatus(p, source, nil); len(e) != 1 || e[0].Kind != "collector_recovered" {
			t.Fatal("recovery not disclosed")
		}
		if len(w.sampleStatus(p, source, errors.New("access denied again"))) != 1 {
			t.Fatal("later failure silently ignored")
		}
	}
}
