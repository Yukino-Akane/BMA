//go:build darwin

package collect

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/shirou/gopsutil/v4/process"
)

func TestDarwinOpenFilesLiveNames(t *testing.T) {
	dir, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	names := []string{"space name.txt", "文件.txt", "back\\slash.txt", "line\nname.txt", "literal\\x41.txt", "quote\"file.txt", "caret^z.txt"}
	for _, name := range names {
		f, err := os.Create(filepath.Join(dir, name))
		if err != nil {
			t.Fatal(err)
		}
		defer f.Close()
	}
	p, err := process.NewProcess(int32(os.Getpid()))
	if err != nil {
		t.Fatal(err)
	}
	files, err := processOpenFiles(context.Background(), p)
	if err != nil {
		t.Fatal(err)
	}
	found := map[string]bool{}
	for _, file := range files {
		found[file.Path] = true
		if strings.HasPrefix(file.Path, dir+"/") {
			t.Logf("fixture name from lsof: %q", strings.TrimPrefix(file.Path, dir+"/"))
		}
	}
	for _, name := range names {
		if !found[filepath.Join(dir, name)] {
			t.Errorf("lsof did not preserve filename %q", name)
		}
	}
}

func TestDarwinOpenFilesRejectsAmbiguousControlNames(t *testing.T) {
	dir := t.TempDir()
	for _, name := range []string{"same^A.txt", "same\x01.txt"} {
		f, err := os.Create(filepath.Join(dir, name))
		if err != nil {
			t.Fatal(err)
		}
		defer f.Close()
	}
	p, err := process.NewProcess(int32(os.Getpid()))
	if err != nil {
		t.Fatal(err)
	}
	if files, err := processOpenFiles(context.Background(), p); err == nil || files != nil {
		t.Fatalf("ambiguous filenames must not identify a file: %v %v", files, err)
	}
}
