package collect

import (
	"bytes"
	"fmt"
	"strconv"
	"strings"

	"github.com/shirou/gopsutil/v4/process"
)

// lsof -F0 separates fields with NUL, and ends process/file sets with newline.
// Non-numeric descriptors (cwd, txt) and non-path names (sockets) are excluded.
func parseLsofFiles(data []byte, expectedPID int) ([]process.OpenFilesStat, error) {
	if !bytes.HasSuffix(bytes.TrimRight(data, "\r\n"), []byte{0}) {
		return nil, fmt.Errorf("lsof: incomplete field output")
	}
	var result []process.OpenFilesStat
	verified, seenFile, haveFD, haveName := false, false, false, false
	var fd uint64
	for _, raw := range bytes.Split(data, []byte{0}) {
		field := strings.TrimLeft(string(raw), "\r\n")
		if field == "" {
			continue
		}
		switch field[0] {
		case 'p':
			pid, err := strconv.Atoi(field[1:])
			if verified || err != nil || pid <= 0 || pid != expectedPID {
				return nil, fmt.Errorf("lsof: unexpected process identity")
			}
			verified = true
		case 'f':
			if !verified || (seenFile && !haveName) {
				return nil, fmt.Errorf("lsof: file before process identity")
			}
			var err error
			fd, err = strconv.ParseUint(field[1:], 10, 64)
			seenFile, haveFD, haveName = true, err == nil, false
		case 'n':
			if !verified || !seenFile || haveName {
				return nil, fmt.Errorf("lsof: unexpected file name")
			}
			haveName = true
			if haveFD && strings.HasPrefix(field[1:], "/") {
				path, err := lsofPath(field[1:])
				if err != nil {
					return nil, err
				}
				result = append(result, process.OpenFilesStat{Path: path, Fd: fd})
			}
		default:
			return nil, fmt.Errorf("lsof: unexpected field")
		}
	}
	if !verified || (seenFile && !haveName) {
		return nil, fmt.Errorf("lsof: missing process identity")
	}
	return result, nil
}

// The NUL field protocol still C-escapes names, including UTF-8 bytes when
// invoked without a UTF-8 locale. Keep hex escapes as bytes, not Unicode runes.
func lsofPath(encoded string) (string, error) {
	var path strings.Builder
	for len(encoded) > 0 {
		// lsof renders both a literal ^A and byte 0x01 as ^A. It is impossible
		// to distinguish them from this output; report a gap instead of
		// attributing the open descriptor to a different existing file.
		if len(encoded) > 1 && encoded[0] == '^' && ((encoded[1] >= '@' && encoded[1] <= '_') || encoded[1] == '?') {
			return "", fmt.Errorf("lsof: ambiguous control-character path notation")
		}
		if encoded[0] != '\\' {
			path.WriteByte(encoded[0])
			encoded = encoded[1:]
			continue
		}
		value, multibyte, tail, err := strconv.UnquoteChar(encoded, '"')
		if err != nil || value == 0 {
			return "", fmt.Errorf("lsof: invalid path escape")
		}
		if multibyte {
			path.WriteRune(value)
		} else {
			path.WriteByte(byte(value))
		}
		encoded = tail
	}
	return path.String(), nil
}
