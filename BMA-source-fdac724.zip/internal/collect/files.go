package collect

import (
	"context"
	"errors"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"time"

	"behavior-monitoring-audit/internal/artifact"
	"behavior-monitoring-audit/internal/event"
	"github.com/fsnotify/fsnotify"
)

type fileRoot struct {
	path     string
	identity os.FileInfo
}

type fileCollector struct {
	session             string
	watch               *fsnotify.Watcher
	roots               []*fileRoot
	directories         map[string]os.FileInfo
	registrations       int
	registeredPathBytes int
	created             map[string]event.Event
	emit                func(event.Event) error
}

func newFileCollector(session string, paths []string, emit func(event.Event) error) (*fileCollector, error) {
	if len(paths) > MaxWatchDirectories {
		return nil, &fileWatchLimitError{resource: "directory_registrations", limit: MaxWatchDirectories, requested: len(paths)}
	}
	watch, err := fsnotify.NewBufferedWatcher(1024)
	if err != nil {
		return nil, err
	}
	f := &fileCollector{session: session, watch: watch, directories: map[string]os.FileInfo{}, created: map[string]event.Event{}, emit: emit}
	for _, path := range paths {
		// File.Stat captures the identity from the open handle. On Windows,
		// os.Stat defers loading the file ID until SameFile, by which time the
		// path may already refer to a replacement. Close before observing so
		// we do not keep the selected directory locked against renaming.
		handle, err := os.Open(path)
		if err != nil {
			f.Close()
			return nil, err
		}
		info, statErr := handle.Stat()
		err = errors.Join(statErr, handle.Close())
		if err != nil {
			f.Close()
			return nil, err
		}
		if !info.IsDir() {
			f.Close()
			return nil, fmt.Errorf("watch path must be a directory: %s", path)
		}
		f.roots = append(f.roots, &fileRoot{path, info})
	}
	return f, nil
}

func (f *fileCollector) Close() {
	_ = f.watch.Close()
}

func (f *fileCollector) gap(source, path string, err error) error {
	return f.emit(fileFailureEvent(f.session, source, path, err))
}

func (r *fileRoot) validate() error {
	info, err := os.Lstat(r.path)
	if err != nil {
		return err
	}
	if isLink(info) || !os.SameFile(r.identity, info) {
		return fmt.Errorf("selected watch directory was replaced")
	}
	return nil
}

// Reject links/reparse points below a selected root. os.Root provides the
// additional traversal-resistant boundary if components change after checking.
func (r *fileRoot) open() (*os.Root, error) {
	handle, err := os.OpenRoot(r.path)
	if err != nil {
		return nil, err
	}
	info, err := handle.Stat(".")
	if err != nil || !os.SameFile(info, r.identity) {
		handle.Close()
		return nil, fmt.Errorf("selected directory changed before opening")
	}
	return handle, nil
}

func fileInfo(root *os.Root, name string) (os.FileInfo, error) {
	if name != "." && !filepath.IsLocal(name) {
		return nil, fmt.Errorf("path is outside selected directory")
	}
	var info os.FileInfo
	var err error
	path := "."
	for _, part := range strings.Split(name, string(filepath.Separator)) {
		path = filepath.Join(path, part)
		info, err = root.Lstat(path)
		if err != nil {
			return nil, err
		}
		if isLink(info) {
			return nil, fmt.Errorf("symbolic links and reparse points are excluded")
		}
	}
	return info, nil
}

func (f *fileCollector) rootFor(path string) (*fileRoot, string) {
	for _, root := range f.roots {
		if ContainsPath(root.path, path) {
			rel, _ := filepath.Rel(root.path, path)
			return root, rel
		}
	}
	return nil, ""
}

func (f *fileCollector) removeTree(path string) {
	for dir := range f.directories {
		if ContainsPath(path, dir) {
			_ = f.watch.Remove(dir)
			delete(f.directories, dir)
		}
	}
	for file := range f.created {
		if ContainsPath(path, file) {
			delete(f.created, file)
		}
	}
}

func (f *fileCollector) handle(ctx context.Context, item fsnotify.Event) error {
	if item.Op&(fsnotify.Create|fsnotify.Write|fsnotify.Remove|fsnotify.Rename) == 0 {
		return nil
	}
	root, rel := f.rootFor(item.Name)
	if root == nil {
		return nil
	}
	if err := root.validate(); err != nil {
		return err
	}
	if (item.Op&(fsnotify.Remove|fsnotify.Rename)) != 0 && f.directories[item.Name] != nil {
		f.removeTree(item.Name)
		kind := "directory_delete"
		if item.Op&fsnotify.Rename != 0 {
			kind = "directory_rename_from"
		}
		return f.emit(event.New(f.session, "file", event.Process{Name: "unattributed"}, kind, "temporal", map[string]any{"path": item.Name, "watch_root": root.path}))
	}
	handle, err := root.open()
	if err != nil {
		return err
	}
	defer handle.Close()
	info, err := fileInfo(handle, rel)
	if err != nil && !errors.Is(err, os.ErrNotExist) {
		return f.gap("filesystem_boundary", item.Name, err)
	}
	if info != nil && info.IsDir() {
		if item.Op&fsnotify.Create != 0 {
			return f.addTree(ctx, root, rel, true)
		}
		return nil
	}
	kind := "file_modify"
	if item.Op&fsnotify.Create != 0 {
		kind = "file_create"
	}
	if item.Op&fsnotify.Remove != 0 {
		kind = "file_delete"
	}
	if item.Op&fsnotify.Rename != 0 {
		kind = "file_rename_from"
	}
	return f.emit(f.fileEvent(root, rel, kind, info))
}

type fileNotification struct {
	event fsnotify.Event
	err   error
}

// Drain the OS backend even while recursively registering directories. Add
// can otherwise deadlock behind a full notification channel during a burst.
func (f *fileCollector) forward(ctx context.Context, events <-chan fsnotify.Event, failures <-chan error, queue chan<- fileNotification, dropped *atomic.Uint64) {
	defer close(queue)
	for {
		var notification fileNotification
		select {
		case <-ctx.Done():
			return
		case item, ok := <-events:
			if !ok {
				return
			}
			notification.event = item
		case err, ok := <-failures:
			if !ok {
				return
			}
			notification.err = err
		}
		select {
		case queue <- notification:
		default:
			dropped.Add(1)
		}
	}
}

func (f *fileCollector) Run(ctx context.Context, interval time.Duration) error {
	return f.run(ctx, interval, f.watch.Events, f.watch.Errors)
}

func (f *fileCollector) run(ctx context.Context, interval time.Duration, events <-chan fsnotify.Event, failures <-chan error) (runErr error) {
	queue := make(chan fileNotification, 1024)
	var dropped atomic.Uint64
	forwardCtx, stopForward := context.WithCancel(context.Background())
	forwardDone := make(chan struct{})
	go func() { defer close(forwardDone); f.forward(forwardCtx, events, failures, queue, &dropped) }()
	flushDrops := func() error {
		if count := dropped.Swap(0); count > 0 {
			return f.gap("filesystem_queue", "", fmt.Errorf("%d filesystem notifications omitted because the collection queue was full", count))
		}
		return nil
	}
	defer func() {
		stopForward()
		<-forwardDone
		runErr = errors.Join(runErr, flushDrops())
		if pending := len(queue); pending > 0 {
			runErr = errors.Join(runErr, f.gap("filesystem_shutdown", "", fmt.Errorf("%d filesystem notifications still pending when observation ended", pending)))
		}
	}()
	for _, root := range f.roots {
		if err := f.addTree(ctx, root, ".", false); err != nil {
			if ctx.Err() != nil && errors.Is(err, ctx.Err()) {
				return nil
			}
			return err
		}
	}
	if err := f.emit(event.New(f.session, "file", event.Process{Name: "collector"}, "watch_ready", "direct", map[string]any{"directories": len(f.directories), "roots": len(f.roots), "directory_registrations": f.registrations, "max_directory_registrations": MaxWatchDirectories, "registered_path_bytes": f.registeredPathBytes, "max_registered_path_bytes": maxWatchPathBytes})); err != nil {
		return err
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return nil
		case notification, ok := <-queue:
			if !ok {
				return fmt.Errorf("file watcher event stream closed")
			}
			if notification.err != nil {
				if err := f.gap("filesystem", "", notification.err); err != nil {
					return err
				}
				continue
			}
			if err := f.handle(ctx, notification.event); err != nil {
				if ctx.Err() != nil && errors.Is(err, ctx.Err()) {
					return nil
				}
				return err
			}
		case <-ticker.C:
			if err := flushDrops(); err != nil {
				return err
			}
			for _, root := range f.roots {
				if err := root.validate(); err != nil {
					return fmt.Errorf("selected directory unavailable: %w", err)
				}
			}
		}
	}
}

func (f *fileCollector) fileEvent(root *fileRoot, rel, kind string, info os.FileInfo) event.Event {
	path := filepath.Join(root.path, rel)
	detail := map[string]any{"path": path, "watch_root": root.path, "op": kind, "sensitive_path": sensitive(path)}
	if info != nil && info.Mode().IsRegular() && kind != "file_delete" && kind != "file_rename_from" {
		detail["size_bytes"] = info.Size()
		if hint := artifact.NameHint(path); hint != "" {
			detail["artifact_kind"] = hint
			detail["artifact_candidate"] = true
		}
		if entropy, err := sampleRootEntropy(root, rel, info); err == nil {
			detail["entropy"] = entropy
		} else {
			detail["sample_error"] = err.Error()
		}
	}
	e := event.New(f.session, "file", event.Process{Name: "unattributed"}, kind, "temporal", detail)
	if kind == "file_create" {
		f.created[path] = e
	}
	if kind == "file_delete" || kind == "file_rename_from" {
		if created, ok := f.created[path]; ok {
			detail["created_event_id"] = created.ID
			detail["deleted_after_sec"] = e.TS.Sub(created.TS).Seconds()
			delete(f.created, path)
		}
	}
	return e
}

func sampleRootEntropy(root *fileRoot, name string, expected os.FileInfo) (float64, error) {
	handle, err := root.open()
	if err != nil {
		return 0, err
	}
	defer handle.Close()
	return sampleEntropy(handle, name, expected)
}

func sampleEntropy(root *os.Root, name string, expected os.FileInfo) (float64, error) {
	file, err := openSample(root, name)
	if err != nil {
		return 0, err
	}
	defer file.Close()
	info, err := file.Stat()
	if err != nil {
		return 0, err
	}
	if !info.Mode().IsRegular() || !os.SameFile(info, expected) {
		return 0, fmt.Errorf("file changed before sampling")
	}
	data := make([]byte, 8192)
	n, err := file.ReadAt(data[:4096], 0)
	if err != nil && err != io.EOF {
		return 0, err
	}
	if info.Size() > 8192 {
		m, err := file.ReadAt(data[n:n+4096], info.Size()/2)
		if err != nil && err != io.EOF {
			return 0, err
		}
		n += m
	}
	if n == 0 {
		return 0, nil
	}
	counts := [256]int{}
	for _, b := range data[:n] {
		counts[b]++
	}
	var entropy float64
	for _, count := range counts {
		if count > 0 {
			p := float64(count) / float64(n)
			entropy -= p * math.Log2(p)
		}
	}
	return entropy, nil
}
