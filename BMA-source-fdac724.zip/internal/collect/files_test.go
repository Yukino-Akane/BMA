package collect

import (
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/rules"
	"github.com/fsnotify/fsnotify"
)

func TestWatchDirectoriesMergeOverlapAndRejectMissing(t *testing.T) {
	root := t.TempDir()
	child := filepath.Join(root, "child")
	if err := os.Mkdir(child, 0700); err != nil {
		t.Fatal(err)
	}
	other := t.TempDir()
	for _, input := range [][]string{{root, child, root, other}, {child, other, root}} {
		roots, err := watchDirectories(input)
		if err != nil || len(roots) != 2 {
			t.Fatalf("roots=%v error=%v", roots, err)
		}
	}
	if _, err := watchDirectories([]string{root, filepath.Join(root, "missing")}); err == nil {
		t.Fatal("missing directory silently ignored")
	}
	if ContainsPath(root, root+"-outside") || ContainsPath(child, root) {
		t.Fatal("invalid scope containment")
	}
}

func TestLiveMultipleRootsAndNewDirectoryCapture(t *testing.T) {
	workspace, dataDir := t.TempDir(), t.TempDir()
	w, err := NewWatcher("s", workspace, []string{dataDir}, []string{"bma-test-no-process"}, 20*time.Millisecond)
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()
	var mu sync.Mutex
	var events []event.Event
	ready := make(chan struct{})
	w.Emit = func(e event.Event) error {
		mu.Lock()
		events = append(events, e)
		mu.Unlock()
		if e.Kind == "watch_ready" {
			close(ready)
		}
		return nil
	}
	done := make(chan error, 1)
	go func() { done <- w.Run(ctx) }()
	defer func() {
		cancel()
		if err := <-done; err != nil {
			t.Errorf("watch ended: %v", err)
		}
	}()
	select {
	case <-ready:
	case <-ctx.Done():
		t.Fatal("watch startup timed out")
	}
	paths := []string{filepath.Join(workspace, "workspace.zip"), filepath.Join(dataDir, "new", "nested", "archive.zip")}
	for i, path := range paths {
		base := workspace
		if i == 1 {
			base = dataDir
		}
		resolved, err := directory(base)
		if err != nil {
			t.Fatal(err)
		}
		rel, _ := filepath.Rel(base, path)
		paths[i] = filepath.Join(resolved, rel)
	}
	for _, path := range paths {
		if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(path, []byte("fixture"), 0600); err != nil {
			t.Fatal(err)
		}
	}
	ticker := time.NewTicker(10 * time.Millisecond)
	defer ticker.Stop()
	for {
		mu.Lock()
		found := map[string]bool{}
		for _, e := range events {
			if e.Kind == "file_create" || e.Kind == "file_observed" || e.Kind == "file_modify" {
				if path, ok := e.Detail["path"].(string); ok {
					found[path] = true
					if e.Attribution != "temporal" || e.Detail["watch_root"] == nil {
						t.Error("incorrect file provenance")
					}
				}
			}
		}
		mu.Unlock()
		if found[paths[0]] && found[paths[1]] {
			break
		}
		select {
		case <-ticker.C:
		case <-ctx.Done():
			t.Fatal("multiple-root capture timed out")
		}
	}
}

func TestDiscoveryDoesNotInventCreationLifetime(t *testing.T) {
	root := t.TempDir()
	file := filepath.Join(root, "already-present.zip")
	if err := os.WriteFile(file, []byte("fixture"), 0600); err != nil {
		t.Fatal(err)
	}
	var events []event.Event
	f, err := newFileCollector("s", []string{root}, func(e event.Event) error { events = append(events, e); return nil })
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	if err := f.addTree(context.Background(), f.roots[0], ".", true); err != nil {
		t.Fatal(err)
	}
	if len(events) != 1 || events[0].Kind != "file_observed" || events[0].Detail["creation_time"] != "unknown" {
		t.Fatal("discovery invented a create")
	}
	if err := os.Remove(file); err != nil {
		t.Fatal(err)
	}
	if err := f.handle(context.Background(), fsnotify.Event{Name: file, Op: fsnotify.Remove}); err != nil {
		t.Fatal(err)
	}
	if events[1].Detail["created_event_id"] != nil {
		t.Fatal("unobserved creation got a lifetime")
	}
	findings := rules.Evaluate(events)
	if len(findings) != 1 || findings[0].Rule != "file/large-or-packed" {
		t.Fatalf("incorrect discovery rules: %+v", findings)
	}
}

func TestFileEntropyUsesRuleThreshold(t *testing.T) {
	root := t.TempDir()
	data := make([]byte, 8192)
	for i := range data {
		data[i] = byte(i % 128)
	}
	path := filepath.Join(root, "opaque")
	if err := os.WriteFile(path, data, 0600); err != nil {
		t.Fatal(err)
	}
	f, err := newFileCollector("s", []string{root}, func(event.Event) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	info, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	e := f.fileEvent(f.roots[0], "opaque", "file_create", info)
	if e.Detail["entropy"] != float64(7) || e.Detail["artifact_kind"] != nil {
		t.Fatalf("collector preclassified entropy: %+v", e.Detail)
	}
	for _, tt := range []struct {
		threshold float64
		want      bool
	}{{6.5, true}, {7.5, false}} {
		cfg := rules.DefaultConfig()
		cfg.Entropy = tt.threshold
		found := false
		for _, finding := range rules.EvaluateWithConfig([]event.Event{e}, cfg) {
			if finding.Rule == "file/suspicious-artifact" {
				found = true
			}
		}
		if found != tt.want {
			t.Fatalf("threshold %v: suspicious artifact = %v, want %v", tt.threshold, found, tt.want)
		}
	}
}

func TestSymlinkTraversalAndSampleSwapAreRejected(t *testing.T) {
	root, outside := t.TempDir(), t.TempDir()
	outsideFile := filepath.Join(outside, "secret.bin")
	if err := os.WriteFile(outsideFile, []byte("private-outside-data"), 0600); err != nil {
		t.Fatal(err)
	}
	link := filepath.Join(root, "linked")
	if err := os.Symlink(outside, link); err != nil {
		t.Skipf("symlink unavailable: %v", err)
	}
	var events []event.Event
	f, err := newFileCollector("s", []string{root}, func(e event.Event) error { events = append(events, e); return nil })
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	if err := f.addTree(context.Background(), f.roots[0], ".", true); err != nil {
		t.Fatal(err)
	}
	if len(f.directories) != 1 {
		t.Fatal("symlink directory was watched")
	}
	handle, err := f.roots[0].open()
	if err != nil {
		t.Fatal(err)
	}
	defer handle.Close()
	if _, err := fileInfo(handle, filepath.Join("linked", "secret.bin")); err == nil {
		t.Fatal("external path passed link check")
	}
	expected, err := os.Stat(outsideFile)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := sampleEntropy(handle, filepath.Join("linked", "secret.bin"), expected); err == nil {
		t.Fatal("root confinement allowed external sample")
	}
	local := filepath.Join(root, "swap.bin")
	if err := os.WriteFile(local, []byte("local"), 0600); err != nil {
		t.Fatal(err)
	}
	before, err := os.Stat(local)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.Remove(local); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(outsideFile, local); err != nil {
		t.Fatal(err)
	}
	if _, err := sampleEntropy(handle, "swap.bin", before); err == nil {
		t.Fatal("replacement symlink read outside data")
	}
	for _, e := range events {
		if e.Kind == "file_observed" {
			t.Fatal("outside file imported")
		}
	}
}

func TestRootReplacementIsDetected(t *testing.T) {
	parent := t.TempDir()
	root := filepath.Join(parent, "watched")
	if err := os.Mkdir(root, 0700); err != nil {
		t.Fatal(err)
	}
	f, err := newFileCollector("s", []string{root}, func(event.Event) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	if err := f.addTree(context.Background(), f.roots[0], ".", false); err != nil {
		t.Fatal(err)
	}
	if err := os.Rename(root, root+"-old"); err != nil {
		t.Fatal(err)
	}
	if err := os.Mkdir(root, 0700); err != nil {
		t.Fatal(err)
	}
	if err := f.roots[0].validate(); err == nil {
		t.Fatal("replacement root silently accepted")
	}
	if handle, err := f.roots[0].open(); err == nil {
		handle.Close()
		t.Fatal("replacement root opened for collection")
	}
}

func TestRegularFileReplacementBeforeSamplingIsRejected(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "sample.bin")
	if err := os.WriteFile(path, []byte("original"), 0600); err != nil {
		t.Fatal(err)
	}
	root, err := os.OpenRoot(dir)
	if err != nil {
		t.Fatal(err)
	}
	defer root.Close()
	before, err := fileInfo(root, "sample.bin")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.Rename(path, path+"-old"); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, []byte("replacement"), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := sampleEntropy(root, "sample.bin", before); err == nil {
		t.Fatal("replacement file was sampled using the original metadata")
	}
}

func TestNotificationBurstDoesNotDeadlockAndDisclosesLoss(t *testing.T) {
	root := t.TempDir()
	ready := make(chan struct{})
	var mu sync.Mutex
	gapFound := false
	f, err := newFileCollector("s", []string{root}, func(e event.Event) error {
		if e.Kind == "watch_ready" {
			close(ready)
		}
		if e.Kind == "file_modify" {
			time.Sleep(time.Millisecond)
		}
		if e.Kind == "collector_error" {
			mu.Lock()
			gapFound = true
			mu.Unlock()
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	done := make(chan error, 1)
	// Never send into fsnotify-owned channels: the native backend owns closure.
	// Supply synthetic input to the same forwarding/queue/collector path.
	notifications := make(chan fsnotify.Event)
	go func() { done <- f.run(ctx, 20*time.Millisecond, notifications, nil) }()
	select {
	case <-ready:
	case <-ctx.Done():
		t.Fatal("startup timed out")
	}
	for i := 0; i < 4000; i++ {
		select {
		case notifications <- fsnotify.Event{Name: filepath.Join(root, fmt.Sprintf("burst-%d", i)), Op: fsnotify.Write}:
		case <-ctx.Done():
			t.Fatal("backend could not drain burst")
		}
	}
	cancel()
	if err := <-done; err != nil && !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
	mu.Lock()
	defer mu.Unlock()
	if !gapFound {
		t.Fatal("notification loss not disclosed")
	}
}
