//go:build darwin

package collect

import (
	"context"
	"os/exec"
	"testing"
	"time"
)

func TestLiveNettopMoreThanTwentyProcesses(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	pids := map[int]bool{}
	for i := 0; i < 21; i++ {
		cmd := exec.CommandContext(ctx, "/bin/sleep", "20")
		if err := cmd.Start(); err != nil {
			t.Fatal(err)
		}
		defer func() { _ = cmd.Process.Kill(); _ = cmd.Wait() }()
		pids[cmd.Process.Pid] = true
	}
	samples, err := sampleNetworkBytes(ctx, pids)
	if err != nil {
		t.Fatalf("21 selected processes must not trigger nettop usage error: %v", err)
	}
	for _, sample := range samples {
		if !pids[sample.PID] {
			t.Fatal("unselected process sampled")
		}
	}
}
