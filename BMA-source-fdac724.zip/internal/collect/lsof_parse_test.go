package collect

import "testing"

func TestLsofFieldProtocol(t *testing.T) {
	data := []byte("p42\x00\nfcwd\x00n/workspace\x00\nftxt\x00n/bin/agent\x00\nf3\x00n/workspace/a b.txt\x00\nf4\x00n127.0.0.1:123->127.0.0.1:456\x00\nf5\x00n/workspace/line\nname\x00\n")
	files, err := parseLsofFiles(data, 42)
	if err != nil || len(files) != 2 || files[0].Fd != 3 || files[0].Path != "/workspace/a b.txt" || files[1].Path != "/workspace/line\nname" {
		t.Fatalf("%+v %v", files, err)
	}
}

func TestLsofRejectsWrongIdentityAndIncompleteOutput(t *testing.T) {
	for _, data := range []string{"", "p42", "p99\x00\n", "f3\x00n/a\x00\n", "p42\x00n/a\x00\n", "p42\x00f3\x00n/a", "p42\x00f3\x00n/a\x00p99\x00\n", "p42\x00f3\x00n/a\x00n/b\x00\n", "p42\x00f3\x00\n", "p42\x00f3\x00n/a\x00zunexpected\x00\n"} {
		files, err := parseLsofFiles([]byte(data), 42)
		if err == nil || files != nil {
			t.Fatalf("invalid output accepted %q: %+v %v", data, files, err)
		}
	}
}

func TestLsofPathEscapes(t *testing.T) {
	for encoded, want := range map[string]string{
		`/work/\xe6\x96\x87\xe4\xbb\xb6.txt`: "/work/文件.txt",
		`/work/back\\slash.txt`:              "/work/back\\slash.txt",
		`/work/line\nname.txt`:               "/work/line\nname.txt",
		`/work/literal\\x41.txt`:             `/work/literal\x41.txt`,
		`/work/quote"file.txt`:               `/work/quote"file.txt`,
	} {
		got, err := lsofPath(encoded)
		if err != nil || got != want {
			t.Fatalf("%q -> %q, want %q: %v", encoded, got, want, err)
		}
	}
	for _, invalid := range []string{`/work/\`, `/work/\xg0`, `/work/\x00`, `/work/\unknown`, `/work/^A`, `/work/^?`} {
		if _, err := lsofPath(invalid); err == nil {
			t.Fatalf("invalid escape accepted: %q", invalid)
		}
	}
}
