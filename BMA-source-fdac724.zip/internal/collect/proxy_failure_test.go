package collect

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"sync"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/rules"
)

func fixtureProxy(t *testing.T) (*Proxy, net.Listener, chan event.Event) {
	t.Helper()
	events := make(chan event.Event, 32)
	p, listener, err := StartProxy("s", 0, "", time.Minute, func(e event.Event) error { events <- e; return nil }, func(context.Context, net.Addr, net.Addr) (event.Process, error) {
		return event.Process{PID: 42, Name: "fixture", CreatedAtMS: 100}, nil
	})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { p.Close() })
	return p, listener, events
}

func proxyTerminalEvents(t *testing.T, events <-chan event.Event) []event.Event {
	t.Helper()
	var result []event.Event
	deadline := time.After(5 * time.Second)
	for {
		select {
		case e := <-events:
			result = append(result, e)
			if e.Kind == "connection_failed" || e.Kind == "connection_closed" {
				return result
			}
		case <-deadline:
			t.Fatal("proxy did not record terminal evidence")
			return nil
		}
	}
}

func connectFixture(t *testing.T, listener net.Listener, target string) net.Conn {
	t.Helper()
	client, err := net.Dial("tcp", listener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { client.Close() })
	client.SetDeadline(time.Now().Add(5 * time.Second))
	fmt.Fprintf(client, "CONNECT %s HTTP/1.1\r\nHost: %s\r\n\r\n", target, target)
	return client
}

func TestProxyRecordsRefusedConnectionWithoutUploadClaim(t *testing.T) {
	backend, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	target := backend.Addr().String()
	backend.Close()
	_, listener, events := fixtureProxy(t)
	client := connectFixture(t, listener, target)
	status, err := readProxyHeaders(client)
	if err != nil || !strings.Contains(status, "502") {
		t.Fatalf("response: %q %v", status, err)
	}
	rows := proxyTerminalEvents(t, events)
	if len(rows) != 1 || rows[0].Process.CreatedAtMS != 100 || rows[0].Detail["stage"] != "dial" || rows[0].Detail["error_code"] != "connection_refused" || rows[0].Detail["remote_host"] != target {
		t.Fatalf("failure evidence: %+v", rows)
	}
	if f := rules.Evaluate(rows); len(f) != 0 {
		t.Fatalf("failed dial became upload finding: %+v", f)
	}
}

func TestProxyPreservesPartialHTTPRequestWithoutLoggingContents(t *testing.T) {
	backend, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer backend.Close()
	wire := make(chan []byte, 1)
	go func() {
		c, err := backend.Accept()
		if err != nil {
			return
		}
		defer c.Close()
		c.SetDeadline(time.Now().Add(5 * time.Second))
		data, _ := io.ReadAll(c)
		wire <- data
	}()
	_, listener, events := fixtureProxy(t)
	client, err := net.Dial("tcp", listener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer client.Close()
	client.SetDeadline(time.Now().Add(5 * time.Second))
	fmt.Fprintf(client, "POST http://%s/private-fixture?token=fixture-secret HTTP/1.1\r\nHost: %s\r\nAuthorization: Bearer fixture-secret\r\nProxy-Authorization: proxy-fixture-secret\r\nContent-Length: 100\r\n\r\nprivate-body", backend.Addr(), backend.Addr())
	client.(*net.TCPConn).CloseWrite()
	rows := proxyTerminalEvents(t, events)
	var data []byte
	select {
	case data = <-wire:
	case <-time.After(5 * time.Second):
		t.Fatal("backend not released")
	}
	if len(rows) != 3 || rows[0].Kind != "connection_observed" || rows[1].Kind != "egress" || rows[2].Kind != "connection_failed" {
		t.Fatalf("partial request not accounted: %+v", rows)
	}
	if rows[1].Detail["bytes_out"] != uint64(len(data)) || len(data) <= len("private-body") || rows[2].Detail["stage"] != "request_body" {
		t.Fatalf("lost forwarded bytes: %d / %+v", len(data), rows)
	}
	for _, row := range rows[1:] {
		if row.Detail["connection_event_id"] != rows[0].ID {
			t.Fatal("connection evidence link lost")
		}
	}
	encoded, _ := json.Marshal(rows)
	for _, secret := range []string{"fixture-secret", "private-fixture", "private-body", "Authorization", "Content-Length"} {
		if bytes.Contains(encoded, []byte(secret)) {
			t.Fatal("request content leaked to evidence")
		}
	}
	if bytes.Contains(data, []byte("proxy-fixture-secret")) {
		t.Fatal("proxy credential forwarded to backend")
	}
}

func TestProxyStreamsHTTPBodyLargerThanHeaderLimit(t *testing.T) {
	body := strings.Repeat("b", 128*1024)
	backend := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		data, err := io.ReadAll(r.Body)
		if err != nil || string(data) != body {
			t.Error("streaming request body truncated")
		}
		fmt.Fprint(w, "ok")
	}))
	defer backend.Close()
	_, listener, events := fixtureProxy(t)
	proxyURL, _ := url.Parse("http://" + listener.Addr().String())
	transport := &http.Transport{Proxy: http.ProxyURL(proxyURL)}
	defer transport.CloseIdleConnections()
	client := &http.Client{Transport: transport, Timeout: 5 * time.Second}
	res, err := client.Post(backend.URL, "text/plain", strings.NewReader(body))
	if err != nil {
		t.Fatal(err)
	}
	data, err := io.ReadAll(res.Body)
	res.Body.Close()
	if err != nil || string(data) != "ok" {
		t.Fatalf("response: %q %v", data, err)
	}
	rows := proxyTerminalEvents(t, events)
	if len(rows) != 3 || rows[1].Detail["bytes_out"].(uint64) < uint64(len(body)) || rows[2].Kind != "connection_closed" {
		t.Fatalf("HTTP success evidence: %+v", rows)
	}
}

func TestProxyHeaderLimitAndUnverifiedPeerHideRequest(t *testing.T) {
	_, listener, events := fixtureProxy(t)
	client, err := net.Dial("tcp", listener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer client.Close()
	client.SetDeadline(time.Now().Add(5 * time.Second))
	fmt.Fprintf(client, "GET http://private-fixture.invalid/ HTTP/1.1\r\nHost: private-fixture.invalid\r\nX-Large: %s\r\n\r\n", strings.Repeat("x", 70*1024))
	rows := proxyTerminalEvents(t, events)
	if len(rows) != 1 || rows[0].Detail["error_code"] != "header_limit" || rows[0].Detail["remote_host"] != "" {
		t.Fatalf("header failure leaked target: %+v", rows)
	}
	denied := make(chan event.Event, 2)
	p, ln, err := StartProxy("s", 0, "", time.Minute, func(e event.Event) error { denied <- e; return nil }, func(context.Context, net.Addr, net.Addr) (event.Process, error) {
		return event.Process{}, fmt.Errorf("private authorization detail")
	})
	if err != nil {
		t.Fatal(err)
	}
	defer p.Close()
	c := connectFixture(t, ln, "private-fixture.invalid:443")
	status, err := readProxyHeaders(c)
	if err != nil || !strings.Contains(status, "403") {
		t.Fatalf("denial: %q %v", status, err)
	}
	select {
	case e := <-denied:
		data, _ := json.Marshal(e)
		if e.Kind != "collector_error" || e.Process.PID != 0 || bytes.Contains(data, []byte("private")) {
			t.Fatalf("unverified peer evidence: %+v", e)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("missing authorization gap")
	}
}

func TestProxyTCPResetRetainsForwardedBytesAndReleasesWorkers(t *testing.T) {
	backend, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer backend.Close()
	go func() {
		c, err := backend.Accept()
		if err != nil {
			return
		}
		c.SetDeadline(time.Now().Add(5 * time.Second))
		io.ReadFull(c, make([]byte, 5))
		c.(*net.TCPConn).SetLinger(0)
		c.Close()
	}()
	p, listener, events := fixtureProxy(t)
	client := connectFixture(t, listener, backend.Addr().String())
	if status, err := readProxyHeaders(client); err != nil || !strings.Contains(status, "200") {
		t.Fatalf("CONNECT failed: %q %v", status, err)
	}
	client.Write([]byte("hello"))
	rows := proxyTerminalEvents(t, events)
	if len(rows) != 3 || rows[1].Detail["bytes_out"] != uint64(5) || rows[2].Kind != "connection_failed" {
		t.Fatalf("reset lost evidence: %+v", rows)
	}
	closed := make(chan error, 1)
	go func() { closed <- p.Close() }()
	select {
	case err := <-closed:
		if err != nil {
			t.Fatal(err)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("reset leaked a transfer worker")
	}
	if c, err := net.DialTimeout("tcp", listener.Addr().String(), time.Second); err == nil {
		c.Close()
		t.Fatal("proxy listener survived Close")
	}
}

func TestConcurrentProxyCloseWaitsForFinalEvidence(t *testing.T) {
	backend, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer backend.Close()
	received := make(chan struct{})
	go func() {
		c, err := backend.Accept()
		if err != nil {
			return
		}
		defer c.Close()
		c.SetDeadline(time.Now().Add(5 * time.Second))
		io.ReadFull(c, make([]byte, 5))
		close(received)
		io.Copy(io.Discard, c)
	}()
	events := make(chan event.Event, 8)
	flushing, release := make(chan struct{}), make(chan struct{})
	var once sync.Once
	releaseEvidence := func() { once.Do(func() { close(release) }) }
	p, listener, err := StartProxy("s", 0, "", time.Minute, func(e event.Event) error {
		if e.Kind == "egress" {
			close(flushing)
			<-release
		}
		events <- e
		return nil
	}, func(context.Context, net.Addr, net.Addr) (event.Process, error) {
		return event.Process{PID: 42, CreatedAtMS: 100}, nil
	})
	if err != nil {
		t.Fatal(err)
	}
	defer p.Close()
	defer releaseEvidence()
	client := connectFixture(t, listener, backend.Addr().String())
	if status, err := readProxyHeaders(client); err != nil || !strings.Contains(status, "200") {
		t.Fatalf("CONNECT: %q %v", status, err)
	}
	client.Write([]byte("hello"))
	select {
	case <-received:
	case <-time.After(5 * time.Second):
		t.Fatal("no forwarded data")
	}
	first, second := make(chan error, 1), make(chan error, 1)
	go func() { first <- p.Close() }()
	select {
	case <-flushing:
	case <-time.After(5 * time.Second):
		t.Fatal("shutdown did not flush")
	}
	go func() { second <- p.Close() }()
	select {
	case <-second:
		t.Fatal("concurrent Close returned before final evidence")
	case <-time.After(100 * time.Millisecond):
	}
	releaseEvidence()
	for _, done := range []chan error{first, second} {
		select {
		case err := <-done:
			if err != nil {
				t.Fatal(err)
			}
		case <-time.After(5 * time.Second):
			t.Fatal("Close did not finish")
		}
	}
	rows := proxyTerminalEvents(t, events)
	if len(rows) != 3 || rows[1].Detail["bytes_out"] != uint64(5) || rows[2].Kind != "connection_closed" || rows[2].Detail["reason"] != "observation_stopped" {
		t.Fatalf("shutdown misreported: %+v", rows)
	}
	p.mu.Lock()
	remaining := len(p.connections)
	p.mu.Unlock()
	if remaining != 0 {
		t.Fatalf("connections left after close: %d", remaining)
	}
}

func TestProxyListenerFailureStopsAcceptLoopAndDisclosesGap(t *testing.T) {
	p, listener, events := fixtureProxy(t)
	listener.Close()
	select {
	case e := <-events:
		if e.Kind != "collector_error" || e.Detail["source"] != "proxy_listener" {
			t.Fatalf("listener gap: %+v", e)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("listener failure not disclosed")
	}
	select {
	case <-p.accepted:
	case <-time.After(5 * time.Second):
		t.Fatal("accept loop spinning after permanent error")
	}
}
