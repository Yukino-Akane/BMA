package collect

import (
	"encoding/csv"
	"fmt"
	"io"
	"strconv"
	"strings"
)

// ParseNettop reads the native -P -x -L 1 -J bytes_in,bytes_out CSV observed
// on macOS 26.4. The first column is name.PID; PID is not a selectable metric.
func ParseNettop(text string, pids map[int]bool) ([]NetworkSample, error) {
	reader := csv.NewReader(strings.NewReader(text))
	header, err := reader.Read()
	if err != nil || len(header) != 4 || header[0] != "" || header[3] != "" {
		return nil, fmt.Errorf("nettop: invalid CSV header")
	}
	inColumn, outColumn := 1, 2
	if header[1] == "bytes_out" && header[2] == "bytes_in" {
		inColumn, outColumn = 2, 1
	} else if header[1] != "bytes_in" || header[2] != "bytes_out" {
		return nil, fmt.Errorf("nettop: missing byte columns")
	}
	var result []NetworkSample
	for row := 2; ; row++ {
		fields, err := reader.Read()
		if err == io.EOF {
			return result, nil
		}
		if err != nil || fields[3] != "" {
			return nil, fmt.Errorf("nettop: invalid CSV row %d", row)
		}
		name := fields[0]
		dot := strings.LastIndexByte(name, '.')
		if dot <= 0 {
			return nil, fmt.Errorf("nettop: missing process identity at row %d", row)
		}
		pid, err := strconv.ParseInt(name[dot+1:], 10, 32)
		if err != nil || pid <= 0 {
			return nil, fmt.Errorf("nettop: invalid PID at row %d", row)
		}
		if !pids[int(pid)] {
			continue
		}
		in, errIn := strconv.ParseUint(fields[inColumn], 10, 64)
		out, errOut := strconv.ParseUint(fields[outColumn], 10, 64)
		if errIn != nil || errOut != nil {
			return nil, fmt.Errorf("nettop: invalid counters at row %d", row)
		}
		result = append(result, NetworkSample{PID: int(pid), Process: name[:dot], BytesIn: in, BytesOut: out})
	}
}
