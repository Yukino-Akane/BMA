//go:build darwin

package collect

import (
	"context"
	"time"
)

const networkBytesAvailable = true

func sampleNetworkBytes(ctx context.Context, pids map[int]bool) ([]NetworkSample, error) {
	ctx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	return sampleNettopBatches(ctx, pids, boundedCommandOutput)
}
