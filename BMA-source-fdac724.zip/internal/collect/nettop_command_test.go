package collect

import (
	"context"
	"fmt"
	"reflect"
	"strconv"
	"strings"
	"testing"
)

func TestNettopRequiresExplicitScopeAndNoDNS(t *testing.T) {
	for _, pids := range []map[int]bool{nil, {}, {7: false}, {0: true}, {-1: true, 7: true}} {
		if _, err := nettopArguments(pids); err == nil {
			t.Fatalf("unsafe selection accepted: %v", pids)
		}
	}
	args, err := nettopArguments(map[int]bool{98: true, 7: true, 1: false})
	if err != nil {
		t.Fatal(err)
	}
	// The process filter is repeated, not comma-joined or a process-name match.
	want := []string{"-n", "-P", "-x", "-L", "1", "-J", "bytes_in,bytes_out", "-p", "7", "-p", "98"}
	if !reflect.DeepEqual(args, want) {
		t.Fatalf("scope or numeric/no-DNS mode changed: %v", args)
	}
}

func TestNettopBatchesRespectLimitAndDiscardPartialFailure(t *testing.T) {
	for _, count := range []int{1, 20, 21, 41} {
		pids := map[int]bool{}
		for pid := 1; pid <= count; pid++ {
			pids[pid] = true
		}
		calls := 0
		run := func(_ context.Context, path string, args ...string) ([]byte, error) {
			calls++
			if path != "/usr/bin/nettop" || len(args) < 9 || (len(args)-7)/2 > 20 {
				t.Fatalf("invalid batch: %v", args)
			}
			var csv strings.Builder
			csv.WriteString(",bytes_in,bytes_out,\n")
			for i := 7; i < len(args); i += 2 {
				if args[i] != "-p" {
					t.Fatal(args)
				}
				pid, err := strconv.Atoi(args[i+1])
				if err != nil || !pids[pid] {
					t.Fatal("scope widened")
				}
				fmt.Fprintf(&csv, "fixture.%d,10,20,\n", pid)
			}
			return []byte(csv.String()), nil
		}
		samples, err := sampleNettopBatches(context.Background(), pids, run)
		if err != nil || len(samples) != count || calls != (count+19)/20 {
			t.Fatalf("count %d: samples=%d calls=%d err=%v", count, len(samples), calls, err)
		}
		seen := map[int]bool{}
		for _, s := range samples {
			if seen[s.PID] {
				t.Fatal("duplicated PID")
			}
			seen[s.PID] = true
		}
		if count > 20 {
			calls = 0
			samples, err = sampleNettopBatches(context.Background(), pids, func(ctx context.Context, path string, args ...string) ([]byte, error) {
				if calls > 0 {
					return nil, fmt.Errorf("second batch failed")
				}
				return run(ctx, path, args...)
			})
			if err == nil || len(samples) != 0 {
				t.Fatal("partial batch accepted")
			}
		}
	}
}
