package collect

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/redact"
)

func upstreamFixture(t *testing.T, handle func(net.Conn)) net.Listener {
	t.Helper()
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { listener.Close() })
	go func() {
		c, err := listener.Accept()
		if err == nil {
			defer c.Close()
			c.SetDeadline(time.Now().Add(5 * time.Second))
			handle(c)
		}
	}()
	return listener
}

func chainedFixture(t *testing.T, upstream net.Listener) (*Proxy, net.Listener, chan event.Event) {
	t.Helper()
	events := make(chan event.Event, 32)
	p, listener, err := StartProxy("s", 0, "http://"+upstream.Addr().String(), time.Minute,
		func(e event.Event) error { events <- e; return nil },
		func(context.Context, net.Addr, net.Addr) (event.Process, error) {
			return event.Process{PID: 42, CreatedAtMS: 100}, nil
		})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { p.Close() })
	return p, listener, events
}

func TestProxyUpstreamCONNECTPreservesBufferedBytesAndHalfClose(t *testing.T) {
	target := "only-upstream-can-resolve.invalid:443"
	request := make(chan *http.Request, 1)
	upstream := upstreamFixture(t, func(c net.Conn) {
		r, err := http.ReadRequest(bufio.NewReader(c))
		if err != nil {
			return
		}
		request <- r
		// The greeting can be prefetched alongside the response headers.
		io.WriteString(c, "HTTP/1.1 200 Connection Established\r\n\r\nhello")
		data, err := io.ReadAll(c)
		if err == nil {
			c.Write(data) // Only responds once the upstream receives a half-close.
		}
	})
	_, listener, events := chainedFixture(t, upstream)
	client := connectFixture(t, listener, target)
	// Keep client-side prefetched tunnel bytes when the greeting arrives with
	// the headers; discarding this reader makes the test itself lose data.
	reader := bufio.NewReader(client)
	if status, err := readProxyHeaders(reader); err != nil || !strings.Contains(status, "200") {
		t.Fatalf("CONNECT: %s %v", status, err)
	}
	if _, err := io.WriteString(client, "payload"); err != nil {
		t.Fatal(err)
	}
	client.(*net.TCPConn).CloseWrite()
	data, err := io.ReadAll(reader)
	if err != nil || string(data) != "hellopayload" {
		t.Fatalf("lost buffered bytes or half-close: %q %v", data, err)
	}
	r := <-request
	if r.Method != "CONNECT" || r.Host != target || r.Header.Get("Proxy-Authorization") != "" {
		t.Fatal("wrong upstream handshake")
	}
	rows := proxyTerminalEvents(t, events)
	var out, in uint64
	for _, e := range rows {
		if e.Detail["remote_host"] != target || e.Detail["transport_route"] != "upstream_connect" || e.Detail["upstream_proxy"] != upstream.Addr().String() {
			t.Fatalf("lost route provenance: %+v", e.Detail)
		}
		if ip, ok := e.Detail["remote_ip"].(string); ok && ip != "" {
			t.Fatal("upstream socket IP masqueraded as destination IP")
		}
		if e.Kind == "egress" {
			out += e.Detail["bytes_out"].(uint64)
			in += e.Detail["bytes_in"].(uint64)
		}
	}
	if out != 7 || in != 12 {
		t.Fatalf("handshake counted or payload lost: %d/%d", out, in)
	}
	clean := redact.Events(rows, true)
	if clean[0].Detail["transport_route"] != "upstream_connect" || clean[0].Detail["upstream_proxy"] != upstream.Addr().String() {
		t.Fatal("model preview lost route context")
	}
}

func TestProxyUpstreamHTTPCountsTargetRequestAndRemovesProxyCredentials(t *testing.T) {
	type received struct {
		handshake, request *http.Request
		bytes              int
		body               string
	}
	wire := make(chan received, 1)
	upstream := upstreamFixture(t, func(c net.Conn) {
		reader := bufio.NewReader(c)
		handshake, err := http.ReadRequest(reader)
		if err != nil {
			return
		}
		io.WriteString(c, "HTTP/1.1 200 OK\r\n\r\n")
		var raw bytes.Buffer
		r, err := http.ReadRequest(bufio.NewReader(io.TeeReader(reader, &raw)))
		if err != nil {
			return
		}
		body, _ := io.ReadAll(r.Body)
		wire <- received{handshake, r, raw.Len(), string(body)}
		io.WriteString(c, "HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok")
	})
	_, listener, events := chainedFixture(t, upstream)
	proxyURL, _ := url.Parse("http://" + listener.Addr().String())
	transport := &http.Transport{Proxy: http.ProxyURL(proxyURL)}
	defer transport.CloseIdleConnections()
	client := &http.Client{Transport: transport, Timeout: 5 * time.Second}
	req, _ := http.NewRequest("POST", "http://target.invalid/upload?token=private-query", strings.NewReader("private-body"))
	req.Header.Set("Proxy-Authorization", "private-proxy-credential")
	resp, err := client.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	data, err := io.ReadAll(resp.Body)
	resp.Body.Close()
	if err != nil || string(data) != "ok" {
		t.Fatalf("response %s %v", data, err)
	}
	r := <-wire
	if r.handshake.Method != "CONNECT" || r.handshake.Host != "target.invalid:80" || r.handshake.Header.Get("Proxy-Authorization") != "" || r.request.Header.Get("Proxy-Authorization") != "" || r.request.RequestURI != "/upload?token=private-query" || r.body != "private-body" {
		t.Fatal("wrong HTTP tunneling or credential handling")
	}
	rows := proxyTerminalEvents(t, events)
	var out uint64
	for _, e := range rows {
		if e.Kind == "egress" {
			out += e.Detail["bytes_out"].(uint64)
		}
	}
	if out != uint64(r.bytes) {
		t.Fatalf("target bytes differ: %d/%d", out, r.bytes)
	}
	encoded, _ := json.Marshal(rows)
	if strings.Contains(string(encoded), "private-") {
		t.Fatal("request secrets copied into evidence")
	}
}

func TestProxyUpstreamFailureNeverFallsBack(t *testing.T) {
	for _, response := range []string{
		"HTTP/1.1 407 private-secret\r\nContent-Length: 100000\r\n\r\n",
		"not-http private-secret\r\n\r\n",
		"HTTP/1.1 200 OK\r\nX-Secret: " + strings.Repeat("s", 65536) + "\r\n\r\n",
	} {
		t.Run(fmt.Sprint(len(response)), func(t *testing.T) {
			target, err := net.Listen("tcp", "127.0.0.1:0")
			if err != nil {
				t.Fatal(err)
			}
			defer target.Close()
			upstream := upstreamFixture(t, func(c net.Conn) {
				http.ReadRequest(bufio.NewReader(c))
				io.WriteString(c, response)
			})
			p, listener, events := chainedFixture(t, upstream)
			client := connectFixture(t, listener, target.Addr().String())
			if status, err := readProxyHeaders(client); err != nil || !strings.Contains(status, "502") {
				t.Fatalf("response: %q %v", status, err)
			}
			rows := proxyTerminalEvents(t, events)
			if len(rows) != 1 || rows[0].Kind != "connection_failed" || !strings.HasPrefix(rows[0].Detail["error_code"].(string), "upstream_") {
				t.Fatalf("failed handshake claimed traffic: %+v", rows)
			}
			p.Close()
			target.(*net.TCPListener).SetDeadline(time.Now().Add(100 * time.Millisecond))
			if c, err := target.Accept(); err == nil {
				c.Close()
				t.Fatal("failed upstream silently dialed target directly")
			}
			encoded, _ := json.Marshal(rows)
			if strings.Contains(string(encoded), "private-secret") {
				t.Fatal("upstream response leaked into evidence")
			}
		})
	}
}

func TestProxyCloseCancelsPendingUpstreamHandshake(t *testing.T) {
	started := make(chan struct{})
	ended := make(chan struct{})
	upstream := upstreamFixture(t, func(c net.Conn) {
		http.ReadRequest(bufio.NewReader(c))
		close(started)
		io.Copy(io.Discard, c)
		close(ended)
	})
	p, listener, _ := chainedFixture(t, upstream)
	connectFixture(t, listener, "target.invalid:443")
	select {
	case <-started:
	case <-time.After(3 * time.Second):
		t.Fatal("upstream handshake did not start")
	}
	closed := make(chan struct{})
	go func() { p.Close(); close(closed) }()
	select {
	case <-closed:
	case <-time.After(2 * time.Second):
		t.Fatal("Close waited for upstream deadline")
	}
	select {
	case <-ended:
	case <-time.After(2 * time.Second):
		t.Fatal("upstream connection remained open")
	}
}

func TestProxyUpstreamValidation(t *testing.T) {
	for _, raw := range []string{"https://127.0.0.1:7897", "socks5://127.0.0.1:7897", "http://localhost:7897", "http://example.com:80", "http://192.168.1.1:80", "http://user:secret@127.0.0.1:80", "http://127.0.0.1:80/", "http://127.0.0.1:80?", "http://127.0.0.1:80#fragment", "http://127.0.0.1", "http://127.0.0.1:0", "http://127.0.0.1:65536"} {
		if _, err := parseProxyUpstream(raw); err == nil {
			t.Fatalf("accepted unsupported upstream %q", raw)
		}
	}
	for _, raw := range []string{"", "http://127.0.0.1:7897", "http://[::1]:7897"} {
		if _, err := parseProxyUpstream(raw); err != nil {
			t.Fatalf("rejected valid upstream %q: %v", raw, err)
		}
	}
	if got, err := parseProxyUpstream("http://[::ffff:127.0.0.1]:07897"); err != nil || got != "127.0.0.1:7897" {
		t.Fatalf("upstream address was not normalized: %s %v", got, err)
	}
}

func TestProxyUpstreamDeniesUnselectedClientBeforeDialing(t *testing.T) {
	upstream, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer upstream.Close()
	p, listener, err := StartProxy("s", 0, "http://"+upstream.Addr().String(), time.Minute,
		func(event.Event) error { return nil },
		func(context.Context, net.Addr, net.Addr) (event.Process, error) {
			return event.Process{}, fmt.Errorf("unselected")
		})
	if err != nil {
		t.Fatal(err)
	}
	defer p.Close()
	client := connectFixture(t, listener, "target.invalid:443")
	if status, err := readProxyHeaders(client); err != nil || !strings.Contains(status, "403") {
		t.Fatalf("unselected client accepted: %s %v", status, err)
	}
	upstream.(*net.TCPListener).SetDeadline(time.Now().Add(100 * time.Millisecond))
	if c, err := upstream.Accept(); err == nil {
		c.Close()
		t.Fatal("unauthorized client caused an upstream connection")
	}
}
