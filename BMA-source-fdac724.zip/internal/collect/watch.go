package collect

import (
	"context"
	"errors"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"behavior-monitoring-audit/internal/event"
	"github.com/shirou/gopsutil/v4/process"
)

type Watcher struct {
	SessionID     string
	Names         map[string]bool
	RootProcesses map[int]int64
	RootCode      map[int]CodeIdentity
	scopeMembers  map[string]event.Process
	Workspace     string
	Roots         []string
	Interval      time.Duration
	ReverseDNS    bool
	lastIO        map[string][2]uint64
	lastNetwork   map[string]networkCounter
	seenNet       map[string]bool
	seenFiles     map[string]bool
	seenProcesses map[string]bool
	processInfo   map[string]event.Process
	health        CollectorHealth
	Emit          func(event.Event) error
}

type CodeIdentity struct {
	BundleID   string
	Identifier string
	TeamID     string
	CDHash     string
}

func NewWatcher(sessionID, workspace string, directories, names []string, interval time.Duration) (*Watcher, error) {
	if interval <= 0 {
		return nil, fmt.Errorf("interval must be positive")
	}
	allow := make(map[string]bool)
	for _, name := range names {
		name = strings.ToLower(strings.TrimSpace(name))
		if name != "" {
			allow[name] = true
		}
	}
	if len(allow) == 0 {
		return nil, fmt.Errorf("at least one process name or PID is required")
	}
	root := ""
	if workspace != "" {
		var err error
		root, err = directory(workspace)
		if err != nil {
			return nil, err
		}
		directories = append([]string{root}, directories...)
	}
	roots, err := watchDirectories(directories)
	if err != nil {
		return nil, err
	}
	return &Watcher{SessionID: sessionID, Names: allow, Workspace: root, Roots: roots, Interval: interval,
		lastIO: map[string][2]uint64{}, seenNet: map[string]bool{}, seenFiles: map[string]bool{},
		seenProcesses: map[string]bool{}, processInfo: map[string]event.Process{}, lastNetwork: map[string]networkCounter{}, scopeMembers: map[string]event.Process{}}, nil
}

// SetRootProcesses locks a watch to explicit process instances. Descendants are
// discovered from the live parent tree on each sample and inherit this scope.
func (w *Watcher) SetRootProcesses(roots map[int]int64) error {
	if len(roots) == 0 {
		return fmt.Errorf("at least one root process is required")
	}
	if len(roots) != len(w.Names) {
		return fmt.Errorf("each --process selection must have one matching root identity when --root-process is used")
	}
	for pid, created := range roots {
		if pid <= 0 || created <= 0 {
			return fmt.Errorf("root process identity requires a positive PID and start time")
		}
		if !w.Names[strconv.Itoa(pid)] {
			return fmt.Errorf("root PID %d must also be explicitly selected with --process", pid)
		}
	}
	w.RootProcesses = make(map[int]int64, len(roots))
	for pid, created := range roots {
		w.RootProcesses[pid] = created
	}
	return nil
}

func (w *Watcher) SetRootCodeIdentities(identities map[int]CodeIdentity) error {
	for pid, identity := range identities {
		if _, ok := w.RootProcesses[pid]; !ok {
			return fmt.Errorf("code identity PID %d must have a matching root process", pid)
		}
		if err := validateCodeIdentity(identity); err != nil {
			return fmt.Errorf("root PID %d: %w", pid, err)
		}
	}
	w.RootCode = make(map[int]CodeIdentity, len(identities))
	for pid, identity := range identities {
		w.RootCode[pid] = identity
	}
	return nil
}

func (w *Watcher) samplingFailure(source string, err error) []event.Event {
	w.lastNetwork = map[string]networkCounter{}
	w.lastIO = map[string][2]uint64{}
	w.seenNet, w.seenFiles = map[string]bool{}, map[string]bool{}
	return w.observeHealth(event.Process{Name: "collector"}, source, err)
}

func (w *Watcher) selectionEvents(count int) []event.Event {
	state, reason := healthOK, "selected_process_observed"
	if count == 0 {
		state, reason = healthIdle, "no_verified_selected_process"
	}
	return w.health.observe(w.SessionID, event.Process{Name: "collector"}, "process_selection", state, reason)
}

func (w *Watcher) Run(ctx context.Context) error {
	if w.Emit == nil {
		return fmt.Errorf("event sink is required")
	}
	if len(w.Roots) == 0 {
		return w.runSamples(ctx)
	}
	files, err := newFileCollector(w.SessionID, w.Roots, w.Emit)
	if err != nil {
		return errors.Join(err, w.Emit(fileFailureEvent(w.SessionID, "filesystem_stopped", "", err)))
	}
	defer files.Close()
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()
	done := make(chan error, 2)
	go func() {
		err := files.Run(ctx, w.Interval)
		if err != nil {
			err = errors.Join(err, files.gap("filesystem_stopped", "", err))
		}
		done <- err
	}()
	go func() { done <- w.runSamples(ctx) }()
	first := <-done
	cancel()
	return errors.Join(first, <-done)
}

func (w *Watcher) runSamples(ctx context.Context) error {
	ticker := time.NewTicker(w.Interval)
	defer ticker.Stop()
	for {
		if ctx.Err() != nil {
			return nil
		}
		if err := w.emitSample(ctx); err != nil {
			return err
		}
		select {
		case <-ctx.Done():
			return nil
		case <-ticker.C:
		}
	}
}
func (w *Watcher) emitSample(ctx context.Context) error {
	for _, e := range w.sample(ctx) {
		if err := w.Emit(e); err != nil {
			return err
		}
	}
	return nil
}

func (w *Watcher) sample(ctx context.Context) (out []event.Event) {
	w.health.begin()
	covered, rootCount, children := 0, len(w.RootProcesses), 0
	defer func() {
		if ctx.Err() == nil {
			out = append(out, w.health.finish(w.SessionID, time.Now().UTC(), w.Interval, covered, rootCount, children))
		}
	}()
	out = []event.Event{}
	items, err := process.ProcessesWithContext(ctx)
	if err != nil {
		out = append(out, w.samplingFailure("processes", err)...)
		return out
	}
	out = append(out, w.observeHealth(event.Process{Name: "collector"}, "processes", nil)...)
	self, err := process.NewProcess(int32(os.Getpid()))
	if err != nil {
		out = append(out, w.samplingFailure("self", err)...)
		return out
	}
	out = append(out, w.observeHealth(event.Process{Name: "collector"}, "self", nil)...)
	user, err := self.UsernameWithContext(ctx)
	if err != nil {
		out = append(out, w.samplingFailure("current_user", err)...)
		return out
	}
	out = append(out, w.observeHealth(event.Process{Name: "collector"}, "current_user", nil)...)
	nextNet, nextFiles, nextProc := map[string]bool{}, map[string]bool{}, map[string]bool{}
	nextIO := map[string][2]uint64{}
	selectedPIDs := map[int]bool{}
	selectedProcesses := map[int]event.Process{}
	records := w.processSnapshot(ctx, items, user)
	activeRoots, rootErrors := w.verifiedRoots(ctx, records)
	selectedInstances := w.expandVerifiedScope(records, activeRoots)
	for _, p := range items {
		if ctx.Err() != nil {
			break
		}
		if p.Pid == int32(os.Getpid()) {
			continue
		}
		record, exists := records[int(p.Pid)]
		if !exists {
			continue
		}
		if record.identityErr != nil {
			out = append(out, w.observeHealth(record.identity, "process_identity", record.identityErr)...)
			continue
		}
		created, name := record.identity.CreatedAtMS, record.identity.Name
		if len(w.RootProcesses) > 0 {
			if !selectedInstances[identityKey(record.identity)] {
				continue
			}
		} else if !w.Names[strings.ToLower(name)] && !w.Names[strconv.Itoa(int(p.Pid))] {
			continue
		}
		key := fmt.Sprintf("%d/%d", p.Pid, created)
		proc := record.identity
		processEventsStart := len(out)
		nextProc[key] = true
		w.processInfo[key] = proc
		if !w.seenProcesses[key] {
			out = append(out, event.New(w.SessionID, "net", proc, "process_observed", "direct", nil))
		}
		counters, err := processIOCounters(ctx, p)
		if err == nil && counters == nil {
			err = fmt.Errorf("process IO counters unavailable")
		}
		out = append(out, w.sampleStatus(proc, "process_io", err)...)
		if err == nil && counters != nil {
			current := [2]uint64{counters.ReadBytes, counters.WriteBytes}
			nextIO[key] = current
			previous, exists := w.lastIO[key]
			if exists && current != previous && current[0] >= previous[0] && current[1] >= previous[1] {
				out = append(out, event.New(w.SessionID, "net", proc, "process_io", "direct", map[string]any{
					"io_read_bytes": current[0] - previous[0], "io_write_bytes": current[1] - previous[1], "metric": "process_io_not_network"}))
			}
		}
		connections, err := p.ConnectionsWithContext(ctx)
		out = append(out, w.sampleStatus(proc, "process_connections", err)...)
		if err == nil {
			for _, conn := range connections {
				if conn.Raddr.IP == "" || conn.Raddr.Port == 0 {
					continue
				}
				connectionKey := fmt.Sprintf("%s/%d/%s:%d/%s:%d", key, conn.Type, conn.Laddr.IP, conn.Laddr.Port, conn.Raddr.IP, conn.Raddr.Port)
				nextNet[connectionKey] = true
				if w.seenNet[connectionKey] {
					continue
				}
				host := conn.Raddr.IP
				hostSource := "socket_ip"
				if w.ReverseDNS {
					lookupCtx, cancel := context.WithTimeout(ctx, 250*time.Millisecond)
					if names, lookupErr := net.DefaultResolver.LookupAddr(lookupCtx, conn.Raddr.IP); lookupErr == nil && len(names) > 0 {
						host = strings.TrimSuffix(names[0], ".")
						hostSource = "reverse_dns"
					}
					cancel()
				}
				out = append(out, event.New(w.SessionID, "net", proc, "connection_observed", "direct", map[string]any{
					"remote_ip": conn.Raddr.IP, "port": conn.Raddr.Port, "local_ip": conn.Laddr.IP, "local_port": conn.Laddr.Port,
					"remote_host": host, "host_source": hostSource, "status": conn.Status, "metric": "connection_only", "direction": "unknown", "bytes_out": nil, "bytes_in": nil}))
			}
		}
		var files []process.OpenFilesStat
		if len(w.Roots) > 0 {
			files, err = processOpenFiles(ctx, p)
			out = append(out, w.sampleStatus(proc, "open_files_best_effort", err)...)
		}
		if err == nil {
			for _, f := range files {
				resolved, err := filepath.EvalSymlinks(f.Path)
				if err != nil {
					continue
				}
				allowed := false
				for _, root := range w.Roots {
					if ContainsPath(root, resolved) {
						allowed = true
						break
					}
				}
				if !allowed {
					continue
				}
				fileKey := key + "/" + f.Path
				nextFiles[fileKey] = true
				if w.seenFiles[fileKey] {
					continue
				}
				out = append(out, event.New(w.SessionID, "file", proc, "file_open_observed", "direct", map[string]any{
					"path": f.Path, "access": "unknown", "sampling": "best_effort", "sensitive_path": sensitive(f.Path)}))
			}
		}
		if err := w.verifyScopeIdentity(ctx, records, proc); err != nil {
			out = out[:processEventsStart]
			w.health.forgetProcess(proc)
			out = append(out, w.observeHealth(proc, "process_identity", err)...)
			delete(nextProc, key)
			delete(nextIO, key)
			// Discard de-duplication state for unverified evidence.
			for item := range nextNet {
				if strings.HasPrefix(item, key+"/") {
					delete(nextNet, item)
				}
			}
			for item := range nextFiles {
				if strings.HasPrefix(item, key+"/") {
					delete(nextFiles, item)
				}
			}
			if !w.seenProcesses[key] {
				delete(w.processInfo, key)
			}
			continue
		}
		selectedPIDs[int(p.Pid)] = true
		selectedProcesses[int(p.Pid)] = proc
	}
	if ctx.Err() != nil {
		return out
	}
	out = append(out, w.selectionEvents(len(selectedPIDs))...)
	if networkBytesAvailable && len(selectedPIDs) > 0 {
		samples, sampleErr := sampleNetworkBytes(ctx, selectedPIDs)
		for pid, proc := range selectedProcesses {
			if err := w.verifyScopeIdentity(ctx, records, proc); err != nil {
				w.health.forgetProcess(proc)
				out = append(out, w.observeHealth(proc, "network_identity", err)...)
				delete(selectedProcesses, pid)
			}
		}
		out = append(out, w.networkEvents(selectedProcesses, samples, sampleErr, time.Now().UTC())...)
	} else {
		w.lastNetwork = map[string]networkCounter{}
		if !networkBytesAvailable {
			for _, proc := range selectedProcesses {
				out = append(out, w.observeHealth(proc, "network_bytes", errCollectorUnsupported)...)
			}
		}
	}
	if len(w.RootProcesses) > 0 {
		out = append(out, w.rootHealth(ctx, selectedProcesses, rootErrors)...)
		out = append(out, w.scopeEvents(selectedProcesses)...)
	}

	covered = len(selectedProcesses)
	for _, proc := range selectedProcesses {
		if len(w.RootProcesses) > 0 && w.RootProcesses[proc.PID] != proc.CreatedAtMS {
			children++
		}
	}
	for key := range w.seenProcesses {
		if !nextProc[key] {
			if proc, ok := w.processInfo[key]; ok {
				out = append(out, event.New(w.SessionID, "net", proc, "process_no_longer_observed", "direct", map[string]any{"reason": "process no longer matched the allowlist or exited"}))
				state, reason := collectorErrorState(verifyProcessIdentity(ctx, proc))
				if state == healthOK {
					state, reason = healthIdle, "process_left_scope"
				}
				out = append(out, w.health.observe(w.SessionID, proc, "process_lifecycle", state, reason)...)
			}
			delete(w.processInfo, key)
		}
	}
	w.seenNet, w.seenFiles, w.seenProcesses, w.lastIO = nextNet, nextFiles, nextProc, nextIO
	return out
}

func sensitive(path string) bool {
	path = strings.ToLower(filepath.ToSlash(path))
	base := filepath.Base(path)
	return strings.Contains(path, "/.git/") || strings.Contains(path, "/.ssh/") || strings.Contains(path, "/.aws/") || strings.Contains(path, "/.kube/") || strings.Contains(path, "/.config/gcloud/") || strings.HasPrefix(base, ".env") || strings.HasPrefix(base, "id_rsa") || strings.HasSuffix(base, ".pem") || base == ".npmrc" || strings.HasSuffix(path, "/.docker/config.json")
}
