//go:build darwin

package collect

import (
	"context"
	"strconv"

	"github.com/shirou/gopsutil/v4/process"
)

// gopsutil v4.25.6 does not implement OpenFiles on Darwin. Use the system lsof
// field protocol directly, selecting only this already verified process.
func processOpenFiles(ctx context.Context, p *process.Process) ([]process.OpenFilesStat, error) {
	output, err := boundedCommandOutput(ctx, "/usr/sbin/lsof", "-nP", "-a", "-p", strconv.Itoa(int(p.Pid)), "-F0pfn")
	if err != nil {
		return nil, err
	}
	return parseLsofFiles(output, int(p.Pid))
}
