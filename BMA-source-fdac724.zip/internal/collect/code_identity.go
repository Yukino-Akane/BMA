package collect

import (
	"encoding/hex"
	"fmt"
	"regexp"
)

var codeIdentityToken = regexp.MustCompile(`^[A-Za-z0-9._-]{1,256}$`)

func validateCodeIdentity(identity CodeIdentity) error {
	if (identity.BundleID != "" && identity.BundleID != identity.Identifier) || !codeIdentityToken.MatchString(identity.Identifier) {
		return fmt.Errorf("invalid or mismatched bundle/signing identifier")
	}
	if identity.TeamID != "" && !codeIdentityToken.MatchString(identity.TeamID) {
		return fmt.Errorf("invalid team identifier")
	}
	hash, err := hex.DecodeString(identity.CDHash)
	if err != nil || len(hash) != 20 {
		return fmt.Errorf("code directory hash must be 40 hexadecimal characters")
	}
	return nil
}
