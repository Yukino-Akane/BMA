package collect

import (
	"context"
	"fmt"
	"net"
	"os"
	"strconv"
	"strings"

	"behavior-monitoring-audit/internal/event"
	"github.com/shirou/gopsutil/v4/process"
)

// ResolveProxyPeer attributes only sockets belonging to a selected process of
// the current user. Failure to establish that evidence denies proxy access.
func (w *Watcher) ResolveProxyPeer(ctx context.Context, source, destination net.Addr) (event.Process, error) {
	src, ok := source.(*net.TCPAddr)
	if !ok {
		return event.Process{}, fmt.Errorf("source must be TCP")
	}
	dst, ok := destination.(*net.TCPAddr)
	if !ok {
		return event.Process{}, fmt.Errorf("destination must be TCP")
	}
	self, err := process.NewProcess(int32(os.Getpid()))
	if err != nil {
		return event.Process{}, err
	}
	owner, err := self.UsernameWithContext(ctx)
	if err != nil {
		return event.Process{}, err
	}
	procs, err := process.ProcessesWithContext(ctx)
	if err != nil {
		return event.Process{}, err
	}
	current := w.processSnapshot(ctx, procs, owner)
	activeRoots, _ := w.verifiedRoots(ctx, current)
	selected := w.expandVerifiedScope(current, activeRoots)
	for _, entry := range current {
		if entry.identityErr != nil {
			continue
		}
		p := entry.p
		expected := entry.identity
		if len(w.RootProcesses) > 0 && !selected[identityKey(expected)] {
			continue
		}
		if len(w.RootProcesses) == 0 && !w.Names[strings.ToLower(expected.Name)] && !w.Names[strconv.Itoa(expected.PID)] {
			continue
		}
		connections, err := p.ConnectionsWithContext(ctx)
		if err != nil {
			continue
		}
		for _, conn := range connections {
			if int(conn.Laddr.Port) == src.Port && int(conn.Raddr.Port) == dst.Port && src.IP.Equal(net.ParseIP(conn.Laddr.IP)) && dst.IP.Equal(net.ParseIP(conn.Raddr.IP)) {
				if err := w.verifyScopeIdentity(ctx, current, expected); err != nil {
					return event.Process{}, err
				}
				return expected, nil
			}
		}
	}
	return event.Process{}, fmt.Errorf("proxy peer is not a selected process with a verifiable socket")
}
