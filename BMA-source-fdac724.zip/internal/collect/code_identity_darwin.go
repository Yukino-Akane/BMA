//go:build darwin

package collect

import (
	"context"
	"fmt"
	"strconv"
	"time"
)

func codeIdentityRequirement(expected CodeIdentity) (string, error) {
	if err := validateCodeIdentity(expected); err != nil {
		return "", err
	}
	requirement := `=identifier "` + expected.Identifier + `" and cdhash H"` + expected.CDHash + `"`
	// TeamIdentifier is part of the signed CodeDirectory pinned by CDHash.
	// Do not equate it with certificate subject.OU: Apple platform binaries
	// legitimately have a different certificate subject (e.g. system Python).
	return requirement, nil
}

// A numeric codesign target validates the running code, including exec changes
// that preserve PID/start time. Requirements pin the originally selected code.
func verifyCodeIdentity(ctx context.Context, pid int, expected CodeIdentity) error {
	checkCtx, cancel := context.WithTimeout(ctx, 2*time.Second)
	defer cancel()
	requirement, err := codeIdentityRequirement(expected)
	if err != nil {
		return err
	}
	if _, err := boundedCommandOutput(checkCtx, "/usr/bin/codesign", "--verify", "-R", requirement, strconv.Itoa(pid)); err != nil {
		return fmt.Errorf("root live code identity could not be verified")
	}
	return nil
}
