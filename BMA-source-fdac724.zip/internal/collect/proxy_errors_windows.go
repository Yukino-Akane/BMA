package collect

import "golang.org/x/sys/windows"

const (
	proxyRefusedError = windows.WSAECONNREFUSED
	proxyResetError   = windows.WSAECONNRESET
)
