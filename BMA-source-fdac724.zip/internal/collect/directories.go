package collect

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// ContainsPath is a lexical containment check. Callers must resolve a root
// first; actual file reads use os.Root rather than relying on this check.
func ContainsPath(root, path string) bool {
	rel, err := filepath.Rel(root, path)
	return err == nil && (rel == "." || filepath.IsLocal(rel))
}

func directory(path string) (string, error) {
	if strings.TrimSpace(path) == "" {
		return "", fmt.Errorf("watch directory must not be empty")
	}
	abs, err := filepath.Abs(path)
	if err != nil {
		return "", err
	}
	abs, err = filepath.EvalSymlinks(abs)
	if err != nil {
		return "", err
	}
	info, err := os.Stat(abs)
	if err != nil {
		return "", err
	}
	if !info.IsDir() {
		return "", fmt.Errorf("watch path must be a directory: %s", abs)
	}
	return abs, nil
}

func watchDirectories(paths []string) ([]string, error) {
	var roots []string
	for _, path := range paths {
		root, err := directory(path)
		if err != nil {
			return nil, err
		}
		covered := false
		for _, existing := range roots {
			if ContainsPath(existing, root) {
				covered = true
				break
			}
		}
		if covered {
			continue
		}
		filtered := roots[:0]
		for _, existing := range roots {
			if !ContainsPath(root, existing) {
				filtered = append(filtered, existing)
			}
		}
		roots = append(filtered, root)
	}
	return roots, nil
}
