package collect

import (
	"bufio"
	"context"
	"fmt"
	"io"
	"net"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"

	"behavior-monitoring-audit/internal/event"
)

// Proxy is an explicitly enabled loopback HTTP/CONNECT byte counter. It never
// decrypts TLS. Every forwarded connection is attributed to a verified
// selected-process socket. Request bodies and headers are never logged.
type Proxy struct {
	listener    net.Listener
	session     string
	interval    time.Duration
	emit        func(event.Event) error
	mu          sync.Mutex
	closed      bool
	connections map[net.Conn]struct{}
	authorize   func(context.Context, net.Addr, net.Addr) (event.Process, error)
	ctx         context.Context
	cancel      context.CancelFunc
	workers     sync.WaitGroup
	accepted    chan struct{}
	closeDone   chan struct{}
	closeErr    error
	upstream    string
}

func StartProxy(session string, port int, upstreamURL string, interval time.Duration, emit func(event.Event) error, authorize func(context.Context, net.Addr, net.Addr) (event.Process, error)) (*Proxy, net.Listener, error) {
	if emit == nil || authorize == nil {
		return nil, nil, fmt.Errorf("proxy requires selected-process authorization and an event sink")
	}
	if interval <= 0 {
		return nil, nil, fmt.Errorf("proxy sampling interval must be positive")
	}
	if port < 0 || port > 65535 {
		return nil, nil, fmt.Errorf("proxy port out of range")
	}
	upstream, err := parseProxyUpstream(upstreamURL)
	if err != nil {
		return nil, nil, err
	}
	listener, err := net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", port))
	if err != nil {
		return nil, nil, err
	}
	if upstream == listener.Addr().String() {
		listener.Close()
		return nil, nil, fmt.Errorf("upstream proxy cannot be the BMA listener")
	}
	ctx, cancel := context.WithCancel(context.Background())
	p := &Proxy{listener: listener, session: session, interval: interval, emit: emit, connections: map[net.Conn]struct{}{}, authorize: authorize, ctx: ctx, cancel: cancel, accepted: make(chan struct{}), closeDone: make(chan struct{}), upstream: upstream}
	go p.acceptLoop()
	return p, listener, nil
}

func (p *Proxy) acceptLoop() {
	defer close(p.accepted)
	for {
		conn, err := p.listener.Accept()
		if err != nil {
			p.mu.Lock()
			closed := p.closed
			p.mu.Unlock()
			if closed {
				return
			}
			_ = p.emit(event.New(p.session, "net", event.Process{Name: "collector"}, "collector_error", "direct", map[string]any{"source": "proxy_listener", "reason": "listener_failed", "coverage": "incomplete"}))
			return
		}
		p.mu.Lock()
		if p.closed {
			p.mu.Unlock()
			_ = conn.Close()
			return
		}
		p.connections[conn] = struct{}{}
		p.workers.Add(1)
		p.mu.Unlock()
		go p.handle(conn)
	}
}

func (p *Proxy) handle(client net.Conn) {
	defer p.workers.Done()
	defer client.Close()
	defer func() { p.mu.Lock(); delete(p.connections, client); p.mu.Unlock() }()
	_ = client.SetDeadline(time.Now().Add(90 * time.Second))
	// Limit only request headers; restore streaming reads before consuming a body.
	limited := &io.LimitedReader{R: client, N: 64 * 1024}
	reader := bufio.NewReader(limited)
	req, requestErr := http.ReadRequest(reader)
	authorizationCtx, cancel := context.WithTimeout(p.ctx, 5*time.Second)
	proc, err := p.authorize(authorizationCtx, client.RemoteAddr(), client.LocalAddr())
	cancel()
	if err != nil || proc.PID <= 0 || proc.CreatedAtMS <= 0 {
		if p.ctx.Err() == nil {
			_ = p.emit(event.New(p.session, "net", event.Process{Name: "collector"}, "collector_error", "direct", map[string]any{"source": "proxy_authorization", "reason": "peer_unverified", "coverage": "incomplete"}))
		}
		writeProxyError(client, http.StatusForbidden)
		return
	}
	if requestErr != nil {
		code := proxyErrorCode(requestErr)
		if code == "io_error" {
			code = "invalid_request"
		}
		if limited.N == 0 {
			code = "header_limit"
		}
		p.recordFailure(proc, "", "request_headers", code, "", "")
		writeProxyError(client, http.StatusBadRequest)
		return
	}
	limited.N = 1<<63 - 1
	host := req.Host
	if req.Method == http.MethodConnect {
		if !validHostPort(host) {
			p.recordFailure(proc, "", "request_headers", "invalid_target", "", "connect_tunnel")
			writeProxyError(client, http.StatusBadRequest)
			return
		}
		server, err := p.dial(host)
		if err != nil {
			p.recordFailure(proc, host, "dial", proxyErrorCode(err), "", "connect_tunnel")
			writeProxyError(client, http.StatusBadGateway)
			return
		}
		defer server.Close()
		defer p.forget(server)
		transfer := p.beginTransfer(host, server, proc, "", "connect_tunnel")
		if _, err := io.WriteString(client, "HTTP/1.1 200 Connection Established\r\n\r\n"); err != nil {
			transfer.finish("handshake", err)
			return
		}
		_ = client.SetDeadline(time.Time{})
		stage, err := proxyTunnel(reader, client, server, transfer)
		transfer.finish(stage, err)
		return
	}
	if req.URL == nil || req.URL.Host == "" || req.URL.Scheme != "http" || req.URL.User != nil {
		p.recordFailure(proc, "", "request_headers", "unsupported_target", req.Method, "http")
		writeProxyError(client, http.StatusBadRequest)
		return
	}
	host = req.URL.Host
	if req.URL.Port() == "" {
		host = net.JoinHostPort(req.URL.Hostname(), "80")
	}
	server, err := p.dial(host)
	if err != nil {
		p.recordFailure(proc, host, "dial", proxyErrorCode(err), req.Method, "http")
		writeProxyError(client, http.StatusBadGateway)
		return
	}
	defer server.Close()
	defer p.forget(server)
	transfer := p.beginTransfer(host, server, proc, req.Method, "http")
	_ = server.SetDeadline(time.Now().Add(90 * time.Second))
	req.RequestURI = ""
	req.URL.Scheme, req.URL.Host = "", ""
	req.Close = true
	for _, key := range []string{"Proxy-Authorization", "Proxy-Connection"} {
		req.Header.Del(key)
	}
	counted := &proxyWriter{conn: server, transfer: transfer, outbound: true}
	var transferErr error
	stage := "request_body"
	defer func() { transfer.finish(stage, transferErr) }()
	if transferErr = req.Write(counted); transferErr != nil {
		return
	}
	stage = "response"
	_, transferErr = io.Copy(&proxyWriter{conn: client, transfer: transfer}, server)
}

func proxyTunnel(buffered io.Reader, client, server net.Conn, transfer *proxyTransfer) (string, error) {
	type result struct {
		stage string
		err   error
	}
	results := make(chan result, 2)
	go func() {
		_, err := io.Copy(&proxyWriter{conn: server, transfer: transfer, outbound: true}, buffered)
		if tcp, ok := server.(interface{ CloseWrite() error }); ok {
			_ = tcp.CloseWrite()
		}
		results <- result{stage: "tunnel_outbound", err: err}
	}()
	go func() {
		_, err := io.Copy(&proxyWriter{conn: client, transfer: transfer}, server)
		if tcp, ok := client.(*net.TCPConn); ok {
			_ = tcp.CloseWrite()
		}
		results <- result{stage: "tunnel_inbound", err: err}
	}()
	first := <-results
	if first.err != nil {
		// An error must release the other direction instead of leaking a worker.
		_ = server.Close()
		_ = client.Close()
	}
	second := <-results
	stage, err := second.stage, second.err
	if first.err != nil {
		stage, err = first.stage, first.err
	}
	return stage, err
}

func writeProxyError(conn net.Conn, status int) {
	_, _ = fmt.Fprintf(conn, "HTTP/1.1 %d %s\r\nConnection: close\r\n\r\n", status, http.StatusText(status))
}

func (p *Proxy) Close() error {
	p.mu.Lock()
	if p.closed {
		p.mu.Unlock()
		<-p.closeDone
		return p.closeErr
	}
	p.closed = true
	p.cancel()
	err := p.listener.Close()
	for conn := range p.connections {
		_ = conn.Close()
	}
	p.connections = map[net.Conn]struct{}{}
	p.mu.Unlock()
	<-p.accepted
	p.workers.Wait()
	p.closeErr = err
	close(p.closeDone)
	return err
}

func (p *Proxy) dial(host string) (net.Conn, error) {
	if p.upstream != "" {
		return p.dialUpstream(host)
	}
	return p.dialSocket(host)
}

func (p *Proxy) dialSocket(host string) (net.Conn, error) {
	dialer := net.Dialer{Timeout: 15 * time.Second}
	conn, err := dialer.DialContext(p.ctx, "tcp", host)
	if err != nil {
		return nil, err
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.closed {
		conn.Close()
		return nil, net.ErrClosed
	}
	p.connections[conn] = struct{}{}
	return conn, nil
}

func (p *Proxy) forget(conn net.Conn) {
	if buffered, ok := conn.(*proxyBufferedConn); ok {
		conn = buffered.Conn
	}
	p.mu.Lock()
	delete(p.connections, conn)
	p.mu.Unlock()
}
func validHostPort(host string) bool {
	host = strings.TrimSpace(host)
	if host == "" {
		return false
	}
	name, port, err := net.SplitHostPort(host)
	if err != nil || name == "" || strings.ContainsAny(name, "/@?#\\") {
		return false
	}
	n, err := strconv.Atoi(port)
	return err == nil && n > 0 && n <= 65535
}
