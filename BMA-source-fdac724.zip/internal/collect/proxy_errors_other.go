//go:build !windows

package collect

import "syscall"

const (
	proxyRefusedError = syscall.ECONNREFUSED
	proxyResetError   = syscall.ECONNRESET
)
