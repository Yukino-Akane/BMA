package collect

import (
	"context"
	"errors"
	"io"
	"net"
	"sync"
	"time"

	"behavior-monitoring-audit/internal/event"
)

// Error categories never include raw request text, headers or error messages.
func proxyErrorCode(err error) string {
	var dns *net.DNSError
	var network net.Error
	switch {
	case errors.Is(err, errUpstreamRejected):
		return "upstream_rejected"
	case errors.Is(err, errUpstreamResponse):
		return "upstream_invalid_response"
	case errors.Is(err, context.Canceled):
		return "canceled"
	case errors.As(err, &network) && network.Timeout():
		return "timeout"
	case errors.As(err, &dns):
		return "dns_error"
	case errors.Is(err, proxyRefusedError):
		return "connection_refused"
	case errors.Is(err, proxyResetError):
		return "connection_reset"
	case errors.Is(err, net.ErrClosed):
		return "connection_closed"
	case errors.Is(err, io.ErrUnexpectedEOF):
		return "incomplete_stream"
	default:
		return "io_error"
	}
}

func (p *Proxy) recordFailure(proc event.Process, host, stage, code, method, transport string) {
	if p.ctx.Err() != nil {
		return
	}
	_ = p.emit(event.New(p.session, "net", proc, "connection_failed", "direct", p.routeDetail(map[string]any{"source": "proxy", "proxy": true, "remote_host": host, "host_source": "proxy_request", "stage": stage, "error_code": code, "metric": "connection_only", "http_method": method, "transport": transport})))
}

type proxyTransfer struct {
	proxy                        *Proxy
	process                      event.Process
	host, remoteIP, connectionID string
	method, transport            string
	mu                           sync.Mutex
	periodStart                  time.Time
	out, in                      uint64
	emitted                      bool
	stop, done                   chan struct{}
}

func (p *Proxy) beginTransfer(host string, server net.Conn, proc event.Process, method, transport string) *proxyTransfer {
	remoteIP := ""
	if remote, ok := server.RemoteAddr().(*net.TCPAddr); ok && p.upstream == "" {
		remoteIP = remote.IP.String()
	}
	e := event.New(p.session, "net", proc, "connection_observed", "direct", p.routeDetail(map[string]any{"source": "proxy", "proxy": true, "remote_host": host, "remote_ip": remoteIP, "host_source": "proxy_request", "status": "connected", "metric": "connection_only", "direction": "outbound", "http_method": method, "transport": transport}))
	_ = p.emit(e)
	transfer := &proxyTransfer{proxy: p, process: proc, host: host, remoteIP: remoteIP, connectionID: e.ID, method: method, transport: transport, periodStart: time.Now(), stop: make(chan struct{}), done: make(chan struct{})}
	go transfer.run()
	return transfer
}

// Each interval contains successful writes only. A write that spans a flush
// retains its actual start bound, so late completion does not invent timing.
func (t *proxyTransfer) add(outbound bool, count uint64, started time.Time) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if started.Before(t.periodStart) {
		t.periodStart = started
	}
	if outbound {
		t.out += count
	} else {
		t.in += count
	}
}

func (t *proxyTransfer) run() {
	defer close(t.done)
	ticker := time.NewTicker(t.proxy.interval)
	defer ticker.Stop()
	for {
		select {
		case <-t.stop:
			return
		case <-ticker.C:
			t.flush(false)
		}
	}
}

func (t *proxyTransfer) flush(final bool) {
	t.mu.Lock()
	ended := time.Now()
	started, out, in := t.periodStart, t.out, t.in
	emit := out != 0 || in != 0 || (final && !t.emitted)
	t.periodStart, t.out, t.in = ended, 0, 0
	t.emitted = t.emitted || emit
	t.mu.Unlock()
	if !emit {
		return
	}
	detail := map[string]any{"source": "proxy", "proxy": true, "remote_host": t.host, "remote_ip": t.remoteIP, "host_source": "proxy_request", "connection_event_id": t.connectionID, "bytes_in": in, "bytes_out": out, "metric": "network_bytes", "direction": "outbound", "sample_start": started.UTC().Format(time.RFC3339Nano), "sample_end": ended.UTC().Format(time.RFC3339Nano), "window_sec": ended.Sub(started).Seconds(), "http_method": t.method, "transport": t.transport}
	_ = t.proxy.emit(event.New(t.proxy.session, "net", t.process, "egress", "direct", t.proxy.routeDetail(detail)))
}

func (t *proxyTransfer) finish(stage string, err error) {
	close(t.stop)
	<-t.done
	t.flush(true)
	kind, reason, code := "connection_closed", "stream_ended", ""
	if err != nil {
		kind, reason, code = "connection_failed", "transfer_failed", proxyErrorCode(err)
	}
	if t.proxy.ctx.Err() != nil {
		kind, reason, code = "connection_closed", "observation_stopped", ""
	}
	_ = t.proxy.emit(event.New(t.proxy.session, "net", t.process, kind, "direct", t.proxy.routeDetail(map[string]any{"source": "proxy", "proxy": true, "remote_host": t.host, "host_source": "proxy_request", "connection_event_id": t.connectionID, "reason": reason, "stage": stage, "error_code": code, "metric": "connection_only", "http_method": t.method, "transport": t.transport})))
}

// Expose only Write to io.Copy, so sendfile/ReaderFrom cannot bypass counting.
type proxyWriter struct {
	conn     net.Conn
	transfer *proxyTransfer
	outbound bool
}

func (w *proxyWriter) Write(data []byte) (int, error) {
	started := time.Now()
	n, err := w.conn.Write(data)
	if n > 0 {
		w.transfer.add(w.outbound, uint64(n), started)
	}
	return n, err
}
