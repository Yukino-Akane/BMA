package scan

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/rules"
)

type pattern struct {
	rule, severity string
	re             *regexp.Regexp
}

var patterns = []pattern{
	{"static/network-client", "medium", regexp.MustCompile(`(?i)(requests\.(post|put|request)|urllib\.request|fetch\s*\(|curl\s+|Invoke-WebRequest)`)},
	{"static/shell-execution", "medium", regexp.MustCompile(`(?i)(subprocess\.|os\.system\s*\(|child_process|exec\s*\()`)},
	{"static/credential-access", "high", regexp.MustCompile(`(?i)(api[_-]?key|access[_-]?token|secret[_-]?key|password|private[_-]?key)`)},
	{"static/declared-permissions", "medium", regexp.MustCompile(`(?i)(permissions?|capabilities?|scopes?)\"?\s*[:=]`)},
	{"static/external-domain", "medium", regexp.MustCompile(`https?://[^\s\"'<>]+`)},
}
var installPattern = regexp.MustCompile(`(?i)(pre|post)?(install|uninstall|setup)\"?\s*[:=]`)
var names = map[string]bool{"package.json": true, "pyproject.toml": true, "setup.py": true, "setup.cfg": true, "manifest.json": true, "plugin.json": true}
var suffixes = map[string]bool{".c": true, ".cc": true, ".cpp": true, ".go": true, ".java": true, ".js": true, ".json": true, ".md": true, ".py": true, ".rs": true, ".sh": true, ".ts": true, ".tsx": true, ".toml": true, ".txt": true, ".yaml": true, ".yml": true, ".ps1": true}

func Scan(root, session string) ([]event.Event, []rules.Finding, error) {
	root, err := filepath.Abs(root)
	if err != nil {
		return nil, nil, err
	}
	root, err = filepath.EvalSymlinks(root)
	if err != nil {
		return nil, nil, err
	}
	info, err := os.Stat(root)
	if err != nil {
		return nil, nil, err
	}
	targets := []string{root}
	if info.IsDir() {
		targets = nil
		err = filepath.Walk(root, func(path string, i os.FileInfo, e error) error {
			if e != nil {
				return e
			}
			if i.Mode().IsRegular() {
				targets = append(targets, path)
			}
			return nil
		})
		if err != nil {
			return nil, nil, err
		}
	}
	events := []event.Event{}
	findings := []rules.Finding{}
	for _, path := range targets {
		ext := strings.ToLower(filepath.Ext(path))
		if !suffixes[ext] || infoTooLarge(path) {
			continue
		}
		file, err := os.Open(path)
		if err != nil {
			return nil, nil, fmt.Errorf("cannot read scan target: %w", err)
		}
		scanner := bufio.NewScanner(file)
		scanner.Buffer(make([]byte, 4096), 1_000_001)
		lineNo := 0
		lineHits := map[string][]string{}
		for scanner.Scan() {
			lineNo++
			line := scanner.Text()
			for _, p := range patterns {
				if p.rule == "static/declared-permissions" && !map[string]bool{".json": true, ".yaml": true, ".yml": true, ".toml": true}[ext] {
					continue
				}
				if p.re.MatchString(line) {
					id := event.EventID()
					events = append(events, event.Event{ID: id, TS: time.Now().UTC(), Layer: "file", SessionID: session, Process: event.Process{Name: "static-scanner"}, Kind: "static_indicator", Attribution: "direct", Detail: map[string]any{"path": path, "line": lineNo, "rule": p.rule}})
					lineHits[p.rule] = append(lineHits[p.rule], id)
				}
			}
			if names[strings.ToLower(filepath.Base(path))] && installPattern.MatchString(line) {
				id := event.EventID()
				events = append(events, event.Event{ID: id, TS: time.Now().UTC(), Layer: "file", SessionID: session, Process: event.Process{Name: "static-scanner"}, Kind: "static_indicator", Attribution: "direct", Detail: map[string]any{"path": path, "line": lineNo, "rule": "static/install-hook"}})
				lineHits["static/install-hook"] = append(lineHits["static/install-hook"], id)
			}
		}
		_ = file.Close()
		if err := scanner.Err(); err != nil {
			return nil, nil, err
		}
		for rule, ids := range lineHits {
			severity := "medium"
			if rule == "static/credential-access" || rule == "static/install-hook" {
				severity = "high"
			}
			findings = append(findings, rules.Finding{Severity: severity, Rule: rule, Summary: fmt.Sprintf("文件 %s 存在需要检查的代码线索", filepath.Base(path)), EvidenceIDs: ids})
		}
	}
	sort.Slice(findings, func(i, j int) bool {
		if findings[i].Rule == findings[j].Rule {
			return findings[i].Summary < findings[j].Summary
		}
		return findings[i].Rule < findings[j].Rule
	})
	return events, findings, nil
}
func infoTooLarge(path string) bool {
	info, err := os.Stat(path)
	return err != nil || info.Size() > 1_000_000
}
