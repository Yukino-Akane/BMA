package event

import (
	"bytes"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestLoadJSONLValidatesAndSorts(t *testing.T) {
	p := filepath.Join(t.TempDir(), "events.jsonl")
	a := New("s", "net", Process{Name: "a"}, "egress", "direct", nil)
	b := New("s", "file", Process{Name: "a"}, "file_create", "temporal", nil)
	a.TS = b.TS.Add(time.Second)
	data := string(mustJSON(b)) + "\n" + string(mustJSON(a)) + "\n"
	if err := os.WriteFile(p, []byte(data), 0600); err != nil {
		t.Fatal(err)
	}
	values, err := LoadJSONL(p)
	if err != nil || len(values) != 2 || values[0].ID != b.ID {
		t.Fatalf("%#v %v", values, err)
	}
	if err := os.WriteFile(p, []byte(`{"id":"e"}`), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := LoadJSONL(p); err == nil {
		t.Fatal("accepted incomplete event")
	}
}

func TestLoadJSONLRejectsInvalidSchemaAndDuplicateIDs(t *testing.T) {
	base := New("s", "net", Process{Name: "agent"}, "egress", "direct", nil)
	severity := "high"
	cases := []struct {
		name string
		edit func(*Event)
		want string
	}{
		{"missing timestamp", func(e *Event) { e.TS = time.Time{} }, "timestamp"},
		{"invalid layer", func(e *Event) { e.Layer = "system" }, "layer"},
		{"invalid attribution", func(e *Event) { e.Attribution = "guessed" }, "attribution"},
		{"temporal network", func(e *Event) { e.Attribution = "temporal" }, "direct attribution"},
		{"collection severity", func(e *Event) { e.Severity = &severity }, "severity"},
	}
	path := filepath.Join(t.TempDir(), "events.jsonl")
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			e := base
			tc.edit(&e)
			if err := os.WriteFile(path, append(mustJSON(e), '\n'), 0600); err != nil {
				t.Fatal(err)
			}
			if _, err := LoadJSONL(path); err == nil || !strings.Contains(err.Error(), tc.want) {
				t.Fatalf("expected %q rejection, got %v", tc.want, err)
			}
		})
	}
	duplicate := append(append(mustJSON(base), '\n'), append(mustJSON(base), '\n')...)
	if err := os.WriteFile(path, duplicate, 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := LoadJSONL(path); err == nil || !strings.Contains(err.Error(), "duplicate event ID") {
		t.Fatalf("accepted duplicate ID: %v", err)
	}
}

func TestLoadJSONLHasByteAndEventLimits(t *testing.T) {
	path := filepath.Join(t.TempDir(), "events.jsonl")
	if err := os.WriteFile(path, nil, 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.Truncate(path, maxImportBytes+1); err != nil {
		t.Fatal(err)
	}
	if _, err := LoadJSONL(path); err == nil || !strings.Contains(err.Error(), "byte limit") {
		t.Fatalf("accepted oversized import: %v", err)
	}
	e := New("s", "file", Process{Name: "scanner"}, "file_create", "temporal", nil)
	var data bytes.Buffer
	for i := 0; i <= maxImportEvents; i++ {
		e.ID = fmt.Sprintf("e_%d", i)
		data.Write(mustJSON(e))
		data.WriteByte('\n')
	}
	if err := os.WriteFile(path, data.Bytes(), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := LoadJSONL(path); err == nil || !strings.Contains(err.Error(), "event limit") {
		t.Fatalf("accepted too many events: %v", err)
	}
}
