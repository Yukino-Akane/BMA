package event

import (
	"bytes"
	"encoding/json"
	"testing"
)

func TestNewUsesUnifiedSchema(t *testing.T) {
	e := New("s_test", "net", Process{PID: 42, Name: "agent"}, "egress", "direct", map[string]any{"remote_ip": "127.0.0.1"})
	if e.ID == "" || e.SessionID != "s_test" || e.Layer != "net" {
		t.Fatalf("invalid event: %#v", e)
	}
	var decoded map[string]any
	if err := json.Unmarshal(mustJSON(e), &decoded); err != nil {
		t.Fatal(err)
	}
	for _, key := range []string{"id", "ts", "layer", "session_id", "process", "kind", "attribution", "detail", "severity"} {
		if _, ok := decoded[key]; !ok {
			t.Errorf("missing schema field %q", key)
		}
	}
	if decoded["severity"] != nil {
		t.Fatal("collection-time severity must be null")
	}
	semantic := New("s_test", "semantic", Process{Name: "user"}, "goal", "direct", nil)
	data := mustJSON(semantic)
	if !bytes.Contains(data, []byte(`"pid":null`)) {
		t.Fatalf("unset PID must be null: %s", data)
	}
}

func mustJSON(value any) []byte {
	data, err := json.Marshal(value)
	if err != nil {
		panic(err)
	}
	return data
}

func TestProcessIdentitySurvivesJournalRoundTrip(t *testing.T) {
	e := New("s", "net", Process{PID: 42, Name: "agent", CreatedAtMS: 1789831861000}, "egress", "direct", nil)
	var decoded Event
	if err := json.Unmarshal(mustJSON(e), &decoded); err != nil {
		t.Fatal(err)
	}
	if decoded.Process != e.Process {
		t.Fatalf("process identity lost: %+v", decoded.Process)
	}
}
