package event

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"time"
)

type Process struct {
	PID         int    `json:"pid"`
	Name        string `json:"name"`
	Path        string `json:"path,omitempty"`
	CreatedAtMS int64  `json:"created_at_ms,omitempty"`
}

func (p Process) MarshalJSON() ([]byte, error) {
	var pid any
	if p.PID != 0 {
		pid = p.PID
	}
	value := map[string]any{"pid": pid, "name": p.Name}
	if p.Path != "" {
		value["path"] = p.Path
	}
	if p.CreatedAtMS > 0 {
		value["created_at_ms"] = p.CreatedAtMS
	}
	return json.Marshal(value)
}

type Event struct {
	ID          string         `json:"id"`
	TS          time.Time      `json:"ts"`
	Layer       string         `json:"layer"`
	SessionID   string         `json:"session_id"`
	Process     Process        `json:"process"`
	Kind        string         `json:"kind"`
	Attribution string         `json:"attribution"`
	Detail      map[string]any `json:"detail"`
	Severity    *string        `json:"severity"`
}

func SessionID() string {
	b := make([]byte, 6)
	_, _ = rand.Read(b)
	return "s_" + hex.EncodeToString(b)
}

func EventID() string {
	b := make([]byte, 6)
	_, _ = rand.Read(b)
	return "e_" + hex.EncodeToString(b)
}

func New(sessionID, layer string, process Process, kind, attribution string, detail map[string]any) Event {
	return Event{ID: EventID(), TS: time.Now().UTC(), Layer: layer, SessionID: sessionID, Process: process, Kind: kind, Attribution: attribution, Detail: detail}
}
