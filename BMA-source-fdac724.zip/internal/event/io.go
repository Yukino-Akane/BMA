package event

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"sort"
)

const (
	maxImportBytes     int64 = 64 * 1024 * 1024
	maxImportEvents          = 50000
	maxImportLineBytes       = 4 * 1024 * 1024
)

// LoadJSONLRecoverable reads the complete records that precede an interrupted
// final write. A process crash can leave the last JSONL record without its
// newline or with an incomplete JSON value; that tail is reported separately
// so recovery never silently turns it into a valid event.
func LoadJSONLRecoverable(path string, maxBytes int64, maxEvents int) ([]Event, bool, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, false, err
	}
	defer file.Close()
	info, err := file.Stat()
	if err != nil {
		return nil, false, err
	}
	if !info.Mode().IsRegular() || info.Size() > maxBytes {
		return nil, false, fmt.Errorf("journal must be a regular file within the session byte limit")
	}
	scanner := bufio.NewScanner(io.LimitReader(file, maxBytes+1))
	scanner.Buffer(make([]byte, 4096), 4*1024*1024+1)
	scanner.Split(func(data []byte, atEOF bool) (int, []byte, error) {
		if i := bytes.IndexByte(data, '\n'); i >= 0 {
			return i + 1, data[:i+1], nil
		}
		if atEOF && len(data) > 0 {
			return len(data), data, nil
		}
		return 0, nil, nil
	})
	var result []Event
	seen := make(map[string]bool)
	var total int64
	lineNumber := 0
	truncated := false
	for scanner.Scan() {
		lineNumber++
		line := scanner.Bytes()
		total += int64(len(line))
		if total > maxBytes {
			return nil, false, fmt.Errorf("journal exceeds session byte limit")
		}
		if line[len(line)-1] != '\n' {
			truncated = true
			break
		}
		if len(bytes.TrimSpace(line)) == 0 {
			continue
		}
		if len(result) >= maxEvents {
			return nil, false, fmt.Errorf("journal exceeds session event limit")
		}
		var item Event
		if err := json.Unmarshal(line, &item); err != nil {
			return nil, false, fmt.Errorf("invalid event at %s:%d", path, lineNumber)
		}
		if err := validateImportedEvent(item, seen); err != nil {
			return nil, false, fmt.Errorf("%s at %s:%d", err, path, lineNumber)
		}
		seen[item.ID] = true
		result = append(result, item)
	}
	if err := scanner.Err(); err != nil {
		return nil, false, fmt.Errorf("read journal: %w", err)
	}
	sort.SliceStable(result, func(i, j int) bool { return result[i].TS.Before(result[j].TS) })
	return result, truncated, nil
}

func LoadJSONL(path string) ([]Event, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	info, err := file.Stat()
	if err != nil {
		return nil, err
	}
	if !info.Mode().IsRegular() || info.Size() > maxImportBytes {
		return nil, fmt.Errorf("events import must be a regular file within the byte limit")
	}
	limited := &io.LimitedReader{R: file, N: maxImportBytes + 1}
	scanner := bufio.NewScanner(limited)
	scanner.Buffer(make([]byte, 4096), maxImportLineBytes+1)
	result := []Event{}
	seen := make(map[string]bool)
	line := 0
	for scanner.Scan() {
		line++
		if len(bytes.TrimSpace(scanner.Bytes())) == 0 {
			continue
		}
		if len(result) >= maxImportEvents {
			return nil, fmt.Errorf("events import exceeds event limit")
		}
		var item Event
		if err := json.Unmarshal(scanner.Bytes(), &item); err != nil {
			return nil, fmt.Errorf("invalid event at %s:%d", path, line)
		}
		if err := validateImportedEvent(item, seen); err != nil {
			return nil, fmt.Errorf("%s at %s:%d", err, path, line)
		}
		seen[item.ID] = true
		result = append(result, item)
	}
	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("read events: %w", err)
	}
	if maxImportBytes+1-limited.N > maxImportBytes {
		return nil, fmt.Errorf("events import exceeds byte limit")
	}
	sort.SliceStable(result, func(i, j int) bool { return result[i].TS.Before(result[j].TS) })
	return result, nil
}

func validateImportedEvent(item Event, seen map[string]bool) error {
	if item.ID == "" || item.SessionID == "" || item.Layer == "" || item.Kind == "" || item.Attribution == "" {
		return fmt.Errorf("incomplete event")
	}
	if item.TS.IsZero() || item.TS.Year() < 1970 || item.TS.Year() > 9999 {
		return fmt.Errorf("invalid event timestamp")
	}
	if item.Layer != "net" && item.Layer != "file" && item.Layer != "semantic" {
		return fmt.Errorf("invalid event layer")
	}
	if item.Attribution != "direct" && item.Attribution != "temporal" {
		return fmt.Errorf("invalid event attribution")
	}
	if item.Layer == "net" && item.Attribution != "direct" {
		return fmt.Errorf("network events require direct attribution")
	}
	if item.Severity != nil {
		return fmt.Errorf("event severity must be null")
	}
	if seen[item.ID] {
		return fmt.Errorf("duplicate event ID")
	}
	return nil
}
