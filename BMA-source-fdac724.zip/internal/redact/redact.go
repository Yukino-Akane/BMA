// Package redact constructs an allowlisted model payload. Unknown detail keys,
// source lines, file contents, command arguments and environment values never
// pass through the boundary. Collection omits raw tool arguments and matched
// source lines from local evidence; user-supplied goals remain in local reports.
package redact

import (
	"crypto/sha256"
	"fmt"
	"path"
	"regexp"
	"strings"

	"behavior-monitoring-audit/internal/event"
)

var secrets = regexp.MustCompile(`(?i)\b(?:sk-[a-z0-9_-]{8,}|gh[pousr]_[a-z0-9_]{8,}|github_pat_[a-z0-9_]{8,}|AKIA[A-Z0-9]{12,}|Bearer\s+\S+)`)
var assignments = regexp.MustCompile(`(?i)(api[_-]?key|access[_-]?token|secret|password|token)\s*[:=]\s*(?:"[^"]*"|'[^']*'|[^\s,;]+)`)
var paths = regexp.MustCompile(`(?:[a-zA-Z]:[\\/]|/|~/)[^\s"'<>]+`)
var extension = regexp.MustCompile(`^\.[a-z0-9]{1,8}$`)

func Text(value string) string {
	value = secrets.ReplaceAllString(value, "[redacted-secret]")
	value = assignments.ReplaceAllString(value, "$1=[redacted-secret]")
	return paths.ReplaceAllStringFunc(value, Path)
}

// Path preserves directory depth and extension without sending project names,
// usernames or filenames. Stable opaque tokens allow events to be correlated.
func Path(value string) string {
	normal := strings.ReplaceAll(value, `\`, "/")
	parts := strings.Split(strings.Trim(normal, "/"), "/")
	for i, part := range parts {
		if part == "" {
			continue
		}
		sum := sha256.Sum256([]byte(strings.Join(parts[:i+1], "/")))
		ext := ""
		if i == len(parts)-1 {
			ext = strings.ToLower(path.Ext(part))
			if !extension.MatchString(ext) {
				ext = ""
			}
		}
		parts[i] = fmt.Sprintf("p_%x%s", sum[:5], ext)
	}
	return "<path>/" + strings.Join(parts, "/")
}

func Events(events []event.Event, redactGoal bool) []event.Event {
	result := make([]event.Event, 0, len(events))
	for _, e := range events {
		clean := e
		clean.Process = event.Process{PID: e.Process.PID, Name: Text(e.Process.Name), CreatedAtMS: e.Process.CreatedAtMS}
		clean.Detail = make(map[string]any)
		for _, key := range []string{"size_bytes", "entropy", "deleted_after_sec", "window_sec", "bytes_out", "bytes_in", "io_read_bytes", "io_write_bytes", "port", "local_port", "line", "log_line", "log_record", "record_bytes", "limit", "used", "requested", "directory_registrations", "max_directory_registrations", "registered_path_bytes", "max_registered_path_bytes"} {
			if value, ok := e.Detail[key]; ok {
				switch value.(type) {
				case float64, int, int64, uint64, uint32, nil:
					clean.Detail[key] = value
				}
			}
		}
		for _, key := range []string{"sensitive_path", "synthetic", "proxy"} {
			if value, ok := e.Detail[key].(bool); ok {
				clean.Detail[key] = value
			}
		}
		for _, key := range []string{"metric", "direction", "role", "agent_role", "trust", "op", "sampling", "access", "tool", "remote_ip", "remote_host", "host_source", "transport_route", "upstream_proxy", "asn_org", "rule", "coverage", "time_source", "source", "sample_start", "sample_end", "stage", "error_code", "reason", "resource", "connection_event_id", "created_event_id"} {
			if value, ok := e.Detail[key].(string); ok {
				clean.Detail[key] = Text(value)
			}
		}
		if value, ok := e.Detail["path"].(string); ok {
			clean.Detail["path"] = Path(value)
		}
		if value, ok := e.Detail["watch_root"].(string); ok {
			clean.Detail["watch_root"] = Path(value)
		}
		if e.Kind == "goal" {
			if redactGoal {
				clean.Detail["text"] = "[redacted-goal]"
			} else if value, ok := e.Detail["text"].(string); ok {
				clean.Detail["text"] = Text(value)
			}
		}
		result = append(result, clean)
	}
	return result
}
