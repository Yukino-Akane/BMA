package redact

import (
	"testing"

	"behavior-monitoring-audit/internal/event"
)

func TestEventsNeverExposeSourceOrSecrets(t *testing.T) {
	e := event.New("s", "file", event.Process{Name: "agent"}, "file_create", "direct", map[string]any{"path": `C:\Users\Alice\project\.env`, "text": "API_KEY=sk-secretvalue"})
	clean := Events([]event.Event{e}, false)[0]
	if clean.Detail["path"] == e.Detail["path"] {
		t.Fatal("path was not redacted")
	}
	if clean.Detail["text"] != nil {
		t.Fatal("unallowlisted source text escaped")
	}
	if got := Text("token=sk-secretvalue C:/Users/Alice/a.py"); got == "token=sk-secretvalue C:/Users/Alice/a.py" {
		t.Fatal("text was not redacted")
	}
}
