package rules

import (
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
)

func correlationEvent(session, layer, kind string, process event.Process, at time.Time, detail map[string]any) event.Event {
	e := event.New(session, layer, process, kind, "direct", detail)
	e.TS = at
	return e
}

func findingForRule(findings []Finding, rule string) []Finding {
	result := []Finding{}
	for _, finding := range findings {
		if finding.Rule == rule {
			result = append(result, finding)
		}
	}
	return result
}

func TestCorrelationReportsArtifactWithoutClaimingUpload(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	file := correlationEvent("s", "file", "file_create", event.Process{Name: "unattributed"}, at, map[string]any{
		"path": "/tmp/workspace/snapshot.enc", "size_bytes": uint64(15 * 1024), "artifact_kind": "encrypted",
	})
	findings := EvaluateWithConfig([]event.Event{file}, DefaultConfig())
	artifacts := findingForRule(findings, "file/suspicious-artifact")
	if len(artifacts) != 1 || artifacts[0].Conclusion != "发现可疑打包或加密产物" || artifacts[0].EvidenceStrength != "heuristic" {
		t.Fatalf("unexpected artifact finding: %+v", artifacts)
	}
	if len(findingForRule(findings, "correlation/upload-attempt")) != 0 || len(findingForRule(findings, "correlation/suspected-exfiltration")) != 0 {
		t.Fatalf("artifact alone must not imply network transfer: %+v", findings)
	}
}

func TestCorrelationDeduplicatesArtifactUpdates(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	create := correlationEvent("s", "file", "file_create", event.Process{Name: "unattributed"}, at, map[string]any{
		"path": "/tmp/workspace/snapshot.enc", "size_bytes": uint64(15 * 1024), "artifact_kind": "encrypted",
	})
	modify := correlationEvent("s", "file", "file_modify", event.Process{Name: "unattributed"}, at.Add(time.Second), map[string]any{
		"path": "/tmp/workspace/snapshot.enc", "size_bytes": uint64(16 * 1024), "artifact_kind": "encrypted",
	})
	findings := EvaluateWithConfig([]event.Event{create, modify}, DefaultConfig())
	artifacts := findingForRule(findings, "file/suspicious-artifact")
	if len(artifacts) != 1 || !containsID(artifacts[0].EvidenceIDs, create.ID) || !containsID(artifacts[0].EvidenceIDs, modify.ID) {
		t.Fatalf("create and modify should be one artifact finding with both evidence IDs: %+v", artifacts)
	}
}

func TestGitFilesAreSensitivePathsNotNewArtifacts(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	file := correlationEvent("s", "file", "file_create", event.Process{Name: "unattributed"}, at, map[string]any{
		"path": "/tmp/workspace/.git/objects/pack/pack-fixture.pack", "size_bytes": uint64(500),
		"sensitive_path": true,
	})
	findings := EvaluateWithConfig([]event.Event{file}, DefaultConfig())
	if len(findingForRule(findings, "file/suspicious-artifact")) != 0 {
		t.Fatalf("ordinary .git files must not be called new packaging artifacts: %+v", findings)
	}
	if len(findingForRule(findings, "file/sensitive-path")) != 1 {
		t.Fatalf("ordinary .git files should retain sensitive-path evidence: %+v", findings)
	}
}

func TestCorrelationDistinguishesProxyAttemptAndUnknownAuthorization(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	proc := event.Process{PID: 42, Name: "agent", CreatedAtMS: 7}
	file := correlationEvent("s", "file", "file_create", event.Process{Name: "unattributed"}, at, map[string]any{
		"path": "/tmp/workspace/.env", "size_bytes": uint64(120), "sensitive_path": true,
	})
	network := correlationEvent("s", "net", "egress", proc, at.Add(2*time.Second), map[string]any{
		"source": "proxy", "proxy": true, "metric": "network_bytes", "bytes_out": uint64(120),
		"bytes_in": uint64(12), "remote_host": "receiver.test:443", "direction": "outbound",
		"http_method": "POST", "transport": "http",
	})
	findings := EvaluateWithConfig([]event.Event{file, network}, DefaultConfig())
	attempts := findingForRule(findings, "correlation/upload-attempt")
	if len(attempts) != 1 {
		t.Fatalf("expected one upload attempt, got %+v", findings)
	}
	f := attempts[0]
	if f.Conclusion != "观察到上传尝试" || f.AuthorizationState != "unknown" || f.EvidenceStrength != "observed_network_write" || f.Target != "receiver.test:443" {
		t.Fatalf("unexpected attempt: %+v", f)
	}
	if len(f.EvidenceIDs) != 2 || f.EvidenceIDs[0] != network.ID || f.EvidenceIDs[1] != file.ID {
		t.Fatalf("attempt must cite original network and file evidence: %+v", f.EvidenceIDs)
	}
	if strings.Contains(f.Conclusion, "确认") || strings.Contains(f.Details, "确认") {
		t.Fatalf("proxy bytes must not confirm content: %+v", f)
	}
}

func TestCorrelationUsesAggregateNetTopAsSuspectedOnly(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	proc := event.Process{PID: 42, Name: "agent", CreatedAtMS: 7}
	file := correlationEvent("s", "file", "file_create", event.Process{Name: "unattributed"}, at, map[string]any{
		"path": "/tmp/workspace/history.tar", "size_bytes": uint64(500),
	})
	network := correlationEvent("s", "net", "egress", proc, at.Add(3*time.Second), map[string]any{
		"source": "nettop", "metric": "network_bytes", "bytes_out": uint64(500),
		"bytes_in": uint64(20), "direction": "aggregate",
	})
	findings := EvaluateWithConfig([]event.Event{file, network}, DefaultConfig())
	suspected := findingForRule(findings, "correlation/suspected-exfiltration")
	if len(suspected) != 1 || suspected[0].Conclusion != "疑似数据外传" || suspected[0].EvidenceStrength != "suggestive_process_aggregate" {
		t.Fatalf("unexpected aggregate correlation: %+v", findings)
	}
	if suspected[0].Target != "" || !strings.Contains(strings.Join(suspected[0].Uncertainty, " "), "聚合") {
		t.Fatalf("aggregate evidence must disclose unknown target: %+v", suspected[0])
	}
}

func TestCorrelationRecordsAuthorizationAndFailedDelete(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	proc := event.Process{PID: 42, Name: "helper", CreatedAtMS: 7}
	path := "/tmp/workspace/repo-snapshot.enc"
	file := correlationEvent("s", "file", "file_create", event.Process{Name: "unattributed"}, at, map[string]any{
		"path": path, "size_bytes": uint64(100), "artifact_kind": "encrypted",
	})
	failure := correlationEvent("s", "net", "connection_failed", proc, at.Add(2*time.Second), map[string]any{
		"source": "proxy", "proxy": true, "remote_host": "blocked.test:443", "stage": "request_body",
		"error_code": "connection_reset", "direction": "outbound", "http_method": "POST", "transport": "http",
	})
	deleted := correlationEvent("s", "file", "file_delete", event.Process{Name: "unattributed"}, at.Add(4*time.Second), map[string]any{
		"path": path, "created_event_id": file.ID, "deleted_after_sec": 4.0,
	})
	cfg := DefaultConfig()
	cfg.Authorization.State = AuthorizationAuthorized
	cfg.Policy.AllowedUploadTargets = []string{"allowed.test:443"}
	cfg.Policy.AllowedUploadDirectories = []string{"/tmp/workspace"}
	findings := EvaluateWithConfig([]event.Event{file, failure, deleted}, cfg)
	attempts := findingForRule(findings, "correlation/upload-attempt")
	if len(attempts) != 1 {
		t.Fatalf("expected failed attempt, got %+v", findings)
	}
	f := attempts[0]
	if f.Conclusion != "观察到上传尝试但连接失败或重试" || f.AuthorizationState != "authorized_target_out_of_range" || f.Severity != "high" {
		t.Fatalf("unexpected authorization result: %+v", f)
	}
	if !containsID(f.EvidenceIDs, file.ID) || !containsID(f.EvidenceIDs, failure.ID) || !containsID(f.EvidenceIDs, deleted.ID) {
		t.Fatalf("failed attempt must include file, failure and deletion evidence: %+v", f.EvidenceIDs)
	}
}

func TestCorrelationKeepsConnectTunnelBelowUploadAttempt(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	proc := event.Process{PID: 42, Name: "agent", CreatedAtMS: 7}
	file := correlationEvent("s", "file", "file_create", event.Process{Name: "unattributed"}, at, map[string]any{
		"path": "/tmp/workspace/snapshot.enc", "size_bytes": uint64(100), "artifact_kind": "encrypted",
	})
	network := correlationEvent("s", "net", "egress", proc, at.Add(2*time.Second), map[string]any{
		"source": "proxy", "proxy": true, "metric": "network_bytes", "bytes_out": uint64(100),
		"bytes_in": uint64(20), "remote_host": "receiver.test:443", "transport": "connect_tunnel",
	})
	findings := EvaluateWithConfig([]event.Event{file, network}, DefaultConfig())
	if len(findingForRule(findings, "correlation/upload-attempt")) != 0 {
		t.Fatalf("CONNECT bytes must not be classified as an HTTP upload attempt: %+v", findings)
	}
	suspected := findingForRule(findings, "correlation/suspected-exfiltration")
	if len(suspected) != 1 || suspected[0].EvidenceStrength != "suggestive_proxy_bytes" || !strings.Contains(strings.Join(suspected[0].Uncertainty, " "), "CONNECT/TLS") {
		t.Fatalf("CONNECT evidence must stay suggestive and disclose opaque TLS: %+v", findings)
	}
}

func TestCorrelationRequiresArtifactBeforeNetwork(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	proc := event.Process{PID: 42, Name: "agent", CreatedAtMS: 7}
	network := correlationEvent("s", "net", "egress", proc, at, map[string]any{
		"source": "proxy", "proxy": true, "metric": "network_bytes", "bytes_out": uint64(100),
		"remote_host": "receiver.test:443", "http_method": "POST", "transport": "http",
	})
	file := correlationEvent("s", "file", "file_create", event.Process{Name: "unattributed"}, at.Add(time.Second), map[string]any{
		"path": "/tmp/workspace/snapshot.enc", "size_bytes": uint64(100), "artifact_kind": "encrypted",
	})
	findings := EvaluateWithConfig([]event.Event{network, file}, DefaultConfig())
	attempts := findingForRule(findings, "correlation/upload-attempt")
	if len(attempts) != 1 || len(attempts[0].FilePaths) != 0 || len(attempts[0].EvidenceIDs) != 1 || attempts[0].EvidenceIDs[0] != network.ID {
		t.Fatalf("a file created after the request must not be linked, but the network attempt remains actionable: %+v", findings)
	}
}

func TestCorrelationChecksAuthorizedTargetPortAndDirectory(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	proc := event.Process{PID: 42, Name: "agent", CreatedAtMS: 7}
	file := correlationEvent("s", "file", "file_open_observed", proc, at, map[string]any{
		"path": "/tmp/workspace/notes/small.txt", "size_bytes": uint64(100), "sensitive_path": true,
	})
	network := correlationEvent("s", "net", "egress", proc, at.Add(time.Second), map[string]any{
		"source": "proxy", "proxy": true, "metric": "network_bytes", "bytes_out": uint64(100),
		"remote_host": "receiver.test:8443", "http_method": "POST", "transport": "http",
	})
	cfg := DefaultConfig()
	cfg.Authorization.State = AuthorizationAuthorized
	cfg.Policy.AllowedUploadTargets = []string{"receiver.test:443"}
	cfg.Policy.AllowedUploadDirectories = []string{"/tmp/allowed"}
	findings := EvaluateWithConfig([]event.Event{file, network}, cfg)
	attempts := findingForRule(findings, "correlation/upload-attempt")
	if len(attempts) != 1 || attempts[0].AuthorizationState != "authorized_target_out_of_range" || attempts[0].Target != "receiver.test:8443" {
		t.Fatalf("target port must be checked exactly: %+v", attempts)
	}

	cfg.Policy.AllowedUploadTargets = []string{"receiver.test:8443"}
	findings = EvaluateWithConfig([]event.Event{file, network}, cfg)
	attempts = findingForRule(findings, "correlation/upload-attempt")
	if len(attempts) != 1 || attempts[0].AuthorizationState != "authorized_related_path_out_of_range" {
		t.Fatalf("related file directory must be checked: %+v", attempts)
	}
}

func TestCorrelationDoesNotJoinOtherSessionFilesOrDeletes(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	proc := event.Process{PID: 42, Name: "agent", CreatedAtMS: 7}
	otherFile := correlationEvent("other", "file", "file_create", event.Process{Name: "unattributed"}, at, map[string]any{
		"path": "/tmp/other/snapshot.enc", "artifact_kind": "encrypted",
	})
	network := correlationEvent("current", "net", "egress", proc, at.Add(time.Second), map[string]any{
		"source": "proxy", "proxy": true, "metric": "network_bytes", "bytes_out": uint64(100),
		"remote_host": "receiver.test:443", "http_method": "POST", "transport": "http",
	})
	attempts := findingForRule(EvaluateWithConfig([]event.Event{otherFile, network}, DefaultConfig()), "correlation/upload-attempt")
	if len(attempts) != 1 || len(attempts[0].FilePaths) != 0 || len(attempts[0].EvidenceIDs) != 1 || attempts[0].EvidenceIDs[0] != network.ID {
		t.Fatalf("other session file was linked to upload: %+v", attempts)
	}

	currentFile := correlationEvent("current", "file", "file_create", event.Process{Name: "unattributed"}, at, map[string]any{
		"path": "/tmp/current/snapshot.enc", "artifact_kind": "encrypted",
	})
	otherDelete := correlationEvent("other", "file", "file_delete", event.Process{Name: "unattributed"}, at.Add(2*time.Second), map[string]any{
		"path": "/tmp/current/snapshot.enc",
	})
	attempts = findingForRule(EvaluateWithConfig([]event.Event{otherFile, currentFile, network, otherDelete}, DefaultConfig()), "correlation/upload-attempt")
	if len(attempts) != 1 || len(attempts[0].FilePaths) != 1 || attempts[0].FilePaths[0] != "/tmp/current/snapshot.enc" ||
		!containsID(attempts[0].EvidenceIDs, currentFile.ID) || containsID(attempts[0].EvidenceIDs, otherFile.ID) ||
		containsID(attempts[0].EvidenceIDs, otherDelete.ID) {
		t.Fatalf("cross-session file or deletion polluted correlation: %+v", attempts)
	}
}

func TestCorrelationAuthorizationIgnoresUnattributedNearbyFiles(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	proc := event.Process{PID: 42, Name: "agent", CreatedAtMS: 7}
	allowedOpen := correlationEvent("s", "file", "file_open_observed", proc, at, map[string]any{
		"path": "/tmp/allowed/notes.txt",
	})
	outsideCreate := correlationEvent("s", "file", "file_create", event.Process{Name: "unattributed"}, at, map[string]any{
		"path": "/tmp/outside/snapshot.enc", "artifact_kind": "encrypted", "sensitive_path": true,
	})
	network := correlationEvent("s", "net", "egress", proc, at.Add(time.Second), map[string]any{
		"source": "proxy", "proxy": true, "metric": "network_bytes", "bytes_out": uint64(100),
		"remote_host": "receiver.test:443", "http_method": "POST", "transport": "http",
	})
	cfg := DefaultConfig()
	cfg.Authorization.State = AuthorizationAuthorized
	cfg.Policy.AllowedUploadTargets = []string{"receiver.test:443"}
	cfg.Policy.AllowedUploadDirectories = []string{"/tmp/allowed"}

	attempts := findingForRule(EvaluateWithConfig([]event.Event{allowedOpen, outsideCreate, network}, cfg), "correlation/upload-attempt")
	if len(attempts) != 1 || attempts[0].AuthorizationState != "authorized" || attempts[0].Severity != "medium" {
		t.Fatalf("unattributed nearby file upgraded authorized request: %+v", attempts)
	}
	attempts = findingForRule(EvaluateWithConfig([]event.Event{outsideCreate, network}, cfg), "correlation/upload-attempt")
	if len(attempts) != 1 || attempts[0].AuthorizationState != "authorized_related_path_unknown" || attempts[0].Severity != "medium" {
		t.Fatalf("temporal file clue was treated as proven scope breach: %+v", attempts)
	}
}

func TestCorrelationRejectsTemporalNetworkAttempts(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	proc := event.Process{PID: 42, Name: "agent", CreatedAtMS: 7}
	file := correlationEvent("s", "file", "file_create", event.Process{Name: "unattributed"}, at, map[string]any{
		"path": "/tmp/snapshot.enc", "artifact_kind": "encrypted",
	})
	for _, kind := range []string{"egress", "connection_failed"} {
		network := correlationEvent("s", "net", kind, proc, at.Add(time.Second), map[string]any{
			"source": "proxy", "proxy": true, "metric": "network_bytes", "bytes_out": uint64(100),
			"remote_host": "receiver.test:443", "http_method": "POST", "transport": "http",
		})
		network.Attribution = "temporal"
		findings := EvaluateWithConfig([]event.Event{file, network}, DefaultConfig())
		if len(findingForRule(findings, "correlation/upload-attempt")) != 0 || len(findingForRule(findings, "correlation/suspected-exfiltration")) != 0 {
			t.Fatalf("temporal %s yielded network conclusion: %+v", kind, findings)
		}
	}
}

func TestCorrelationFilenameAndEntropyUseConfiguredThreshold(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	report := correlationEvent("s", "file", "file_create", event.Process{Name: "unattributed"}, at, map[string]any{
		"path": "/tmp/report.json",
	})
	if artifacts := findingForRule(EvaluateWithConfig([]event.Event{report}, DefaultConfig()), "file/suspicious-artifact"); len(artifacts) != 0 {
		t.Fatalf("report name became repo snapshot: %+v", artifacts)
	}
	opaque := correlationEvent("s", "file", "file_create", event.Process{Name: "unattributed"}, at, map[string]any{
		"path": "/tmp/opaque", "entropy": 7.6,
	})
	cfg := DefaultConfig()
	cfg.Entropy = 7.8
	if artifacts := findingForRule(EvaluateWithConfig([]event.Event{opaque}, cfg), "file/suspicious-artifact"); len(artifacts) != 0 {
		t.Fatalf("entropy below configured threshold became an artifact: %+v", artifacts)
	}
	opaque.Detail["artifact_kind"] = "opaque_high_entropy"
	if artifacts := findingForRule(EvaluateWithConfig([]event.Event{opaque}, cfg), "file/suspicious-artifact"); len(artifacts) != 0 {
		t.Fatalf("old collector entropy hint bypassed configured threshold: %+v", artifacts)
	}
	cfg.Entropy = 7.5
	if artifacts := findingForRule(EvaluateWithConfig([]event.Event{opaque}, cfg), "file/suspicious-artifact"); len(artifacts) != 1 || artifacts[0].EvidenceIDs[0] != opaque.ID {
		t.Fatalf("entropy above configured threshold was missed: %+v", artifacts)
	}
}

func TestCorrelationFailedDialIsAttemptWithoutNetworkWrite(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	proc := event.Process{PID: 42, Name: "agent", CreatedAtMS: 7}
	file := correlationEvent("s", "file", "file_create", event.Process{Name: "unattributed"}, at, map[string]any{
		"path": "/tmp/workspace/snapshot.enc", "size_bytes": uint64(100), "artifact_kind": "encrypted",
	})
	failure := correlationEvent("s", "net", "connection_failed", proc, at.Add(time.Second), map[string]any{
		"source": "proxy", "proxy": true, "remote_host": "receiver.test:443", "stage": "dial",
		"error_code": "connection_refused", "http_method": "POST", "transport": "http",
	})
	findings := EvaluateWithConfig([]event.Event{file, failure}, DefaultConfig())
	attempts := findingForRule(findings, "correlation/upload-attempt")
	if len(attempts) != 1 || attempts[0].EvidenceStrength != "observed_request_attempt" || strings.Contains(attempts[0].Details, "成功写入") {
		t.Fatalf("failed dial must not claim a successful network write: %+v", attempts)
	}
}

func TestProxyUploadAttemptWithoutFileEvidenceKeepsContentUnknown(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	proc := event.Process{PID: 42, Name: "agent", CreatedAtMS: 7}
	for _, method := range []string{"POST", "PUT", "PATCH"} {
		network := correlationEvent("s", "net", "egress", proc, at, map[string]any{
			"source": "proxy", "proxy": true, "metric": "network_bytes", "bytes_out": uint64(31),
			"remote_host": "api.openai.com:443", "http_method": method, "transport": "http",
		})
		cfg := DefaultConfig()
		cfg.Authorization.State = AuthorizationAuthorized
		cfg.Policy.AllowedUploadDirectories = []string{"/tmp/allowed"}
		cfg.Policy.AllowedUploadTargets = []string{"allowed.test:443"}
		for _, test := range []struct {
			name     string
			cfg      Config
			wantAuth string
		}{
			{"unknown", DefaultConfig(), "unknown"},
			{"target_out_of_range", cfg, "authorized_target_out_of_range"},
			{"denied", func() Config {
				denied := DefaultConfig()
				denied.Authorization.State = AuthorizationDenied
				return denied
			}(), "denied"},
		} {
			t.Run(method+"_"+test.name, func(t *testing.T) {
				attempts := findingForRule(EvaluateWithConfig([]event.Event{network}, test.cfg), "correlation/upload-attempt")
				if len(attempts) != 1 {
					t.Fatalf("small network-only HTTP request was missed: %+v", attempts)
				}
				f := attempts[0]
				if f.AuthorizationState != test.wantAuth || f.EvidenceStrength != "observed_network_write" ||
					len(f.EvidenceIDs) != 1 || f.EvidenceIDs[0] != network.ID || len(f.FilePaths) != 0 ||
					f.Target != "api.openai.com:443" || f.Process != proc || !strings.Contains(f.Summary, "文件内容未知") ||
					!strings.Contains(strings.Join(f.Uncertainty, " "), "不能确定请求正文") || strings.Contains(f.Conclusion+f.Summary+f.Details, "确认发送了特定内容") {
					t.Fatalf("network-only finding overstated its evidence: %+v", f)
				}
			})
		}
	}
}

func TestProxyFailedUploadWithoutFileEvidenceIsAttemptOnly(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	proc := event.Process{PID: 42, Name: "agent", CreatedAtMS: 7}
	failure := correlationEvent("s", "net", "connection_failed", proc, at, map[string]any{
		"source": "proxy", "proxy": true, "remote_host": "receiver.test:443", "stage": "dial",
		"http_method": "POST", "transport": "http",
	})
	attempts := findingForRule(EvaluateWithConfig([]event.Event{failure}, DefaultConfig()), "correlation/upload-attempt")
	if len(attempts) != 1 || attempts[0].EvidenceStrength != "observed_request_attempt" ||
		len(attempts[0].FilePaths) != 0 || attempts[0].Conclusion != "观察到上传尝试但连接失败或重试" ||
		strings.Contains(attempts[0].Details, "成功写入") {
		t.Fatalf("failed request must not become a successful transfer: %+v", attempts)
	}
}

func TestNetworkOnlyAttemptRequiresVerifiedProxyUploadMethod(t *testing.T) {
	at := time.Unix(100, 0).UTC()
	proc := event.Process{PID: 42, Name: "agent", CreatedAtMS: 7}
	for _, test := range []struct {
		name   string
		proc   event.Process
		detail map[string]any
	}{
		{"get", proc, map[string]any{"source": "proxy", "metric": "network_bytes", "bytes_out": uint64(31), "http_method": "GET", "transport": "http"}},
		{"tls", proc, map[string]any{"source": "proxy", "metric": "network_bytes", "bytes_out": uint64(31), "transport": "connect_tunnel"}},
		{"nettop", proc, map[string]any{"source": "nettop", "metric": "network_bytes", "bytes_out": uint64(31), "http_method": "POST", "transport": "http"}},
		{"unverified", event.Process{Name: "agent"}, map[string]any{"source": "proxy", "metric": "network_bytes", "bytes_out": uint64(31), "http_method": "POST", "transport": "http"}},
	} {
		t.Run(test.name, func(t *testing.T) {
			network := correlationEvent("s", "net", "egress", test.proc, at, test.detail)
			if attempts := findingForRule(EvaluateWithConfig([]event.Event{network}, DefaultConfig()), "correlation/upload-attempt"); len(attempts) != 0 {
				t.Fatalf("weak network evidence became an upload attempt: %+v", attempts)
			}
		})
	}
}

func containsID(values []string, id string) bool {
	for _, value := range values {
		if value == id {
			return true
		}
	}
	return false
}
