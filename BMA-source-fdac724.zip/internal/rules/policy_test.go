package rules

import "testing"

func TestPolicyNormalizesMetadataAndDefaultsAuthorization(t *testing.T) {
	policy := (Policy{
		ProtectedDirectories:     []string{" /workspace ", "", "/workspace"},
		SensitiveCategories:      []string{"credentials", "credentials", " source ", ""},
		AllowedUploadDirectories: []string{" /workspace ", "/workspace"},
		AllowedUploadTargets:     []string{"api.example.com:443", " api.example.com:443 "},
	}).Normalize()
	if len(policy.ProtectedDirectories) != 1 || policy.ProtectedDirectories[0] != "/workspace" {
		t.Fatalf("protected directories were not normalized: %#v", policy.ProtectedDirectories)
	}
	if len(policy.SensitiveCategories) != 2 || policy.SensitiveCategories[1] != "source" {
		t.Fatalf("sensitive categories were not normalized: %#v", policy.SensitiveCategories)
	}
	if len(policy.AllowedUploadTargets) != 1 || policy.AllowedUploadTargets[0] != "api.example.com:443" {
		t.Fatalf("upload targets were not normalized: %#v", policy.AllowedUploadTargets)
	}
	if len(policy.AllowedUploadDirectories) != 1 || policy.AllowedUploadDirectories[0] != "/workspace" {
		t.Fatalf("upload directories were not normalized: %#v", policy.AllowedUploadDirectories)
	}
	if got := (Authorization{}).Normalize().State; got != AuthorizationUnknown {
		t.Fatalf("missing authorization became %q", got)
	}
}

func TestAuthorizedPolicyRequiresTargetAndDirectory(t *testing.T) {
	authorized := Authorization{State: AuthorizationAuthorized}
	absolute := t.TempDir()
	if err := (Policy{}).ValidateAuthorization(authorized); err == nil {
		t.Fatal("authorized policy without scope accepted")
	}
	if err := (Policy{AllowedUploadTargets: []string{"receiver.test:443"}}).ValidateAuthorization(authorized); err == nil {
		t.Fatal("authorized policy without directory accepted")
	}
	if err := (Policy{AllowedUploadDirectories: []string{"relative"}, AllowedUploadTargets: []string{"receiver.test:443"}}).ValidateAuthorization(authorized); err == nil {
		t.Fatal("relative authorized directory accepted")
	}
	if err := (Policy{AllowedUploadDirectories: []string{absolute}, AllowedUploadTargets: []string{"receiver.test:443"}}).ValidateAuthorization(authorized); err != nil {
		t.Fatal(err)
	}
	if err := (Policy{AllowedUploadDirectories: []string{"relative"}}).ValidateAuthorization(DefaultAuthorization()); err == nil {
		t.Fatal("relative directory accepted with unknown authorization")
	}
	cfg := DefaultConfig()
	cfg.Authorization = authorized
	if err := cfg.Validate(); err == nil {
		t.Fatal("configuration accepted unscoped authorization")
	}
	cfg.Policy = Policy{AllowedUploadDirectories: []string{absolute}, AllowedUploadTargets: []string{"receiver.test:443"}}
	if err := cfg.Validate(); err != nil {
		t.Fatal(err)
	}
}

func TestPolicyRejectsUnresolvedProtectedDirectory(t *testing.T) {
	if err := (Policy{ProtectedDirectories: []string{"workspace/secrets"}}).ValidateAuthorization(DefaultAuthorization()); err == nil {
		t.Fatal("relative protected directory accepted without resolution")
	}
}

func TestAllowedUploadTargetMatchesObservableHostScope(t *testing.T) {
	for _, target := range []string{"receiver.test:443", "http://127.0.0.1:8080", "https://receiver.test/", "https://[::1]:8443/"} {
		if err := validateUploadTarget(target); err != nil {
			t.Fatalf("valid target %q rejected: %v", target, err)
		}
	}
	for _, target := range []string{"receiver.test", "https://receiver.test/private", "https://receiver.test/?token=fixture", "https://receiver.test/#secret", "https://user@receiver.test", "ftp://receiver.test", "receiver.test:0", "*.receiver.test"} {
		if err := validateUploadTarget(target); err == nil {
			t.Fatalf("unobservable or invalid target %q accepted", target)
		}
	}
}

func TestAuthorizationStateValidation(t *testing.T) {
	for _, state := range []AuthorizationState{AuthorizationUnknown, AuthorizationAuthorized, AuthorizationDenied} {
		if !(Authorization{State: state}).Valid() {
			t.Fatalf("valid state rejected: %q", state)
		}
	}
	if (Authorization{State: "not-recorded"}).Valid() {
		t.Fatal("invalid authorization state accepted")
	}
}
