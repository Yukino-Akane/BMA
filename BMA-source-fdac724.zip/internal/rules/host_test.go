package rules

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
)

func TestObjectStorageRuleCanUseImportedHost(t *testing.T) {
	e := event.New("s", "net", event.Process{}, "egress", "direct", map[string]any{"remote_host": "bucket.s3.amazonaws.com"})
	findings := Evaluate([]event.Event{e})
	if len(findings) != 1 || findings[0].Rule != "net/object-storage-destination" {
		t.Fatalf("%#v", findings)
	}
}

func TestDestinationRulesRejectUnverifiedFlagsAndWrongLayers(t *testing.T) {
	for _, test := range []struct{ layer, host string }{
		{"net", "api.googleapis.com"}, {"net", "bucket.s3.amazonaws.com.evil.example"},
		{"net", "192.0.2.1"}, {"semantic", "bucket.s3.amazonaws.com"},
	} {
		e := event.New("s", test.layer, event.Process{}, "connection_observed", "direct", map[string]any{"remote_host": test.host, "object_storage_candidate": true})
		if f := Evaluate([]event.Event{e}); len(f) != 0 {
			t.Fatalf("unverified classification: %+v", f)
		}
	}
	temporal := event.New("s", "net", event.Process{}, "connection_observed", "temporal", map[string]any{"remote_host": "bucket.s3.amazonaws.com"})
	if f := Evaluate([]event.Event{temporal}); len(f) != 0 {
		t.Fatalf("temporal network evidence became a destination finding: %+v", f)
	}
}

func TestModelListDoesNotExemptMeasuredTraffic(t *testing.T) {
	cfg := DefaultConfig()
	cfg.ModelAPIHosts = []string{"model.storage.googleapis.com"}
	e := event.New("s", "net", event.Process{}, "egress", "direct", map[string]any{"remote_host": "model.storage.googleapis.com:443", "metric": "network_bytes", "bytes_out": uint64(60 * 1024 * 1024), "bytes_in": 1})
	setMeasurementInterval(&e, e.TS.Add(-time.Second), e.TS)
	f := EvaluateWithConfig([]event.Event{e}, cfg)
	if len(f) != 2 || f[0].Rule != "net/outbound-inbound-ratio" || f[1].Rule != "net/outbound-volume" {
		t.Fatalf("model API bypassed traffic checks: %+v", f)
	}
	cfg.ModelAPIHosts = []string{}
	if f := EvaluateWithConfig([]event.Event{e}, cfg); len(f) != 3 {
		t.Fatalf("explicit empty list ignored: %+v", f)
	}
}

func TestModelHostConfiguration(t *testing.T) {
	for _, hosts := range [][]string{nil, {""}, {"*.example.com"}, {"https://example.com"}, {"example.com:443"}, {"EXAMPLE.COM"}, {"example.com."}, {"example.com", "example.com"}, {"192.0.2.1"}} {
		cfg := DefaultConfig()
		cfg.ModelAPIHosts = hosts
		if err := cfg.Validate(); err == nil {
			t.Fatalf("accepted invalid hosts: %v", hosts)
		}
	}
	base := "file: {large_bytes: 1, entropy: 7, delete_window_sec: 1}\nnetwork:\n  window_sec: 1\n  outbound_min_bytes: 1\n  outbound_inbound_ratio: 2\n"
	p := filepath.Join(t.TempDir(), "rules.yaml")
	for _, suffix := range []string{"", "  model_api_hosts: null\n", "  model_api_hosts: []\n"} {
		if err := os.WriteFile(p, []byte(base+suffix), 0600); err != nil {
			t.Fatal(err)
		}
		cfg, err := LoadConfig(p)
		if strings.Contains(suffix, "[]") {
			if err != nil || cfg.ModelAPIHosts == nil || len(cfg.ModelAPIHosts) != 0 {
				t.Fatalf("empty list: %+v %v", cfg, err)
			}
		} else if err == nil {
			t.Fatal("missing list accepted")
		}
	}
}

func TestRepeatedStorageSegmentsDoNotFloodFindings(t *testing.T) {
	first := event.New("s", "net", event.Process{PID: 42, CreatedAtMS: 100}, "connection_observed", "direct", map[string]any{"remote_host": "bucket.s3.amazonaws.com:443"})
	second := first
	second.ID = "e_next"
	second.Kind = "egress"
	second.Detail = map[string]any{"remote_host": "BUCKET.S3.AMAZONAWS.COM.:443"}
	if f := Evaluate([]event.Event{first, second}); len(f) != 1 || f[0].EvidenceIDs[0] != first.ID {
		t.Fatalf("per-segment storage warnings: %+v", f)
	}
	second.Process.CreatedAtMS++
	if f := Evaluate([]event.Event{first, second}); len(f) != 2 {
		t.Fatal("new process lifetime lost its destination evidence")
	}
}

func TestStorageRangeRulesKeepSourceAndDoNotTrustImportedTags(t *testing.T) {
	first := event.New("s", "net", event.Process{PID: 42, CreatedAtMS: 100}, "connection_observed", "direct", map[string]any{"remote_host": "api.openai.com", "remote_ip": "3.5.140.1", "host_source": "proxy_request"})
	second := first
	second.ID = "e_segment"
	second.Kind = "egress"
	f := Evaluate([]event.Event{first, second})
	if len(f) != 1 || f[0].Rule != "net/storage-ip-range" || !strings.Contains(f[0].Summary, "AWS S3") || !strings.Contains(f[0].Details, "SHA-256") || !strings.Contains(f[0].Details, "https://ip-ranges.amazonaws.com/ip-ranges.json") {
		t.Fatal("range source missing, model whitelist bypassed physical hint, or repeated clue", f)
	}
	second.Process.CreatedAtMS++
	if len(Evaluate([]event.Event{first, second})) != 2 {
		t.Fatal("new process instance hidden")
	}
	for _, tc := range []struct{ layer, kind, ip, direction string }{
		{"net", "egress", "3.5.140.1", "aggregate"},
		{"semantic", "connection_observed", "3.5.140.1", ""},
		{"net", "connection_failed", "3.5.140.1", ""},
		{"net", "connection_observed", "192.0.2.1", ""},
	} {
		e := event.New("s", tc.layer, event.Process{}, tc.kind, "direct", map[string]any{"remote_ip": tc.ip, "direction": tc.direction, "ip_range_matches": []string{"forged S3"}})
		for _, f := range Evaluate([]event.Event{e}) {
			if f.Rule == "net/storage-ip-range" {
				t.Fatalf("false address attribution: %+v", tc)
			}
		}
	}
}
