package rules

import (
	"fmt"
	"net/url"
	"path/filepath"
	"strconv"
	"strings"
)

// AuthorizationState describes what the user recorded for outbound transfers.
// Unknown is deliberately the default: an absent record is not a denial.
type AuthorizationState string

const (
	AuthorizationUnknown    AuthorizationState = "unknown"
	AuthorizationAuthorized AuthorizationState = "authorized"
	AuthorizationDenied     AuthorizationState = "denied"
)

// Policy is the user supplied protection scope. These values are metadata for
// the observation session and are not evidence that a transfer occurred.
type Policy struct {
	ProtectedDirectories     []string `json:"protected_directories"`
	SensitiveCategories      []string `json:"sensitive_categories"`
	AllowedUploadDirectories []string `json:"allowed_upload_directories"`
	AllowedUploadTargets     []string `json:"allowed_upload_targets"`
}

type Authorization struct {
	State AuthorizationState `json:"state"`
}

func DefaultPolicy() Policy {
	return Policy{}
}

func DefaultAuthorization() Authorization {
	return Authorization{State: AuthorizationUnknown}
}

// Normalize trims and de-duplicates user supplied metadata while preserving
// the order in which it was entered. Empty entries are discarded.
func (p Policy) Normalize() Policy {
	return Policy{
		ProtectedDirectories:     normalizeList(p.ProtectedDirectories),
		SensitiveCategories:      normalizeList(p.SensitiveCategories),
		AllowedUploadDirectories: normalizeList(p.AllowedUploadDirectories),
		AllowedUploadTargets:     normalizeList(p.AllowedUploadTargets),
	}
}

func (p Policy) ValidateAuthorization(a Authorization) error {
	p = p.Normalize()
	for _, dir := range p.ProtectedDirectories {
		if !filepath.IsAbs(dir) {
			return fmt.Errorf("protected directory must be an absolute path: %q", dir)
		}
	}
	for _, dir := range p.AllowedUploadDirectories {
		if !filepath.IsAbs(dir) {
			return fmt.Errorf("allowed upload directory must be an absolute path: %q", dir)
		}
	}
	for _, target := range p.AllowedUploadTargets {
		if err := validateUploadTarget(target); err != nil {
			return err
		}
	}
	if a.Normalize().State == AuthorizationAuthorized && (len(p.AllowedUploadTargets) == 0 || len(p.AllowedUploadDirectories) == 0) {
		return fmt.Errorf("authorized uploads require at least one allowed upload target and one allowed upload directory")
	}
	return nil
}

func validateUploadTarget(target string) error {
	raw := target
	hasScheme := strings.Contains(raw, "://")
	if !strings.Contains(raw, "://") {
		raw = "//" + raw
	}
	parsed, err := url.Parse(raw)
	if err != nil || (parsed.Scheme != "" && parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.User != nil ||
		parsed.Hostname() == "" || parsed.Path != "" && parsed.Path != "/" || parsed.RawQuery != "" || parsed.ForceQuery ||
		parsed.Fragment != "" || strings.ContainsAny(parsed.Hostname(), " \t\r\n*") {
		return fmt.Errorf("allowed upload target must be a host:port or root HTTP(S) URL without credentials, path, query, or fragment: %q", target)
	}
	if parsed.Port() == "" && !hasScheme {
		return fmt.Errorf("allowed upload target must include a port when written as a bare host: %q", target)
	}
	if port := parsed.Port(); port != "" {
		value, err := strconv.Atoi(port)
		if err != nil || value < 1 || value > 65535 {
			return fmt.Errorf("allowed upload target has invalid port: %q", target)
		}
	}
	return nil
}

func (a Authorization) Normalize() Authorization {
	state := AuthorizationState(strings.ToLower(strings.TrimSpace(string(a.State))))
	if state == "" {
		state = AuthorizationUnknown
	}
	return Authorization{State: state}
}

func (a Authorization) Valid() bool {
	switch a.Normalize().State {
	case AuthorizationUnknown, AuthorizationAuthorized, AuthorizationDenied:
		return true
	default:
		return false
	}
}

func normalizeList(values []string) []string {
	if values == nil {
		return nil
	}
	result := make([]string, 0, len(values))
	seen := make(map[string]bool, len(values))
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value == "" || seen[value] {
			continue
		}
		seen[value] = true
		result = append(result, value)
	}
	return result
}
