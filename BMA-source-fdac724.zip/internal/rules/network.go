package rules

import (
	"container/heap"
	"math"
	"sort"
	"time"

	"behavior-monitoring-audit/internal/event"
)

type networkMeasurement struct {
	id         string
	start, end time.Time
	out, in    float64
}

// Expire fully contained samples by start time; concurrent connections can
// complete in a different order. Window accounting is O(n log n); evidence
// materialization additionally depends on the number and size of findings.
type networkStarts []networkMeasurement

func (s networkStarts) Len() int { return len(s) }
func (s networkStarts) Less(i, j int) bool {
	if s[i].start.Equal(s[j].start) {
		return s[i].end.Before(s[j].end)
	}
	return s[i].start.Before(s[j].start)
}
func (s networkStarts) Swap(i, j int) { s[i], s[j] = s[j], s[i] }
func (s *networkStarts) Push(v any)   { *s = append(*s, v.(networkMeasurement)) }
func (s *networkStarts) Pop() any {
	old := *s
	n := len(old)
	v := old[n-1]
	old[n-1] = networkMeasurement{}
	*s = old[:n-1]
	return v
}

func measurement(e event.Event) (networkMeasurement, bool) {
	start, okStart := e.Detail["sample_start"].(string)
	end, okEnd := e.Detail["sample_end"].(string)
	a, errStart := time.Parse(time.RFC3339Nano, start)
	b, errEnd := time.Parse(time.RFC3339Nano, end)
	if !okStart || !okEnd || errStart != nil || errEnd != nil || a.After(b) || b.After(e.TS) {
		return networkMeasurement{}, false
	}
	for _, key := range []string{"bytes_out", "bytes_in"} {
		v, exists := e.Detail[key]
		if !exists || v == nil {
			return networkMeasurement{}, false
		}
		switch v.(type) {
		case int, int64, uint64, float32, float64:
		default:
			return networkMeasurement{}, false
		}
		n := numericFloat(v)
		if math.IsNaN(n) || math.IsInf(n, 0) || n < 0 || n > math.MaxUint64 || math.Trunc(n) != n {
			return networkMeasurement{}, false
		}
	}
	return networkMeasurement{id: e.ID, start: a, end: b, out: numericFloat(e.Detail["bytes_out"]), in: numericFloat(e.Detail["bytes_in"])}, true
}

func evaluateNetwork(events []event.Event, cfg Config, add func(string, string, string, ...string)) {
	type groupKey struct{ session, process, source, remote string }
	groups := map[groupKey][]networkMeasurement{}
	var keys []groupKey
	for _, e := range events {
		if e.Layer != "net" || e.Kind != "egress" || e.Attribution != "direct" || e.Detail["metric"] != "network_bytes" {
			continue
		}
		m, valid := measurement(e)
		if !valid {
			add("info", "net/measurement-unusable", "网络记录缺少有效字节量或测量区间，未参与时间窗口判断", e.ID)
			continue
		}
		if m.end.Sub(m.start).Seconds() > cfg.NetworkWindowSeconds {
			add("info", "net/measurement-wider-than-window", "单条网络记录跨越整个规则窗口，无法确定窗口内实际流量", e.ID)
		}
		remote, _ := e.Detail["remote_host"].(string)
		if remote == "" {
			remote, _ = e.Detail["remote_ip"].(string)
		}
		if e.Detail["direction"] == "aggregate" {
			remote = "aggregate"
		}
		if remote == "" {
			continue
		}
		source := "imported"
		if e.Detail["proxy"] == true {
			source = "proxy"
		}
		if e.Detail["source"] == "nettop" {
			source = "nettop"
		}
		if e.Detail["synthetic"] == true {
			source = "synthetic/" + source
		}
		key := groupKey{e.SessionID, processKey(e), source, remote}
		if _, ok := groups[key]; !ok {
			keys = append(keys, key)
		}
		groups[key] = append(groups[key], m)
	}
	for _, key := range keys {
		rows := groups[key]
		sort.SliceStable(rows, func(i, j int) bool { return rows[i].end.Before(rows[j].end) })
		starts := append([]networkMeasurement(nil), rows...)
		sort.SliceStable(starts, func(i, j int) bool { return starts[i].start.Before(starts[j].start) })
		full := &networkStarts{}
		left, right := 0, 0
		var confirmedOut, possibleIn float64
		activeVolume, activeRatio := false, false
		for i, m := range rows {
			cutoff := m.end.Add(-time.Duration(cfg.NetworkWindowSeconds * float64(time.Second)))
			// Include inbound samples crossing either edge, even if their
			// measurements finish after this window. They may contain inbound
			// bytes inside it; excluding them would inflate the ratio.
			for right < len(starts) && !starts[right].start.After(m.end) {
				possibleIn += starts[right].in
				right++
			}
			for left <= i && !rows[left].end.After(cutoff) {
				possibleIn -= rows[left].in
				left++
			}
			for full.Len() > 0 && ((*full)[0].start.Before(cutoff) || !(*full)[0].end.After(cutoff)) {
				confirmedOut -= heap.Pop(full).(networkMeasurement).out
			}
			if !m.start.Before(cutoff) {
				heap.Push(full, m)
				confirmedOut += m.out
			}
			confirmedOut, possibleIn = max(0, confirmedOut), max(0, possibleIn)
			volume := confirmedOut > float64(cfg.OutboundMinBytes)
			ratio := confirmedOut > 0 && (possibleIn == 0 || confirmedOut/possibleIn > cfg.OutboundInRatio)
			if volume && !activeVolume {
				var ids []string
				for _, row := range rows[left : i+1] {
					if !row.start.Before(cutoff) {
						ids = append(ids, row.id)
					}
				}
				add("high", "net/outbound-volume", "窗口内已确认的出站量超过设定阈值", ids...)
			}
			if ratio && !activeRatio {
				var ids []string
				for _, row := range starts[:right] {
					if row.end.After(cutoff) {
						ids = append(ids, row.id)
					}
				}
				add("high", "net/outbound-inbound-ratio", "保守计算后，窗口内出站量仍明显多于入站量", ids...)
			}
			activeVolume, activeRatio = volume, ratio
		}
	}
}
