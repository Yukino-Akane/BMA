package rules

import (
	"fmt"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
)

func measuredInterval(start, end int64, out, in int) event.Event {
	e := event.New("s", "net", event.Process{PID: 42, CreatedAtMS: 100}, "egress", "direct", map[string]any{"remote_host": "example.invalid:443", "metric": "network_bytes", "bytes_out": out, "bytes_in": in, "proxy": true})
	e.TS = time.Unix(end, 0)
	setMeasurementInterval(&e, time.Unix(start, 0), e.TS)
	return e
}

func TestLongMeasurementCannotBecomeFiveMinuteBurst(t *testing.T) {
	e := measuredInterval(0, 1000, 100*1024*1024, 1)
	f := Evaluate([]event.Event{e})
	if len(f) != 1 || f[0].Rule != "net/measurement-wider-than-window" {
		t.Fatalf("long transfer turned into burst: %+v", f)
	}
}

func TestClockResolutionZeroDurationSamplesExpireAtBoundary(t *testing.T) {
	first := measuredInterval(100, 100, 30*1024*1024, 30*1024*1024)
	next := measuredInterval(400, 400, 30*1024*1024, 30*1024*1024)
	if f := Evaluate([]event.Event{first, next}); len(f) != 0 {
		t.Fatalf("instant sample failed to expire: %+v", f)
	}
	inside := measuredInterval(399, 399, 30*1024*1024, 30*1024*1024)
	if f := Evaluate([]event.Event{first, inside, next}); len(f) != 1 || f[0].Rule != "net/outbound-volume" {
		t.Fatalf("clock-resolution sample was lost: %+v", f)
	}
}

func TestWindowBoundaryExcludesUncertainOutboundAndIncludesInbound(t *testing.T) {
	// First sample crosses the later window's left edge. Its outbound cannot
	// establish a burst, while all of its inbound must remain in the ratio bound.
	left := measuredInterval(0, 100, 30*1024*1024, 30*1024*1024)
	current := measuredInterval(100, 350, 30*1024*1024, 1)
	if f := Evaluate([]event.Event{left, current}); len(f) != 0 {
		t.Fatalf("boundary sample inflated traffic or ratio: %+v", f)
	}
	inside := measuredInterval(350, 351, 30*1024*1024, 30*1024*1024)
	f := Evaluate([]event.Event{inside, current, left}) // Input order is irrelevant.
	if len(f) != 1 || f[0].Rule != "net/outbound-volume" || len(f[0].EvidenceIDs) != 2 || f[0].EvidenceIDs[0] != current.ID || f[0].EvidenceIDs[1] != inside.ID {
		t.Fatalf("contained evidence wrong: %+v", f)
	}
}

func TestLaterEndingInboundPreventsFalseHistoricalRatio(t *testing.T) {
	out := measuredInterval(99, 100, 1000, 0)
	later := measuredInterval(99, 200, 0, 1000)
	if f := Evaluate([]event.Event{out, later}); len(f) != 0 {
		t.Fatalf("right-edge inbound omitted: %+v", f)
	}
	// When even the conservative ratio exceeds the threshold, include both IDs.
	out.Detail["bytes_out"] = 100000
	f := Evaluate([]event.Event{later, out})
	if len(f) != 1 || f[0].Rule != "net/outbound-inbound-ratio" || len(f[0].EvidenceIDs) != 2 {
		t.Fatalf("ratio lost boundary evidence: %+v", f)
	}
}

func TestMissingInvalidAndFutureMeasurementsAreDisclosed(t *testing.T) {
	for _, kind := range []string{"missing_start", "missing_in", "nil_in", "string_in", "fractional", "future", "reversed"} {
		t.Run(kind, func(t *testing.T) {
			e := measuredInterval(99, 100, 100000000, 1)
			switch kind {
			case "missing_start":
				delete(e.Detail, "sample_start")
			case "missing_in":
				delete(e.Detail, "bytes_in")
			case "nil_in":
				e.Detail["bytes_in"] = nil
			case "string_in":
				e.Detail["bytes_in"] = "1"
			case "fractional":
				e.Detail["bytes_in"] = 0.5
			case "future":
				e.TS = time.Unix(90, 0)
			case "reversed":
				setMeasurementInterval(&e, time.Unix(100, 0), time.Unix(99, 0))
			}
			f := Evaluate([]event.Event{e})
			if len(f) != 1 || f[0].Rule != "net/measurement-unusable" {
				t.Fatalf("invalid input caused traffic alert: %+v", f)
			}
		})
	}
}

func TestTemporalNetworkMeasurementCannotTriggerVolumeOrRatio(t *testing.T) {
	e := measuredInterval(99, 100, 100*1024*1024, 1)
	e.Attribution = "temporal"
	findings := Evaluate([]event.Event{e})
	if len(findingForRule(findings, "net/outbound-volume")) != 0 || len(findingForRule(findings, "net/outbound-inbound-ratio")) != 0 {
		t.Fatalf("unverified network measurement triggered a strong conclusion: %+v", findings)
	}
}

func BenchmarkNetworkWindow50000(b *testing.B) {
	events := make([]event.Event, 50000)
	for i := range events {
		e := measuredInterval(999, 1000, 2048, 2048)
		e.ID = fmt.Sprintf("e_%d", i)
		e.TS = e.TS.Add(time.Duration(i) * time.Millisecond)
		setMeasurementInterval(&e, e.TS.Add(-time.Millisecond), e.TS)
		events[i] = e
	}
	b.ResetTimer()
	for b.Loop() {
		f := Evaluate(events)
		if len(f) != 1 || f[0].Rule != "net/outbound-volume" {
			b.Fatal("large window evidence changed")
		}
	}
}
