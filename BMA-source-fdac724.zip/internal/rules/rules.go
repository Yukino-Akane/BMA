package rules

import (
	"encoding/json"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"

	"behavior-monitoring-audit/internal/destination"
	"behavior-monitoring-audit/internal/event"
)

type Config struct {
	ModelAPIHosts        []string      `json:"model_api_hosts"`
	LargeBytes           int64         `json:"large_bytes"`
	Entropy              float64       `json:"entropy"`
	DeleteWindowSeconds  float64       `json:"delete_window_sec"`
	OutboundMinBytes     uint64        `json:"outbound_min_bytes"`
	OutboundInRatio      float64       `json:"outbound_inbound_ratio"`
	NetworkWindowSeconds float64       `json:"window_sec"`
	Policy               Policy        `json:"policy"`
	Authorization        Authorization `json:"authorization"`
}

func DefaultConfig() Config {
	return Config{ModelAPIHosts: []string{"api.openai.com", "api.anthropic.com", "generativelanguage.googleapis.com"}, LargeBytes: 20 * 1024 * 1024, Entropy: 7.5, DeleteWindowSeconds: 300, OutboundMinBytes: 50 * 1024 * 1024, OutboundInRatio: 20, NetworkWindowSeconds: 300, Policy: DefaultPolicy(), Authorization: DefaultAuthorization()}
}

type Finding struct {
	Severity           string        `json:"severity"`
	Rule               string        `json:"rule"`
	Summary            string        `json:"summary"`
	Details            string        `json:"details,omitempty"`
	EvidenceIDs        []string      `json:"evidence_ids"`
	Conclusion         string        `json:"conclusion,omitempty"`
	EvidenceStrength   string        `json:"evidence_strength,omitempty"`
	AuthorizationState string        `json:"authorization_state,omitempty"`
	Target             string        `json:"target,omitempty"`
	FilePaths          []string      `json:"file_paths,omitempty"`
	Process            event.Process `json:"process,omitempty"`
	ObservedFrom       time.Time     `json:"observed_from,omitempty"`
	ObservedTo         time.Time     `json:"observed_to,omitempty"`
	CorrelationBasis   []string      `json:"correlation_basis,omitempty"`
	Uncertainty        []string      `json:"uncertainty,omitempty"`
}

func Evaluate(events []event.Event) []Finding { return EvaluateWithConfig(events, DefaultConfig()) }

func EvaluateWithConfig(events []event.Event, cfg Config) []Finding {
	findings := []Finding{}
	seen := map[string]bool{}
	add := func(severity, rule, summary string, ids ...string) {
		if len(ids) == 0 {
			return
		}
		key := rule + "\x00" + strings.Join(ids, ",")
		if seen[key] {
			return
		}
		seen[key] = true
		findings = append(findings, Finding{Severity: severity, Rule: rule, Summary: summary, EvidenceIDs: ids})
	}

	evaluateNetwork(events, cfg, add)

	storageSeen := map[[3]string]bool{}
	rangeSeen := map[[3]string]bool{}
	largeFileSeen := map[string]bool{}
	for _, item := range events {
		if item.Layer == "net" && item.Attribution == "direct" && (item.Kind == "connection_observed" || item.Kind == "egress") && item.Detail["direction"] != "aggregate" {
			host, _ := item.Detail["remote_host"].(string)
			ip, _ := item.Detail["remote_ip"].(string)
			if matches, field := destination.MatchIP(host, ip); len(matches) > 0 {
				key := [3]string{item.SessionID, processKey(item), matches[0].Address}
				if !rangeSeen[key] {
					rangeSeen[key] = true
					findings = append(findings, Finding{Severity: "medium", Rule: "net/storage-ip-range",
						Summary: "IP 命中存储服务网段快照：" + destination.SummarizeRanges(matches),
						Details: "记录字段：" + field + "。不证明实际服务、上传或事件发生时的归属。" + destination.DescribeRanges(matches), EvidenceIDs: []string{item.ID}})
				}
			}
			if destination.Classify(host, cfg.ModelAPIHosts) == destination.ObjectStorage {
				key := [3]string{item.SessionID, processKey(item), destination.Hostname(host)}
				if !storageSeen[key] {
					storageSeen[key] = true
					add("medium", "net/object-storage-destination", "记录中的域名符合对象存储地址格式；需核实实际用途", item.ID)
				}
			}
		}
		if item.Layer == "file" && (item.Kind == "file_create" || item.Kind == "file_modify" || item.Kind == "file_observed") {
			path, _ := item.Detail["path"].(string)
			size := numericUint(item.Detail["size_bytes"])
			entropy := numericFloat(item.Detail["entropy"])
			ext := strings.ToLower(filepath.Ext(path))
			archive := ext == ".zip" || ext == ".tar" || ext == ".gz" || ext == ".7z" || ext == ".rar"
			if size >= uint64(cfg.LargeBytes) || entropy >= cfg.Entropy || archive {
				key := item.SessionID + "\x00" + path
				if !largeFileSeen[key] {
					largeFileSeen[key] = true
					add("high", "file/large-or-packed", "所选目录出现大文件或疑似压缩、加密文件", item.ID)
				}
			}
		}
		if sensitive, ok := item.Detail["sensitive_path"].(bool); ok && sensitive {
			add("high", "file/sensitive-path", "所选目录的事件涉及敏感路径", item.ID)
		}
		if item.Kind == "file_delete" {
			createdID, _ := item.Detail["created_event_id"].(string)
			ageValue, exists := item.Detail["deleted_after_sec"]
			age := numericFloat(ageValue)
			if !exists || createdID == "" || age < 0 || age > cfg.DeleteWindowSeconds {
				continue
			}
			for _, prior := range events {
				if prior.ID == createdID && prior.SessionID == item.SessionID && prior.Kind == "file_create" {
					add("high", "file/create-delete-window", "文件创建后很快被删除；仅凭这一点不能证明上传", createdID, item.ID)
					break
				}
			}
		}
	}
	findings = append(findings, evaluateCorrelations(events, cfg)...)
	sort.SliceStable(findings, func(i, j int) bool { return findings[i].Rule < findings[j].Rule })
	return findings
}

func processKey(item event.Event) string {
	return item.Process.Name + "/" + strconv.Itoa(item.Process.PID) + "/" + strconv.FormatInt(item.Process.CreatedAtMS, 10)
}

func numericUint(values ...any) uint64 {
	for _, value := range values {
		switch n := value.(type) {
		case uint64:
			return n
		case uint32:
			return uint64(n)
		case int:
			if n > 0 {
				return uint64(n)
			}
		case int64:
			if n > 0 {
				return uint64(n)
			}
		case float64:
			if n > 0 {
				return uint64(n)
			}
		case json.Number:
			if parsed, err := strconv.ParseUint(string(n), 10, 64); err == nil {
				return parsed
			}
		}
	}
	return 0
}

func numericFloat(value any) float64 {
	switch n := value.(type) {
	case float64:
		return n
	case float32:
		return float64(n)
	case int:
		return float64(n)
	case int64:
		return float64(n)
	case uint64:
		return float64(n)
	case json.Number:
		v, _ := n.Float64()
		return v
	default:
		return 0
	}
}
