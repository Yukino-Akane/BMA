package rules

import (
	"fmt"
	"net"
	"net/url"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"behavior-monitoring-audit/internal/artifact"
	"behavior-monitoring-audit/internal/event"
)

// correlationCandidate is deliberately metadata-only. The collector never
// copies file contents into an event, so a correlation can only refer to the
// path, bounded size/entropy hints and the original event IDs.
type correlationCandidate struct {
	event     event.Event
	path      string
	size      uint64
	artifact  string
	protected bool
	sensitive bool
}

type correlationNetwork struct {
	event     event.Event
	target    string
	bytesOut  uint64
	attempt   bool
	method    string
	transport string
	source    string
}

func evaluateCorrelations(events []event.Event, cfg Config) []Finding {
	policy := cfg.Policy.Normalize()
	state := string(cfg.Authorization.Normalize().State)
	window := time.Duration(cfg.NetworkWindowSeconds * float64(time.Second))
	if window <= 0 {
		window = 5 * time.Minute
	}

	candidates := make([]correlationCandidate, 0)
	for _, e := range events {
		if e.Layer != "file" {
			continue
		}
		if e.Kind != "file_create" && e.Kind != "file_modify" && e.Kind != "file_open_observed" {
			continue
		}
		path := stringValue(e.Detail["path"])
		if path == "" {
			continue
		}
		artifact := stringValue(e.Detail["artifact_kind"])
		if artifact == "" || artifact == "opaque_high_entropy" {
			artifact = inferArtifact(path, stringValue(e.Detail["op"]), numberFloat(e.Detail["entropy"]), cfg.Entropy)
		}
		protected := pathInRoots(path, policy.ProtectedDirectories)
		sensitive := boolValue(e.Detail["sensitive_path"]) || protected || hasConfiguredCategory(path, artifact, policy.SensitiveCategories)
		// An initial directory inventory proves existence only. Keep changes
		// and open-handle samples as correlation clues; neither proves a read.
		if artifact == "" && !sensitive && e.Kind != "file_open_observed" {
			continue
		}
		candidates = append(candidates, correlationCandidate{event: e, path: path,
			size: numberUint(e.Detail["size_bytes"]), artifact: artifact,
			protected: protected, sensitive: sensitive})
	}

	findings := make([]Finding, 0)
	type artifactGroup struct {
		candidate correlationCandidate
		ids       []string
	}
	artifactGroups := map[string]*artifactGroup{}
	artifactOrder := make([]string, 0)
	for _, candidate := range candidates {
		// The legacy large-or-packed rule already covers common archive
		// extensions. Keep its stable finding count and add this richer
		// metadata finding for opaque/encrypted/snapshot candidates.
		if candidate.artifact == "" || candidate.artifact == "archive" || candidate.event.Kind == "file_open_observed" {
			continue
		}
		key := candidate.event.SessionID + "\x00" + candidate.path + "\x00" + candidate.artifact
		group, ok := artifactGroups[key]
		if !ok {
			group = &artifactGroup{candidate: candidate}
			artifactGroups[key] = group
			artifactOrder = append(artifactOrder, key)
		}
		group.ids = appendUnique(group.ids, candidate.event.ID)
		if candidatePriority(candidate) > candidatePriority(group.candidate) {
			group.candidate = candidate
		}
	}
	for _, key := range artifactOrder {
		candidate := artifactGroups[key].candidate
		ids := artifactGroups[key].ids
		severity := "medium"
		if candidate.sensitive || candidate.protected {
			severity = "high"
		}
		findings = append(findings, Finding{
			Severity: severity, Rule: "file/suspicious-artifact", Summary: "发现可疑打包或加密产物",
			Details:     fmt.Sprintf("产物类型线索：%s；路径：%s。", candidate.artifact, candidate.path),
			EvidenceIDs: ids, Conclusion: "发现可疑打包或加密产物",
			EvidenceStrength: "heuristic", AuthorizationState: state, FilePaths: []string{candidate.path},
			Process: candidate.event.Process, ObservedFrom: candidate.event.TS, ObservedTo: candidate.event.TS,
			CorrelationBasis: []string{"file_event", "artifact_name_or_entropy_hint"},
			Uncertainty:      []string{"扩展名、文件名或有限熵采样只是线索，未读取文件内容或归档成员"},
		})
	}

	network := make([]correlationNetwork, 0)
	for _, e := range events {
		if e.Layer != "net" || e.Attribution != "direct" || e.Process.PID <= 0 || e.Process.CreatedAtMS <= 0 {
			continue
		}
		source := stringValue(e.Detail["source"])
		isProxy := source == "proxy" || boolValue(e.Detail["proxy"])
		method := strings.ToUpper(stringValue(e.Detail["http_method"]))
		transport := stringValue(e.Detail["transport"])
		switch e.Kind {
		case "egress":
			if e.Detail["metric"] != "network_bytes" {
				continue
			}
			bytesOut, ok := exactUint(e.Detail["bytes_out"])
			if !ok || bytesOut == 0 {
				continue
			}
			network = append(network, correlationNetwork{event: e, target: eventTarget(e), bytesOut: bytesOut, attempt: isProxy && transport == "http" && isUploadMethod(method), method: method, transport: transport, source: source})
		case "connection_failed":
			if !isProxy || transport != "http" || !isUploadMethod(method) {
				continue
			}
			network = append(network, correlationNetwork{event: e, target: eventTarget(e), attempt: true, method: method, transport: transport, source: source})
		}
	}

	// Build one bounded finding per network segment. This keeps a large Git
	// tree actionable without flooding the report with one finding per object.
	for _, transfer := range network {
		related := make([]correlationCandidate, 0, 8)
		for _, candidate := range candidates {
			if candidate.event.SessionID != transfer.event.SessionID || candidate.event.TS.After(transfer.event.TS) || !withinWindow(candidate.event.TS, transfer.event.TS, window) {
				continue
			}
			if !sameProcess(candidate.event.Process, transfer.event.Process) && candidate.event.Kind == "file_open_observed" {
				continue
			}
			related = append(related, candidate)
		}
		if len(related) == 0 {
			if transfer.attempt {
				findings = append(findings, networkOnlyUploadAttempt(transfer, cfg))
			}
			continue
		}
		sort.SliceStable(related, func(i, j int) bool {
			left, right := candidatePriority(related[i]), candidatePriority(related[j])
			if left != right {
				return left > right
			}
			return related[i].event.TS.After(related[j].event.TS)
		})
		selected := make([]correlationCandidate, 0, 8)
		selectedPaths := map[string]bool{}
		for _, candidate := range related {
			if selectedPaths[candidate.path] {
				continue
			}
			selected = append(selected, candidate)
			selectedPaths[candidate.path] = true
			if len(selected) == 8 {
				break
			}
		}
		ids := []string{transfer.event.ID}
		paths := make([]string, 0, len(selected))
		basis := []string{"temporal_proximity"}
		uncertainty := []string{"文件变化没有操作进程归属；时间接近或打开句柄不证明文件内容进入网络字节"}
		from, to := transfer.event.TS, transfer.event.TS
		for _, candidate := range selected {
			ids = append(ids, candidate.event.ID)
			paths = append(paths, candidate.path)
			if candidate.event.TS.Before(from) {
				from = candidate.event.TS
			}
			if candidate.event.TS.After(to) {
				to = candidate.event.TS
			}
			if candidate.protected {
				basis = appendUnique(basis, "protected_directory")
			}
			if candidate.sensitive {
				basis = appendUnique(basis, "sensitive_path_or_category")
			}
			if candidate.event.Kind == "file_open_observed" && sameProcess(candidate.event.Process, transfer.event.Process) {
				basis = appendUnique(basis, "same_verified_process_open_sample")
				uncertainty = appendUnique(uncertainty, "lsof 只证明采样时句柄仍打开，不证明 read(2) 或读取内容")
			}
			if candidate.artifact != "" && candidate.event.Kind != "file_open_observed" {
				basis = appendUnique(basis, "artifact_generation_hint")
			}
			for _, extra := range related {
				if extra.path != candidate.path || extra.event.ID == candidate.event.ID {
					continue
				}
				if extra.event.Kind == "file_open_observed" && sameProcess(extra.event.Process, transfer.event.Process) {
					ids = appendUnique(ids, extra.event.ID)
					basis = appendUnique(basis, "same_verified_process_open_sample")
					uncertainty = appendUnique(uncertainty, "lsof 只证明采样时句柄仍打开，不证明 read(2) 或读取内容")
				} else if extra.event.Kind == "file_create" && extra.artifact != "" {
					ids = appendUnique(ids, extra.event.ID)
					basis = appendUnique(basis, "artifact_generation_hint")
				}
			}
		}
		if len(paths) == 0 {
			continue
		}
		transferStart := transfer.event.TS
		if value := stringValue(transfer.event.Detail["sample_start"]); value != "" {
			if parsed, err := time.Parse(time.RFC3339Nano, value); err == nil && !parsed.After(transferStart) {
				transferStart = parsed
			}
		}
		for _, e := range events {
			if e.Kind != "file_delete" || e.SessionID != transfer.event.SessionID || e.TS.Before(transferStart) || e.TS.After(transfer.event.TS.Add(window)) {
				continue
			}
			deletedPath := stringValue(e.Detail["path"])
			for _, path := range paths {
				if deletedPath == path {
					ids = appendUnique(ids, e.ID)
					basis = appendUnique(basis, "artifact_deleted_during_or_after_transfer")
					uncertainty = appendUnique(uncertainty, "产物删除与网络事件接近，不能证明已接收或删除前已上传")
				}
			}
		}
		target := transfer.target
		// Filesystem changes only establish timing. A verified open handle has
		// process identity suitable for evaluating the recorded path scope.
		attributed := make([]correlationCandidate, 0, len(selected))
		for _, candidate := range selected {
			if candidate.event.Kind == "file_open_observed" && candidate.event.Attribution == "direct" && sameProcess(candidate.event.Process, transfer.event.Process) {
				attributed = append(attributed, candidate)
			}
		}
		auth := authorizationFor(cfg, target, attributed)
		if auth == string(AuthorizationAuthorized) {
			uncertainty = appendUnique(uncertainty, "授权范围匹配关联路径和目标，但当前观测不能核验实际上传内容是否仅包含允许目录内数据")
		}
		if transfer.attempt {
			conclusion := "观察到上传尝试"
			summary := "观察到与可疑产物时间相关的上传尝试"
			details := fmt.Sprintf("代理观察到 %s 请求并向 %s 的下一跳连接成功写入 %d 字节；这不证明特定文件内容或远端接收。", transfer.method, displayTarget(target), transfer.bytesOut)
			strength := "observed_network_write"
			attemptBasis := "proxy_http_upload_method_and_write"
			if transfer.event.Kind == "connection_failed" {
				conclusion = "观察到上传尝试但连接失败或重试"
				summary = "观察到上传尝试失败或重试"
				details = fmt.Sprintf("代理观察到 %s 请求，但向 %s 的 %s 阶段失败；此事件不证明上游写入字节。", transfer.method, displayTarget(target), stringValue(transfer.event.Detail["stage"]))
				strength = "observed_request_attempt"
				attemptBasis = "proxy_http_upload_method_and_failure"
				uncertainty = appendUnique(uncertainty, "失败/重试记录不能证明服务端收到任何完整对象")
			}
			findings = append(findings, Finding{Severity: severityForTransfer(auth, attributed), Rule: "correlation/upload-attempt",
				Summary: summary, Details: details, EvidenceIDs: ids, Conclusion: conclusion,
				EvidenceStrength: strength, AuthorizationState: auth, Target: target,
				FilePaths: paths, Process: transfer.event.Process, ObservedFrom: from, ObservedTo: to,
				CorrelationBasis: appendUnique(basis, attemptBasis), Uncertainty: uncertainty})
		} else {
			details := fmt.Sprintf("记录到进程聚合出站 %d 字节；目标和内容未知。", transfer.bytesOut)
			strength := "suggestive_process_aggregate"
			if transfer.source == "proxy" {
				details = fmt.Sprintf("代理观察到向 %s 的 %d 字节出站；请求内容未观察到。", displayTarget(target), transfer.bytesOut)
				strength = "suggestive_proxy_bytes"
				if transfer.transport == "connect_tunnel" {
					details = fmt.Sprintf("代理观察到向 %s 的 %d 字节 CONNECT 隧道流量；TLS 内的请求方法和内容不可见。", displayTarget(target), transfer.bytesOut)
					uncertainty = appendUnique(uncertainty, "CONNECT/TLS 密文字节不能证明隧道内发生上传请求")
				} else {
					uncertainty = appendUnique(uncertainty, "非上传方法或方法未知；代理未保存正文和请求头")
				}
			} else if transfer.source == "nettop" {
				uncertainty = appendUnique(uncertainty, "nettop 是进程聚合字节，不能定位目标或请求内容")
			} else {
				uncertainty = appendUnique(uncertainty, "网络记录来源不明，无法核验其目标和计量方法")
			}
			findings = append(findings, Finding{Severity: severityForTransfer(auth, attributed), Rule: "correlation/suspected-exfiltration",
				Summary: "疑似数据外传：文件线索与进程出站在时间上相关", Details: details,
				EvidenceIDs: ids, Conclusion: "疑似数据外传", EvidenceStrength: strength, AuthorizationState: auth,
				Target: target, FilePaths: paths, Process: transfer.event.Process, ObservedFrom: from, ObservedTo: to,
				CorrelationBasis: basis, Uncertainty: uncertainty})
		}
	}
	return findings
}

// A verified proxy HTTP method is useful even when short file access escaped
// fsnotify/lsof. It is only a request observation: no file identity or body
// content can be inferred from this event.
func networkOnlyUploadAttempt(transfer correlationNetwork, cfg Config) Finding {
	auth := authorizationFor(cfg, transfer.target, nil)
	conclusion := "观察到上传尝试"
	summary := "观察到 HTTP 上传尝试（文件内容未知）"
	details := fmt.Sprintf("代理观察到 %s 请求并向 %s 的下一跳连接写入 %d 字节；没有可关联的文件访问或产物事件。", transfer.method, displayTarget(transfer.target), transfer.bytesOut)
	strength := "observed_network_write"
	basis := "proxy_http_upload_method_and_write"
	uncertainty := []string{"未观察到可关联文件；不能确定请求正文、来源文件或是否包含受保护数据", "向下一跳写入字节不证明远端应用接收"}
	if transfer.event.Kind == "connection_failed" {
		conclusion = "观察到上传尝试但连接失败或重试"
		summary = "观察到 HTTP 上传尝试失败（文件内容未知）"
		details = fmt.Sprintf("代理观察到 %s 请求，但向 %s 的 %s 阶段失败；此事件不证明写入任何上游字节。", transfer.method, displayTarget(transfer.target), stringValue(transfer.event.Detail["stage"]))
		strength = "observed_request_attempt"
		basis = "proxy_http_upload_method_and_failure"
		uncertainty = append(uncertainty, "失败记录不能证明服务端收到请求或文件")
	}
	return Finding{
		Severity: severityForTransfer(auth, nil), Rule: "correlation/upload-attempt",
		Summary: summary, Details: details, EvidenceIDs: []string{transfer.event.ID},
		Conclusion: conclusion, EvidenceStrength: strength, AuthorizationState: auth,
		Target: transfer.target, Process: transfer.event.Process,
		ObservedFrom: transfer.event.TS, ObservedTo: transfer.event.TS,
		CorrelationBasis: []string{basis}, Uncertainty: uncertainty,
	}
}

func sameProcess(a, b event.Process) bool {
	return a.PID > 0 && b.PID > 0 && a.PID == b.PID && a.CreatedAtMS > 0 && a.CreatedAtMS == b.CreatedAtMS
}

func isUploadMethod(method string) bool {
	return method == "POST" || method == "PUT" || method == "PATCH"
}

func candidatePriority(candidate correlationCandidate) int {
	if candidate.event.Kind == "file_open_observed" {
		return 5
	}
	if candidate.artifact != "" && candidate.event.Kind == "file_create" {
		return 4
	}
	if candidate.artifact != "" {
		return 3
	}
	if candidate.sensitive {
		return 2
	}
	return 1
}

func withinWindow(a, b time.Time, window time.Duration) bool {
	delta := a.Sub(b)
	if delta < 0 {
		delta = -delta
	}
	return delta <= window
}

func pathInRoots(path string, roots []string) bool {
	cleanPath := canonicalBoundaryPath(path)
	for _, root := range roots {
		cleanRoot := canonicalBoundaryPath(root)
		if cleanRoot == "." || cleanRoot == "" {
			continue
		}
		rel, err := filepath.Rel(cleanRoot, cleanPath)
		if err == nil && rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
			return true
		}
	}
	return false
}

// macOS commonly exposes /tmp as a symlink to /private/tmp. Resolve the
// deepest existing ancestor so deleted files and missing subdirectories still
// compare against the same policy root.
func canonicalBoundaryPath(path string) string {
	clean := filepath.Clean(path)
	suffix := ""
	for {
		if resolved, err := filepath.EvalSymlinks(clean); err == nil {
			return filepath.Join(resolved, suffix)
		}
		parent := filepath.Dir(clean)
		if parent == clean {
			return filepath.Clean(path)
		}
		suffix = filepath.Join(filepath.Base(clean), suffix)
		clean = parent
	}
}

func hasConfiguredCategory(path, artifact string, categories []string) bool {
	if len(categories) == 0 {
		return false
	}
	values := map[string]bool{}
	for _, value := range pathCategories(path, artifact) {
		values[strings.ToLower(strings.TrimSpace(value))] = true
	}
	for _, category := range categories {
		if values[strings.ToLower(strings.TrimSpace(category))] {
			return true
		}
	}
	return false
}

func pathCategories(path, artifact string) []string {
	lower := strings.ToLower(filepath.ToSlash(path))
	base := strings.ToLower(filepath.Base(path))
	result := []string{}
	if strings.Contains(lower, "/.git/") || strings.HasPrefix(base, ".git") {
		result = append(result, "git", "git_history")
	}
	if strings.Contains(lower, "/.ssh/") || strings.Contains(lower, "/.aws/") || strings.Contains(lower, "/.kube/") || strings.HasPrefix(base, ".env") || strings.HasSuffix(base, ".pem") || base == ".npmrc" || strings.HasSuffix(lower, "/.docker/config.json") {
		result = append(result, "credentials", "secrets", "sensitive")
	}
	if artifact != "" {
		result = append(result, artifact)
	}
	return result
}

func inferArtifact(path, op string, entropy, threshold float64) string {
	base := strings.ToLower(filepath.Base(path))
	ext := strings.ToLower(filepath.Ext(base))
	if hint := artifact.NameHint(path); hint != "" {
		return hint
	}
	if ext == "" && threshold > 0 && entropy >= threshold {
		return "opaque_high_entropy"
	}
	if op == "create" && strings.Contains(base, "tmp") {
		return "temporary_artifact"
	}
	return ""
}

func eventTarget(e event.Event) string {
	for _, key := range []string{"remote_host", "remote_ip"} {
		if value := stringValue(e.Detail[key]); value != "" {
			return normalizeTarget(value)
		}
	}
	return ""
}

func normalizeTarget(value string) string {
	value = strings.TrimSpace(strings.ToLower(value))
	if value == "" {
		return ""
	}
	if parsed, err := url.Parse(value); err == nil && parsed.Hostname() != "" {
		port := parsed.Port()
		if port == "" {
			switch parsed.Scheme {
			case "http":
				port = "80"
			case "https":
				port = "443"
			}
		}
		return targetWithPort(parsed.Hostname(), port)
	}
	if host, port, err := net.SplitHostPort(value); err == nil {
		return targetWithPort(host, port)
	}
	return strings.TrimSuffix(value, ".")
}

func targetWithPort(host, port string) string {
	host = strings.TrimSuffix(strings.ToLower(host), ".")
	if port == "" {
		return host
	}
	return net.JoinHostPort(host, port)
}

func displayTarget(target string) string {
	if target == "" {
		return "未知目标"
	}
	return target
}

func targetAllowed(target string, allowed []string) bool {
	if target == "" {
		return false
	}
	for _, item := range allowed {
		if normalizeTarget(item) == target {
			return true
		}
	}
	return false
}

func authorizationFor(cfg Config, target string, related []correlationCandidate) string {
	state := cfg.Authorization.Normalize().State
	if state != AuthorizationAuthorized {
		return string(state)
	}
	policy := cfg.Policy.Normalize()
	if len(policy.AllowedUploadTargets) == 0 || len(policy.AllowedUploadDirectories) == 0 {
		return "authorized_scope_incomplete"
	}
	if target == "" {
		return "authorized_target_unknown"
	}
	if !targetAllowed(target, policy.AllowedUploadTargets) {
		return "authorized_target_out_of_range"
	}
	if len(related) == 0 {
		return "authorized_related_path_unknown"
	}
	for _, candidate := range related {
		if !pathInRoots(candidate.path, policy.AllowedUploadDirectories) {
			return "authorized_related_path_out_of_range"
		}
	}
	return string(state)
}

func severityForTransfer(auth string, related []correlationCandidate) string {
	if auth == string(AuthorizationDenied) || auth == "authorized_target_out_of_range" || auth == "authorized_related_path_out_of_range" {
		return "high"
	}
	for _, candidate := range related {
		if candidate.sensitive || candidate.protected {
			return "high"
		}
	}
	return "medium"
}

func appendUnique(values []string, value string) []string {
	for _, existing := range values {
		if existing == value {
			return values
		}
	}
	return append(values, value)
}

func stringValue(value any) string {
	text, _ := value.(string)
	return text
}

func boolValue(value any) bool {
	result, _ := value.(bool)
	return result
}

func numberFloat(value any) float64 {
	switch number := value.(type) {
	case float64:
		return number
	case float32:
		return float64(number)
	case int:
		return float64(number)
	case int64:
		return float64(number)
	case uint64:
		return float64(number)
	default:
		return 0
	}
}

func numberUint(value any) uint64 {
	number := numberFloat(value)
	if number <= 0 {
		return 0
	}
	return uint64(number)
}

func exactUint(value any) (uint64, bool) {
	number := numberFloat(value)
	if number <= 0 || number != float64(uint64(number)) {
		return 0, false
	}
	return uint64(number), true
}
