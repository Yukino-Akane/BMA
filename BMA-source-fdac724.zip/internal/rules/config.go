package rules

import (
	"bytes"
	"fmt"
	"io"
	"math"
	"os"

	"behavior-monitoring-audit/internal/destination"
	"go.yaml.in/yaml/v3"
)

type fileConfig struct {
	File struct {
		LargeBytes      int64   `yaml:"large_bytes"`
		Entropy         float64 `yaml:"entropy"`
		DeleteWindowSec float64 `yaml:"delete_window_sec"`
	} `yaml:"file"`
	Network struct {
		ModelAPIHosts        []string `yaml:"model_api_hosts"`
		OutboundMinBytes     uint64   `yaml:"outbound_min_bytes"`
		OutboundInboundRatio float64  `yaml:"outbound_inbound_ratio"`
		WindowSec            float64  `yaml:"window_sec"`
	} `yaml:"network"`
}

func LoadConfig(path string) (Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return Config{}, err
	}
	var source fileConfig
	decoder := yaml.NewDecoder(bytes.NewReader(data))
	decoder.KnownFields(true)
	if err := decoder.Decode(&source); err != nil {
		return Config{}, fmt.Errorf("invalid rules file: %w", err)
	}
	var extra any
	if err := decoder.Decode(&extra); err != io.EOF {
		return Config{}, fmt.Errorf("rules must contain exactly one YAML document")
	}
	// Rules YAML intentionally contains thresholds only. Keep the user policy
	// metadata at its explicit default while loading those thresholds.
	cfg := DefaultConfig()
	cfg.ModelAPIHosts = source.Network.ModelAPIHosts
	cfg.LargeBytes = source.File.LargeBytes
	cfg.Entropy = source.File.Entropy
	cfg.DeleteWindowSeconds = source.File.DeleteWindowSec
	cfg.OutboundMinBytes = source.Network.OutboundMinBytes
	cfg.OutboundInRatio = source.Network.OutboundInboundRatio
	cfg.NetworkWindowSeconds = source.Network.WindowSec
	if err := cfg.Validate(); err != nil {
		return Config{}, err
	}
	return cfg, nil
}

func (cfg Config) Validate() error {
	if !cfg.Authorization.Valid() {
		return fmt.Errorf("authorization state must be unknown, authorized, or denied")
	}
	if err := cfg.Policy.ValidateAuthorization(cfg.Authorization); err != nil {
		return err
	}
	if cfg.ModelAPIHosts == nil {
		return fmt.Errorf("model_api_hosts is required; use [] for no model destinations")
	}
	seen := map[string]bool{}
	for _, host := range cfg.ModelAPIHosts {
		if destination.Hostname(host) != host || host == "" || seen[host] {
			return fmt.Errorf("model_api_hosts must contain unique lowercase DNS names without ports, wildcards or trailing dots")
		}
		seen[host] = true
	}

	for _, value := range []float64{cfg.Entropy, cfg.DeleteWindowSeconds, cfg.OutboundInRatio, cfg.NetworkWindowSeconds} {
		if value <= 0 || math.IsNaN(value) || math.IsInf(value, 0) {
			return fmt.Errorf("all rule thresholds are required and must be finite positive values")
		}
	}
	if cfg.LargeBytes <= 0 || cfg.OutboundMinBytes == 0 || cfg.Entropy > 8 || cfg.NetworkWindowSeconds > 86400 {
		return fmt.Errorf("invalid rule thresholds")
	}
	return nil
}
