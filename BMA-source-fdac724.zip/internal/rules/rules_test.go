package rules

import (
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
)

func TestProcessIOCannotBecomeUploadEvidence(t *testing.T) {
	created := event.New("s", "file", event.Process{Name: "unattributed"}, "file_create", "temporal", map[string]any{"path": "/tmp/a.zip", "size_bytes": int64(22 * 1024 * 1024)})
	deleted := event.New("s", "file", event.Process{Name: "unattributed"}, "file_delete", "temporal", map[string]any{"created_event_id": created.ID, "deleted_after_sec": 4.0})
	io := event.New("s", "net", event.Process{PID: 10, Name: "agent"}, "process_io", "direct", map[string]any{"bytes_in": uint64(1), "bytes_out": uint64(60 * 1024 * 1024), "metric": "process_io_proxy"})
	findings := Evaluate([]event.Event{created, deleted, io})
	seenRatio, seenDelete := false, false
	for _, f := range findings {
		if f.Rule == "net/outbound-inbound-ratio" || f.Rule == "net/outbound-volume" {
			seenRatio = true
		}
		if f.Rule == "file/create-delete-window" {
			seenDelete = len(f.EvidenceIDs) == 2
		}
	}
	if seenRatio || !seenDelete {
		t.Fatalf("findings=%#v", findings)
	}
}

func TestNetworkWindowExcludesOldAndOtherProcessEvidence(t *testing.T) {
	eventAt := func(offset time.Duration, pid int, out, in int) event.Event {
		e := event.New("s", "net", event.Process{PID: pid, Name: "agent"}, "egress", "direct", map[string]any{"metric": "network_bytes", "bytes_out": out, "bytes_in": in, "remote_ip": "192.0.2.1"})
		e.TS = time.Unix(1000, 0).Add(offset)
		setMeasurementInterval(&e, e.TS.Add(-time.Second), e.TS)
		return e
	}
	a := eventAt(0, 1, 30*1024*1024, 30*1024*1024)
	b := eventAt(301*time.Second, 1, 30*1024*1024, 30*1024*1024)
	c := eventAt(302*time.Second, 2, 30*1024*1024, 30*1024*1024)
	if f := Evaluate([]event.Event{a, b, c}); len(f) != 0 {
		t.Fatalf("unrelated/expired samples aggregated: %#v", f)
	}
	d := eventAt(303*time.Second, 1, 30*1024*1024, 0)
	f := Evaluate([]event.Event{a, b, c, d})
	if len(f) != 1 || f[0].Rule != "net/outbound-volume" || len(f[0].EvidenceIDs) != 2 || f[0].EvidenceIDs[0] != b.ID {
		t.Fatalf("bad volume evidence: %#v", f)
	}
	zeroIn := eventAt(0, 3, 1024, 0)
	if f := Evaluate([]event.Event{zeroIn}); len(f) != 1 || f[0].Rule != "net/outbound-inbound-ratio" {
		t.Fatalf("zero input ratio missing: %#v", f)
	}
}

func TestReloadedReportPreservesFileRule(t *testing.T) {
	e := event.New("s", "file", event.Process{}, "file_create", "temporal", map[string]any{"path": "artifact.bin", "size_bytes": int64(21 * 1024 * 1024)})
	raw, _ := json.Marshal([]event.Event{e})
	var reloaded []event.Event
	if err := json.Unmarshal(raw, &reloaded); err != nil {
		t.Fatal(err)
	}
	if len(Evaluate(reloaded)) != 1 {
		t.Fatal("JSON numeric decoding lost size threshold")
	}
	e.Kind = "file_rename_from"
	e.Detail["created_event_id"] = "unknown"
	e.Detail["deleted_after_sec"] = 1.0
	if len(Evaluate([]event.Event{e})) != 0 {
		t.Fatal("rename reported as deletion")
	}
}

func TestRulesFileIsStrictAndMatchesDefaults(t *testing.T) {
	cfg, err := LoadConfig(filepath.Join("..", "..", "rules.yaml"))
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(cfg, DefaultConfig()) {
		t.Fatalf("published thresholds differ: %+v", cfg)
	}
	p := filepath.Join(t.TempDir(), "rules.yaml")
	for _, data := range []string{"", "file: {large_bytes: -1}", "network: {unknown: 4}"} {
		if err := os.WriteFile(p, []byte(data), 0600); err != nil {
			t.Fatal(err)
		}
		if _, err := LoadConfig(p); err == nil {
			t.Fatalf("accepted invalid rules %q", data)
		}
	}
}

func TestNetworkWindowsSeparateLifetimesAndMeasurementSources(t *testing.T) {
	makeEvent := func(created int64, source string) event.Event {
		e := event.New("s", "net", event.Process{PID: 42, Name: "agent", CreatedAtMS: created}, "egress", "direct", map[string]any{"metric": "network_bytes", "bytes_out": 30 * 1024 * 1024, "bytes_in": 30 * 1024 * 1024, "remote_host": "same.example", "source": source})
		e.TS = time.Unix(1000, 0)
		setMeasurementInterval(&e, e.TS.Add(-time.Second), e.TS)
		return e
	}
	first, restarted := makeEvent(100, "nettop"), makeEvent(200, "nettop")
	proxy := makeEvent(100, "proxy")
	proxy.Detail["proxy"] = true
	if f := Evaluate([]event.Event{first, restarted, proxy}); len(f) != 0 {
		t.Fatalf("different lifetimes or sources combined: %+v", f)
	}
	next := makeEvent(100, "nettop")
	next.TS = next.TS.Add(time.Second)
	setMeasurementInterval(&next, next.TS.Add(-time.Second), next.TS)
	if f := Evaluate([]event.Event{first, next}); len(f) != 1 || f[0].Rule != "net/outbound-volume" {
		t.Fatalf("same process lost window: %+v", f)
	}
	delete(first.Detail, "remote_host")
	delete(next.Detail, "remote_host")
	first.Detail["direction"], next.Detail["direction"] = "aggregate", "aggregate"
	if f := Evaluate([]event.Event{first, next}); len(f) != 1 {
		t.Fatalf("aggregate measurement ignored: %+v", f)
	}
}

func TestProxyDestinationsOnSharedIPKeepSeparateWindows(t *testing.T) {
	var events []event.Event
	for _, host := range []string{"first.example:443", "second.example:443", "first.example:8443"} {
		events = append(events, event.New("s", "net", event.Process{PID: 42, CreatedAtMS: 100}, "egress", "direct", map[string]any{"metric": "network_bytes", "proxy": true, "remote_ip": "192.0.2.1", "remote_host": host, "bytes_out": 30 * 1024 * 1024, "bytes_in": 30 * 1024 * 1024}))
	}
	for i := range events {
		setMeasurementInterval(&events[i], events[i].TS.Add(-time.Second), events[i].TS)
	}
	if f := Evaluate(events); len(f) != 0 {
		t.Fatalf("different proxy destinations sharing an IP were merged: %+v", f)
	}
}

func setMeasurementInterval(e *event.Event, start, end time.Time) {
	e.Detail["sample_start"] = start.Format(time.RFC3339Nano)
	e.Detail["sample_end"] = end.Format(time.RFC3339Nano)
}
