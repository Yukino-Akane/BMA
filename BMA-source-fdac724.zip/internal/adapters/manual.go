package adapters

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"strings"

	"behavior-monitoring-audit/internal/event"
)

const maxGoalBytes = 1024 * 1024

func Goal(session, text string) (event.Event, error) {
	if strings.TrimSpace(text) == "" {
		return event.Event{}, fmt.Errorf("goal must not be empty")
	}
	if len(text) > maxGoalBytes {
		return event.Event{}, fmt.Errorf("goal exceeds 1 MiB")
	}
	return event.New(session, "semantic", event.Process{Name: "user"}, "goal", "direct", map[string]any{"role": "user", "text": text}), nil
}

func GoalFile(session, path string) (event.Event, error) {
	file, err := os.Open(path)
	if err != nil {
		return event.Event{}, err
	}
	defer file.Close()
	data, err := io.ReadAll(io.LimitReader(file, maxGoalBytes+1))
	if err != nil {
		return event.Event{}, err
	}
	if len(data) > maxGoalBytes {
		return event.Event{}, fmt.Errorf("goal exceeds 1 MiB")
	}
	return Goal(session, strings.TrimPrefix(string(data), "\ufeff"))
}

// Claims reads an explicitly supplied file. Claimed actions are self-reported,
// not proof that an operating-system action actually occurred.
func Claims(session, path string, emit func(event.Event) error) error {
	if emit == nil {
		return fmt.Errorf("claims require an event sink")
	}
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()
	scanner := bufio.NewScanner(f)
	scanner.Buffer(make([]byte, 4096), 1024*1024)
	for line := 1; scanner.Scan(); line++ {
		text := strings.TrimSpace(strings.TrimPrefix(scanner.Text(), "\ufeff"))
		if text == "" {
			continue
		}
		var claim map[string]any
		if err := json.Unmarshal([]byte(text), &claim); err != nil || claim == nil {
			return fmt.Errorf("invalid claim at line %d", line)
		}
		detail := map[string]any{"role": "claimed_action", "source": "manual", "trust": "self_reported"}
		if tool, ok := claim["tool"].(string); ok && strings.TrimSpace(tool) != "" {
			detail["tool"] = tool
		}
		var supplied []string
		for _, key := range []string{"args", "arguments", "command", "path", "url"} {
			if _, ok := claim[key]; ok {
				supplied = append(supplied, key)
			}
		}
		if len(supplied) > 0 {
			detail["argument_fields"] = supplied
		}
		if detail["tool"] == nil && len(supplied) == 0 {
			return fmt.Errorf("claim at line %d has no supported action field", line)
		}
		if err := emit(event.New(session, "semantic", event.Process{Name: "agent-log"}, "claimed_action", "direct", detail)); err != nil {
			return err
		}
	}
	if err := scanner.Err(); err != nil {
		return fmt.Errorf("read claims: %w", err)
	}
	return nil
}
