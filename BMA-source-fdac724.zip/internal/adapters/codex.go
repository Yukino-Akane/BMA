package adapters

import "behavior-monitoring-audit/internal/event"

func codexRecord(session string, value map[string]any) []event.Event {
	// event_msg mirrors user messages/tool lifecycle events. Import only
	// response_item records to avoid counting a single action twice.
	if value["type"] != "response_item" {
		return nil
	}
	payload, _ := value["payload"].(map[string]any)
	switch payload["type"] {
	case "message":
		if payload["role"] == "user" {
			return addGoal(nil, session, "codex", payload["content"])
		}
	case "function_call":
		return addTool(nil, session, "codex", payload["name"], payload["arguments"], payload["call_id"])
	case "custom_tool_call":
		return addTool(nil, session, "codex", payload["name"], payload["input"], payload["call_id"])
	}
	return nil
}
