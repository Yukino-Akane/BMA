package adapters

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"behavior-monitoring-audit/internal/event"
)

type clineReader struct {
	sessionID, agent string
	seen             map[int]clineObserved
	gap              bool
}

type clineObserved struct {
	fingerprint [32]byte
	emitted     int
}

type clineSnapshot struct {
	Version   int               `json:"version"`
	SessionID string            `json:"sessionId"`
	Agent     string            `json:"agent"`
	Messages  []json.RawMessage `json:"messages"`
}

type clineMessage struct {
	ID        string          `json:"id"`
	SessionID string          `json:"sessionId"`
	Role      string          `json:"role"`
	TS        *int64          `json:"ts"`
	Content   json.RawMessage `json:"content"`
}

type clineEntry struct {
	index       int
	fingerprint [32]byte
	events      []event.Event
}

func (r *LogReader) pollCline(ctx context.Context, final bool, emit func(event.Event) error) error {
	snapshot, entries, err := readClineSnapshot(ctx, r.session, r.path)
	if err != nil {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		if final {
			return err
		}
		if !r.cline.gap {
			if err := emit(event.New(r.session, "semantic", event.Process{Name: "cline-log"}, "collector_error", "direct", map[string]any{
				"source": "cline", "coverage": "incomplete", "reason": "snapshot_unavailable", "error": err.Error(),
			})); err != nil {
				return err
			}
			r.cline.gap = true
		}
		return nil
	}
	if r.cline.sessionID != "" && (r.cline.sessionID != snapshot.SessionID || r.cline.agent != snapshot.Agent) {
		return fmt.Errorf("Cline session identity changed; select the session again")
	}
	current := make(map[int][32]byte, len(entries))
	for _, entry := range entries {
		current[entry.index] = entry.fingerprint
	}
	for index, observed := range r.cline.seen {
		if next, ok := current[index]; !ok || next != observed.fingerprint {
			return fmt.Errorf("Cline observed history changed or was removed; select the session again")
		}
	}
	r.cline.sessionID, r.cline.agent = snapshot.SessionID, snapshot.Agent
	if r.cline.gap {
		if err := emit(event.New(r.session, "semantic", event.Process{Name: "cline-log"}, "collector_recovered", "direct", map[string]any{
			"source": "cline", "reason": "snapshot_available", "coverage": "previous_gap_remains",
		})); err != nil {
			return err
		}
		r.cline.gap = false
	}
	for _, entry := range entries {
		if err := ctx.Err(); err != nil {
			return err
		}
		observed := r.cline.seen[entry.index]
		for _, e := range entry.events[observed.emitted:] {
			if err := emit(e); err != nil {
				return err
			}
			observed.fingerprint = entry.fingerprint
			observed.emitted++
			r.cline.seen[entry.index] = observed
		}
	}
	return nil
}

func readClineSnapshot(ctx context.Context, session, path string) (clineSnapshot, []clineEntry, error) {
	var snapshot clineSnapshot
	data, err := readSnapshot(path, "Cline")
	if err != nil {
		return snapshot, nil, err
	}
	if err := json.Unmarshal(bytes.TrimPrefix(data, []byte("\xef\xbb\xbf")), &snapshot); err != nil || snapshot.Version != 1 || strings.TrimSpace(snapshot.SessionID) == "" || snapshot.Messages == nil ||
		(snapshot.Agent != "lead" && snapshot.Agent != "subagent" && snapshot.Agent != "teammate") {
		return snapshot, nil, fmt.Errorf("Cline log must be a version 1 SDK messages snapshot with session identity")
	}
	if len(snapshot.Messages) > maxSnapshotRecords {
		return snapshot, nil, fmt.Errorf("Cline snapshot exceeds 50000 messages")
	}
	var entries []clineEntry
	ids := map[string]bool{}
	calls := map[string]bool{}
	count := 0
	for index, raw := range snapshot.Messages {
		if err := ctx.Err(); err != nil {
			return snapshot, nil, err
		}
		if len(raw) > maxLogLine {
			return snapshot, nil, fmt.Errorf("Cline message exceeds 4 MiB; snapshot not imported")
		}
		var m clineMessage
		if err := json.Unmarshal(raw, &m); err != nil || (m.Role != "user" && m.Role != "assistant") ||
			(m.TS != nil && (*m.TS <= 0 || *m.TS > 253402300799999)) || (m.SessionID != "" && m.SessionID != snapshot.SessionID) {
			return snapshot, nil, fmt.Errorf("invalid Cline message at record %d", index+1)
		}
		if m.ID != "" {
			if ids[m.ID] {
				return snapshot, nil, fmt.Errorf("duplicate Cline message id at record %d", index+1)
			}
			ids[m.ID] = true
		}
		events, err := clineSemantic(session, m)
		if err != nil {
			return snapshot, nil, fmt.Errorf("invalid Cline content at record %d", index+1)
		}
		count += len(events)
		if count > maxSnapshotRecords {
			return snapshot, nil, fmt.Errorf("Cline snapshot exceeds 50000 semantic events")
		}
		for i := range events {
			d := events[i].Detail
			if id, ok := d["call_id"].(string); ok {
				if calls[id] {
					return snapshot, nil, fmt.Errorf("duplicate Cline tool request id at record %d", index+1)
				}
				calls[id] = true
			}
			d["source"], d["trust"], d["time_source"] = "cline", "self_reported", "observed"
			d["log_record"], d["agent_role"] = index+1, snapshot.Agent
			d["source_session_id"] = snapshot.SessionID
			if m.ID != "" {
				d["message_id"] = m.ID
			}
			if m.TS != nil {
				events[i].TS = time.UnixMilli(*m.TS).UTC()
				d["time_source"] = "agent_log"
			}
		}
		if len(events) > 0 {
			// Hash source content in memory to detect edited arguments; only
			// the selected semantic fields above leave this reader.
			encoded, err := json.Marshal(m)
			if err != nil {
				return snapshot, nil, fmt.Errorf("Cline source message could not be encoded")
			}
			entries = append(entries, clineEntry{index: index, fingerprint: sha256.Sum256(encoded), events: events})
		}
	}
	return snapshot, entries, nil
}

func clineSemantic(session string, m clineMessage) ([]event.Event, error) {
	if bytes.Equal(bytes.TrimSpace(m.Content), []byte("null")) {
		return nil, fmt.Errorf("content is null")
	}
	var text string
	if json.Unmarshal(m.Content, &text) == nil {
		if m.Role == "user" && strings.TrimSpace(text) != "" {
			return []event.Event{semantic(session, "cline", "goal", map[string]any{"role": "user", "text": text})}, nil
		}
		return nil, nil
	}
	var blocks []struct {
		Type string `json:"type"`
		Text string `json:"text"`
		Name string `json:"name"`
		ID   string `json:"id"`
	}
	if err := json.Unmarshal(m.Content, &blocks); err != nil || blocks == nil || len(blocks) > maxSnapshotRecords {
		return nil, fmt.Errorf("expected text or content blocks")
	}
	var result []event.Event
	var texts []string
	for _, b := range blocks {
		switch b.Type {
		case "text", "tool_use", "tool_result", "image", "media", "file", "thinking", "redacted_thinking":
		default:
			return nil, fmt.Errorf("unknown block type")
		}
		if m.Role == "user" && b.Type == "text" && strings.TrimSpace(b.Text) != "" {
			texts = append(texts, b.Text)
		}
		if m.Role == "assistant" && b.Type == "tool_use" {
			if strings.TrimSpace(b.Name) == "" || strings.TrimSpace(b.ID) == "" {
				return nil, fmt.Errorf("invalid tool request")
			}
			result = append(result, semantic(session, "cline", "claimed_action", map[string]any{
				"role": "claimed_action", "tool": b.Name, "call_id": b.ID, "stage": "tool_request",
			}))
		}
	}
	if len(texts) > 0 {
		result = append(result, semantic(session, "cline", "goal", map[string]any{"role": "user", "text": strings.Join(texts, "\n")}))
	}
	return result, nil
}
