package adapters

import (
	"context"
	"errors"
	"os"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
)

// Optional smoke check for explicitly supplied local sessions. It never writes
// their contents, paths, goals or arguments to test output or report files.
func TestExplicitLocalSessions(t *testing.T) {
	for _, spec := range []struct{ format, env string }{{"claude", "BMA_TEST_CLAUDE_LOG"}, {"codex", "BMA_TEST_CODEX_LOG"}} {
		t.Run(spec.format, func(t *testing.T) {
			path := os.Getenv(spec.env)
			if path == "" {
				t.Skip("no explicit local session selected")
			}
			r, err := NewLogReader("test-local", path, spec.format)
			if err != nil {
				t.Fatal("unable to open selected local session")
			}
			ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
			defer cancel()
			goals, actions, gaps := 0, 0, 0
			err = r.Poll(ctx, false, func(e event.Event) error {
				if e.Kind == "goal" {
					goals++
				}
				if e.Kind == "claimed_action" {
					actions++
				}
				if e.Kind == "collector_error" {
					gaps++
				}
				return nil
			})
			if err != nil {
				var pathErr *os.PathError
				if errors.As(err, &pathErr) {
					t.Fatal("local session filesystem error")
				}
				t.Fatalf("after %d records: %v", r.line, err)
			}
			if goals+actions == 0 {
				t.Fatal("no supported semantic records found")
			}
			t.Logf("processed records=%d goals=%d actions=%d coverage_gaps=%d", r.line, goals, actions, gaps)
		})
	}
}
