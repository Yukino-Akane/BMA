package adapters

import (
	"strings"

	"behavior-monitoring-audit/internal/event"
)

func genericRecord(session string, value map[string]any) []event.Event {
	result := []event.Event{}
	role, _ := value["role"].(string)
	if role == "user" || role == "human" {
		if text := textValue(value["content"]); text != "" {
			result = append(result, event.New(session, "semantic", event.Process{Name: "agent-log"}, "goal", "direct", map[string]any{"role": "user", "text": text, "source": "agent-log"}))
		}
	}
	if action := claimed(value); action != nil {
		result = append(result, event.New(session, "semantic", event.Process{Name: "agent-log"}, "claimed_action", "direct", action))
	}
	calls, _ := value["tool_calls"].([]any)
	for _, call := range calls {
		item, _ := call.(map[string]any)
		function, _ := item["function"].(map[string]any)
		result = addTool(result, session, "generic", function["name"], function["arguments"], item["id"])
	}
	return result
}

func textValue(value any) string {
	if text, ok := value.(string); ok {
		return strings.TrimSpace(text)
	}
	if blocks, ok := value.([]any); ok {
		var result []string
		for _, block := range blocks {
			if item, ok := block.(map[string]any); ok {
				if kind, ok := item["type"].(string); ok && kind != "text" && kind != "input_text" && kind != "output_text" {
					continue
				}
				if text, ok := item["text"].(string); ok {
					result = append(result, text)
				}
			}
		}
		return strings.TrimSpace(strings.Join(result, "\n"))
	}
	return ""
}

func claimed(value map[string]any) map[string]any {
	tool, _ := value["tool"].(string)
	if tool == "" {
		tool, _ = value["tool_name"].(string)
	}
	if tool == "" {
		return nil
	}
	detail := map[string]any{"role": "claimed_action", "source": "agent-log", "trust": "self_reported"}
	if tool != "" {
		detail["tool"] = tool
	}
	return detail
}
