package adapters

import (
	"context"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/redact"
)

func clineFixture() map[string]any {
	return map[string]any{
		"version": 1, "sessionId": "task-a", "agent": "lead", "system_prompt": "private-system",
		"messages": []map[string]any{
			{"id": "m1", "role": "user", "ts": 1789812000000, "content": []any{
				map[string]any{"type": "text", "text": "Only edit README"},
				map[string]any{"type": "file", "content": "private-file", "path": "private-path"},
				map[string]any{"type": "image", "source": "private-image"},
				map[string]any{"type": "media", "media": "private-media"},
			}},
			{"id": "m2", "role": "assistant", "ts": 1789812000001, "content": []any{
				map[string]any{"type": "text", "text": "private-assistant"},
				map[string]any{"type": "thinking", "thinking": "private-thinking"},
				map[string]any{"type": "redacted_thinking", "data": "private-thinking"},
				map[string]any{"type": "tool_use", "id": "call1", "name": "read_files", "input": map[string]any{"path": "private-arguments"}},
			}},
			{"id": "m3", "role": "user", "content": []any{
				map[string]any{"type": "tool_result", "tool_use_id": "call1", "content": "private-result"},
			}},
		},
	}
}

func writeCline(t *testing.T, path string, value map[string]any) {
	t.Helper()
	data, err := json.Marshal(value)
	if err != nil {
		t.Fatal(err)
	}
	writeLog(t, path, string(data), false)
}

func TestClineSDKSnapshotSemanticsAndRewrite(t *testing.T) {
	path := filepath.Join(t.TempDir(), "task-a.messages.json")
	fixture := clineFixture()
	writeCline(t, path, fixture)
	r, err := NewLogReader("s", path, "cline")
	if err != nil {
		t.Fatal(err)
	}
	var events []event.Event
	emit := func(e event.Event) error { events = append(events, e); return nil }
	if err := r.Poll(context.Background(), false, emit); err != nil {
		t.Fatal(err)
	}
	if len(events) != 2 || events[0].Kind != "goal" || events[1].Detail["stage"] != "tool_request" || events[1].Detail["log_record"] != 2 || events[1].TS.UnixMilli() != 1789812000001 {
		t.Fatal("wrong SDK semantics")
	}
	rows := fixture["messages"].([]map[string]any)
	rows[1]["metrics"] = map[string]any{"cost": 0.01}
	fixture["updated_at"] = "2026-09-19T10:00:02Z"
	fixture["messages"] = append(rows, map[string]any{"id": "m4", "role": "user", "content": "Keep it small"})
	if err := os.Rename(path, path+".old"); err != nil {
		t.Fatal(err)
	}
	writeCline(t, path, fixture)
	for i := 0; i < 2; i++ {
		if err := r.Poll(context.Background(), true, emit); err != nil {
			t.Fatal(err)
		}
	}
	if len(events) != 3 || events[2].Detail["time_source"] != "observed" {
		t.Fatal("duplicate records or fabricated timestamp")
	}
	for _, e := range events {
		if e.Detail["source"] != "cline" || e.Detail["trust"] != "self_reported" || e.Detail["agent_role"] != "lead" {
			t.Fatal("lost source provenance")
		}
	}
	for _, value := range []any{events, redact.Events(events, false)} {
		data, _ := json.Marshal(value)
		if strings.Contains(string(data), "private-") {
			t.Fatal("private source content copied")
		}
	}
	if redact.Events(events, false)[1].Detail["stage"] != "tool_request" || redact.Events(events, false)[0].Detail["agent_role"] != "lead" {
		t.Fatal("model lost SDK context")
	}
}

func TestClineRejectsReplacedIdentityAndRewrittenHistoryBeforeEmission(t *testing.T) {
	for _, mode := range []string{"identity", "agent", "goal", "arguments", "removed", "timestamp"} {
		t.Run(mode, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "messages.json")
			fixture := clineFixture()
			writeCline(t, path, fixture)
			r, _ := NewLogReader("s", path, "cline")
			count := 0
			emit := func(event.Event) error { count++; return nil }
			if err := r.Poll(context.Background(), false, emit); err != nil {
				t.Fatal(err)
			}
			rows := fixture["messages"].([]map[string]any)
			switch mode {
			case "identity":
				fixture["sessionId"] = "task-b"
			case "agent":
				fixture["agent"] = "subagent"
			case "goal":
				rows[0]["content"] = "changed goal"
			case "arguments":
				rows[1]["content"].([]any)[3].(map[string]any)["input"] = "changed arguments"
			case "removed":
				rows = rows[:1]
			case "timestamp":
				rows[0]["ts"] = 1
			}
			fixture["messages"] = append(rows, map[string]any{"role": "user", "content": "new request must not emit"})
			writeCline(t, path, fixture)
			if err := r.Poll(context.Background(), false, emit); err == nil || count != 2 {
				t.Fatal("changed source accepted or new evidence emitted early")
			}
		})
	}
}

func TestClineInvalidSnapshotAndLimits(t *testing.T) {
	for _, mode := range []string{"version", "array", "session", "agent", "null-messages", "missing-content", "null-content", "unknown-block", "invalid-tool", "duplicate-message", "duplicate-tool", "foreign-message", "timestamp", "record-size", "record-count", "file-size", "trailing"} {
		t.Run(mode, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "messages.json")
			fixture := clineFixture()
			rows := fixture["messages"].([]map[string]any)
			switch mode {
			case "version":
				fixture["version"] = 2
			case "session":
				delete(fixture, "sessionId")
			case "agent":
				fixture["agent"] = "other"
			case "missing-content":
				delete(rows[0], "content")
			case "null-content":
				rows[0]["content"] = nil
			case "unknown-block":
				rows[0]["content"] = []any{map[string]any{"type": "future-kind"}}
			case "invalid-tool":
				delete(rows[1]["content"].([]any)[3].(map[string]any), "name")
			case "duplicate-message":
				rows[1]["id"] = "m1"
			case "duplicate-tool":
				rows[1]["content"] = append(rows[1]["content"].([]any), rows[1]["content"].([]any)[3])
			case "foreign-message":
				rows[0]["sessionId"] = "task-b"
			case "timestamp":
				rows[0]["ts"] = 1.2
			case "record-size":
				rows[0]["content"] = strings.Repeat("x", maxLogLine+1)
			case "record-count":
				for len(rows) <= maxSnapshotRecords {
					rows = append(rows, map[string]any{"role": "assistant", "content": "ignored"})
				}
			}
			fixture["messages"] = rows
			if mode == "null-messages" {
				fixture["messages"] = nil
			}
			writeCline(t, path, fixture)
			switch mode {
			case "array":
				writeLog(t, path, "[]", false)
			case "trailing":
				writeLog(t, path, "{}", true)
			case "file-size":
				if err := os.Truncate(path, maxSnapshotBytes+1); err != nil {
					t.Fatal(err)
				}
			}
			if _, _, err := readClineSnapshot(context.Background(), "s", path); err == nil {
				t.Fatal("invalid snapshot accepted")
			}
		})
	}
}

func TestClineGapRecoveryAndPartialEmissionRetry(t *testing.T) {
	path := filepath.Join(t.TempDir(), "messages.json")
	fixture := clineFixture()
	rows := fixture["messages"].([]map[string]any)
	rows[1]["content"] = append(rows[1]["content"].([]any), map[string]any{"type": "tool_use", "id": "call2", "name": "run_commands"})
	writeCline(t, path, fixture)
	r, _ := NewLogReader("s", path, "cline")
	var events []event.Event
	want := errors.New("fixture store failure")
	emit := func(e event.Event) error { events = append(events, e); return nil }
	if err := r.Poll(context.Background(), false, func(e event.Event) error {
		if len(events) == 2 {
			return want
		}
		return emit(e)
	}); !errors.Is(err, want) {
		t.Fatal("missing callback failure")
	}
	if err := r.Poll(context.Background(), false, emit); err != nil || len(events) != 3 || events[2].Detail["call_id"] != "call2" {
		t.Fatal("partial callback retry duplicated successful events", err)
	}
	writeLog(t, path, "{", false)
	for i := 0; i < 2; i++ {
		if err := r.Poll(context.Background(), false, emit); err != nil {
			t.Fatal(err)
		}
	}
	if len(events) != 4 || events[3].Kind != "collector_error" {
		t.Fatal("missing or repeated snapshot gap")
	}
	if err := r.Poll(context.Background(), true, emit); err == nil {
		t.Fatal("final invalid snapshot accepted")
	}
	writeCline(t, path, fixture)
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := r.Follow(ctx, time.Millisecond, emit); err != nil || len(events) != 5 || events[4].Kind != "collector_recovered" {
		t.Fatal("recovery/final flush lost or evidence duplicated", err)
	}
}

func TestClineEmptySnapshotPinsIdentityAndDelegation(t *testing.T) {
	for _, agent := range []string{"lead", "subagent", "teammate"} {
		t.Run(agent, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "messages.json")
			fixture := clineFixture()
			fixture["agent"] = agent
			fixture["messages"] = []any{}
			writeCline(t, path, fixture)
			r, _ := NewLogReader("s", path, "cline")
			var events []event.Event
			emit := func(e event.Event) error { events = append(events, e); return nil }
			if err := r.Poll(context.Background(), false, emit); err != nil || len(events) != 0 {
				t.Fatal("new empty SDK session rejected", err)
			}
			fixture["messages"] = []any{map[string]any{"role": "user", "content": "Task"}}
			writeCline(t, path, fixture)
			if err := r.Poll(context.Background(), false, emit); err != nil || len(events) != 1 || events[0].Detail["agent_role"] != agent || events[0].Detail["source_session_id"] != "task-a" {
				t.Fatal("identity or delegation lost", err)
			}
			fixture["sessionId"] = "different-task"
			writeCline(t, path, fixture)
			if err := r.Poll(context.Background(), true, emit); err == nil {
				t.Fatal("different session accepted")
			}
		})
	}
}

func TestClineSemanticExpansionLimitBeforeEmission(t *testing.T) {
	path := filepath.Join(t.TempDir(), "messages.json")
	fixture := clineFixture()
	rows := []map[string]any{}
	for message := 0; message < 2; message++ {
		blocks := []map[string]any{}
		for i := 0; i < 25001; i++ {
			blocks = append(blocks, map[string]any{"type": "tool_use", "id": strconv.Itoa(message*25001 + i), "name": "read_files"})
		}
		rows = append(rows, map[string]any{"role": "assistant", "content": blocks})
	}
	fixture["messages"] = rows
	writeCline(t, path, fixture)
	r, err := NewLogReader("s", path, "cline")
	if err != nil {
		t.Fatal(err)
	}
	count := 0
	err = r.Poll(context.Background(), true, func(event.Event) error { count++; return nil })
	if err == nil || !strings.Contains(err.Error(), "semantic events") || count != 0 {
		t.Fatalf("snapshot expansion not bounded before emission: count=%d error=%v", count, err)
	}
}
