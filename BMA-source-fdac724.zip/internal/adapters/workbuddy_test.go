package adapters

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"behavior-monitoring-audit/internal/event"
)

func TestWorkBuddyPersistedLog(t *testing.T) {
	path := filepath.Join(t.TempDir(), "session.jsonl")
	lines := []string{
		`{"type":"message","role":"user","content":[{"type":"input_text","text":"edit fixture"},{"type":"input_image","text":"private-image"}],"timestamp":1789880422644}`,
		`{"type":"function_call","name":"Read","callId":"read-1","arguments":"private-args","message":{"content":"private-mirror"},"timestamp":1789880422695}`,
		`{"type":"function_call_result","name":"Read","output":"private-output","timestamp":1789880422695}`,
		`{"type":"message","role":"assistant","content":[{"type":"output_text","text":"private-answer"}],"timestamp":1789880422778}`,
		`{"type":"file-history-snapshot","snapshot":{"text":"private-snapshot"}}`,
	}
	if err := os.WriteFile(path, []byte(strings.Join(lines, "\n")+"\n"), 0600); err != nil {
		t.Fatal(err)
	}
	r, err := NewLogReader("audit-session", path, "workbuddy")
	if err != nil {
		t.Fatal(err)
	}
	var events []event.Event
	emit := func(e event.Event) error { events = append(events, e); return nil }
	for range 2 {
		if err := r.Poll(context.Background(), true, emit); err != nil {
			t.Fatal(err)
		}
	}
	if len(events) != 2 || events[0].Kind != "goal" || events[0].Detail["text"] != "edit fixture" || events[1].Detail["tool"] != "Read" || events[1].Detail["call_id"] != "read-1" {
		t.Fatalf("unexpected semantic records: %+v", events)
	}
	if events[1].TS.UnixMilli() != 1789880422695 || events[1].Detail["log_line"] != 2 || events[1].Detail["source"] != "workbuddy" || events[1].Detail["trust"] != "self_reported" || events[1].Detail["stage"] != "tool_request" || events[1].Detail["time_source"] != "agent_log" {
		t.Fatal("source evidence lost")
	}
	data, _ := json.Marshal(events)
	if strings.Contains(string(data), "private-") {
		t.Fatal("copied arguments, mirrors, outputs or metadata")
	}
}

func TestWorkBuddyInvalidRecords(t *testing.T) {
	for _, timestamp := range []string{`null`, `"1789880422695"`, `0`, `-1`, `1.5`, `253402300800000`} {
		_, err := decodeRecord("s", "workbuddy", []byte(`{"type":"function_call","name":"Read","callId":"c","timestamp":`+timestamp+`}`))
		if err == nil {
			t.Fatalf("accepted invalid timestamp %s", timestamp)
		}
	}
	for _, line := range []string{
		`{"type":"function_call","name":"Read","timestamp":1789880422695}`,
		`{"type":"function_call","callId":"c","timestamp":1789880422695}`,
		`{"type":"message","role":"user","content":"task"}`,
	} {
		if _, err := decodeRecord("s", "workbuddy", []byte(line)); err == nil {
			t.Fatalf("accepted invalid semantic record %s", line)
		}
	}
}
