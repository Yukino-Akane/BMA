package adapters

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"behavior-monitoring-audit/internal/event"
)

func TestClaimsAndGoalRejectInvalidInput(t *testing.T) {
	dir := t.TempDir()
	goal := filepath.Join(dir, "goal.txt")
	if err := os.WriteFile(goal, []byte("update README"), 0600); err != nil {
		t.Fatal(err)
	}
	e, err := GoalFile("s_test", goal)
	if err != nil || e.Kind != "goal" {
		t.Fatalf("goal: %#v %v", e, err)
	}
	claims := filepath.Join(dir, "claims.jsonl")
	if err := os.WriteFile(claims, []byte(`{"tool":"read_file","path":"README.md"}`+"\n"), 0600); err != nil {
		t.Fatal(err)
	}
	var values []event.Event
	emit := func(e event.Event) error { values = append(values, e); return nil }
	err = Claims("s_test", claims, emit)
	if err != nil || len(values) != 1 || values[0].Kind != "claimed_action" {
		t.Fatalf("claims: %#v %v", values, err)
	}
	if err := os.WriteFile(claims, []byte(`{"unknown":true}`+"\n"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := Claims("s_test", claims, emit); err == nil {
		t.Fatal("expected unsupported claim error")
	}
}

func TestClaimsDoNotPersistRawActionFields(t *testing.T) {
	path := filepath.Join(t.TempDir(), "claims.jsonl")
	data := `{"tool":"read_file","args":{"token":"private-args"},"arguments":"private-arguments","command":"private-command","path":"private-path","url":"https://example.test/?token=private-url"}` + "\n" +
		`{"command":"private-command-only"}` + "\n"
	if err := os.WriteFile(path, []byte(data), 0600); err != nil {
		t.Fatal(err)
	}
	var values []event.Event
	if err := Claims("s", path, func(e event.Event) error { values = append(values, e); return nil }); err != nil {
		t.Fatal(err)
	}
	if len(values) != 2 || values[0].Detail["tool"] != "read_file" || values[1].Detail["argument_fields"] == nil {
		t.Fatalf("lost claim metadata: %#v", values)
	}
	local, err := json.Marshal(values)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(local), "private-") {
		t.Fatal("private claim arguments entered local evidence")
	}
}

func TestClaimsStopWhenSinkFailsAndGoalFileIsBounded(t *testing.T) {
	dir := t.TempDir()
	claims := filepath.Join(dir, "claims.jsonl")
	if err := os.WriteFile(claims, []byte("{\"tool\":\"read\"}\n{invalid}\n"), 0600); err != nil {
		t.Fatal(err)
	}
	stopped := errors.New("stop collection")
	err := Claims("s", claims, func(event.Event) error { return stopped })
	if !errors.Is(err, stopped) {
		t.Fatal("reader continued beyond the failed event sink")
	}
	goal := filepath.Join(dir, "goal.txt")
	if err := os.WriteFile(goal, []byte(strings.Repeat("a", maxGoalBytes+10)), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := GoalFile("s", goal); err == nil {
		t.Fatal("oversized goal accepted")
	}
}
