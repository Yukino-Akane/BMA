package adapters

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"strings"
	"time"

	"behavior-monitoring-audit/internal/event"
)

// Roo rewrites its UI message array, including atomic file replacement and
// partial-message updates. Only finalized semantic projections are retained.
type rooReader struct {
	seen map[int][32]byte
	gap  bool
}

type rooMessage struct {
	TS      int64  `json:"ts"`
	Type    string `json:"type"`
	Say     string `json:"say"`
	Ask     string `json:"ask"`
	Text    string `json:"text"`
	Partial bool   `json:"partial"`
}

type rooEntry struct {
	index       int
	fingerprint [32]byte
	event       *event.Event
}

func (r *LogReader) pollRoo(ctx context.Context, final bool, emit func(event.Event) error) error {
	entries, err := readRooSnapshot(ctx, r.session, r.path)
	if err != nil {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		if final {
			return err
		}
		if !r.roo.gap {
			gap := event.New(r.session, "semantic", event.Process{Name: "roo-log"}, "collector_error", "direct", map[string]any{
				"source": "roo", "coverage": "incomplete", "reason": "snapshot_unavailable", "error": err.Error(),
			})
			if err := emit(gap); err != nil {
				return err
			}
			r.roo.gap = true
		}
		return nil
	}
	current := make(map[int][32]byte, len(entries))
	for _, entry := range entries {
		current[entry.index] = entry.fingerprint
	}
	for index, fingerprint := range r.roo.seen {
		if next, ok := current[index]; !ok || next != fingerprint {
			return fmt.Errorf("Roo finalized history changed or was removed; select the task session again")
		}
	}
	if r.roo.gap {
		if err := emit(event.New(r.session, "semantic", event.Process{Name: "roo-log"}, "collector_recovered", "direct", map[string]any{
			"source": "roo", "reason": "snapshot_available", "coverage": "previous_gap_remains",
		})); err != nil {
			return err
		}
		r.roo.gap = false
	}
	for _, entry := range entries {
		if err := ctx.Err(); err != nil {
			return err
		}
		if _, ok := r.roo.seen[entry.index]; ok {
			continue
		}
		if entry.event != nil {
			if err := emit(*entry.event); err != nil {
				return err
			}
		}
		r.roo.seen[entry.index] = entry.fingerprint
	}
	return nil
}

func readRooSnapshot(ctx context.Context, session, path string) ([]rooEntry, error) {
	data, err := readSnapshot(path, "Roo")
	if err != nil {
		return nil, err
	}
	decoder := json.NewDecoder(bytes.NewReader(bytes.TrimPrefix(data, []byte("\xef\xbb\xbf"))))
	start, err := decoder.Token()
	if err != nil || start != json.Delim('[') {
		return nil, fmt.Errorf("Roo task snapshot must be a UI message array")
	}
	var entries []rooEntry
	index := 0
	for decoder.More() {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		if index >= maxSnapshotRecords {
			return nil, fmt.Errorf("Roo task snapshot exceeds 50000 messages")
		}
		var raw json.RawMessage
		if err := decoder.Decode(&raw); err != nil {
			return nil, fmt.Errorf("Roo task snapshot is incomplete or invalid")
		}
		if len(raw) > maxLogLine {
			return nil, fmt.Errorf("Roo message exceeds 4 MiB; snapshot not imported")
		}
		var message rooMessage
		if err := json.Unmarshal(raw, &message); err != nil || message.TS <= 0 || message.TS > 253402300799999 || (message.Type != "ask" && message.Type != "say") {
			return nil, fmt.Errorf("invalid Roo UI message at record %d", index+1)
		}
		if index == 0 && (message.Type != "say" || message.Say != "text") {
			return nil, fmt.Errorf("Roo task snapshot must start with its original task message")
		}
		if !message.Partial {
			e, err := rooSemantic(session, message, index)
			if err != nil {
				return nil, err
			}
			// The first task is also the session anchor when it has no text.
			if e != nil || index == 0 {
				// Include the source text in the in-memory digest so changed
				// command arguments cannot masquerade as the same record.
				// Raw arguments are never copied into the emitted evidence.
				encoded, err := json.Marshal(message)
				if err != nil {
					return nil, fmt.Errorf("Roo semantic projection could not be encoded")
				}
				entries = append(entries, rooEntry{index: index, fingerprint: sha256.Sum256(encoded), event: e})
			}
		}
		index++
	}
	if token, err := decoder.Token(); err != nil || token != json.Delim(']') {
		return nil, fmt.Errorf("Roo task snapshot is incomplete or invalid")
	}
	var extra any
	if decoder.Decode(&extra) != io.EOF {
		return nil, fmt.Errorf("Roo task snapshot has trailing data")
	}
	return entries, nil
}

func rooSemantic(session string, m rooMessage, index int) (*event.Event, error) {
	var e event.Event
	if m.Type == "say" && (index == 0 || m.Say == "user_feedback") {
		if strings.TrimSpace(m.Text) == "" {
			return nil, nil
		}
		e = semantic(session, "roo", "goal", map[string]any{"role": "user", "text": m.Text})
	} else {
		kind := m.Say
		if m.Type == "ask" {
			kind = m.Ask
		}
		tool := ""
		switch kind {
		case "command":
			if m.Type != "ask" {
				return nil, nil
			}
			tool = "execute_command"
		case "tool":
			var hint struct {
				Tool string `json:"tool"`
			}
			if json.Unmarshal([]byte(m.Text), &hint) != nil || strings.TrimSpace(hint.Tool) == "" {
				return nil, fmt.Errorf("invalid Roo tool metadata at record %d", index+1)
			}
			tool = hint.Tool
		case "use_mcp_server":
			if m.Type != "ask" {
				return nil, nil
			}
			tool = "use_mcp_server"
		default:
			return nil, nil
		}
		stage := "self_reported"
		if m.Type == "ask" {
			stage = "approval_request"
		}
		e = semantic(session, "roo", "claimed_action", map[string]any{"role": "claimed_action", "tool": tool, "stage": stage})
	}
	e.TS = time.UnixMilli(m.TS).UTC()
	e.Detail["source"], e.Detail["trust"], e.Detail["time_source"], e.Detail["log_record"] = "roo", "self_reported", "agent_log", index+1
	return &e, nil
}
