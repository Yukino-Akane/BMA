package adapters

import (
	"fmt"
	"math"
	"time"

	"behavior-monitoring-audit/internal/event"
)

// workbuddyRecord reads the persisted JSONL format from WorkBuddy's bundled
// CodeBuddy engine. Its stream-json stdout is a different format.
func workbuddyRecord(session string, value map[string]any) ([]event.Event, error) {
	var result []event.Event
	switch value["type"] {
	case "message":
		if value["role"] == "user" {
			result = addGoal(nil, session, "workbuddy", value["content"])
		}
	case "function_call":
		name, _ := value["name"].(string)
		id, _ := value["callId"].(string)
		if name == "" || id == "" {
			return nil, fmt.Errorf("invalid WorkBuddy tool call")
		}
		// Arguments, provider metadata and tool results may contain file content.
		result = addTool(nil, session, "workbuddy", name, nil, id)
		result[0].Detail["stage"] = "tool_request"
	}
	if len(result) == 0 {
		return nil, nil
	}
	ms, ok := value["timestamp"].(float64)
	if !ok || math.IsNaN(ms) || math.IsInf(ms, 0) || ms <= 0 || ms > 253402300799999 || math.Trunc(ms) != ms {
		return nil, fmt.Errorf("invalid WorkBuddy millisecond timestamp")
	}
	for i := range result {
		result[i].TS = time.UnixMilli(int64(ms)).UTC()
		result[i].Detail["time_source"] = "agent_log"
	}
	return result, nil
}
