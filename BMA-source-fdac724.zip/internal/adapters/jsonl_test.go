package adapters

import (
	"behavior-monitoring-audit/internal/event"
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestReadJSONLExtractsOnlySemanticHints(t *testing.T) {
	p := filepath.Join(t.TempDir(), "agent.jsonl")
	data := "{\"role\":\"user\",\"content\":\"Update README\",\"secret\":\"do not copy\"}\n{\"tool_name\":\"read_file\",\"arguments\":{\"token\":\"private-argument\"},\"args\":\"private-args\",\"command\":\"private-command\",\"path\":\"private-path\",\"url\":\"https://example.test/?token=private-url\",\"raw\":\"ignored\"}\n"
	if err := os.WriteFile(p, []byte(data), 0600); err != nil {
		t.Fatal(err)
	}
	reader, err := NewLogReader("s", p, "generic")
	if err != nil {
		t.Fatal(err)
	}
	var values []event.Event
	err = reader.Poll(context.Background(), true, func(e event.Event) error { values = append(values, e); return nil })
	if err != nil || len(values) != 2 {
		t.Fatalf("%#v %v", values, err)
	}
	if values[0].Kind != "goal" || values[1].Kind != "claimed_action" || values[0].Detail["secret"] != nil || values[1].Detail["raw"] != nil {
		t.Fatalf("unsafe extraction: %#v", values)
	}
	local, err := json.Marshal(values)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(local), "private-") {
		t.Fatal("private claimed-action fields entered local evidence")
	}
}
