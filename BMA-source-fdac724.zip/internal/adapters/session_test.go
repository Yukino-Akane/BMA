package adapters

import (
	"encoding/json"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/redact"
)

func TestNativeFormatsExtractGoalsAndActionsOnly(t *testing.T) {
	cases := []struct{ name, format, line, kind, text, tool string }{
		{"claude goal", "claude", `{"type":"user","timestamp":"2026-09-19T10:00:00+08:00","message":{"role":"user","content":[{"type":"text","text":"edit README"},{"type":"tool_result","text":"private-result"} ]},"credential":"private-meta"}`, "goal", "edit README", ""},
		{"claude tool", "claude", `{"type":"assistant","timestamp":"2026-09-19T10:00:00+08:00","message":{"role":"assistant","content":[{"type":"thinking","thinking":"private-thinking"},{"type":"tool_use","id":"call-1","name":"Read","input":{"file_path":"README.md","token":"private-argument"}}]}}`, "claimed_action", "", "Read"},
		{"codex goal", "codex", `{"type":"response_item","timestamp":"2026-09-19T10:00:00+08:00","payload":{"type":"message","role":"user","content":[{"type":"input_text","text":"edit README"},{"type":"input_image","text":"private-image"}]}}`, "goal", "edit README", ""},
		{"codex function", "codex", `{"type":"response_item","timestamp":"2026-09-19T10:00:00+08:00","payload":{"type":"function_call","name":"exec_command","arguments":"private-argument","call_id":"call-1"}}`, "claimed_action", "", "exec_command"},
		{"codex custom", "codex", `{"type":"response_item","timestamp":"2026-09-19T10:00:00+08:00","payload":{"type":"custom_tool_call","name":"apply_patch","input":"private-argument","call_id":"call-1"}}`, "claimed_action", "", "apply_patch"},
		{"generic calls", "generic", `{"timestamp":"2026-09-19T10:00:00+08:00","tool_calls":[{"id":"call-1","function":{"name":"read_file","arguments":"private-argument"}}]}`, "claimed_action", "", "read_file"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			values, err := decodeRecord("s", tc.format, []byte(tc.line))
			if err != nil || len(values) != 1 {
				t.Fatalf("count=%d error=%v", len(values), err)
			}
			e := values[0]
			if e.Kind != tc.kind || e.Detail["source"] != tc.format || e.Detail["trust"] != "self_reported" {
				t.Fatal("incorrect provenance")
			}
			if tc.text != "" && e.Detail["text"] != tc.text {
				t.Fatal("incorrect goal")
			}
			if tc.tool != "" && (e.Detail["tool"] != tc.tool || e.Detail["call_id"] != "call-1") {
				t.Fatal("incorrect call")
			}
			want := time.Date(2026, 9, 19, 2, 0, 0, 0, time.UTC)
			if !e.TS.Equal(want) || e.Detail["time_source"] != "agent_log" {
				t.Fatal("source timestamp lost")
			}
			local, err := json.Marshal(values)
			if err != nil {
				t.Fatal(err)
			}
			if strings.Contains(string(local), "private-") {
				t.Fatal("private tool arguments or ignored content entered local evidence")
			}
			data, err := json.Marshal(redact.Events(values, false))
			if err != nil {
				t.Fatal(err)
			}
			if strings.Contains(string(data), "private-") {
				t.Fatal("private content passed model boundary")
			}
		})
	}
}

func TestNativeFormatsSkipMirrorsMetadataAndResults(t *testing.T) {
	cases := []struct{ format, line string }{
		{"claude", `{"type":"user","isMeta":true,"message":{"role":"user","content":"metadata"}}`},
		{"claude", `{"type":"user","isSidechain":true,"message":{"role":"user","content":"other session"}}`},
		{"claude", `{"type":"user","message":{"role":"user","content":[{"type":"tool_result","content":"result","text":"result"}]}}`},
		{"claude", `{"type":"assistant","message":{"role":"assistant","content":[{"type":"thinking","text":"hidden"}]}}`},
		{"codex", `{"type":"event_msg","payload":{"type":"user_message","message":"duplicate goal"}}`},
		{"codex", `{"type":"response_item","payload":{"type":"function_call_output","output":"secret"}}`},
		{"codex", `{"type":"response_item","payload":{"type":"reasoning","summary":[{"text":"secret"}]}}`},
		{"codex", `{"type":"response_item","payload":{"type":"message","role":"developer","content":[{"type":"input_text","text":"instructions"}]}}`},
		{"codex", `{"type":"session_meta","payload":{"base_instructions":{"text":"instructions"}}}`},
	}
	for _, tc := range cases {
		values, err := decodeRecord("s", tc.format, []byte(tc.line))
		if err != nil || len(values) != 0 {
			t.Fatalf("unexpected extraction for %s", tc.format)
		}
	}
}

func TestUntrustedGoalRedactionAndInvalidRecord(t *testing.T) {
	for _, raw := range []string{`null`, `[]`, `{"role":"user","content":"x","timestamp":"bad"}`} {
		if _, err := decodeRecord("s", "generic", []byte(raw)); err == nil {
			t.Fatal("accepted invalid record")
		}
	}
	events, err := decodeRecord("s", "codex", []byte(`{"type":"response_item","payload":{"type":"message","role":"user","content":[{"type":"input_text","text":"token=top-secret-value C:\\private\\file.txt"}]}}`))
	if err != nil || len(events) != 1 {
		t.Fatal("goal missing")
	}
	for _, hide := range []bool{false, true} {
		data, _ := json.Marshal(redact.Events(events, hide))
		if strings.Contains(string(data), "top-secret-value") || strings.Contains(string(data), "private") {
			t.Fatal("goal leaked")
		}
	}
}
