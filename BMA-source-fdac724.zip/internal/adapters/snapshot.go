package adapters

import (
	"fmt"
	"io"
)

const maxSnapshotBytes = 64 * 1024 * 1024
const maxSnapshotRecords = 50000

// Snapshot sources rewrite their whole file. Read one bounded regular file
// and reject observable writes during the read; this is not an atomic OS view.
func readSnapshot(path, source string) ([]byte, error) {
	f, err := openLog(path)
	if err != nil {
		return nil, fmt.Errorf("%s task snapshot cannot be opened", source)
	}
	defer f.Close()
	before, err := f.Stat()
	if err != nil || !before.Mode().IsRegular() || before.Size() > maxSnapshotBytes {
		return nil, fmt.Errorf("%s task snapshot must be a regular file of at most 64 MiB", source)
	}
	data, err := io.ReadAll(io.LimitReader(f, maxSnapshotBytes+1))
	if err != nil || len(data) > maxSnapshotBytes {
		return nil, fmt.Errorf("%s task snapshot cannot be read within 64 MiB", source)
	}
	after, err := f.Stat()
	if err != nil || before.Size() != after.Size() || !before.ModTime().Equal(after.ModTime()) || int64(len(data)) != before.Size() {
		return nil, fmt.Errorf("%s task snapshot changed while being read", source)
	}
	return data, nil
}
