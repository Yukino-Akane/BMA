package adapters

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
)

func writeLog(t *testing.T, path, data string, appendData bool) {
	t.Helper()
	flags := os.O_WRONLY | os.O_CREATE | os.O_TRUNC
	if appendData {
		flags = os.O_WRONLY | os.O_APPEND
	}
	f, err := os.OpenFile(path, flags, 0600)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := f.WriteString(data); err != nil {
		t.Fatal(err)
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}
}

func TestLogTailPartialAppendAndFinalLine(t *testing.T) {
	p := filepath.Join(t.TempDir(), "session.jsonl")
	writeLog(t, p, "\ufeff{\"role\":\"user\",\"content\":\"first\"}\r\n{\"tool_name\":", false)
	r, err := NewLogReader("s", p, "generic")
	if err != nil {
		t.Fatal(err)
	}
	var values []event.Event
	emit := func(e event.Event) error { values = append(values, e); return nil }
	for i := 0; i < 2; i++ {
		if err := r.Poll(context.Background(), false, emit); err != nil {
			t.Fatal(err)
		}
	}
	if len(values) != 1 {
		t.Fatal("partial/duplicate event imported")
	}
	writeLog(t, p, "\"read_file\",\"arguments\":{\"path\":\"README.md\"}}\n{\"role\":\"user\",\"content\":\"last\"}", true)
	if err := r.Poll(context.Background(), false, emit); err != nil {
		t.Fatal(err)
	}
	if len(values) != 2 {
		t.Fatal("append not read correctly")
	}
	if err := r.Poll(context.Background(), true, emit); err != nil {
		t.Fatal(err)
	}
	if len(values) != 3 || values[2].Detail["text"] != "last" || values[2].Detail["log_line"] != 3 {
		t.Fatal("last unterminated line lost")
	}
	if err := r.Poll(context.Background(), true, emit); err != nil {
		t.Fatal(err)
	}
	if len(values) != 3 {
		t.Fatal("duplicate final line")
	}
}

func TestLogTailRejectsReplacementTruncationAndRewrite(t *testing.T) {
	for _, operation := range []string{"replace", "truncate", "rewrite"} {
		t.Run(operation, func(t *testing.T) {
			p := filepath.Join(t.TempDir(), "session.jsonl")
			writeLog(t, p, "{\"role\":\"user\",\"content\":\"first\"}\n", false)
			r, err := NewLogReader("s", p, "generic")
			if err != nil {
				t.Fatal(err)
			}
			count := 0
			emit := func(e event.Event) error { count++; return nil }
			if err := r.Poll(context.Background(), false, emit); err != nil {
				t.Fatal(err)
			}
			switch operation {
			case "replace":
				if err := os.Rename(p, p+".old"); err != nil {
					t.Fatal(err)
				}
				writeLog(t, p, "{\"role\":\"user\",\"content\":\"other\"}\n", false)
			case "truncate":
				writeLog(t, p, "", false)
			case "rewrite":
				writeLog(t, p, "{\"role\":\"user\",\"content\":\"other\"}\n", false)
			}
			if err := r.Poll(context.Background(), false, emit); err == nil {
				t.Fatal("mutation silently accepted")
			}
			if count != 1 {
				t.Fatal("reimported replaced evidence")
			}
		})
	}
}

func TestLogTailBoundsAndSanitizedErrors(t *testing.T) {
	for _, data := range []string{`{"private-secret":`, `null`, `[]`} {
		p := filepath.Join(t.TempDir(), "session.jsonl")
		writeLog(t, p, data, false)
		r, err := NewLogReader("s", p, "codex")
		if err != nil {
			t.Fatal(err)
		}
		err = r.Poll(context.Background(), true, func(event.Event) error { t.Fatal("bad event emitted"); return nil })
		if err == nil || strings.Contains(err.Error(), "private-secret") {
			t.Fatal("missing or unsanitized error")
		}
	}
}

func TestOversizedRecordDisclosesGapAndContinues(t *testing.T) {
	p := filepath.Join(t.TempDir(), "session.jsonl")
	writeLog(t, p, strings.Repeat("x", maxLogLine+1), false)
	r, err := NewLogReader("s", p, "generic")
	if err != nil {
		t.Fatal(err)
	}
	var values []event.Event
	emit := func(e event.Event) error { values = append(values, e); return nil }
	if err := r.Poll(context.Background(), false, emit); err != nil {
		t.Fatal(err)
	}
	if len(values) != 0 {
		t.Fatal("partial oversized record committed")
	}
	writeLog(t, p, "\n{\"role\":\"user\",\"content\":\"next goal\"}\n", true)
	if err := r.Poll(context.Background(), false, emit); err != nil {
		t.Fatal(err)
	}
	if len(values) != 2 || values[0].Kind != "collector_error" || values[0].Detail["coverage"] != "incomplete" || values[1].Kind != "goal" {
		t.Fatal("oversized line hid coverage loss or prevented subsequent ingestion")
	}
	if err := r.Poll(context.Background(), true, emit); err != nil {
		t.Fatal(err)
	}
	if len(values) != 2 {
		t.Fatal("oversized line counted twice")
	}
}

func TestFollowCancellationFlushesFinalRecord(t *testing.T) {
	p := filepath.Join(t.TempDir(), "session.jsonl")
	writeLog(t, p, "{\"role\":\"user\",\"content\":\"last\"}", false)
	r, err := NewLogReader("s", p, "generic")
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	count := 0
	if err := r.Follow(ctx, time.Millisecond, func(event.Event) error { count++; return nil }); err != nil {
		t.Fatal(err)
	}
	if count != 1 {
		t.Fatal("cancel lost complete last record")
	}
}
