package adapters

import (
	"context"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/redact"
)

func rooFixture() []map[string]any {
	return []map[string]any{
		{"ts": 1789812000000, "type": "say", "say": "text", "text": "Only edit README"},
		{"ts": 1789812000001, "type": "ask", "ask": "tool", "text": `{"tool":"readFile","path":"private-path","content":"private-file-content"}`, "partial": true},
		{"ts": 1789812000002, "type": "say", "say": "reasoning", "text": "private-thinking"},
		{"ts": 1789812000003, "type": "say", "say": "command_output", "text": "private-output"},
		{"ts": 1789812000004, "type": "say", "say": "text", "text": "private-assistant-text"},
	}
}

func writeRoo(t *testing.T, path string, rows []map[string]any) {
	t.Helper()
	data, err := json.Marshal(rows)
	if err != nil {
		t.Fatal(err)
	}
	writeLog(t, path, string(data), false)
}

func TestRooSnapshotsFinalizeWithoutDuplicatesOrPrivateContent(t *testing.T) {
	path := filepath.Join(t.TempDir(), "ui_messages.json")
	rows := rooFixture()
	writeRoo(t, path, rows)
	r, err := NewLogReader("s", path, "roo")
	if err != nil {
		t.Fatal(err)
	}
	var events []event.Event
	emit := func(e event.Event) error { events = append(events, e); return nil }
	for i := 0; i < 2; i++ {
		if err := r.Poll(context.Background(), false, emit); err != nil {
			t.Fatal(err)
		}
	}
	if len(events) != 1 || events[0].Kind != "goal" || events[0].Detail["log_record"] != 1 || events[0].TS.UnixMilli() != 1789812000000 {
		t.Fatal("wrong original goal", events)
	}
	rows[1]["partial"] = false
	rows = append(rows, map[string]any{"ts": 1789812000005, "type": "say", "say": "user_feedback", "text": "Keep it small", "images": []string{"private-image"}})
	rows = append(rows, map[string]any{"ts": 1789812000006, "type": "ask", "ask": "command", "text": "private-shell-command"})
	rows = append(rows, map[string]any{"ts": 1789812000007, "type": "ask", "ask": "use_mcp_server", "text": "private-mcp-arguments"})
	rows = append(rows, map[string]any{"ts": 1789812000008, "type": "say", "say": "tool", "text": `{"tool":"appliedDiff","diff":"private-diff"}`})
	// Same path, a new file identity: this is Roo's normal persistence model.
	if err := os.Rename(path, path+".old"); err != nil {
		t.Fatal(err)
	}
	writeRoo(t, path, rows)
	if err := r.Poll(context.Background(), false, emit); err != nil {
		t.Fatal(err)
	}
	if len(events) != 6 || events[1].Detail["stage"] != "approval_request" || events[1].Detail["tool"] != "readFile" || events[5].Detail["stage"] != "self_reported" {
		t.Fatal("lost semantic records", events)
	}
	rows[1]["isAnswered"] = true
	rows[1]["progressStatus"] = "completed"
	writeRoo(t, path, rows)
	if err := r.Poll(context.Background(), true, emit); err != nil {
		t.Fatal(err)
	}
	if len(events) != 6 {
		t.Fatal("metadata rewrite duplicated actions")
	}
	for _, e := range events {
		if e.Detail["trust"] != "self_reported" || e.Detail["source"] != "roo" || e.Detail["time_source"] != "agent_log" {
			t.Fatal("lost provenance")
		}
	}
	for _, value := range []any{events, redact.Events(events, false)} {
		data, _ := json.Marshal(value)
		if strings.Contains(string(data), "private-") {
			t.Fatal("private tool arguments/results/reasoning/images copied")
		}
	}
	if redact.Events(events, false)[1].Detail["log_record"] != 2 {
		t.Fatal("model provenance lost record index")
	}
}

func TestRooMissingOrIncompleteSnapshotReportsGapAndRecovers(t *testing.T) {
	path := filepath.Join(t.TempDir(), "ui_messages.json")
	rows := rooFixture()
	writeRoo(t, path, rows)
	r, _ := NewLogReader("s", path, "roo")
	var events []event.Event
	emit := func(e event.Event) error { events = append(events, e); return nil }
	if err := r.Poll(context.Background(), false, emit); err != nil {
		t.Fatal(err)
	}
	if err := os.Rename(path, path+".old"); err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 2; i++ {
		if err := r.Poll(context.Background(), false, emit); err != nil {
			t.Fatal(err)
		}
	}
	writeLog(t, path, "[{", false)
	if err := r.Poll(context.Background(), false, emit); err != nil {
		t.Fatal(err)
	}
	if len(events) != 2 || events[1].Kind != "collector_error" {
		t.Fatal("gap missing or repeated")
	}
	if err := r.Poll(context.Background(), true, emit); err == nil {
		t.Fatal("final invalid snapshot silently accepted")
	}
	writeRoo(t, path, rows)
	if err := r.Poll(context.Background(), false, emit); err != nil {
		t.Fatal(err)
	}
	if len(events) != 3 || events[2].Kind != "collector_recovered" {
		t.Fatal("recovery missing or goal duplicated")
	}
}

func TestRooChangedHistoryRejectedBeforeNewEvidence(t *testing.T) {
	for _, mode := range []string{"task", "arguments", "removed", "partial-again"} {
		t.Run(mode, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "ui_messages.json")
			rows := rooFixture()
			rows[1]["partial"] = false
			writeRoo(t, path, rows)
			r, _ := NewLogReader("s", path, "roo")
			count := 0
			emit := func(event.Event) error { count++; return nil }
			if err := r.Poll(context.Background(), false, emit); err != nil {
				t.Fatal(err)
			}
			switch mode {
			case "task":
				rows[0]["text"] = "different task"
			case "arguments":
				rows[1]["text"] = `{"tool":"readFile","path":"changed"}`
			case "removed":
				rows = rows[:1]
			case "partial-again":
				rows[1]["partial"] = true
			}
			rows = append(rows, map[string]any{"ts": 1789812000009, "type": "say", "say": "user_feedback", "text": "must not be imported"})
			writeRoo(t, path, rows)
			if err := r.Poll(context.Background(), false, emit); err == nil || count != 2 {
				t.Fatal("rewritten history accepted or new evidence emitted first")
			}
		})
	}
}

func TestRooSnapshotValidationAndLimits(t *testing.T) {
	for _, mode := range []string{"wrong-root", "object", "timestamp", "tool", "trailing", "record-size", "record-count", "file-size"} {
		t.Run(mode, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "ui_messages.json")
			rows := rooFixture()
			rows[1]["partial"] = false
			switch mode {
			case "wrong-root":
				rows[0]["say"] = "reasoning"
			case "timestamp":
				rows[0]["ts"] = 1.5
			case "tool":
				rows[1]["text"] = "invalid tool metadata"
			case "record-size":
				rows[1]["text"] = strings.Repeat("x", maxLogLine+1)
			case "record-count":
				for len(rows) <= maxSnapshotRecords {
					rows = append(rows, map[string]any{"ts": 1, "type": "say", "say": "text"})
				}
			}
			writeRoo(t, path, rows)
			switch mode {
			case "object":
				writeLog(t, path, `{}`, false)
			case "trailing":
				writeLog(t, path, `{}`, true)
			case "file-size":
				if err := os.Truncate(path, maxSnapshotBytes+1); err != nil {
					t.Fatal(err)
				}
			}
			if _, err := readRooSnapshot(context.Background(), "s", path); err == nil {
				t.Fatal("invalid snapshot accepted")
			}
		})
	}
}

func TestRooCancellationFlushAndEmissionFailure(t *testing.T) {
	path := filepath.Join(t.TempDir(), "ui_messages.json")
	writeRoo(t, path, rooFixture())
	r, _ := NewLogReader("s", path, "roo")
	want := errors.New("fixture write failed")
	if err := r.Poll(context.Background(), false, func(event.Event) error { return want }); !errors.Is(err, want) {
		t.Fatal("write failure lost")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	count := 0
	if err := r.Follow(ctx, time.Millisecond, func(event.Event) error { count++; return nil }); err != nil {
		t.Fatal(err)
	}
	if count != 1 {
		t.Fatal("failed emission was consumed or final flush lost")
	}
}
