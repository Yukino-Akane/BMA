package adapters

import (
	"context"
	"io"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"behavior-monitoring-audit/internal/event"
)

func TestOpenLogAllowsWriterToReplaceFileWhileReadHandleIsOpen(t *testing.T) {
	for _, long := range []bool{false, true} {
		dir := t.TempDir()
		if long {
			for len(dir) < 280 {
				dir = filepath.Join(dir, strings.Repeat("x", 40))
			}
			if err := os.MkdirAll(dir, 0700); err != nil {
				t.Fatal(err)
			}
		}
		path := filepath.Join(dir, "session.json")
		if err := os.WriteFile(path, []byte("original"), 0600); err != nil {
			t.Fatal(err)
		}
		f, err := openLog(path)
		if err != nil {
			t.Fatal(err)
		}
		t.Cleanup(func() { f.Close() })
		before, err := f.Stat()
		if err != nil {
			t.Fatal(err)
		}
		if err := os.Rename(path, path+".bak"); err != nil {
			t.Fatal("observer blocked writer rename", err)
		}
		if err := os.WriteFile(path, []byte("replacement"), 0600); err != nil {
			t.Fatal(err)
		}
		if err := os.Remove(path + ".bak"); err != nil {
			t.Fatal("observer blocked writer cleanup", err)
		}
		data, err := io.ReadAll(f)
		if err != nil || string(data) != "original" {
			t.Fatal("open reader switched to replacement", err)
		}
		after, err := os.Stat(path)
		if err != nil || os.SameFile(before, after) {
			t.Fatal("replacement identity hidden", err)
		}
		if err := f.Close(); err != nil {
			t.Fatal(err)
		}
	}
}

func TestJSONLWriterRotationDuringPollDoesNotBlockAndNextPollRejectsReplacement(t *testing.T) {
	path := filepath.Join(t.TempDir(), "session.jsonl")
	line := []byte("{\"role\":\"user\",\"content\":\"synthetic task\"}\n")
	if err := os.WriteFile(path, line, 0600); err != nil {
		t.Fatal(err)
	}
	r, err := NewLogReader("s", path, "generic")
	if err != nil {
		t.Fatal(err)
	}
	emitted := 0
	err = r.Poll(context.Background(), false, func(event.Event) error {
		emitted++
		if err := os.Rename(path, path+".old"); err != nil {
			return err
		}
		return os.WriteFile(path, line, 0600)
	})
	if err != nil || emitted != 1 {
		t.Fatal("rotation failed while polling", emitted, err)
	}
	if err := r.Poll(context.Background(), false, func(event.Event) error { t.Error("replacement emitted as original session"); return nil }); err == nil {
		t.Fatal("JSONL replacement not rejected")
	}
}
