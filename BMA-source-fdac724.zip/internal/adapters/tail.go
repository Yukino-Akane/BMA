package adapters

import (
	"bufio"
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"time"

	"behavior-monitoring-audit/internal/event"
)

const maxLogLine = 4 * 1024 * 1024

// LogReader follows one explicitly selected session file, reopening each poll.
// JSONL sources must be append-only; Roo and Cline use rewritten snapshots.
// Changed observed history is never silently reimported.
type LogReader struct {
	session, path, format string
	identity              os.FileInfo
	offset                int64
	line                  int
	boundary              []byte
	roo                   *rooReader
	cline                 *clineReader
}

func NewLogReader(session, path, format string) (*LogReader, error) {
	if format != "generic" && format != "claude" && format != "codex" && format != "workbuddy" && format != "roo" && format != "cline" {
		return nil, fmt.Errorf("agent format must be generic, claude, codex, workbuddy, roo or cline")
	}
	f, err := openLog(path)
	if err != nil {
		return nil, fmt.Errorf("open Agent log: %w", err)
	}
	defer f.Close()
	info, err := f.Stat()
	if err != nil {
		return nil, err
	}
	if !info.Mode().IsRegular() {
		return nil, fmt.Errorf("Agent log must be a regular file")
	}
	r := &LogReader{session: session, path: path, format: format, identity: info}
	if format == "roo" {
		r.roo = &rooReader{seen: map[int][32]byte{}}
	}
	if format == "cline" {
		r.cline = &clineReader{seen: map[int]clineObserved{}}
	}
	return r, nil
}

// Poll reads a bounded snapshot. For JSONL, appends during a poll are left for
// the next one; final also accepts a complete last record without a newline.
// Snapshot formats retry unavailable files live and reject a final bad read.
func (r *LogReader) Poll(ctx context.Context, final bool, emit func(event.Event) error) error {
	if r.cline != nil {
		return r.pollCline(ctx, final, emit)
	}
	if r.roo != nil {
		return r.pollRoo(ctx, final, emit)
	}
	f, err := openLog(r.path)
	if err != nil {
		return fmt.Errorf("open Agent log: %w", err)
	}
	defer f.Close()
	info, err := f.Stat()
	if err != nil {
		return err
	}
	if !os.SameFile(r.identity, info) || info.Size() < r.offset {
		return fmt.Errorf("Agent log replaced or truncated; select the new session explicitly")
	}
	if len(r.boundary) > 0 {
		check := make([]byte, len(r.boundary))
		if _, err := f.ReadAt(check, r.offset-int64(len(check))); err != nil || !bytes.Equal(check, r.boundary) {
			return fmt.Errorf("Agent log changed before the cursor; ingestion stopped")
		}
	}
	reader := bufio.NewReader(io.NewSectionReader(f, r.offset, info.Size()-r.offset))
	for {
		if err := ctx.Err(); err != nil {
			return err
		}
		var line []byte
		var lineBytes int64
		oversized := false
		var readErr error
		for {
			part, err := reader.ReadSlice('\n')
			lineBytes += int64(len(part))
			if lineBytes > maxLogLine {
				oversized = true
				line = nil
			} else {
				line = append(line, part...)
			}
			readErr = err
			if err != bufio.ErrBufferFull {
				break
			}
			if err := ctx.Err(); err != nil {
				return err
			}
		}
		if readErr != nil && readErr != io.EOF {
			return readErr
		}
		if lineBytes == 0 {
			return nil
		}
		if readErr == io.EOF && !final {
			return nil
		}
		data := bytes.TrimSpace(line)
		if r.offset == 0 {
			data = bytes.TrimPrefix(data, []byte("\xef\xbb\xbf"))
		}
		if oversized {
			// Preserve bounded memory even for embedded images/tool outputs.
			// A missing record is evidence of a coverage gap, never of silence.
			gap := event.New(r.session, "semantic", event.Process{Name: "agent-log"}, "collector_error", "direct", map[string]any{
				"source": r.format, "coverage": "incomplete", "log_line": r.line + 1,
				"record_bytes": lineBytes, "error": "Agent log record exceeds 4 MiB; record omitted, following records still observed",
			})
			if err := emit(gap); err != nil {
				return err
			}
		} else if len(data) > 0 {
			items, err := decodeRecord(r.session, r.format, data)
			if err != nil {
				return fmt.Errorf("Agent log line %d: %w", r.line+1, err)
			}
			for _, e := range items {
				e.Detail["log_line"] = r.line + 1
				if err := emit(e); err != nil {
					return err
				}
			}
		}
		r.offset += lineBytes
		r.line++
		n := min(int64(64), r.offset)
		r.boundary = make([]byte, n)
		if _, err := f.ReadAt(r.boundary, r.offset-n); err != nil {
			return err
		}
		if readErr == io.EOF {
			return nil
		}
	}
}

// Follow polls until cancellation and then makes a final bounded read.
func (r *LogReader) Follow(ctx context.Context, interval time.Duration, emit func(event.Event) error) error {
	if interval <= 0 {
		return fmt.Errorf("log poll interval must be positive")
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		if err := r.Poll(ctx, false, emit); err != nil {
			if ctx.Err() == nil || (!errors.Is(err, context.Canceled) && !errors.Is(err, context.DeadlineExceeded)) {
				return err
			}
		}
		select {
		case <-ctx.Done():
			finalCtx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
			defer cancel()
			return r.Poll(finalCtx, true, emit)
		case <-ticker.C:
		}
	}
}
