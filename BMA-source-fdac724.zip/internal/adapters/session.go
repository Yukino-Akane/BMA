package adapters

import (
	"encoding/json"
	"fmt"
	"time"

	"behavior-monitoring-audit/internal/event"
)

// decodeRecord only reads semantic fields. Session metadata, reasoning and
// tool results are deliberately not copied into evidence.
func decodeRecord(session, format string, data []byte) ([]event.Event, error) {
	var value map[string]any
	if err := json.Unmarshal(data, &value); err != nil || value == nil {
		return nil, fmt.Errorf("expected a JSON object")
	}
	var result []event.Event
	switch format {
	case "generic":
		result = genericRecord(session, value)
	case "claude":
		result = claudeRecord(session, value)
	case "codex":
		result = codexRecord(session, value)
	case "workbuddy":
		var err error
		result, err = workbuddyRecord(session, value)
		if err != nil {
			return nil, err
		}
	}
	for i := range result {
		result[i].Detail["source"] = format
		result[i].Detail["trust"] = "self_reported"
		if format == "workbuddy" {
			continue // Its persisted format uses validated Unix milliseconds.
		}
		if timestamp, ok := value["timestamp"].(string); ok && timestamp != "" {
			ts, err := time.Parse(time.RFC3339Nano, timestamp)
			if err != nil {
				return nil, fmt.Errorf("invalid timestamp")
			}
			result[i].TS = ts.UTC()
			result[i].Detail["time_source"] = "agent_log"
		} else {
			result[i].Detail["time_source"] = "observed"
		}
	}
	return result, nil
}

func semantic(session, format, kind string, detail map[string]any) event.Event {
	return event.New(session, "semantic", event.Process{Name: format + "-log"}, kind, "direct", detail)
}

func addGoal(result []event.Event, session, format string, content any) []event.Event {
	if text := textValue(content); text != "" {
		return append(result, semantic(session, format, "goal", map[string]any{"role": "user", "text": text}))
	}
	return result
}

func addTool(result []event.Event, session, format string, name, _ any, id any) []event.Event {
	tool, ok := name.(string)
	if !ok || tool == "" {
		return result
	}
	detail := map[string]any{"role": "claimed_action", "tool": tool}
	if callID, ok := id.(string); ok && callID != "" {
		detail["call_id"] = callID
	}
	return append(result, semantic(session, format, "claimed_action", detail))
}
