//go:build !windows

package adapters

import "os"

func openLog(path string) (*os.File, error) { return os.Open(path) }
