package adapters

import "behavior-monitoring-audit/internal/event"

func claudeRecord(session string, value map[string]any) []event.Event {
	if value["isMeta"] == true || value["isSidechain"] == true {
		return nil
	}
	message, _ := value["message"].(map[string]any)
	if value["type"] == "user" && message["role"] == "user" {
		return addGoal(nil, session, "claude", message["content"])
	}
	if value["type"] != "assistant" || message["role"] != "assistant" {
		return nil
	}
	var result []event.Event
	blocks, _ := message["content"].([]any)
	for _, block := range blocks {
		item, _ := block.(map[string]any)
		if item["type"] == "tool_use" {
			result = addTool(result, session, "claude", item["name"], item["input"], item["id"])
		}
	}
	return result
}
