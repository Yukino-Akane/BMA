package artifact

import (
	"path/filepath"
	"strings"
)

// NameHint classifies only the filename. Entropy thresholds belong to the
// rules configuration, which is not available to filesystem collectors.
func NameHint(path string) string {
	base := strings.ToLower(filepath.Base(path))
	ext := strings.ToLower(filepath.Ext(base))
	switch ext {
	case ".zip", ".tar", ".tgz", ".gz", ".bz2", ".xz", ".zst", ".7z", ".rar", ".cab", ".iso":
		return "archive"
	case ".enc", ".encrypted", ".age", ".gpg", ".pgp", ".aes":
		return "encrypted"
	}
	if strings.Contains(base, "cipher") || strings.Contains(base, "encrypted") {
		return "encrypted"
	}
	for _, word := range []string{"snapshot", "workspace", "repo", "baseline", "checkpoint", "bundle"} {
		if hasToken(base, word) {
			return "snapshot_candidate"
		}
	}
	return ""
}

func hasToken(base, token string) bool {
	for _, part := range strings.FieldsFunc(base, func(r rune) bool {
		return !((r >= 'a' && r <= 'z') || (r >= '0' && r <= '9'))
	}) {
		if part == token {
			return true
		}
	}
	return false
}
