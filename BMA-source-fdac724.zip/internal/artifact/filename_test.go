package artifact

import "testing"

func TestNameHintUsesWholeWords(t *testing.T) {
	tests := []struct {
		name string
		want string
	}{
		{"report.json", ""},
		{"reports.txt", ""},
		{"repository.json", ""},
		{"myrepo.txt", ""},
		{"repo.json", "snapshot_candidate"},
		{"repo-backup.json", "snapshot_candidate"},
		{"workspace_snapshot.bin", "snapshot_candidate"},
		{"archive.zip", "archive"},
		{"snapshot.enc", "encrypted"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NameHint(tt.name); got != tt.want {
				t.Fatalf("NameHint(%q) = %q, want %q", tt.name, got, tt.want)
			}
		})
	}
}
