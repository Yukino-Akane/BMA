import AppKit
import Darwin
import Security

struct ProcessCodeIdentity {
    let bundleID: String
    let identifier: String
    let teamID: String
    let cdhash: String
}

struct ProcessChoice {
    let pid: Int32
    let createdAtMS: Int64
    let name: String
    let suggested: Bool
    let family: String?
    var codeIdentity: ProcessCodeIdentity? = nil
}

func codeIdentity(pid: pid_t, bundleID: String?) -> ProcessCodeIdentity? {
    let attributes = [kSecGuestAttributePid as String: pid] as CFDictionary
    var guest: SecCode?
    guard SecCodeCopyGuestWithAttributes(nil, attributes, SecCSFlags(), &guest) == errSecSuccess,
          let guest = guest else { return nil }
    guard SecCodeCheckValidity(guest, SecCSFlags(), nil) == errSecSuccess else { return nil }
    var code: SecStaticCode?
    guard SecCodeCopyStaticCode(guest, SecCSFlags(), &code) == errSecSuccess,
          let code = code else { return nil }
    var raw: CFDictionary?
    guard SecCodeCopySigningInformation(code, SecCSFlags(rawValue: kSecCSSigningInformation), &raw) == errSecSuccess,
          let values = raw as? [String: Any],
          let identifier = values[kSecCodeInfoIdentifier as String] as? String,
          let hash = values[kSecCodeInfoUnique as String] as? Data else { return nil }
    let team = values[kSecCodeInfoTeamIdentifier as String] as? String ?? ""
    let bundle = bundleID ?? ""
    guard bundle.isEmpty || bundle == identifier else { return nil }
    return ProcessCodeIdentity(bundleID: bundle, identifier: identifier, teamID: team,
                               cdhash: hash.map { String(format: "%02x", $0) }.joined())
}

let appFamilies = ["Claude", "Codex", "豆包", "WorkBuddy"]

func applicationFamily(name: String, path: String, bundleID: String? = nil) -> String? {
    if bundleID == "com.openai.codex" || bundleID == "com.openai.chat" { return "Codex" }
    // Match executable names or exact app bundle components, not arbitrary
    // substrings in parent folders (e.g. a project named "codex-tools").
    let executable = URL(fileURLWithPath: path).lastPathComponent.lowercased()
    let bundles = path.split(separator: "/").map { $0.lowercased() }
    let families = [("Claude", "claude"), ("Codex", "codex"), ("豆包", "doubao"), ("WorkBuddy", "workbuddy")]
    for (family, stem) in families where bundles.contains(stem + ".app") { return family }
    for (family, stem) in families {
        if executable == stem || name.lowercased() == stem { return family }
    }
    return name == "豆包" ? "豆包" : nil
}

func runningChoices() throws -> [ProcessChoice] {
    let command = Process(), output = Pipe()
    command.executableURL = URL(fileURLWithPath: "/bin/ps")
    // Only names and IDs belonging to this user; no arguments or environment.
    command.arguments = ["-u", String(getuid()), "-o", "pid=,comm="]
    command.standardOutput = output
    command.standardError = FileHandle.nullDevice
    try command.run()
    output.fileHandleForWriting.closeFile()
    let bytes = output.fileHandleForReading.readDataToEndOfFile()
    command.waitUntilExit()
    guard command.terminationStatus == 0 else {
        throw NSError(domain: "BMA", code: 1, userInfo: [NSLocalizedDescriptionKey: "无法获取当前账户的应用列表。"])
    }
    let apps = Dictionary(NSWorkspace.shared.runningApplications.map { ($0.processIdentifier, $0) }, uniquingKeysWith: { a, _ in a })
    var result: [ProcessChoice] = []
    for line in String(decoding: bytes, as: UTF8.self).split(separator: "\n") {
        let trimmed = String(line).trimmingCharacters(in: .whitespaces)
        let parts = trimmed.split(maxSplits: 1, whereSeparator: { $0.isWhitespace })
        guard parts.count == 2, let pid = Int32(parts[0]), pid != getpid(), pid != command.processIdentifier else { continue }
        let executable = URL(fileURLWithPath: String(parts[1])).lastPathComponent
        let name = apps[pid]?.localizedName ?? executable
        let family = applicationFamily(name: name, path: String(parts[1]), bundleID: apps[pid]?.bundleIdentifier)
        var info = proc_bsdinfo()
        let infoSize = Int32(MemoryLayout<proc_bsdinfo>.size)
        guard proc_pidinfo(pid, PROC_PIDTBSDINFO, 0, &info, infoSize) == infoSize else { continue }
        let createdAtMS = Int64(info.pbi_start_tvsec) * 1000 + Int64(info.pbi_start_tvusec) / 1000
        guard createdAtMS > 0 else { continue }
        let identity = family == nil ? nil : codeIdentity(pid: pid, bundleID: apps[pid]?.bundleIdentifier)
        result.append(ProcessChoice(pid: pid, createdAtMS: createdAtMS, name: name, suggested: family != nil || apps[pid]?.activationPolicy == .regular, family: family, codeIdentity: identity))
    }
    return result.sorted { a, b in
        a.suggested != b.suggested ? a.suggested : (a.name == b.name ? a.pid < b.pid : a.name.localizedStandardCompare(b.name) == .orderedAscending)
    }
}
