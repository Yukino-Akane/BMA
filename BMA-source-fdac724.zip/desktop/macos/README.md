# macOS 桌面端预览

这里是原生 AppKit 启动界面的源码，与现有 Go 单二进制采集后端分离。界面通过参数数组启动包内后端，使用 JSONL 状态通道；不运行 shell、不继承模型凭证、不改系统代理。

当前已编写：应用/进程选择、项目文件夹选择、任务输入、可选 Claude/Codex 日志、开始/停止、演示、浏览器报告和退出收尾。控制管道关闭会让后端停止并保存，以免界面退出后继续采集。

源码现在可由 `scripts/build_macos_app.py` 生成可双击的 `BMA.app`、ZIP 和 DMG。M5 / macOS 26.4 已完成挂载 DMG、复制到隔离目录、启动 GUI、退出和 `codesign --verify --deep --strict` 验证。可用 `--sign-identity "Developer ID Application: ..."` 生成 Developer ID 签名版；当前 M5 已完成该签名，`BUILD.json` 仍明确标记 `notarized=false`。不传身份时仍可生成 `ad-hoc-local-only` 本机预览。脚本只负责本地签名和校验，不自动提交公证或上传。

维护者在 Apple Silicon Mac/Xcode 环境构建当前桌面预览（输出目录必须不存在）：

```sh
python3 scripts/build_macos_app.py \
  --cli-archive /path/to/bma-0.4.0-dev-darwin-arm64.tar.gz \
  --out /path/to/bma-app-preview
```

归档必须是当前 BMA CLI，并由 `BUILD.json` 声明 `darwin/arm64` 和匹配的 SHA-256；旧 `0.4.0-preview.1` 不可直接作为配套后端。构建会先运行包内 `bma version`、`bma demo`，再验证 App bundle 和 DMG。生成的 DMG 带有“开始使用.txt”，适合发给不使用终端的试用者；首次打开仍可能受 Gatekeeper 和签名状态影响。
