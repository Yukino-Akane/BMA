import AppKit
import Darwin

private func processStartMS(_ pid: pid_t) -> Int64 {
    var info = proc_bsdinfo()
    let size = Int32(MemoryLayout<proc_bsdinfo>.size)
    precondition(proc_pidinfo(pid, PROC_PIDTBSDINFO, 0, &info, size) == size)
    return Int64(info.pbi_start_tvsec) * 1000 + Int64(info.pbi_start_tvusec) / 1000
}

// Compile instead of main.swift, inside a test-only bundle with Contents/Helpers/bma.
// Exercises real AppKit layout and the bundled backend against a synthetic PID.
@main
struct DesktopSmoke {
    static func wait(_ seconds: TimeInterval, until condition: () -> Bool) {
        let end = Date().addingTimeInterval(seconds)
        while !condition() && Date() < end { RunLoop.current.run(until: Date().addingTimeInterval(0.1)) }
        precondition(condition(), "timed out waiting for desktop lifecycle")
    }
    static func capture(_ view: NSView, _ path: String) throws {
        view.layoutSubtreeIfNeeded()
        let bitmap = view.bitmapImageRepForCachingDisplay(in: view.bounds)!
        view.effectiveAppearance.performAsCurrentDrawingAppearance {
            view.cacheDisplay(in: view.bounds, to: bitmap)
        }
        try bitmap.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: path))
    }
    static func main() throws {
        let app = NSApplication.shared
        app.setActivationPolicy(.accessory)
        app.appearance = NSAppearance(named: .aqua)
        let controller = AppController()
        controller.buildWindow(); controller.buildSettings()
        let output = CommandLine.arguments[1]
        let fixture = Process()
        fixture.executableURL = URL(fileURLWithPath: "/usr/bin/python3")
        fixture.arguments = ["-c", """
import socket,threading,time
s=socket.socket();s.bind(('127.0.0.1',0));s.listen()
def echo():
 c,_=s.accept()
 with c:
  while True:
   data=c.recv(65536)
   if not data: break
   c.sendall(data)
threading.Thread(target=echo,daemon=True).start()
c=socket.create_connection(s.getsockname())
print('ready',flush=True)
for i in range(240):
 c.sendall(b'x'*32768)
 remaining=32768
 while remaining: remaining-=len(c.recv(remaining))
 time.sleep(.25)
"""]
        let ready = Pipe()
        fixture.standardOutput = ready; fixture.standardError = FileHandle.nullDevice
        try fixture.run()
        defer { if fixture.isRunning { fixture.terminate(); fixture.waitUntilExit() } }
        precondition(String(decoding: ready.fileHandleForReading.availableData, as: UTF8.self).contains("ready"))
        let identity = codeIdentity(pid: fixture.processIdentifier, bundleID: nil)
        precondition(identity != nil, "fixture signing identity unavailable")
        let choice = ProcessChoice(pid: fixture.processIdentifier, createdAtMS: processStartMS(fixture.processIdentifier), name: "Synthetic fixture", suggested: true, family: "Codex", codeIdentity: identity)
        controller.choices = [choice]; controller.updateCards()
        precondition(controller.cards[1].isEnabled && !controller.cards[0].isEnabled)
        precondition(applicationFamily(name: "python", path: "/tmp/codex-tools/python") == nil)
        precondition(applicationFamily(name: "Codex Helper", path: "/Applications/Codex.app/Contents/Frameworks/Helper") == "Codex")
        precondition(applicationFamily(name: "ChatGPT", path: "/Applications/ChatGPT.app/Contents/MacOS/ChatGPT", bundleID: "com.openai.codex") == "Codex")
        let liveChoices = try runningChoices()
        if let codex = liveChoices.first(where: { $0.family == "Codex" && $0.name == "ChatGPT" }) {
            precondition(codex.codeIdentity?.bundleID == "com.openai.codex", "running ChatGPT root must have pinned signing identity")
        }
        try capture(controller.window.contentView!, output + "/idle.png")
        try capture(controller.settingsWindow.contentView!, output + "/settings.png")
        controller.startCard(controller.cards[1])
        precondition(controller.workspace == nil && controller.goal.stringValue.isEmpty)
        wait(15) { controller.reportURL != nil }
        precondition(controller.backend != nil && controller.stopButton.isEnabled && controller.cards[1].isEnabled)
        let end = Date().addingTimeInterval(12)
        while Date() < end {
            controller.refreshDashboard()
            RunLoop.current.run(until: Date().addingTimeInterval(1))
        }
        precondition(controller.fileTile.value.stringValue == "未开启")
        precondition(controller.connectionTile.value.stringValue != "—")
        precondition(controller.outboundTile.value.stringValue != "待采样" && controller.outboundTile.value.stringValue != "—")
        precondition(controller.updatedLabel.stringValue.contains("后端采样") && controller.updatedLabel.stringValue.contains("间隔"))
        precondition(controller.healthLabel.stringValue.contains("不支持 1"))
        precondition(controller.scopeLabel.stringValue.contains("已核验覆盖 1"))
        let observedOutbound = controller.outboundTile.value.stringValue
        controller.applyDashboardResponse(nil)
        precondition(controller.updatedLabel.stringValue.contains("数据陈旧"))
        precondition(controller.outboundTile.value.stringValue == observedOutbound)
        controller.refreshDashboard()
        wait(5) { controller.updatedLabel.stringValue.contains("后端采样") }
        try capture(controller.window.contentView!, output + "/recording.png")
        controller.stopObservation()
        wait(15) { controller.backend == nil }
        precondition(controller.savedReport != nil && controller.updatedLabel.stringValue == "最终数据 · 已停止")
        let data = try Data(contentsOf: controller.savedReport!)
        let report = try JSONSerialization.jsonObject(with: data) as! [String: Any]
        let authorization = report["authorization"] as? [String: Any]
        precondition(authorization?["state"] as? String == "unknown", "default authorization must remain unknown")
        precondition((report["watch_roots"] as? [String])?.isEmpty == true)
        precondition(report["workspace"] as? String == "")
        let events = report["events"] as! [[String: Any]]
        precondition(!events.contains { $0["layer"] as? String == "file" })
        precondition(events.contains { $0["kind"] as? String == "egress" })
        precondition(events.contains { e in
            let detail = e["detail"] as? [String: Any]
            return e["kind"] as? String == "scope_member_added" && detail?["cdhash"] as? String == identity?.cdhash
        })
        precondition(!events.contains { e in
            let detail = e["detail"] as? [String: Any]
            return e["kind"] as? String == "collector_error" && detail?["source"] as? String == "process_io"
        })
        try capture(controller.window.contentView!, output + "/stopped.png")
        // Check rendering at minimum supported window size as well.
        controller.window.setContentSize(NSSize(width: 940, height: 720))
        try capture(controller.window.contentView!, output + "/minimum.png")
        let staleData = Data(#"{"status":"recording","last_sample_at":"2026-01-01T00:00:00.123456789Z","last_success_at":"2026-01-01T00:00:00Z","interval_sec":2,"covered_processes":0,"scope_roots":1,"scope_children":0,"health":{"failed":1},"connections":2,"files":0,"gaps":1,"file_watching":false,"traffic":{},"recent":[]}"#.utf8)
        controller.renderDashboard(try JSONDecoder().decode(DashboardSnapshot.self, from: staleData))
        precondition(controller.updatedLabel.stringValue.contains("数据陈旧"))
        precondition(controller.healthLabel.stringValue.contains("失败 1"))
        precondition(controller.parseDashboardDate("2026-01-01T00:00:00.123456789Z") != nil)
        let alertData = Data(#"{"status":"recording","last_sample_at":"2026-01-01T00:00:00Z","last_success_at":"2026-01-01T00:00:00Z","interval_sec":2,"covered_processes":1,"scope_roots":1,"scope_children":0,"health":{},"connections":1,"files":1,"gaps":0,"file_watching":true,"traffic":{},"recent":[],"alerts":[{"at":"2026-01-01T00:00:00Z","conclusion":"观察到上传尝试","process":"fixture","file":"/tmp/fixture.zip","target":"receiver.test","authorization_state":"unknown","evidence_strength":"observed_network_write","evidence_count":3}]}"#.utf8)
        controller.renderDashboard(try JSONDecoder().decode(DashboardSnapshot.self, from: alertData))
        precondition(controller.alertTitle.stringValue.contains("观察到上传尝试"))
        precondition(controller.alertFile.stringValue.contains("receiver.test"))
        precondition(controller.alertEvidence.stringValue.contains("状态未知"))
        try capture(controller.window.contentView!, output + "/stale.png")
        let fixtureRoot = URL(fileURLWithPath: output)
        let protected = fixtureRoot.appendingPathComponent("protected", isDirectory: true)
        let cache = fixtureRoot.appendingPathComponent("cache", isDirectory: true)
        let allowed = fixtureRoot.appendingPathComponent("allowed", isDirectory: true)
        for directory in [protected, cache, allowed] {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        }
        controller.protectedDirs = [protected]
        controller.cacheDirs = [cache]
        controller.allowedUploadDirs = [allowed]
        controller.allowedUploadTargets.stringValue = "receiver.test:443"
        controller.authorizationChoice.selectItem(at: 1)
        controller.categoryChecks["git_history"]?.state = .on
        controller.startCard(controller.cards[1])
        wait(15) { controller.reportURL != nil }
        RunLoop.current.run(until: Date().addingTimeInterval(2))
        controller.stopObservation()
        wait(15) { controller.backend == nil }
        let policyData = try Data(contentsOf: controller.savedReport!)
        let policyReport = try JSONSerialization.jsonObject(with: policyData) as! [String: Any]
        let policy = policyReport["policy"] as! [String: Any]
        precondition((policyReport["authorization"] as? [String: Any])?["state"] as? String == "authorized")
        precondition(policy["protected_directories"] as? [String] == [protected.path])
        precondition(policy["sensitive_categories"] as? [String] == ["git_history"])
        precondition(policy["allowed_upload_directories"] as? [String] == [allowed.path])
        precondition(policy["allowed_upload_targets"] as? [String] == ["receiver.test:443"])
        let watchRoots = policyReport["watch_roots"] as? [String] ?? []
        precondition(watchRoots.contains { $0.hasSuffix("/protected") } && watchRoots.contains { $0.hasSuffix("/cache") })
        let evidence: [String: Any] = ["passed": true, "uid": getuid(), "events": events.count,
            "report": controller.savedReport!.path, "connection_label": controller.connectionTile.value.stringValue,
            "outbound_label": observedOutbound,
            "limits": ["synthetic loopback fixture", "AppKit view rendering, not Finder download flow"]]
        try JSONSerialization.data(withJSONObject: evidence, options: [.prettyPrinted, .sortedKeys])
            .write(to: URL(fileURLWithPath: output + "/verification.json"))
        print("Desktop smoke passed")
    }
}
