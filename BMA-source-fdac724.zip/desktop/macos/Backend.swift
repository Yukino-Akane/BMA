import Foundation

struct BackendStatus: Decodable {
    let state: String
    let url: String?
    let output: String?
    let status: String?
    let proxy_url: String?
    let dashboard: DashboardSnapshot?

    var localURL: URL? {
        guard let url = url, let value = URL(string: url), value.scheme == "http",
              value.host == "127.0.0.1", value.port != nil,
              value.user == nil, value.password == nil else { return nil }
        return value
    }
}

// A short-lived child owns collection. No shell, service, inherited model key,
// system proxy change, or command-string interpolation is involved.
final class Backend {
    private let executable: URL
    private(set) var process: Process?
    private var control: Pipe?
    var onStatus: ((BackendStatus) -> Void)?
    var onExit: ((Int32, String) -> Void)?

    init(executable: URL) { self.executable = executable }

    func start(_ arguments: [String]) throws {
        precondition(process == nil)
        let child = Process()
        let input = Pipe(), stdout = Pipe(), stderr = Pipe()
        child.executableURL = executable
        child.arguments = arguments
        child.environment = ProcessInfo.processInfo.environment.filter {
            ["HOME", "TMPDIR", "PATH", "LANG", "LC_ALL"].contains($0.key)
        }
        child.standardInput = input
        child.standardOutput = stdout
        child.standardError = stderr
        try child.run()
        process = child
        control = input
        input.fileHandleForReading.closeFile()
        stdout.fileHandleForWriting.closeFile()
        stderr.fileHandleForWriting.closeFile()
        let group = DispatchGroup()
        group.enter()
        DispatchQueue.global().async {
            var pending = Data()
            while true {
                let chunk = stdout.fileHandleForReading.availableData
                if chunk.isEmpty { break }
                pending.append(chunk)
                while let end = pending.firstIndex(of: 10) {
                    let line = pending[..<end]
                    if let status = try? JSONDecoder().decode(BackendStatus.self, from: Data(line)) {
                        DispatchQueue.main.async { self.onStatus?(status) }
                    }
                    pending.removeSubrange(...end)
                }
                if pending.count > 1024 * 1024 { pending.removeAll() }
            }
            stdout.fileHandleForReading.closeFile()
            group.leave()
        }
        group.enter()
        // Drain continuously even after reaching the diagnostic limit.
        DispatchQueue.global().async {
            var diagnostic = Data()
            while true {
                let chunk = stderr.fileHandleForReading.availableData
                if chunk.isEmpty { break }
                if diagnostic.count < 16384 { diagnostic.append(chunk.prefix(16384 - diagnostic.count)) }
            }
            stderr.fileHandleForReading.closeFile()
            child.waitUntilExit()
            let message = String(decoding: diagnostic, as: UTF8.self)
            group.leave()
            group.notify(queue: .main) {
                self.control?.fileHandleForWriting.closeFile()
                self.control = nil
                self.process = nil
                self.onExit?(child.terminationStatus, message)
            }
        }
    }

    func stop() { control?.fileHandleForWriting.closeFile(); control = nil }
}
