import AppKit

struct DashboardSnapshot: Decodable {
    struct Traffic: Decodable { let bytes_in: UInt64; let bytes_out: UInt64 }
    struct Activity: Decodable { let at: String; let kind: String; let process: String }
    struct Alert: Decodable {
        let at: String
        let conclusion: String
        let process: String
        let file: String
        let target: String
        let authorization_state: String
        let evidence_strength: String
        let evidence_count: Int
    }
    let status: String
    let last_sample_at: String?
    let last_success_at: String?
    let interval_sec: Double?
    let covered_processes: Int?
    let health: [String: Int]?
    let connections: Int
    let files: Int
    let gaps: Int
    let file_watching: Bool
    let scope_roots: Int
    let scope_children: Int
    let traffic: [String: Traffic]
    let recent: [Activity]
    let alerts: [Alert]?
}

// One bounded loopback request at a time. No inherited proxy, cookies or redirects.
final class DashboardClient: NSObject, URLSessionTaskDelegate {
    private var task: URLSessionDataTask?
    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.connectionProxyDictionary = [:]
        config.httpCookieStorage = nil
        config.timeoutIntervalForRequest = 4
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()
    func read(_ base: URL, completion: @escaping (DashboardSnapshot?) -> Void) {
        guard task == nil else { return }
        task = session.dataTask(with: base.appendingPathComponent("api/dashboard")) { data, response, error in
            let value: DashboardSnapshot?
            if error == nil, (response as? HTTPURLResponse)?.statusCode == 200,
               let data = data, data.count <= 65536 {
                value = try? JSONDecoder().decode(DashboardSnapshot.self, from: data)
            } else { value = nil }
            DispatchQueue.main.async { self.task = nil; completion(value) }
        }
        task?.resume()
    }
    func close() { task?.cancel(); session.invalidateAndCancel() }
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}

final class MetricTile: NSBox {
    let value = NSTextField(labelWithString: "—")
    init(_ title: String, note: String) {
        super.init(frame: .zero)
        boxType = .custom; borderWidth = 0; cornerRadius = 12
        fillColor = .controlBackgroundColor; contentViewMargins = NSSize(width: 16, height: 14)
        let heading = NSTextField(labelWithString: title)
        heading.font = .systemFont(ofSize: 12, weight: .medium); heading.textColor = .secondaryLabelColor
        value.font = .monospacedDigitSystemFont(ofSize: 26, weight: .semibold)
        let detail = NSTextField(wrappingLabelWithString: note)
        detail.font = .systemFont(ofSize: 11); detail.textColor = .secondaryLabelColor
        let stack = NSStackView(views: [heading, value, detail])
        stack.orientation = .vertical; stack.alignment = .leading; stack.spacing = 8
        stack.translatesAutoresizingMaskIntoConstraints = false
        contentView!.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: contentView!.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: contentView!.trailingAnchor),
            stack.topAnchor.constraint(equalTo: contentView!.topAnchor),
            stack.bottomAnchor.constraint(equalTo: contentView!.bottomAnchor)
        ])
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}

func activityTitle(_ kind: String) -> String {
    switch kind {
    case "scope_member_added": return "进程已加入观察范围"
    case "scope_member_removed": return "进程已离开可核验范围"
    case "process_observed": return "已开始观察进程"
    case "process_no_longer_observed": return "进程已退出或不再可见"
    case "connection_observed": return "发现网络连接"
    case "connection_failed": return "网络连接未完成"
    case "egress": return "记录网络流量"
    case "network_baseline": return "网络采样已就绪"
    case "collector_error": return "出现采集缺口 · 查看报告了解详情"
    case "collector_status": return "采集能力或进程状态变化"
    case "collector_recovered": return "采集已恢复 · 先前缺口仍保留"
    case "file_open_observed": return "观察到打开的文件"
    case "file_change": return "项目文件发生变化"
    case "file_create": return "项目中创建了文件"
    case "file_modify": return "项目文件已修改"
    case "file_delete": return "项目文件已删除"
    case "file_rename": return "项目文件已重命名"
    case "goal": return "已记录任务目标"
    case "agent_claim": return "已记录应用自述"
    default: return "新增观察记录"
    }
}
