import AppKit
import CoreText

// Build-time artwork; no runtime image generator or external asset dependency.
let destination = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
for size in [16, 32, 128, 256, 512] {
    for scale in [1, 2] {
        let pixels = size * scale
        let context = CGContext(data: nil, width: pixels, height: pixels, bitsPerComponent: 8,
            bytesPerRow: 0, space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
        context.scaleBy(x: CGFloat(pixels) / 1024, y: CGFloat(pixels) / 1024)
        context.setFillColor(CGColor(red: 0.06, green: 0.19, blue: 0.30, alpha: 1))
        context.addPath(CGPath(roundedRect: CGRect(x: 48, y: 48, width: 928, height: 928),
            cornerWidth: 210, cornerHeight: 210, transform: nil))
        context.fillPath()
        context.setStrokeColor(CGColor(red: 0.29, green: 0.85, blue: 0.74, alpha: 1))
        context.setLineWidth(38); context.setLineCap(.round); context.setLineJoin(.round)
        context.move(to: CGPoint(x: 210, y: 635)); context.addLine(to: CGPoint(x: 330, y: 635))
        context.addLine(to: CGPoint(x: 415, y: 775)); context.addLine(to: CGPoint(x: 530, y: 530))
        context.addLine(to: CGPoint(x: 640, y: 685)); context.addLine(to: CGPoint(x: 815, y: 685))
        context.strokePath()
        let text = NSAttributedString(string: "BMA", attributes: [
            .font: NSFont.boldSystemFont(ofSize: 225), .foregroundColor: NSColor.white])
        let line = CTLineCreateWithAttributedString(text)
        context.textPosition = CGPoint(x: (1024 - CTLineGetTypographicBounds(line, nil, nil, nil)) / 2, y: 250)
        CTLineDraw(line, context)
        let bitmap = NSBitmapImageRep(cgImage: context.makeImage()!)
        let suffix = scale == 2 ? "@2x" : ""
        try bitmap.representation(using: .png, properties: [:])!.write(
            to: destination.appendingPathComponent("icon_\(size)x\(size)\(suffix).png"))
    }
}
