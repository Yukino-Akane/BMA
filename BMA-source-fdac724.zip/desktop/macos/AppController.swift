import AppKit

final class AppController: NSObject, NSApplicationDelegate, NSWindowDelegate, NSTableViewDataSource, NSTableViewDelegate, NSSearchFieldDelegate {
    var window: NSWindow!
    let search = NSSearchField()
    let allProcesses = NSButton(checkboxWithTitle: "显示当前账户的后台进程", target: nil, action: nil)
    let table = NSTableView()
    let workspaceLabel = NSTextField(labelWithString: "未开启文件观察（可选）")
    let protectedDirsLabel = NSTextField(labelWithString: "未选择")
    let cacheDirsLabel = NSTextField(labelWithString: "未选择")
    let allowedUploadDirsLabel = NSTextField(labelWithString: "未选择")
    let allowedUploadTargets = NSTextField()
    let authorizationChoice = NSPopUpButton()
    var categoryChecks: [String: NSButton] = [:]
    let goal = NSTextField()
    let logLabel = NSTextField(labelWithString: "可选：没有日志也可以观察文件与网络")
    let logFormat = NSPopUpButton()
    let statusLabel = NSTextField(wrappingLabelWithString: "点击正在运行的应用卡片，即可开始观察。")
    let startButton = NSButton(title: "开始观察", target: nil, action: nil)
    let stopButton = NSButton(title: "停止并保存", target: nil, action: nil)
    let reportButton = NSButton(title: "查看报告", target: nil, action: nil)
    var inputs: [NSControl] = []
    var choices: [ProcessChoice] = []
    var visibleChoices: [ProcessChoice] = []
    var workspace: URL?
    var protectedDirs: [URL] = []
    var cacheDirs: [URL] = []
    var allowedUploadDirs: [URL] = []
    var logURL: URL?
    var reportURL: URL?
    var savedReport: URL?
    var backend: Backend?
    var operation = ""
    var stopping = false
    var quitting = false
    var sessionOutput: URL?

    var settingsWindow: NSWindow!
    var cards: [NSButton] = []
    var selectedPIDs: Set<Int32> = []
    var selectedName = ""
    var processRefreshPending = false
    var refreshTimer: Timer?
    var dashboardClient = DashboardClient()
    var proxyAddress: String?
    let scopeLabel = NSTextField(wrappingLabelWithString: "尚未开始 · 只观察你点击的应用")
    let activityLabel = NSTextField(wrappingLabelWithString: "开始后，这里会实时显示网络连接、流量和采集状态。")
    let alertTitle = NSTextField(labelWithString: "暂无关联告警")
    let alertFile = NSTextField(labelWithString: "")
    let alertEvidence = NSTextField(labelWithString: "")
    let proxyLabel = NSTextField(wrappingLabelWithString: "系统网络采样 · 不读取 HTTPS 正文")
    let updatedLabel = NSTextField(labelWithString: "等待开始")
    let healthLabel = NSTextField(wrappingLabelWithString: "")
    let connectionTile = MetricTile("已观察连接", note: "会话累计 · 非当前在线数")
    let outboundTile = MetricTile("出站流量", note: "系统采样 · 会话累计")
    let inboundTile = MetricTile("入站流量", note: "系统采样 · 会话累计")
    let fileTile = MetricTile("文件事件", note: "仅限选定目录")
    let gapTile = MetricTile("采集缺口", note: "历史累计 · 不代表风险")
    let intervalChoice = NSPopUpButton()
    let enableProxy = NSButton(checkboxWithTitle: "启用选定进程的代理转发计量", target: nil, action: nil)
    let upstream = NSTextField()

    var executable: URL { Bundle.main.bundleURL.appendingPathComponent("Contents/Helpers/bma") }
    var sessions: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Behavior Monitoring and Audit/Sessions", isDirectory: true)
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        buildMenu()
        buildWindow()
        buildSettings()
        refreshProcesses()
        refreshTimer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in
            self?.refreshProcesses()
            self?.refreshDashboard()
        }
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    func buildMenu() {
        let menu = NSMenu(), application = NSMenuItem(), actions = NSMenu()
        actions.addItem(withTitle: "关于 Behavior Monitoring and Audit", action: #selector(NSApplication.orderFrontStandardAboutPanel(_:)), keyEquivalent: "")
        actions.addItem(.separator())
        actions.addItem(withTitle: "退出", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        application.submenu = actions; menu.addItem(application)
        let edit = NSMenuItem(), editActions = NSMenu(title: "编辑")
        for (title, action, key) in [("撤销", "undo:", "z"), ("剪切", "cut:", "x"), ("复制", "copy:", "c"), ("粘贴", "paste:", "v"), ("全选", "selectAll:", "a")] {
            editActions.addItem(withTitle: title, action: Selector(action), keyEquivalent: key)
        }
        edit.submenu = editActions; menu.addItem(edit)
        NSApp.mainMenu = menu
    }

    func label(_ text: String, size: CGFloat = 13, bold: Bool = false) -> NSTextField {
        let field = NSTextField(wrappingLabelWithString: text)
        field.font = bold ? .boldSystemFont(ofSize: size) : .systemFont(ofSize: size)
        return field
    }

    func button(_ title: String, _ selector: Selector) -> NSButton {
        let value = NSButton(title: title, target: self, action: selector)
        value.bezelStyle = .rounded
        return value
    }

    func row(_ views: [NSView]) -> NSStackView {
        let stack = NSStackView(views: views)
        stack.orientation = .horizontal; stack.spacing = 10; stack.alignment = .centerY
        return stack
    }

    func buildWindow() {
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1040, height: 760),
            styleMask: [.titled, .closable, .miniaturizable, .resizable], backing: .buffered, defer: false)
        let version = Bundle.main.object(forInfoDictionaryKey: "BMABuildVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "开发测试"
        window.title = "BMA \(version) · 实时监控"
        window.minSize = NSSize(width: 940, height: 720)
        window.center(); window.delegate = self
        let root = NSStackView()
        root.orientation = .vertical; root.spacing = 9; root.alignment = .leading
        root.translatesAutoresizingMaskIntoConstraints = false
        let content = window.contentView!
        content.addSubview(root)
        NSLayoutConstraint.activate([
            root.leadingAnchor.constraint(equalTo: content.leadingAnchor, constant: 28),
            root.trailingAnchor.constraint(equalTo: content.trailingAnchor, constant: -28),
            root.topAnchor.constraint(equalTo: content.topAnchor, constant: 20),
            root.bottomAnchor.constraint(lessThanOrEqualTo: content.bottomAnchor, constant: -16)
        ])
        let title = label("应用正在做什么，一眼看清", size: 26, bold: true)
        let space = NSView(); space.setContentHuggingPriority(.defaultLow, for: .horizontal)
        let header = row([title, space, button("高级设置…", #selector(showSettings))])
        root.addArrangedSubview(header); header.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        root.addArrangedSubview(label("先打开应用，再点击卡片开始 · 只在本次会话观察 · 退出即停止", size: 13))
        for (index, name) in appFamilies.enumerated() {
            let card = button(name + "\n正在查找…", #selector(startCard(_:)))
            card.tag = index; card.bezelStyle = .regularSquare
            card.font = .systemFont(ofSize: 15, weight: .medium)
            card.setAccessibilityLabel(name + "，正在查找")
            card.heightAnchor.constraint(equalToConstant: 88).isActive = true
            cards.append(card)
        }
        let cardRow = row(cards); cardRow.distribution = .fillEqually
        root.addArrangedSubview(cardRow); cardRow.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        scopeLabel.font = .systemFont(ofSize: 16, weight: .semibold)
        root.addArrangedSubview(scopeLabel)
        let metrics = row([connectionTile, outboundTile, inboundTile, fileTile, gapTile])
        metrics.distribution = .fillEqually
        root.addArrangedSubview(metrics); metrics.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        proxyLabel.font = .systemFont(ofSize: 12); proxyLabel.textColor = .secondaryLabelColor
        root.addArrangedSubview(proxyLabel); proxyLabel.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        healthLabel.font = .systemFont(ofSize: 11)
        healthLabel.textColor = .secondaryLabelColor
        root.addArrangedSubview(healthLabel)
        healthLabel.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        let alertHeader = row([label("最近告警", size: 16, bold: true), button("完整证据", #selector(showReport))])
        root.addArrangedSubview(alertHeader)
        for field in [alertTitle, alertFile, alertEvidence] {
            field.font = .systemFont(ofSize: 12)
            field.lineBreakMode = .byTruncatingMiddle
            root.addArrangedSubview(field)
            field.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        }
        alertTitle.font = .systemFont(ofSize: 13, weight: .semibold)
        let recentHeader = row([label("最近活动", size: 16, bold: true), updatedLabel])
        updatedLabel.font = .systemFont(ofSize: 11); updatedLabel.textColor = .secondaryLabelColor
        root.addArrangedSubview(recentHeader)
        activityLabel.font = .systemFont(ofSize: 13)
        activityLabel.maximumNumberOfLines = 4
        root.addArrangedSubview(activityLabel)
        activityLabel.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        activityLabel.heightAnchor.constraint(equalToConstant: 75).isActive = true
        stopButton.target = self; stopButton.action = #selector(stopObservation); stopButton.bezelStyle = .rounded
        reportButton.target = self; reportButton.action = #selector(showReport); reportButton.bezelStyle = .rounded
        root.addArrangedSubview(row([stopButton, reportButton, button("报告所在位置", #selector(revealReports)), button("打开已有报告…", #selector(openReport)), button("体验演示", #selector(startDemo))]))
        root.addArrangedSubview(statusLabel); statusLabel.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        statusLabel.textColor = .secondaryLabelColor
        root.addArrangedSubview(label("连接可能漏采；流量不等于文件上传量。缺口会保留在报告中，未记录不代表安全。", size: 11))
        updateControls()
    }

    @objc func showSettings() { window.beginSheet(settingsWindow) }
    @objc func closeSettings() { window.endSheet(settingsWindow) }

    func buildSettings() {
        settingsWindow = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 760, height: 700),
            styleMask: [.titled], backing: .buffered, defer: false)
        settingsWindow.title = "高级设置 · 可选范围"
        let viewport = NSScrollView()
        viewport.hasVerticalScroller = true; viewport.autohidesScrollers = true
        viewport.drawsBackground = false; viewport.translatesAutoresizingMaskIntoConstraints = false
        settingsWindow.contentView!.addSubview(viewport)
        NSLayoutConstraint.activate([
            viewport.leadingAnchor.constraint(equalTo: settingsWindow.contentView!.leadingAnchor),
            viewport.trailingAnchor.constraint(equalTo: settingsWindow.contentView!.trailingAnchor),
            viewport.topAnchor.constraint(equalTo: settingsWindow.contentView!.topAnchor),
            viewport.bottomAnchor.constraint(equalTo: settingsWindow.contentView!.bottomAnchor)
        ])
        let document = NSView(); document.translatesAutoresizingMaskIntoConstraints = false
        viewport.documentView = document
        let root = NSStackView(); root.orientation = .vertical; root.alignment = .leading; root.spacing = 10
        root.translatesAutoresizingMaskIntoConstraints = false
        document.addSubview(root)
        NSLayoutConstraint.activate([
            document.widthAnchor.constraint(equalTo: viewport.contentView.widthAnchor),
            root.leadingAnchor.constraint(equalTo: document.leadingAnchor, constant: 24),
            root.trailingAnchor.constraint(equalTo: document.trailingAnchor, constant: -24),
            root.topAnchor.constraint(equalTo: document.topAnchor, constant: 20),
            root.bottomAnchor.constraint(equalTo: document.bottomAnchor, constant: -20)
        ])
        root.addArrangedSubview(label("可选范围与采样", size: 22, bold: true))
        root.addArrangedSubview(label("设置只影响下一次观察。默认不读取文件夹或会话日志。", size: 12))
        let choose = button("选择项目文件夹…", #selector(chooseWorkspace))
        let clearWorkspace = button("清除", #selector(clearWorkspace))
        workspaceLabel.lineBreakMode = .byTruncatingMiddle
        let folderRow = row([choose, clearWorkspace, workspaceLabel])
        root.addArrangedSubview(folderRow); folderRow.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        root.addArrangedSubview(label("保护与产物目录", size: 15, bold: true))
        for field in [protectedDirsLabel, cacheDirsLabel, allowedUploadDirsLabel] {
            field.lineBreakMode = .byTruncatingMiddle
            field.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        }
        let chooseProtected = button("添加保护目录…", #selector(chooseProtectedDirs))
        let clearProtected = button("清除", #selector(clearProtectedDirs))
        let protectedRow = row([chooseProtected, clearProtected, protectedDirsLabel])
        root.addArrangedSubview(protectedRow); protectedRow.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        let chooseCache = button("添加缓存/临时目录…", #selector(chooseCacheDirs))
        let clearCache = button("清除", #selector(clearCacheDirs))
        let cacheRow = row([chooseCache, clearCache, cacheDirsLabel])
        root.addArrangedSubview(cacheRow); cacheRow.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        root.addArrangedSubview(label("敏感文件类别", size: 15, bold: true))
        let categories = [("git_history", "Git 历史"), ("credentials", "配置/凭证"),
                          ("archive", "归档"), ("encrypted", "加密产物"), ("opaque_high_entropy", "无扩展名高熵产物")]
        let categoryRow = row(categories.map { key, title in
            let check = NSButton(checkboxWithTitle: title, target: nil, action: nil)
            categoryChecks[key] = check
            return check
        })
        root.addArrangedSubview(categoryRow); categoryRow.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        root.addArrangedSubview(label("上传授权范围", size: 15, bold: true))
        authorizationChoice.addItems(withTitles: ["授权状态未知", "允许指定范围", "明确禁止上传"])
        authorizationChoice.selectItem(at: 0)
        root.addArrangedSubview(row([label("授权状态"), authorizationChoice]))
        let chooseAllowed = button("添加允许上传目录…", #selector(chooseAllowedUploadDirs))
        let clearAllowed = button("清除", #selector(clearAllowedUploadDirs))
        let allowedRow = row([chooseAllowed, clearAllowed, allowedUploadDirsLabel])
        root.addArrangedSubview(allowedRow); allowedRow.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        allowedUploadTargets.placeholderString = "允许上传目标，以逗号分隔，如 api.example.com:443"
        root.addArrangedSubview(allowedUploadTargets); allowedUploadTargets.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        goal.placeholderString = "任务目标（可选）：例如，只修改 README"
        root.addArrangedSubview(goal); goal.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        logFormat.addItems(withTitles: ["不读取会话日志", "Claude Code 日志", "Codex 日志", "WorkBuddy 日志"])
        logFormat.target = self; logFormat.action = #selector(formatChanged)
        let chooseLog = button("选择本次日志…", #selector(chooseLogFile))
        let clearLog = button("清除", #selector(clearLogFile))
        root.addArrangedSubview(row([logFormat, chooseLog, clearLog]))
        logLabel.lineBreakMode = .byTruncatingMiddle
        root.addArrangedSubview(logLabel); logLabel.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        intervalChoice.addItems(withTitles: ["2 秒", "5 秒", "10 秒"])
        root.addArrangedSubview(row([label("采样间隔"), intervalChoice]))
        root.addArrangedSubview(enableProxy)
        upstream.placeholderString = "可选现有本机 HTTP 代理，如 http://127.0.0.1:7897"
        root.addArrangedSubview(upstream); upstream.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        root.addArrangedSubview(label("需在所选应用中手动配置面板给出的代理地址。HTTPS 只计加密字节，不解密正文；系统 VPN 保持原样。", size: 11))
        root.addArrangedSubview(label("手动选择进程", size: 15, bold: true))
        search.placeholderString = "搜索应用 / 进程"; search.delegate = self
        allProcesses.target = self; allProcesses.action = #selector(filterProcesses)
        let searchRow = row([search, allProcesses]); root.addArrangedSubview(searchRow)
        searchRow.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        let name = NSTableColumn(identifier: NSUserInterfaceItemIdentifier("name")); name.title = "应用 / 进程"; name.width = 530
        let pid = NSTableColumn(identifier: NSUserInterfaceItemIdentifier("pid")); pid.title = "PID"; pid.width = 100
        table.addTableColumn(name); table.addTableColumn(pid)
        table.delegate = self; table.dataSource = self; table.allowsMultipleSelection = true; table.rowHeight = 25
        let scroll = NSScrollView(); scroll.documentView = table; scroll.hasVerticalScroller = true
        root.addArrangedSubview(scroll)
        scroll.widthAnchor.constraint(equalTo: root.widthAnchor).isActive = true
        scroll.heightAnchor.constraint(equalToConstant: 130).isActive = true
        startButton.title = "观察所选进程"; startButton.target = self; startButton.action = #selector(startObservation)
        root.addArrangedSubview(row([startButton, button("完成", #selector(closeSettings))]))
        inputs = [search, allProcesses, choose, clearWorkspace, chooseProtected, clearProtected, chooseCache, clearCache,
                  chooseAllowed, clearAllowed, authorizationChoice, allowedUploadTargets, goal, logFormat, chooseLog,
                  clearLog, intervalChoice, enableProxy, upstream] + Array(categoryChecks.values)
        updateControls()
    }

    func updateControls() {
        let idle = backend == nil
        startButton.isEnabled = idle
        stopButton.isEnabled = !idle && !stopping
        stopButton.title = operation == "serve" ? "结束报告浏览" : "停止并保存"
        reportButton.isEnabled = reportURL != nil || (idle && savedReport != nil)
        table.isEnabled = idle
        for input in inputs { input.isEnabled = idle }
        updateCards()
    }

    @objc func refreshProcesses() {
        guard !processRefreshPending else { return }
        processRefreshPending = true
        DispatchQueue.global(qos: .userInitiated).async {
            let result = Result { try runningChoices() }
            DispatchQueue.main.async {
                self.processRefreshPending = false
                switch result {
                case .success(let list): self.choices = list; self.filterProcesses(); self.updateCards()
                case .failure: self.statusLabel.stringValue = "无法刷新应用列表，请检查本机进程访问权限。"
                }
            }
        }
    }

    @objc func filterProcesses() {
        let selected = Set(table.selectedRowIndexes.compactMap { $0 < visibleChoices.count ? visibleChoices[$0].pid : nil })
        let query = search.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        visibleChoices = choices.filter { (allProcesses.state == .on || $0.suggested) && (query.isEmpty || $0.name.localizedCaseInsensitiveContains(query)) }
        table.reloadData()
        table.selectRowIndexes(IndexSet(visibleChoices.indices.filter { selected.contains(visibleChoices[$0].pid) }), byExtendingSelection: false)
    }

    func updateCards() {
        for (index, card) in cards.enumerated() {
            let name = appFamilies[index]
            let members = choices.filter { $0.family == name }
            let observing = backend != nil && operation == "watch" && name == selectedName
            let state = observing ? (stopping ? "正在保存…" : "● 观察中 · 覆盖范围见面板") : (members.isEmpty ? "未运行 · 请先打开应用" : "运行中 · 点击开始观察")
            card.title = name + "\n" + state
            card.isEnabled = (backend == nil && !members.isEmpty) || (observing && reportURL != nil && !stopping)
            card.contentTintColor = observing ? .systemGreen : .labelColor
            card.setAccessibilityLabel(name + "，" + state)
            card.toolTip = observing ? "点击查看本次完整报告" : "锁定当前属于此应用的 \(members.count) 个进程，并按采样周期跟踪可核验的子进程。应用重启后需重新开始观察。"
        }
    }

    @objc func startCard(_ sender: NSButton) {
        let name = appFamilies[sender.tag]
        if backend != nil, operation == "watch", selectedName == name { showReport(); return }
        beginObservation(choices.filter { $0.family == name }, name: name)
    }

    func refreshDashboard() {
        guard let child = backend, operation == "watch", let url = reportURL, !stopping else { return }
        dashboardClient.read(url) { [weak self, weak child] snapshot in
            guard let self = self, let child = child, self.backend === child, !self.stopping else { return }
            self.applyDashboardResponse(snapshot)
        }
    }

    func applyDashboardResponse(_ snapshot: DashboardSnapshot?) {
        if let snapshot = snapshot { renderDashboard(snapshot) }
        else { updatedLabel.stringValue = "更新中断 · 数据陈旧 · 显示上次数据"; updatedLabel.textColor = .systemOrange }
    }

    func renderDashboard(_ snapshot: DashboardSnapshot) {
        if snapshot.status == "recording" {
            scopeLabel.stringValue = "● 观察中 · \(selectedName) · 选定根进程 \(snapshot.scope_roots) · 已核验覆盖 \(snapshot.covered_processes ?? 0) 个（含子进程 \(snapshot.scope_children)）"
        }
        connectionTile.value.stringValue = String(snapshot.connections)
        fileTile.value.stringValue = snapshot.file_watching ? String(snapshot.files) : "未开启"
        gapTile.value.stringValue = String(snapshot.gaps)
        gapTile.value.textColor = snapshot.gaps > 0 ? .systemOrange : .labelColor
        func bytes(_ value: UInt64) -> String { ByteCountFormatter.string(fromByteCount: Int64(clamping: value), countStyle: .binary) }
        if let traffic = snapshot.traffic["nettop"] {
            outboundTile.value.stringValue = bytes(traffic.bytes_out); inboundTile.value.stringValue = bytes(traffic.bytes_in)
        } else { outboundTile.value.stringValue = "待采样"; inboundTile.value.stringValue = "待采样" }
        if let traffic = snapshot.traffic["proxy"] {
            proxyLabel.stringValue = "代理 \(proxyAddress ?? "")：出站 \(bytes(traffic.bytes_out)) · 入站 \(bytes(traffic.bytes_in)) · HTTPS 为加密字节，不与系统采样相加"
        }
        if let alert = snapshot.alerts?.first {
            let time = parseDashboardDate(alert.at).map { DateFormatter.localizedString(from: $0, dateStyle: .short, timeStyle: .medium) } ?? alert.at
            alertTitle.stringValue = "\(alert.conclusion) · \(alert.process) · \(time)"
            alertFile.stringValue = "文件/范围：\(alert.file.isEmpty ? "未确定" : alert.file)    目标：\(alert.target.isEmpty ? "未知" : alert.target)"
            let authorization = ["unknown": "状态未知", "authorized": "已授权", "denied": "明确禁止", "authorized_target_unknown": "授权目标未知", "authorized_target_out_of_range": "超出授权目标", "authorized_related_path_out_of_range": "超出授权目录", "authorized_scope_incomplete": "授权范围不完整", "authorized_related_path_unknown": "关联文件范围未知"].first { $0.key == alert.authorization_state }?.value ?? alert.authorization_state
            let strength = ["heuristic": "线索", "suggestive_process_aggregate": "疑似进程聚合关联", "suggestive_proxy_bytes": "疑似代理字节关联", "observed_request_attempt": "观察到请求尝试", "observed_network_write": "观察到出站写入"].first { $0.key == alert.evidence_strength }?.value ?? alert.evidence_strength
            alertEvidence.stringValue = "授权：\(authorization) · 证据：\(strength)（\(alert.evidence_count) 项） · 采集缺口：\(snapshot.gaps)"
            for field in [alertTitle, alertFile, alertEvidence] { field.toolTip = field.stringValue }
            alertTitle.textColor = alert.authorization_state == "authorized" ? .labelColor : .systemOrange
        } else {
            alertTitle.stringValue = "暂无关联告警"
            alertFile.stringValue = ""
            alertEvidence.stringValue = "采集缺口：\(snapshot.gaps) · 完整证据见报告"
            alertTitle.textColor = .secondaryLabelColor
        }
        activityLabel.stringValue = snapshot.recent.prefix(4).map { item in
            let time = String(item.at.dropFirst(11).prefix(8))
            return "\(time) UTC   \(activityTitle(item.kind))   \(item.process)"
        }.joined(separator: "\n")
        if snapshot.recent.isEmpty { activityLabel.stringValue = "正在等待所选应用产生可观察的活动…" }
        if let raw = snapshot.last_sample_at, let date = parseDashboardDate(raw) {
            let time = DateFormatter.localizedString(from: date, dateStyle: .none, timeStyle: .medium)
            let interval = snapshot.interval_sec.map { String(format: "%.0f 秒", $0) } ?? "未知"
            let stale = Date().timeIntervalSince(date) > max((snapshot.interval_sec ?? 2) * 3, 8)
            let success = snapshot.last_success_at.flatMap { parseDashboardDate($0) }
            let health = snapshot.health ?? [:]
            let healthText = [("ok", "正常"), ("unsupported", "不支持"), ("idle", "空闲"), ("process_exited", "已退出"), ("failed", "失败"), ("recovered", "本轮恢复")].compactMap { key, title in
                guard let count = health[key], count > 0 else { return nil }
                return "\(title) \(count)"
            }.joined(separator: " · ")
            healthLabel.stringValue = "本轮进程采集项：" + healthText + " · 最近完整成功 \(success.map { DateFormatter.localizedString(from: $0, dateStyle: .none, timeStyle: .medium) } ?? "暂无")"
            healthLabel.textColor = (health["failed"] ?? 0) > 0 ? .systemOrange : .secondaryLabelColor
            updatedLabel.stringValue = snapshot.status == "recording" ? "后端采样 \(time) · 间隔 \(interval)" + (stale ? " · 数据陈旧" : "") : "最终数据 · 已停止"
            updatedLabel.textColor = stale && snapshot.status == "recording" ? .systemOrange : .secondaryLabelColor
        } else {
            updatedLabel.stringValue = snapshot.status == "recording" ? "等待后端首次采样" : "最终数据 · 已停止"
            updatedLabel.textColor = .secondaryLabelColor
        }
    }

    func parseDashboardDate(_ value: String) -> Date? {
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return fractional.date(from: value) ?? ISO8601DateFormatter().date(from: value)
    }
    func controlTextDidChange(_ notification: Notification) { filterProcesses() }
    func numberOfRows(in tableView: NSTableView) -> Int { visibleChoices.count }
    func tableView(_ tableView: NSTableView, viewFor column: NSTableColumn?, row: Int) -> NSView? {
        let item = visibleChoices[row]
        return NSTextField(labelWithString: column?.identifier.rawValue == "pid" ? String(item.pid) : item.name)
    }

    @objc func chooseWorkspace() {
        let panel = NSOpenPanel(); panel.canChooseDirectories = true; panel.canChooseFiles = false
        panel.prompt = "观察这个项目"; panel.message = "只选择本次任务的项目文件夹，不要选择整个个人主目录。"
        panel.beginSheetModal(for: settingsWindow.isVisible ? settingsWindow : window) { response in
            if response == .OK, let url = panel.url {
                self.workspace = url; self.workspaceLabel.stringValue = url.path
            }
        }
    }
    @objc func clearWorkspace() { workspace = nil; workspaceLabel.stringValue = "未开启文件观察（可选）" }
    func selectDirectories(_ prompt: String, completion: @escaping ([URL]) -> Void) {
        let panel = NSOpenPanel(); panel.canChooseDirectories = true; panel.canChooseFiles = false
        panel.allowsMultipleSelection = true; panel.prompt = prompt
        panel.message = "只选择本次需要观察或授权的目录，不要选择整个个人主目录。"
        panel.beginSheetModal(for: settingsWindow.isVisible ? settingsWindow : window) { response in
            if response == .OK { completion(panel.urls.map { $0.standardizedFileURL }) }
        }
    }
    func addDirectories(_ urls: [URL], to selected: inout [URL], label: NSTextField) {
        let existing = Set(selected.map(\.path))
        selected += urls.filter { !existing.contains($0.path) && !selected.contains($0) }
        label.stringValue = selected.isEmpty ? "未选择" : selected.map(\.path).joined(separator: " · ")
        label.toolTip = label.stringValue
    }
    @objc func chooseProtectedDirs() {
        selectDirectories("保护这些目录") { [weak self] urls in
            guard let self = self else { return }
            self.addDirectories(urls, to: &self.protectedDirs, label: self.protectedDirsLabel)
        }
    }
    @objc func clearProtectedDirs() { protectedDirs = []; protectedDirsLabel.stringValue = "未选择" }
    @objc func chooseCacheDirs() {
        selectDirectories("观察这些缓存/临时目录") { [weak self] urls in
            guard let self = self else { return }
            self.addDirectories(urls, to: &self.cacheDirs, label: self.cacheDirsLabel)
        }
    }
    @objc func clearCacheDirs() { cacheDirs = []; cacheDirsLabel.stringValue = "未选择" }
    @objc func chooseAllowedUploadDirs() {
        selectDirectories("允许从这些目录上传") { [weak self] urls in
            guard let self = self else { return }
            self.addDirectories(urls, to: &self.allowedUploadDirs, label: self.allowedUploadDirsLabel)
        }
    }
    @objc func clearAllowedUploadDirs() { allowedUploadDirs = []; allowedUploadDirsLabel.stringValue = "未选择" }
    func uploadTargets() -> [String] {
        let separators = CharacterSet(charactersIn: ",;\n")
        let values = allowedUploadTargets.stringValue.components(separatedBy: separators)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        return Array(NSOrderedSet(array: values)) as? [String] ?? values
    }
    @objc func chooseLogFile() {
        if logFormat.indexOfSelectedItem == 0 { showError("先选择 Claude Code、Codex 或 WorkBuddy 日志格式。豆包暂无专用日志适配。"); return }
        let panel = NSOpenPanel(); panel.canChooseDirectories = false; panel.canChooseFiles = true
        panel.message = "仅选择本次会话的 JSONL 文件。不要选择账号、认证或密钥文件。"
        panel.beginSheetModal(for: settingsWindow.isVisible ? settingsWindow : window) { response in
            if response == .OK, let url = panel.url {
                guard url.pathExtension.lowercased() == "jsonl" else { self.showError("请选择本次会话的 .jsonl 文件。"); return }
                self.logURL = url; self.logLabel.stringValue = url.path
            }
        }
    }
    @objc func clearLogFile() { logURL = nil; logLabel.stringValue = "可选：没有日志也可以观察文件与网络" }
    @objc func formatChanged() { clearLogFile() }

    @objc func startObservation() {
        beginObservation(table.selectedRowIndexes.map { visibleChoices[$0] }, name: "所选应用")
    }

    func beginObservation(_ selected: [ProcessChoice], name: String) {
        guard backend == nil else { return }
        guard !selected.isEmpty else { showError("请先打开应用，再点击它的卡片或选择进程。"); return }
        if logFormat.indexOfSelectedItem != 0 && logURL == nil { showError("请选择本次日志文件，或将日志设置改为“不读取会话日志”。"); return }
        let authorization = ["unknown", "authorized", "denied"][authorizationChoice.indexOfSelectedItem]
        let targets = uploadTargets()
        if authorization == "authorized" && (targets.isEmpty || allowedUploadDirs.isEmpty) {
            showError("允许上传时，请至少选择一个允许上传目录并填写一个目标。"); return
        }
        let output = sessions.appendingPathComponent(UUID().uuidString)
        if selected.contains(where: { $0.family != nil && $0.codeIdentity == nil }) {
            showError("无法核验所选应用的代码签名身份。请刷新进程列表后重试。")
            return
        }
        var args = ["watch", "--process", selected.map { String($0.pid) }.joined(separator: ",")]
        for item in selected {
            args += ["--root-process", "\(item.pid)@\(item.createdAtMS)"]
            if let identity = item.codeIdentity {
                args += ["--root-code", "\(item.pid)@\(identity.bundleID)@\(identity.identifier)@\(identity.teamID)@\(identity.cdhash)"]
            }
        }
        args += [
            "--out", output.path, "--port", "0", "--no-llm", "--status-json", "--stop-on-stdin-close",
            "--interval", ["2s", "5s", "10s"][intervalChoice.indexOfSelectedItem]]
        if let workspace = workspace { args += ["--workspace", workspace.path] }
        let extraWatchDirs = protectedDirs + cacheDirs
        var watched = Set(workspace.map { [$0.standardizedFileURL.path] } ?? [])
        for directory in extraWatchDirs where watched.insert(directory.path).inserted {
            args += ["--watch-dir", directory.path]
        }
        for directory in protectedDirs { args += ["--protected-dir", directory.path] }
        for directory in allowedUploadDirs { args += ["--allow-upload-dir", directory.path] }
        for target in targets { args += ["--allow-upload-target", target] }
        for key in categoryChecks.keys.sorted() where categoryChecks[key]?.state == .on {
            args += ["--sensitive-category", key]
        }
        args += ["--authorization-state", authorization]
        let task = goal.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        if !task.isEmpty { args += ["--goal", task] }
        if enableProxy.state == .on {
            args += ["--proxy-port", "0"]
            let proxy = upstream.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
            if !proxy.isEmpty { args += ["--proxy-upstream", proxy] }
        }
        if let log = logURL, logFormat.indexOfSelectedItem != 0 {
            args += ["--agent-log", log.path, "--agent-format", ["", "claude", "codex", "workbuddy"][logFormat.indexOfSelectedItem]]
        }
        if settingsWindow.isVisible { closeSettings() }
        selectedPIDs = Set(selected.map { $0.pid }); selectedName = name
        scopeLabel.stringValue = "准备观察 \(name) · \(selected.count) 个明确选定的进程"
        for tile in [connectionTile, outboundTile, inboundTile, fileTile, gapTile] { tile.value.stringValue = "—" }
        activityLabel.stringValue = "正在等待采样…"; updatedLabel.stringValue = "正在连接"
        alertTitle.stringValue = "暂无关联告警"; alertFile.stringValue = ""; alertEvidence.stringValue = ""
        healthLabel.stringValue = "等待后端采样"
        proxyAddress = nil; proxyLabel.stringValue = "系统网络采样 · 不读取 HTTPS 正文"
        sessionOutput = output; savedReport = nil
        dashboardClient.close(); dashboardClient = DashboardClient()
        launch(args, kind: "watch")
    }

    @objc func startDemo() {
        guard backend == nil else { showError("请先停止当前观察或报告浏览。"); return }
        let output = sessions.appendingPathComponent("Demo-" + UUID().uuidString)
        sessionOutput = output; savedReport = nil
        launch(["demo", "--output-dir", output.path], kind: "demo")
    }

    func launch(_ arguments: [String], kind: String) {
        guard backend == nil else { return }
        do {
            try FileManager.default.createDirectory(at: sessions, withIntermediateDirectories: true,
                attributes: [.posixPermissions: 0o700])
            let child = Backend(executable: executable)
            backend = child; operation = kind; stopping = false; reportURL = nil
            statusLabel.stringValue = kind == "demo" ? "正在生成模拟演示…" : "正在准备，请稍候…"
            child.onStatus = { [weak self] event in
                guard let self = self else { return }
                if event.state == "started", let url = event.localURL {
                    self.reportURL = url
                    self.statusLabel.stringValue = kind == "watch" ? "正在观察所选范围。现在可以让 Agent 执行任务，完成后点击“停止并保存”。" : "报告已打开。结束浏览后可以停止，或退出应用。"
                    self.updateControls()
                    if kind == "serve" { NSWorkspace.shared.open(url) }
                    else {
                        self.scopeLabel.stringValue = "● 监控中 · \(self.selectedName) · \(self.selectedPIDs.count) 个选定进程"
                        if let proxy = event.proxy_url { self.proxyAddress = proxy; self.proxyLabel.stringValue = "代理地址：\(proxy) · 需手动配置到所选应用；当前等待转发流量" }
                        self.refreshDashboard()
                    }
                } else if event.state == "finished" {
                    self.stopping = true; self.updateControls()
                    if let snapshot = event.dashboard { self.renderDashboard(snapshot) }
                    self.scopeLabel.stringValue = "已结束 · " + self.selectedName
                    self.statusLabel.stringValue = event.status == "stopped" ? "报告已保存。" : "观察已结束，报告中保留了限制或错误信息。"
                }
            }
            child.onExit = { [weak self] code, message in self?.completed(kind: kind, code: code, message: message) }
            try child.start(arguments)
            updateControls()
        } catch {
            backend = nil; scopeLabel.stringValue = "未开始观察"; updatedLabel.stringValue = "启动失败"
            updateControls(); showError(error.localizedDescription)
        }
    }

    func completed(kind: String, code: Int32, message: String) {
        backend = nil; reportURL = nil; stopping = false
        dashboardClient.close(); dashboardClient = DashboardClient()
        if kind == "watch", let output = sessionOutput {
            let file = output.appendingPathComponent("report.json")
            if FileManager.default.fileExists(atPath: file.path) { savedReport = file }
        } else if kind == "demo", code == 0, let output = sessionOutput {
            savedReport = output.appendingPathComponent("demo-report.json")
        }
        updateControls()
        if quitting { NSApp.reply(toApplicationShouldTerminate: true); return }
        if code != 0 {
            scopeLabel.stringValue = "观察已中断 · " + selectedName
            updatedLabel.stringValue = "已停止 · 数据可能不完整"
            statusLabel.stringValue = "未能正常完成，请查看错误；已有记录保留在报告所在位置。"
            showError(message.isEmpty ? "后台程序退出（\(code)）。" : message)
        } else if kind == "demo" {
            showReport()
        } else if kind == "watch" {
            statusLabel.stringValue = "观察已结束，报告已保存在本机。点击“查看报告”查看完整证据。"
        } else { statusLabel.stringValue = "已停止。报告保留在本机，可以重新查看。" }
    }

    @objc func stopObservation() {
        guard let child = backend else { return }
        stopping = true; statusLabel.stringValue = "正在停止并保存，请稍候…"
        updateControls(); child.stop()
    }
    @objc func showReport() {
        if let url = reportURL { NSWorkspace.shared.open(url); return }
        if backend == nil, let file = savedReport {
            launch(["serve", "--report", file.path, "--port", "0", "--status-json", "--stop-on-stdin-close"], kind: "serve")
        }
    }
    @objc func openReport() {
        guard backend == nil else { showError("请先停止当前观察或报告浏览。"); return }
        let panel = NSOpenPanel(); panel.canChooseDirectories = false; panel.message = "选择之前保存的 report.json 或 demo-report.json。"
        panel.beginSheetModal(for: settingsWindow.isVisible ? settingsWindow : window) { response in
            if response == .OK, let file = panel.url {
                self.savedReport = file; self.sessionOutput = file.deletingLastPathComponent(); self.showReport()
            }
        }
    }
    @objc func revealReports() {
        if let output = sessionOutput, FileManager.default.fileExists(atPath: output.path) {
            NSWorkspace.shared.selectFile(nil, inFileViewerRootedAtPath: output.path)
        } else { showError("开始观察或体验演示后，报告会保存在这里。"); }
    }
    func showError(_ message: String) {
        let alert = NSAlert(); alert.messageText = "请检查后重试"; alert.informativeText = message
        alert.addButton(withTitle: "知道了"); alert.beginSheetModal(for: settingsWindow?.isVisible == true ? settingsWindow : window)
    }
    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        guard backend != nil else { return .terminateNow }
        quitting = true; stopObservation(); return .terminateLater
    }
    func windowShouldClose(_ sender: NSWindow) -> Bool { NSApp.terminate(nil); return false }
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        window.makeKeyAndOrderFront(nil); return true
    }
}
