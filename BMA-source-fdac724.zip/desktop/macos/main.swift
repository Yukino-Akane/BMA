import AppKit
import Darwin

let app = NSApplication.shared
if let bundleID = Bundle.main.bundleIdentifier,
   let running = NSRunningApplication.runningApplications(withBundleIdentifier: bundleID).first(where: { $0.processIdentifier != getpid() }) {
    app.setActivationPolicy(.accessory)
    let alert = NSAlert()
    alert.messageText = "已有 BMA 正在运行"
    alert.informativeText = "运行位置：\(running.bundleURL?.path ?? "未知")\n请先在原窗口停止并保存、退出，再打开另一版本。"
    alert.addButton(withTitle: "显示正在运行的 BMA")
    alert.runModal()
    running.activate(options: [.activateAllWindows])
    exit(0)
}
let controller = AppController()
app.delegate = controller
app.setActivationPolicy(.regular)
app.run()
