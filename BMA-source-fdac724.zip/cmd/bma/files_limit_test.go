package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/collect"
	"behavior-monitoring-audit/internal/report"
)

func TestDirectoryLimitWatchHelper(t *testing.T) {
	dir := os.Getenv("BMA_TEST_DIRECTORY_LIMIT_DIR")
	if dir == "" {
		return
	}
	err := run([]string{"watch", "--process", "bma-test-no-process", "--workspace", filepath.Join(dir, "workspace"), "--out", filepath.Join(dir, "session"), "--port", "0", "--no-llm"})
	if !errors.Is(err, collect.ErrFileWatchLimit) {
		t.Fatalf("expected directory limit, got %v", err)
	}
}

func TestRealDirectoryLimitStopsWatchAndSavesReport(t *testing.T) {
	dir := t.TempDir()
	workspace := filepath.Join(dir, "workspace")
	if err := os.Mkdir(workspace, 0700); err != nil {
		t.Fatal(err)
	}
	// The root consumes one slot, so the last child exceeds the real production
	// limit. This exercises fsnotify registrations, not an injected small limit.
	for i := 0; i < collect.MaxWatchDirectories; i++ {
		if err := os.Mkdir(filepath.Join(workspace, fmt.Sprintf("dir-%04d", i)), 0700); err != nil {
			t.Fatal(err)
		}
	}
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	command := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestDirectoryLimitWatchHelper$")
	command.Env = append(os.Environ(), "BMA_TEST_DIRECTORY_LIMIT_DIR="+dir)
	if output, err := command.CombinedOutput(); err != nil {
		t.Fatalf("unlimited-duration watch did not stop on directory capacity: %v %s", err, output)
	}
	data, err := os.ReadFile(filepath.Join(dir, "session", "report.json"))
	if err != nil {
		t.Fatal(err)
	}
	var r report.Report
	if err := json.Unmarshal(data, &r); err != nil {
		t.Fatal(err)
	}
	found := false
	for _, e := range r.Events {
		if e.Kind == "watch_ready" {
			t.Fatal("incomplete registration claimed readiness")
		}
		if e.Kind == "collector_error" && e.Detail["source"] == "filesystem_capacity" {
			found = e.Detail["resource"] == "directory_registrations" && e.Detail["limit"] == float64(collect.MaxWatchDirectories) && e.Detail["used"] == float64(collect.MaxWatchDirectories)
		}
	}
	if r.Status != "limit_reached" || !found {
		t.Fatal("directory limit status or measured usage missing")
	}
	html, err := os.ReadFile(filepath.Join(dir, "session", "report.html"))
	if err != nil || !strings.Contains(string(html), "目录监听达到本次会话的容量上限") {
		t.Fatal("HTML lost capacity explanation", err)
	}
	if _, err := os.Stat(filepath.Join(workspace, fmt.Sprintf("dir-%04d", collect.MaxWatchDirectories-1))); err != nil {
		t.Fatal("watch altered its source directories", err)
	}
}
