package main

import (
	"context"
	"io"
)

// The desktop owns this pipe. EOF (including an unexpected desktop exit)
// cancels observation so the backend saves its journal and exits as well.
func stopOnInputClose(ctx context.Context, input io.Reader, stop context.CancelFunc) {
	go func() {
		_, _ = io.Copy(io.Discard, input)
		if ctx.Err() == nil {
			stop()
		}
	}()
}
