package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/report"
)

func TestWatchRooSnapshotReplacement(t *testing.T) {
	dir := t.TempDir()
	workspace := filepath.Join(dir, "workspace")
	if err := os.Mkdir(workspace, 0700); err != nil {
		t.Fatal(err)
	}
	log := filepath.Join(dir, "ui_messages.json")
	rows := []map[string]any{
		{"ts": 1789812000000, "type": "say", "say": "text", "text": "Only edit README"},
		{"ts": 1789812000001, "type": "ask", "ask": "tool", "text": `{"tool":"readFile","path":"private-path"}`, "partial": true},
	}
	write := func(path string) {
		t.Helper()
		data, err := json.Marshal(rows)
		if err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(path, data, 0600); err != nil {
			t.Fatal(err)
		}
	}
	write(log)
	out := filepath.Join(dir, "report")
	done := make(chan error, 1)
	go func() {
		done <- run([]string{"watch", "--process", "bma-test-nonexistent-process", "--workspace", workspace, "--agent-log", log, "--agent-format", "roo", "--duration", "2s", "--interval", "20ms", "--port", "0", "--no-llm", "--out", out})
	}()
	// Join even on a fixture failure so TempDir cleanup cannot race watch.
	joined := false
	defer func() {
		if !joined {
			<-done
		}
	}()
	observed := false
	for deadline := time.Now().Add(5 * time.Second); time.Now().Before(deadline); {
		data, _ := os.ReadFile(filepath.Join(out, "events.jsonl"))
		if strings.Contains(string(data), "Only edit README") {
			observed = true
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if !observed {
		t.Fatal("initial Roo task never reached the event journal")
	}
	rows[1]["partial"] = false
	rows = append(rows,
		map[string]any{"ts": 1789812000002, "type": "say", "say": "user_feedback", "text": "Keep it small"},
		map[string]any{"ts": 1789812000003, "type": "say", "say": "text", "text": "private-assistant-prose"},
		map[string]any{"ts": 1789812000004, "type": "say", "say": "command_output", "text": "private-output"},
	)
	write(log + ".tmp")
	// Roo saves by moving the previous file aside and installing a new file.
	if err := os.Rename(log, log+".bak"); err != nil {
		t.Fatal(err)
	}
	if err := os.Rename(log+".tmp", log); err != nil {
		t.Fatal(err)
	}
	err := <-done
	joined = true
	if err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(filepath.Join(out, "report.json"))
	if err != nil {
		t.Fatal(err)
	}
	var r report.Report
	if err := json.Unmarshal(data, &r); err != nil {
		t.Fatal(err)
	}
	goals, requests := 0, 0
	for _, e := range r.Events {
		if e.Detail["source"] != "roo" || (e.Kind != "goal" && e.Kind != "claimed_action") {
			continue
		}
		if e.Detail["trust"] != "self_reported" || e.Detail["time_source"] != "agent_log" {
			t.Fatal("Roo evidence lost its self-reported provenance")
		}
		if e.Kind == "goal" {
			goals++
		} else {
			requests++
			if e.Detail["stage"] != "approval_request" || e.Detail["log_record"] != float64(2) || e.TS.UnixMilli() != 1789812000001 {
				t.Fatal("approval request changed meaning or source location")
			}
		}
	}
	if r.Status != "stopped" || goals != 2 || requests != 1 || strings.Contains(string(data), "private-") {
		t.Fatalf("invalid Roo report: status=%s goals=%d requests=%d", r.Status, goals, requests)
	}
	html, err := os.ReadFile(filepath.Join(out, "report.html"))
	if err != nil || !strings.Contains(string(html), "批准请求不证明操作已经执行") {
		t.Fatalf("approval semantics missing from saved HTML: %v", err)
	}
}
