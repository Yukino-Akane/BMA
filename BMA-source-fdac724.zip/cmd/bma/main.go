package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"behavior-monitoring-audit/internal/adapters"
	"behavior-monitoring-audit/internal/collect"
	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/llm"
	"behavior-monitoring-audit/internal/report"
	"behavior-monitoring-audit/internal/rules"
	"behavior-monitoring-audit/internal/scan"
)

func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, "bma:", err)
		os.Exit(1)
	}
}

func resolveProtectedDirectories(policy *rules.Policy) error {
	if policy == nil {
		return nil
	}
	for i, value := range policy.ProtectedDirectories {
		if filepath.IsAbs(value) {
			policy.ProtectedDirectories[i] = filepath.Clean(value)
			continue
		}
		absolute, err := filepath.Abs(value)
		if err != nil {
			return fmt.Errorf("resolve protected directory %q: %w", value, err)
		}
		policy.ProtectedDirectories[i] = filepath.Clean(absolute)
	}
	return nil
}

func run(args []string) error {
	if len(args) == 0 {
		return fmt.Errorf("usage: bma watch | scan | analyze | reconcile | recover | serve | demo | version")
	}
	switch args[0] {
	case "version":
		fmt.Println("bma " + report.Version)
		return nil
	case "watch":
		return watch(args[1:])
	case "scan":
		return scanCommand(args[1:])
	case "analyze":
		return analysisCommand(args[1:], false)
	case "reconcile":
		return analysisCommand(args[1:], true)
	case "demo":
		return demo(args[1:])
	case "recover":
		return recoverCommand(args[1:])
	case "serve":
		return serve(args[1:])
	case "help", "--help", "-h":
		fmt.Println("bma watch --process NAME,PID [--workspace PATH] [--goal TEXT] [--duration 30s]\nbma scan PATH [--json-out report.json] [--html-out report.html]\nbma analyze report.json --endpoint URL [--dry-run-llm]\nbma reconcile analyzed.json --endpoint URL [--dry-run-llm]\nbma recover SESSION_DIRECTORY --out NEW_DIRECTORY\nbma recover --request-log model-requests.jsonl --out NEW_DIRECTORY\nbma demo --output-dir demo-output\nbma serve --report report.json\nObservation only. Ctrl+C saves the report and exits.")
		return nil
	default:
		return fmt.Errorf("unknown command %q", args[0])
	}
}
func watch(args []string) error {
	flags := flag.NewFlagSet("watch", flag.ContinueOnError)
	names := flags.String("process", "", "required comma-separated process names or PIDs")
	var rootProcesses []string
	flags.Func("root-process", "root process instance as PID@START_TIME_MS; repeat for multiple roots", func(value string) error {
		if strings.TrimSpace(value) == "" {
			return fmt.Errorf("root process identity must not be empty")
		}
		rootProcesses = append(rootProcesses, value)
		return nil
	})
	var rootCodes []string
	flags.Func("root-code", "root code identity as PID@BUNDLE_ID@SIGNING_ID@TEAM_ID@CDHASH; repeat for selected roots", func(value string) error {
		if strings.TrimSpace(value) == "" {
			return fmt.Errorf("root code identity must not be empty")
		}
		rootCodes = append(rootCodes, value)
		return nil
	})
	workspace := flags.String("workspace", "", "optional explicitly selected directory to observe")
	var watchDirs []string
	flags.Func("watch-dir", "additional explicitly selected directory; repeat for multiple paths", func(value string) error {
		if strings.TrimSpace(value) == "" {
			return fmt.Errorf("watch directory must not be empty")
		}
		watchDirs = append(watchDirs, value)
		return nil
	})
	var protectedDirs []string
	flags.Func("protected-dir", "user-declared protected directory metadata; repeat for multiple paths", func(value string) error {
		if strings.TrimSpace(value) == "" {
			return fmt.Errorf("protected directory must not be empty")
		}
		protectedDirs = append(protectedDirs, value)
		return nil
	})
	var sensitiveCategories []string
	flags.Func("sensitive-category", "user-declared sensitive data category; repeat for multiple values", func(value string) error {
		if strings.TrimSpace(value) == "" {
			return fmt.Errorf("sensitive category must not be empty")
		}
		sensitiveCategories = append(sensitiveCategories, value)
		return nil
	})
	var allowedUploadTargets []string
	flags.Func("allow-upload-target", "user-authorized upload target; repeat for multiple values", func(value string) error {
		if strings.TrimSpace(value) == "" {
			return fmt.Errorf("allowed upload target must not be empty")
		}
		allowedUploadTargets = append(allowedUploadTargets, value)
		return nil
	})
	var allowedUploadDirs []string
	flags.Func("allow-upload-dir", "user-authorized upload directory; repeat for multiple absolute paths", func(value string) error {
		if strings.TrimSpace(value) == "" {
			return fmt.Errorf("allowed upload directory must not be empty")
		}
		allowedUploadDirs = append(allowedUploadDirs, value)
		return nil
	})
	authorizationState := flags.String("authorization-state", string(rules.AuthorizationUnknown), "recorded outbound authorization: unknown, authorized, or denied")
	goal := flags.String("goal", "", "task assigned to the Agent")
	goalFile := flags.String("goal-file", "", "read the task goal from a UTF-8 file")
	claimsFile := flags.String("claims-file", "", "JSONL file of Agent self-reported tool actions")
	agentLog := flags.String("agent-log", "", "explicit Agent session file to import and follow")
	agentFormat := flags.String("agent-format", "generic", "session format: generic, claude, codex, workbuddy JSONL; roo UI array; cline SDK snapshot")
	interval := flags.Duration("interval", 2*time.Second, "sampling interval")
	duration := flags.Duration("duration", 0, "observation duration (0 until Ctrl+C)")
	rulesPath := flags.String("rules", "", "YAML rule thresholds; defaults to built-in values")
	out := flags.String("out", "", "new session directory outside the watched workspace")
	port := flags.Int("port", 7788, "local report port (0 for an available port)")
	jsonStatus := flags.Bool("status-json", false, "emit JSONL lifecycle status for desktop integration")
	stopWithInput := flags.Bool("stop-on-stdin-close", false, "stop and save when the controlling desktop closes stdin")
	proxyPort := flags.Int("proxy-port", -1, "optional loopback HTTP/CONNECT proxy port; disabled by default")
	proxyUpstream := flags.String("proxy-upstream", "", "existing loopback HTTP proxy URL; requires --proxy-port, e.g. http://127.0.0.1:7897")
	reverseDNS := flags.Bool("reverse-dns", false, "opt in to reverse DNS lookups for connection host labels")
	analyzeEndpoint := flags.String("analyze-endpoint", "", "optional HTTPS OpenAI-compatible endpoint after the session")
	analyzeModel := flags.String("analyze-model", "small", "model used with --analyze-endpoint")
	maxAnalyzeEvents := flags.Int("max-events-per-call", llm.DefaultMaxEventsPerCall, "maximum events per model request")
	noLLM := flags.Bool("no-llm", false, "disable model analysis even when an endpoint is supplied")
	dryRun := flags.Bool("dry-run-llm", false, "preview redacted model requests after observation without sending")
	redactGoal := flags.Bool("redact-goal", false, "hide task goal text in model requests and previews")
	if err := flags.Parse(args); err != nil {
		return err
	}
	authorization := rules.Authorization{State: rules.AuthorizationState(*authorizationState)}.Normalize()
	if !authorization.Valid() {
		return fmt.Errorf("invalid --authorization-state %q; use unknown, authorized, or denied", *authorizationState)
	}
	policy := (rules.Policy{ProtectedDirectories: protectedDirs, SensitiveCategories: sensitiveCategories,
		AllowedUploadDirectories: allowedUploadDirs, AllowedUploadTargets: allowedUploadTargets}).Normalize()
	if err := resolveProtectedDirectories(&policy); err != nil {
		return err
	}
	if err := policy.ValidateAuthorization(authorization); err != nil {
		return err
	}
	if flags.NArg() != 0 || *names == "" {
		return fmt.Errorf("--process is required; unexpected arguments are rejected")
	}
	if *proxyUpstream != "" && *proxyPort < 0 {
		return fmt.Errorf("--proxy-upstream requires --proxy-port")
	}
	if *duration < 0 {
		return fmt.Errorf("duration cannot be negative")
	}
	if *noLLM && *dryRun {
		return fmt.Errorf("--no-llm and --dry-run-llm cannot be combined")
	}
	if *jsonStatus && *dryRun {
		return fmt.Errorf("--status-json cannot be combined with --dry-run-llm; preview the saved report separately")
	}
	if (*dryRun || (*analyzeEndpoint != "" && !*noLLM)) && (*maxAnalyzeEvents < 1 || *maxAnalyzeEvents > 1000) {
		return fmt.Errorf("max events per call must be between 1 and 1000")
	}
	session := event.SessionID()
	watcher, err := collect.NewWatcher(session, *workspace, watchDirs, strings.Split(*names, ","), *interval)
	if err != nil {
		return err
	}
	if len(rootProcesses) > 0 {
		roots := make(map[int]int64, len(rootProcesses))
		for _, value := range rootProcesses {
			pidText, createdText, ok := strings.Cut(value, "@")
			pid, pidErr := strconv.Atoi(pidText)
			created, createdErr := strconv.ParseInt(createdText, 10, 64)
			if !ok || pidErr != nil || createdErr != nil {
				return fmt.Errorf("invalid --root-process %q; expected PID@START_TIME_MS", value)
			}
			if _, duplicate := roots[pid]; duplicate {
				return fmt.Errorf("duplicate root process PID %d", pid)
			}
			roots[pid] = created
		}
		if err := watcher.SetRootProcesses(roots); err != nil {
			return err
		}
		if len(rootCodes) > 0 {
			identities := make(map[int]collect.CodeIdentity, len(rootCodes))
			for _, value := range rootCodes {
				parts := strings.Split(value, "@")
				if len(parts) != 5 {
					return fmt.Errorf("invalid --root-code; expected PID@BUNDLE_ID@SIGNING_ID@TEAM_ID@CDHASH")
				}
				pid, err := strconv.Atoi(parts[0])
				if err != nil {
					return fmt.Errorf("invalid --root-code PID")
				}
				if _, duplicate := identities[pid]; duplicate {
					return fmt.Errorf("duplicate root code identity PID %d", pid)
				}
				identities[pid] = collect.CodeIdentity{BundleID: parts[1], Identifier: parts[2], TeamID: parts[3], CDHash: parts[4]}
			}
			if err := watcher.SetRootCodeIdentities(identities); err != nil {
				return err
			}
		}
	} else if len(rootCodes) > 0 {
		return fmt.Errorf("--root-code requires --root-process")
	}
	watcher.ReverseDNS = *reverseDNS
	var logReader *adapters.LogReader
	if *agentLog != "" {
		logReader, err = adapters.NewLogReader(session, *agentLog, *agentFormat)
		if err != nil {
			return err
		}
	} else if *agentFormat != "generic" {
		return fmt.Errorf("--agent-format requires --agent-log")
	}
	if *out == "" {
		cache, err := os.UserCacheDir()
		if err != nil {
			return err
		}
		*out = filepath.Join(cache, "bma", session)
	}
	output, err := resolveOutputPath(*out)
	if err != nil {
		return err
	}
	for _, root := range watcher.Roots {
		if collect.ContainsPath(root, output) {
			return fmt.Errorf("output must be outside all watched directories to avoid self-observation")
		}
	}
	if err = os.MkdirAll(filepath.Dir(output), 0700); err != nil {
		return err
	}
	if err = os.Mkdir(output, 0700); err != nil {
		return err
	}
	if err = report.SecureDirectory(output); err != nil {
		return err
	}
	config := rules.DefaultConfig()
	if *rulesPath != "" {
		config, err = rules.LoadConfig(*rulesPath)
		if err != nil {
			return err
		}
	}
	config.Policy = policy
	config.Authorization = authorization
	initial := report.NewWithConfig(session, watcher.Workspace, strings.Split(*names, ","), []event.Event{}, config)
	initial.ReverseDNS = *reverseDNS
	initial.WatchRoots = append([]string{}, watcher.Roots...)
	store, err := report.NewStore(output, initial)
	if err != nil {
		return err
	}
	ended := false
	defer func() {
		if !ended {
			_ = store.Finish("failed")
			snapshot := store.Snapshot()
			_ = report.WriteJSON(filepath.Join(output, "report.json"), snapshot)
			_ = report.WriteHTML(filepath.Join(output, "report.html"), snapshot)
		}
	}()
	if *goal != "" {
		goalEvent, goalErr := adapters.Goal(session, *goal)
		if goalErr != nil {
			return goalErr
		}
		if err = store.Add(goalEvent); err != nil {
			return err
		}
	}
	if *goalFile != "" {
		goalEvent, goalErr := adapters.GoalFile(session, *goalFile)
		if goalErr != nil {
			return goalErr
		}
		if err = store.Add(goalEvent); err != nil {
			return err
		}
	}
	if *claimsFile != "" {
		if err := adapters.Claims(session, *claimsFile, store.Add); err != nil {
			return err
		}
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	if *stopWithInput {
		stopOnInputClose(ctx, os.Stdin, stop)
	}
	ctx, stopOnStoreFailure := context.WithCancel(ctx)
	defer stopOnStoreFailure()
	go func(observation context.Context) {
		select {
		case <-store.Done():
			stopOnStoreFailure()
		case <-observation.Done():
		}
	}(ctx)
	if *duration > 0 {
		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(ctx, *duration)
		defer cancel()
	}
	server, listener, err := startServer(*port, store.Snapshot, session, store.Add)
	if err != nil {
		return err
	}
	defer shutdown(server)
	var proxy *collect.Proxy
	proxyURL := ""
	if *proxyPort >= 0 {
		var proxyListener net.Listener
		proxy, proxyListener, err = collect.StartProxy(session, *proxyPort, *proxyUpstream, *interval, store.Add, watcher.ResolveProxyPeer)
		if err != nil {
			return err
		}
		defer proxy.Close()
		proxyURL = "http://" + proxyListener.Addr().String()
		if !*jsonStatus {
			fmt.Printf("可选代理：%s（需由 Agent 显式配置；只接受可核实为选定进程的连接）\n", proxyURL)
		}
	}
	if *jsonStatus {
		if err := writeStatus(os.Stdout, commandStatus{State: "started", URL: "http://" + listener.Addr().String(), Output: output, ProxyURL: proxyURL}); err != nil {
			return err
		}
	} else {
		fmt.Printf("观察已开始：%s\n本地报告：http://%s\n保存位置：%s\nCtrl+C 停止并保存。\n", session, listener.Addr(), output)
	}
	watcher.Emit = store.Add
	logCtx, stopLog := context.WithCancel(ctx)
	defer stopLog()
	var logDone chan error
	if logReader != nil {
		logDone = make(chan error, 1)
		go func() {
			logErr := logReader.Follow(logCtx, *interval, store.Add)
			if logErr != nil {
				logErr = errors.Join(logErr, store.Add(event.New(session, "semantic", event.Process{Name: "agent-log"}, "collector_error", "direct", map[string]any{"source": *agentFormat, "error": logErr.Error(), "coverage": "incomplete"})))
			}
			logDone <- logErr
		}()
	}
	err = watcher.Run(ctx)
	stopLog()
	if logDone != nil {
		err = errors.Join(err, <-logDone)
	}
	if proxy != nil {
		_ = proxy.Close()
	}
	err = errors.Join(err, store.Err())
	status := "stopped"
	if errors.Is(err, report.ErrSessionLimit) || errors.Is(err, collect.ErrFileWatchLimit) {
		status = "limit_reached"
	} else if err != nil {
		status = "failed"
	}
	closeErr := store.Finish(status)
	ended = true
	snapshot := store.Snapshot()
	var analysisErr error
	if *dryRun {
		payloads, preview, previewErr := llm.RequestPayloadBatches(snapshot, *analyzeModel, *redactGoal, *maxAnalyzeEvents)
		if previewErr != nil {
			analysisErr = previewErr
			snapshot.AnalysisError = previewErr.Error()
		} else {
			snapshot.AnalysisPreview = &preview
			analysisErr = llm.WritePreview(os.Stdout, payloads)
			if analysisErr != nil {
				snapshot.AnalysisError = analysisErr.Error()
			}
		}
	} else if *analyzeEndpoint != "" && !*noLLM {
		key := os.Getenv("BMA_API_KEY")
		if key == "" {
			snapshot.AnalysisError = "BMA_API_KEY is required for --analyze-endpoint"
			analysisErr = errors.New(snapshot.AnalysisError)
		} else {
			analysis, meta, analyzeErr := llm.AnalyzeBatched(context.Background(), *analyzeEndpoint, key, snapshot, *analyzeModel, *redactGoal, *maxAnalyzeEvents, filepath.Join(output, "model-requests.jsonl"))
			if meta.JournalPath != "" {
				snapshot.AnalysisRequest = &meta
			}
			if analyzeErr != nil {
				snapshot.AnalysisError = analyzeErr.Error()
				analysisErr = analyzeErr
			} else {
				snapshot.Analysis, snapshot.AnalysisRequest = &analysis, &meta
				if status == "stopped" {
					snapshot.Status = "analyzed"
				}
			}
		}
	}
	if closeErr != nil {
		snapshot.Status = "failed"
	} else if analysisErr != nil && snapshot.Status == "stopped" {
		snapshot.Status = "analysis_failed"
	}
	if e := report.WriteJSON(filepath.Join(output, "report.json"), snapshot); e != nil {
		return e
	}
	if e := report.WriteHTML(filepath.Join(output, "report.html"), snapshot); e != nil {
		return e
	}
	var statusErr error
	if *jsonStatus {
		dashboard := report.DashboardSnapshot(snapshot)
		statusErr = writeStatus(os.Stdout, commandStatus{State: "finished", Output: output, Status: snapshot.Status, Dashboard: &dashboard})
	} else {
		fmt.Printf("已保存：%d 条事件，%d 条规则提示\n", len(snapshot.Events), len(snapshot.Findings))
	}
	return errors.Join(err, closeErr, analysisErr, statusErr)
}

func scanCommand(args []string) error {
	flags := flag.NewFlagSet("scan", flag.ContinueOnError)
	target := flags.String("target", "", "file or directory to inspect")
	eventsPath := flags.String("events", "", "optional unified event JSONL to include in the report")
	jsonOut := flags.String("json-out", "", "write JSON report")
	htmlOut := flags.String("html-out", "", "write HTML report")
	rulesPath := flags.String("rules", "", "YAML rule thresholds; defaults to built-in values")
	var protectedDirs []string
	flags.Func("protected-dir", "user-declared protected directory metadata; repeat for multiple paths", func(value string) error {
		if strings.TrimSpace(value) == "" {
			return fmt.Errorf("protected directory must not be empty")
		}
		protectedDirs = append(protectedDirs, value)
		return nil
	})
	var sensitiveCategories []string
	flags.Func("sensitive-category", "user-declared sensitive data category; repeat for multiple values", func(value string) error {
		if strings.TrimSpace(value) == "" {
			return fmt.Errorf("sensitive category must not be empty")
		}
		sensitiveCategories = append(sensitiveCategories, value)
		return nil
	})
	var allowedUploadTargets []string
	flags.Func("allow-upload-target", "user-authorized upload target; repeat for multiple values", func(value string) error {
		if strings.TrimSpace(value) == "" {
			return fmt.Errorf("allowed upload target must not be empty")
		}
		allowedUploadTargets = append(allowedUploadTargets, value)
		return nil
	})
	var allowedUploadDirs []string
	flags.Func("allow-upload-dir", "user-authorized upload directory; repeat for multiple absolute paths", func(value string) error {
		if strings.TrimSpace(value) == "" {
			return fmt.Errorf("allowed upload directory must not be empty")
		}
		allowedUploadDirs = append(allowedUploadDirs, value)
		return nil
	})
	authorizationState := flags.String("authorization-state", string(rules.AuthorizationUnknown), "recorded outbound authorization: unknown, authorized, or denied")
	if len(args) > 0 && !strings.HasPrefix(args[0], "-") {
		*target, args = args[0], args[1:]
	}
	if err := flags.Parse(args); err != nil {
		return err
	}
	authorization := rules.Authorization{State: rules.AuthorizationState(*authorizationState)}.Normalize()
	if !authorization.Valid() {
		return fmt.Errorf("invalid --authorization-state %q; use unknown, authorized, or denied", *authorizationState)
	}
	policy := (rules.Policy{ProtectedDirectories: protectedDirs, SensitiveCategories: sensitiveCategories,
		AllowedUploadDirectories: allowedUploadDirs, AllowedUploadTargets: allowedUploadTargets}).Normalize()
	if err := resolveProtectedDirectories(&policy); err != nil {
		return err
	}
	if err := policy.ValidateAuthorization(authorization); err != nil {
		return err
	}
	if *target == "" {
		if flags.NArg() == 1 {
			*target = flags.Arg(0)
			args = nil
		} else {
			return fmt.Errorf("scan target is required")
		}
	}
	if flags.NArg() > 0 && args != nil {
		return fmt.Errorf("unexpected scan arguments")
	}
	session := event.SessionID()
	events, findings, err := scan.Scan(*target, session)
	if err != nil {
		return err
	}
	if *eventsPath != "" {
		loaded, loadErr := event.LoadJSONL(*eventsPath)
		if loadErr != nil {
			return loadErr
		}
		if len(events)+len(loaded) > report.MaxSessionEvents {
			return fmt.Errorf("combined scanned and imported evidence exceeds %d events", report.MaxSessionEvents)
		}
		seen := make(map[string]bool, len(events)+len(loaded))
		for _, item := range events {
			seen[item.ID] = true
		}
		for _, item := range loaded {
			if seen[item.ID] {
				return fmt.Errorf("duplicate event ID %q across scanned and imported evidence", item.ID)
			}
			seen[item.ID] = true
		}
		events = append(events, loaded...)
	}
	abs, err := filepath.Abs(*target)
	if err != nil {
		return err
	}
	config := rules.DefaultConfig()
	if *rulesPath != "" {
		config, err = rules.LoadConfig(*rulesPath)
		if err != nil {
			return err
		}
	}
	config.Policy = policy
	config.Authorization = authorization
	r := report.NewWithConfig(session, abs, []string{"static-scan"}, events, config)
	r.Status = "completed"
	r.Findings = append(findings, rules.EvaluateWithConfig(events, config)...)
	if err := report.EncodeJSON(os.Stdout, r); err != nil {
		return err
	}
	if *jsonOut != "" {
		if err := report.WriteJSON(*jsonOut, r); err != nil {
			return err
		}
	}
	if *htmlOut != "" {
		if err := report.WriteHTML(*htmlOut, r); err != nil {
			return err
		}
	}
	return nil
}

func analysisCommand(args []string, reviewMode bool) error {
	command := "analyze"
	if reviewMode {
		command = "reconcile"
	}
	flags := flag.NewFlagSet(command, flag.ContinueOnError)
	reportPath := flags.String("report", "", "report.json to analyze")
	endpoint := flags.String("endpoint", "", "OpenAI-compatible chat completions endpoint")
	model := flags.String("model", "small", "model name")
	maxEvents := flags.Int("max-events-per-call", llm.DefaultMaxEventsPerCall, "maximum events sent in one model request")
	dryRun := flags.Bool("dry-run-llm", false, "print the redacted request without sending it")
	redactGoal := flags.Bool("redact-goal", false, "replace the user goal before sending")
	out := flags.String("out", "", "write analyzed JSON report")
	htmlOut := flags.String("html-out", "", "write analyzed HTML report")
	if len(args) > 0 && !strings.HasPrefix(args[0], "-") {
		*reportPath, args = args[0], args[1:]
	}
	if err := flags.Parse(args); err != nil {
		return err
	}
	if *reportPath == "" {
		if flags.NArg() == 1 {
			*reportPath = flags.Arg(0)
			args = nil
		} else {
			return fmt.Errorf("report path is required")
		}
	}
	if flags.NArg() > 0 && args != nil {
		return fmt.Errorf("unexpected analyze arguments")
	}
	r, err := report.ReadJSON(*reportPath)
	if err != nil {
		return err
	}
	if *dryRun {
		var payloads []llm.Payload
		var preview report.AnalysisRequest
		var payloadErr error
		if reviewMode {
			var payload llm.Payload
			payload, preview, payloadErr = llm.ReviewPayload(r, *model, *redactGoal, *maxEvents)
			payloads = []llm.Payload{payload}
		} else {
			payloads, preview, payloadErr = llm.RequestPayloadBatches(r, *model, *redactGoal, *maxEvents)
		}
		if payloadErr != nil {
			return payloadErr
		}
		if reviewMode {
			if r.Review == nil {
				r.Review = &report.Review{}
			}
			r.Review.Preview = &preview
		} else {
			r.AnalysisPreview = &preview
		}
		if err := writeAnalysisOutputs(r, *out, *htmlOut); err != nil {
			return err
		}
		return llm.WritePreview(os.Stdout, payloads)
	}
	if *endpoint == "" {
		return fmt.Errorf("--endpoint is required unless --dry-run-llm is used")
	}
	key := os.Getenv("BMA_API_KEY")
	if key == "" {
		return fmt.Errorf("BMA_API_KEY is required and is never written to the report")
	}
	inputPath, err := filepath.Abs(*reportPath)
	if err != nil {
		return err
	}
	archiveDir := filepath.Join(filepath.Dir(inputPath), command+"-"+event.SessionID())
	if err := os.Mkdir(archiveDir, 0700); err != nil {
		return err
	}
	if err := report.SecureDirectory(archiveDir); err != nil {
		return err
	}
	requestLog := filepath.Join(archiveDir, "model-requests.jsonl")
	fmt.Fprintf(os.Stderr, "模型请求归档：%s\n", requestLog)
	if reviewMode {
		result, meta, reviewErr := llm.Reconcile(context.Background(), *endpoint, key, r, *model, *redactGoal, *maxEvents, requestLog)
		r.Review = &report.Review{}
		if meta.JournalPath != "" {
			r.Review.Request = &meta
		}
		if reviewErr != nil {
			r.Review.Error, r.Status = reviewErr.Error(), "review_failed"
		} else {
			r.Review.Result, r.Status = &result, "reviewed"
		}
		if err := writeAnalysisOutputs(r, *out, *htmlOut); err != nil {
			return err
		}
		return errors.Join(reviewErr, report.EncodeJSON(os.Stdout, r))
	}
	analysis, meta, analysisErr := llm.AnalyzeBatched(context.Background(), *endpoint, key, r, *model, *redactGoal, *maxEvents, requestLog)
	r.Analysis = nil
	r.AnalysisRequest = nil
	r.AnalysisError = ""
	r.AnalysisPreview = nil
	r.Review = nil
	if meta.JournalPath != "" {
		r.AnalysisRequest = &meta
	}
	if analysisErr != nil {
		r.AnalysisError = analysisErr.Error()
		r.Status = "analysis_failed"
	} else {
		r.Analysis, r.Status = &analysis, "analyzed"
	}
	if err := writeAnalysisOutputs(r, *out, *htmlOut); err != nil {
		return err
	}
	return errors.Join(analysisErr, report.EncodeJSON(os.Stdout, r))
}

func writeAnalysisOutputs(r report.Report, jsonPath, htmlPath string) error {
	if jsonPath != "" {
		if err := report.WriteJSON(jsonPath, r); err != nil {
			return err
		}
	}
	if htmlPath != "" {
		return report.WriteHTML(htmlPath, r)
	}
	return nil
}

func demo(args []string) error {
	flags := flag.NewFlagSet("demo", flag.ContinueOnError)
	output := flags.String("output-dir", "bma-demo", "new directory for generated demo artifacts")
	if err := flags.Parse(args); err != nil {
		return err
	}
	if flags.NArg() != 0 {
		return fmt.Errorf("unexpected demo arguments")
	}
	root, err := filepath.Abs(*output)
	if err != nil {
		return err
	}
	if err := os.Mkdir(root, 0700); err != nil {
		return fmt.Errorf("demo output must be a new directory: %w", err)
	}
	r := demoReport()
	_, preview, err := llm.RequestPayloadBatches(r, "demo-preview", false, 200)
	if err != nil {
		return err
	}
	r.AnalysisPreview = &preview
	if err := report.WriteJSON(filepath.Join(root, "demo-report.json"), r); err != nil {
		return err
	}
	if err := report.WriteHTML(filepath.Join(root, "demo-report.html"), r); err != nil {
		return err
	}
	fmt.Printf("示例演示完成（全部行为为模拟，未读取项目、未上传、未请求模型）：%s\nHTML 报告：%s\n", root, filepath.Join(root, "demo-report.html"))
	return nil
}
func startServer(port int, snapshot func() report.Report, session string, add func(event.Event) error) (*http.Server, net.Listener, error) {
	listener, err := net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", port))
	if err != nil {
		return nil, nil, err
	}
	server := &http.Server{Handler: report.Handler(snapshot, listener.Addr().String(), session, add), ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 15 * time.Second, WriteTimeout: 15 * time.Second, IdleTimeout: 30 * time.Second}
	go func() {
		if err := server.Serve(listener); err != nil && err != http.ErrServerClosed {
			fmt.Fprintln(os.Stderr, "report server:", err)
		}
	}()
	return server, listener, nil
}
func shutdown(server *http.Server) {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	_ = server.Shutdown(ctx)
}
func serve(args []string) error {
	flags := flag.NewFlagSet("serve", flag.ContinueOnError)
	path := flags.String("report", "", "report.json to view")
	port := flags.Int("port", 7788, "local report port")
	jsonStatus := flags.Bool("status-json", false, "emit JSONL lifecycle status for desktop integration")
	stopWithInput := flags.Bool("stop-on-stdin-close", false, "stop when the controlling desktop closes stdin")
	if err := flags.Parse(args); err != nil {
		return err
	}
	if *path == "" {
		return fmt.Errorf("--report is required")
	}
	if flags.NArg() != 0 {
		return fmt.Errorf("unexpected serve arguments")
	}
	r, err := report.ReadJSON(*path)
	if err != nil {
		return err
	}
	server, listener, err := startServer(*port, func() report.Report { return r }, "", nil)
	if err != nil {
		return err
	}
	defer shutdown(server)
	if *jsonStatus {
		if err := writeStatus(os.Stdout, commandStatus{State: "started", URL: "http://" + listener.Addr().String()}); err != nil {
			return err
		}
	} else {
		fmt.Printf("http://%s\n", listener.Addr())
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	if *stopWithInput {
		stopOnInputClose(ctx, os.Stdin, stop)
	}
	<-ctx.Done()
	return nil
}

// Resolve the existing parent before creating anything so an output hidden
// below a symlink into a watched tree is rejected without side effects.
func resolveOutputPath(path string) (string, error) {
	abs, err := filepath.Abs(path)
	if err != nil {
		return "", err
	}
	parent := filepath.Dir(abs)
	suffix := []string{filepath.Base(abs)}
	for {
		_, err := os.Lstat(parent)
		if err == nil {
			resolved, err := filepath.EvalSymlinks(parent)
			if err != nil {
				return "", err
			}
			for i := len(suffix) - 1; i >= 0; i-- {
				resolved = filepath.Join(resolved, suffix[i])
			}
			return resolved, nil
		}
		if !errors.Is(err, os.ErrNotExist) {
			return "", err
		}
		next := filepath.Dir(parent)
		if next == parent {
			return "", err
		}
		suffix = append(suffix, filepath.Base(parent))
		parent = next
	}
}
