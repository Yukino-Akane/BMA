package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/collect"
	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/report"
)

func TestWatchUpstreamRequiresExplicitProxy(t *testing.T) {
	err := run([]string{"watch", "--process", "fixture", "--workspace", t.TempDir(), "--proxy-upstream", "http://127.0.0.1:7897"})
	if err == nil || !strings.Contains(err.Error(), "--proxy-upstream requires --proxy-port") {
		t.Fatalf("ignored upstream configuration: %v", err)
	}
}

func TestScanCLIProducesLinkedReports(t *testing.T) {
	dir := t.TempDir()
	input := filepath.Join(dir, "plugin.json")
	output := filepath.Join(dir, "report.json")
	html := filepath.Join(dir, "report.html")
	if err := os.WriteFile(input, []byte(`{"permissions":["filesystem"],"postinstall":"run.js"}`), 0600); err != nil {
		t.Fatal(err)
	}
	if err := run([]string{"scan", input, "--json-out", output, "--html-out", html}); err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(output)
	if err != nil {
		t.Fatal(err)
	}
	var r report.Report
	if err := json.Unmarshal(data, &r); err != nil {
		t.Fatal(err)
	}
	if r.Status != "completed" || len(r.Findings) != 2 {
		t.Fatalf("unexpected report: %+v", r)
	}
	if info, err := os.Stat(html); err != nil || info.Size() == 0 {
		t.Fatalf("HTML not saved: %v", err)
	}
}

func TestWatchFollowsAgentLogAndSavesFinalAppend(t *testing.T) {
	dir := t.TempDir()
	workspace := filepath.Join(dir, "workspace")
	if err := os.Mkdir(workspace, 0700); err != nil {
		t.Fatal(err)
	}
	log := filepath.Join(dir, "session.jsonl")
	initial := `{"timestamp":"2026-09-19T10:00:00Z","type":"response_item","payload":{"type":"message","role":"user","content":[{"type":"input_text","text":"edit README"}]}}` + "\n"
	if err := os.WriteFile(log, []byte(initial), 0600); err != nil {
		t.Fatal(err)
	}
	out := filepath.Join(dir, "report")
	done := make(chan error, 1)
	go func() {
		done <- run([]string{"watch", "--process", "bma-test-nonexistent-process", "--workspace", workspace, "--agent-log", log, "--agent-format", "codex", "--duration", "2s", "--interval", "20ms", "--port", "0", "--out", out})
	}()
	// Wait until the first log record reaches the durable event stream, then
	// append a second record while the same observation session is running.
	deadline := time.Now().Add(5 * time.Second)
	observed := false
	for time.Now().Before(deadline) {
		data, _ := os.ReadFile(filepath.Join(out, "events.jsonl"))
		if strings.Contains(string(data), "edit README") {
			observed = true
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if !observed {
		<-done
		t.Fatal("initial log never reached report")
	}
	f, err := os.OpenFile(log, os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		<-done
		t.Fatal(err)
	}
	_, writeErr := f.WriteString(`{"timestamp":"2026-09-19T10:00:01Z","type":"response_item","payload":{"type":"custom_tool_call","name":"apply_patch","input":"private-command","call_id":"call-1"}}`)
	closeErr := f.Close()
	if err := <-done; err != nil {
		t.Fatal(err)
	}
	if writeErr != nil || closeErr != nil {
		t.Fatal("cannot append fixture")
	}
	data, err := os.ReadFile(filepath.Join(out, "report.json"))
	if err != nil {
		t.Fatal(err)
	}
	var r report.Report
	if err := json.Unmarshal(data, &r); err != nil {
		t.Fatal(err)
	}
	goals, actions := 0, 0
	for _, e := range r.Events {
		if e.Kind == "goal" {
			goals++
		}
		if e.Kind == "claimed_action" {
			actions++
		}
	}
	if r.Status != "stopped" || goals != 1 || actions != 1 {
		t.Fatalf("status=%s goals=%d actions=%d", r.Status, goals, actions)
	}
}

func TestWatchLogFailurePersistsCoverageError(t *testing.T) {
	dir := t.TempDir()
	workspace := filepath.Join(dir, "workspace")
	if err := os.Mkdir(workspace, 0700); err != nil {
		t.Fatal(err)
	}
	log := filepath.Join(dir, "broken.jsonl")
	if err := os.WriteFile(log, []byte("{private-secret\n"), 0600); err != nil {
		t.Fatal(err)
	}
	out := filepath.Join(dir, "report")
	err := run([]string{"watch", "--process", "bma-test-nonexistent-process", "--workspace", workspace, "--agent-log", log, "--agent-format", "claude", "--duration", "50ms", "--port", "0", "--out", out})
	if err == nil || strings.Contains(err.Error(), "private-secret") {
		t.Fatal("missing or unsafe failure")
	}
	data, readErr := os.ReadFile(filepath.Join(out, "report.json"))
	if readErr != nil {
		t.Fatal(readErr)
	}
	var r report.Report
	if err := json.Unmarshal(data, &r); err != nil {
		t.Fatal(err)
	}
	if r.Status != "failed" || strings.Contains(string(data), "private-secret") {
		t.Fatal("invalid failure report")
	}
	found := false
	for _, e := range r.Events {
		if e.Kind == "collector_error" && e.Detail["source"] == "claude" && e.Detail["coverage"] == "incomplete" {
			found = true
		}
	}
	if !found {
		t.Fatal("log coverage failure missing")
	}
}

func TestCLIRejectsExtraArguments(t *testing.T) {
	for _, args := range [][]string{
		{"watch", "--workspace", t.TempDir()},
		{"scan", "--target", t.TempDir(), "stray"},
		{"analyze", "--report", "unused", "stray"},
		{"serve", "--report", "unused", "stray"},
	} {
		if err := run(args); err == nil {
			t.Fatalf("accepted %#v", args)
		}
	}
}

func TestOutputScopeAcrossVolumes(t *testing.T) {
	dir := t.TempDir()
	if !collect.ContainsPath(dir, filepath.Join(dir, "a")) || collect.ContainsPath(dir, dir+"-outside") {
		t.Fatal("invalid workspace boundary")
	}
	if runtime.GOOS == "windows" && collect.ContainsPath(`D:\workspace`, `C:\cache\session`) {
		t.Fatal("different drive cannot be inside workspace")
	}
}

func TestWatchAdditionalRootsPersistAndRejectNestedOutput(t *testing.T) {
	base := t.TempDir()
	workspace, data := filepath.Join(base, "workspace"), filepath.Join(base, "agent-data")
	for _, path := range []string{workspace, data} {
		if err := os.Mkdir(path, 0700); err != nil {
			t.Fatal(err)
		}
	}
	output := filepath.Join(base, "report")
	if err := run([]string{"watch", "--process", "bma-test-no-process", "--workspace", workspace, "--watch-dir", data, "--watch-dir", data, "--port", "0", "--duration", "50ms", "--out", output}); err != nil {
		t.Fatal(err)
	}
	bytes, err := os.ReadFile(filepath.Join(output, "report.json"))
	if err != nil {
		t.Fatal(err)
	}
	var r report.Report
	if err := json.Unmarshal(bytes, &r); err != nil {
		t.Fatal(err)
	}
	if len(r.WatchRoots) != 2 {
		t.Fatalf("roots=%v", r.WatchRoots)
	}
	htmlReport, err := os.ReadFile(filepath.Join(output, "report.html"))
	if err != nil {
		t.Fatal(err)
	}
	for _, root := range r.WatchRoots {
		if !strings.Contains(string(htmlReport), root) {
			t.Fatal("HTML report omitted a watched root")
		}
	}
	nested := filepath.Join(data, "must-not-create", "report")
	if err := run([]string{"watch", "--process", "bma-test-no-process", "--workspace", workspace, "--watch-dir", data, "--out", nested}); err == nil {
		t.Fatal("output inside additional root accepted")
	}
	if _, err := os.Stat(filepath.Dir(nested)); !os.IsNotExist(err) {
		t.Fatal("rejected output still modified watched data")
	}
	alias := filepath.Join(base, "alias")
	if err := os.Symlink(data, alias); err != nil {
		t.Skipf("symlink unavailable: %v", err)
	}
	if err := run([]string{"watch", "--process", "bma-test-no-process", "--workspace", workspace, "--watch-dir", data, "--out", filepath.Join(alias, "also-no", "report")}); err == nil {
		t.Fatal("output alias bypassed root check")
	}
	if _, err := os.Stat(filepath.Join(data, "also-no")); !os.IsNotExist(err) {
		t.Fatal("rejected aliased output created directories")
	}
}

func TestDemoCreatesOfflineArtifacts(t *testing.T) {
	dir := filepath.Join(t.TempDir(), "demo")
	if err := run([]string{"demo", "--output-dir", dir}); err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"demo-report.json", "demo-report.html"} {
		if info, err := os.Stat(filepath.Join(dir, name)); err != nil || info.Size() == 0 {
			t.Fatalf("missing %s: %v", name, err)
		}
	}
	data, err := os.ReadFile(filepath.Join(dir, "demo-report.json"))
	if err != nil {
		t.Fatal(err)
	}
	var r report.Report
	if err := json.Unmarshal(data, &r); err != nil {
		t.Fatal(err)
	}
	if !r.Demonstration {
		t.Fatal("simulated network report was not labeled as a demonstration")
	}
	entries, err := os.ReadDir(dir)
	if err != nil || len(entries) != 2 {
		t.Fatal("demo must only write its two reports, not create source files or archives", err)
	}
	byID := map[string]event.Event{}
	layers := map[string]bool{}
	for i, e := range r.Events {
		if e.Detail["synthetic"] != true || (i > 0 && e.TS.Before(r.Events[i-1].TS)) {
			t.Fatal("demo evidence is unlabeled or out of order")
		}
		if e.Layer == "file" && (e.Attribution != "temporal" || e.Process.PID != 0) {
			t.Fatal("demo must not attribute file activity directly to a process")
		}
		byID[e.ID] = e
		layers[e.Layer] = true
	}
	if !layers["semantic"] || !layers["file"] || !layers["net"] {
		t.Fatal("demo does not cover all three evidence layers")
	}
	foundDeletion := false
	for _, finding := range r.Findings {
		for _, id := range finding.EvidenceIDs {
			if _, ok := byID[id]; !ok {
				t.Fatal("demo finding cannot be traced to original evidence")
			}
		}
		if finding.Rule == "file/create-delete-window" && len(finding.EvidenceIDs) == 2 {
			foundDeletion = byID[finding.EvidenceIDs[0]].Kind == "file_create" && byID[finding.EvidenceIDs[1]].Kind == "file_delete"
		}
	}
	if !foundDeletion {
		t.Fatal("demo is missing the linked create/delete story")
	}
	if r.Analysis != nil || r.AnalysisRequest != nil || r.AnalysisPreview == nil || len(r.AnalysisPreview.RequestBodies) == 0 {
		t.Fatal("demo must provide a preview, not pretend that a model was called")
	}
	for _, body := range r.AnalysisPreview.RequestBodies {
		if !json.Valid([]byte(body)) || strings.Contains(body, "demo-workspace") || strings.Contains(body, "workspace-snapshot.zip") {
			t.Fatal("demo preview is invalid or contains original paths")
		}
	}
}

func TestAnalyzeFailureStillSavesOutboundDisclosure(t *testing.T) {
	dir := t.TempDir()
	input := filepath.Join(dir, "report.json")
	output := filepath.Join(dir, "failed.json")
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(500) }))
	defer server.Close()
	fixture := withTestUploadScope(report.New("s", "w", nil, nil), dir, server.URL)
	if err := report.WriteJSON(input, fixture); err != nil {
		t.Fatal(err)
	}
	t.Setenv("BMA_API_KEY", "fixture-key")
	err := run([]string{"analyze", input, "--endpoint", server.URL, "--out", output})
	if err == nil {
		t.Fatal("failed analysis returned success")
	}
	data, err := os.ReadFile(output)
	if err != nil {
		t.Fatal(err)
	}
	var r report.Report
	if err := json.Unmarshal(data, &r); err != nil {
		t.Fatal(err)
	}
	if r.Analysis != nil || r.AnalysisError == "" || r.AnalysisRequest == nil || r.AnalysisRequest.AttemptedBatches != 1 || r.AnalysisRequest.Endpoint != server.URL {
		t.Fatalf("lost request disclosure: %+v", r)
	}
	if filepath.Dir(filepath.Dir(r.AnalysisRequest.JournalPath)) != dir {
		t.Fatal("standalone archive was not saved beside its input report")
	}
	archive, err := report.ReadRequestJournal(r.AnalysisRequest.JournalPath, r.SessionID)
	if err != nil || len(archive.Records) != 2 || archive.Records[1].Kind != "failed" {
		t.Fatalf("durable failure missing: %v", err)
	}
	recoveredDir := filepath.Join(dir, "recovered")
	if err := run([]string{"recover", "--request-log", r.AnalysisRequest.JournalPath, "--out", recoveredDir}); err != nil {
		t.Fatal(err)
	}
	recoveredJSON, err := os.ReadFile(filepath.Join(recoveredDir, "report.json"))
	if err != nil {
		t.Fatal(err)
	}
	var recovered report.Report
	if err := json.Unmarshal(recoveredJSON, &recovered); err != nil || recovered.RecoveredRequests == nil || recovered.Analysis != nil || recovered.AnalysisRequest != nil || len(recovered.Events) != 0 {
		t.Fatalf("standalone recovery fabricated observations or lost requests: %v", err)
	}
}

func TestWatchModelModesAndSavedDisclosure(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		w.WriteHeader(http.StatusInternalServerError)
	}))
	defer server.Close()
	for _, tc := range []struct {
		name               string
		flags              []string
		key                string
		wantError, preview bool
		attempts           int32
	}{
		{"offline", []string{"--no-llm"}, "fixture-key", false, false, 0},
		{"preview", []string{"--dry-run-llm", "--redact-goal"}, "", false, true, 0},
		{"failed-request", []string{"--redact-goal"}, "fixture-key", true, false, 1},
		{"missing-key", nil, "", true, false, 0},
	} {
		t.Run(tc.name, func(t *testing.T) {
			t.Setenv("BMA_API_KEY", tc.key)
			base := t.TempDir()
			workspace, output := filepath.Join(base, "workspace"), filepath.Join(base, "output")
			if err := os.Mkdir(workspace, 0700); err != nil {
				t.Fatal(err)
			}
			before := calls.Load()
			args := []string{"watch", "--process", "bma-no-such-process", "--workspace", workspace, "--allow-upload-dir", workspace, "--allow-upload-target", testUploadTarget(server.URL), "--port", "0", "--duration", "50ms", "--out", output, "--goal", "private-task-description", "--analyze-endpoint", server.URL}
			err := run(append(args, tc.flags...))
			if (err != nil) != tc.wantError || calls.Load()-before != tc.attempts {
				t.Fatalf("error=%v model calls=%d", err, calls.Load()-before)
			}
			data, err := os.ReadFile(filepath.Join(output, "report.json"))
			if err != nil {
				t.Fatal(err)
			}
			var r report.Report
			if err := json.Unmarshal(data, &r); err != nil {
				t.Fatal(err)
			}
			if (r.AnalysisPreview != nil) != tc.preview || (r.AnalysisError != "") != tc.wantError || (r.AnalysisRequest != nil) != (tc.attempts > 0) {
				t.Fatal("report lost model mode or failure disclosure")
			}
			if tc.wantError && r.Status != "analysis_failed" {
				t.Fatal("analysis failure reported as a successful session")
			}
			for _, meta := range []*report.AnalysisRequest{r.AnalysisRequest, r.AnalysisPreview} {
				if meta == nil {
					continue
				}
				if len(meta.RequestBodies) == 0 {
					t.Fatal("no request bodies archived")
				}
				for _, body := range meta.RequestBodies {
					if strings.Contains(body, "private-task-description") || strings.Contains(body, "fixture-key") || !strings.Contains(body, "[redacted-goal]") {
						t.Fatal("goal or credential redaction was lost")
					}
				}
			}
			if tc.preview {
				html, err := os.ReadFile(filepath.Join(output, "report.html"))
				if err != nil || !strings.Contains(string(html), "本次未发送") {
					t.Fatal("preview not distinguished from sending")
				}
				if r.AnalysisPreview.AttemptedBatches != 0 {
					t.Fatal("preview counted as an attempt")
				}
			}
		})
	}
}

func TestRootCodeArgumentsRejectInvalidSelection(t *testing.T) {
	for _, extra := range [][]string{
		{"--root-code", "42@app@app@@0123"},
		{"--root-process", "42@100", "--root-code", "bad"},
		{"--root-process", "42@100", "--root-code", "43@app@app@@aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"},
		{"--root-process", "42@100", "--root-code", "42@app@other@@aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"},
		{"--root-process", "42@100", "--root-code", "42@app@app@@0123"},
	} {
		args := append([]string{"--process", "42"}, extra...)
		if err := watch(args); err == nil {
			t.Fatalf("accepted invalid root code arguments: %v", extra)
		}
	}
}
