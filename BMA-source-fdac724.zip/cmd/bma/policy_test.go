package main

import (
	"encoding/json"
	"net"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"behavior-monitoring-audit/internal/report"
	"behavior-monitoring-audit/internal/rules"
)

func testUploadTarget(endpoint string) string {
	parsed, err := url.Parse(endpoint)
	if err != nil || parsed.Hostname() == "" {
		return ""
	}
	port := parsed.Port()
	if port == "" {
		if parsed.Scheme == "https" {
			port = "443"
		} else {
			port = "80"
		}
	}
	return net.JoinHostPort(parsed.Hostname(), port)
}

func withTestUploadScope(r report.Report, root, endpoint string) report.Report {
	policy := rules.Policy{AllowedUploadDirectories: []string{root}, AllowedUploadTargets: []string{testUploadTarget(endpoint)}}
	r.Policy = policy
	r.RuleConfig.Policy = policy
	r.Authorization = rules.Authorization{State: rules.AuthorizationUnknown}
	r.RuleConfig.Authorization = r.Authorization
	return r
}

func TestWatchPersistsProtectionPolicy(t *testing.T) {
	base := t.TempDir()
	workspace := filepath.Join(base, "workspace")
	output := filepath.Join(base, "report")
	if err := os.Mkdir(workspace, 0700); err != nil {
		t.Fatal(err)
	}
	if err := run([]string{"watch", "--process", "bma-policy-no-process", "--workspace", workspace,
		"--protected-dir", filepath.Join(workspace, "secrets"), "--sensitive-category", "synthetic-config",
		"--allow-upload-target", "receiver.test:8443", "--allow-upload-dir", workspace, "--authorization-state", "authorized",
		"--port", "0", "--duration", "50ms", "--out", output}); err != nil {
		t.Fatal(err)
	}
	r, err := report.ReadJSON(filepath.Join(output, "report.json"))
	if err != nil {
		t.Fatal(err)
	}
	if r.Authorization.State != rules.AuthorizationAuthorized || len(r.Policy.ProtectedDirectories) != 1 || r.Policy.SensitiveCategories[0] != "synthetic-config" || r.Policy.AllowedUploadDirectories[0] != workspace || r.Policy.AllowedUploadTargets[0] != "receiver.test:8443" {
		t.Fatalf("policy metadata not persisted: %#v %#v", r.Policy, r.Authorization)
	}
	sessionBytes, err := os.ReadFile(filepath.Join(output, "session.json"))
	if err != nil {
		t.Fatal(err)
	}
	var session struct {
		Report report.Report `json:"report"`
	}
	if err := json.Unmarshal(sessionBytes, &session); err != nil {
		t.Fatal(err)
	}
	if session.Report.Authorization.State != rules.AuthorizationAuthorized || len(session.Report.Policy.AllowedUploadDirectories) != 1 || session.Report.Policy.AllowedUploadDirectories[0] != workspace {
		t.Fatalf("session metadata lost allowed scope: %#v", session.Report.Policy)
	}
	html, err := os.ReadFile(filepath.Join(output, "report.html"))
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(html), "允许上传目录") || !strings.Contains(string(html), workspace) {
		t.Fatal("HTML omitted allowed upload directory")
	}
}

func TestWatchResolvesRelativeProtectedDirectory(t *testing.T) {
	base := t.TempDir()
	workspace := filepath.Join(base, "workspace")
	protected := filepath.Join(workspace, "secrets")
	if err := os.MkdirAll(protected, 0700); err != nil {
		t.Fatal(err)
	}
	cwd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	relative, err := filepath.Rel(cwd, protected)
	if err != nil {
		t.Fatal(err)
	}
	output := filepath.Join(base, "report")
	if err := run([]string{"watch", "--process", "bma-policy-no-process", "--workspace", workspace,
		"--protected-dir", relative, "--port", "0", "--duration", "50ms", "--out", output}); err != nil {
		t.Fatal(err)
	}
	r, err := report.ReadJSON(filepath.Join(output, "report.json"))
	if err != nil {
		t.Fatal(err)
	}
	want, err := filepath.Abs(relative)
	if err != nil {
		t.Fatal(err)
	}
	if len(r.Policy.ProtectedDirectories) != 1 || r.Policy.ProtectedDirectories[0] != want {
		t.Fatalf("relative protected directory was not resolved: got=%v want=%q", r.Policy.ProtectedDirectories, want)
	}
}

func TestCLIRejectsAuthorizedWithoutUploadScope(t *testing.T) {
	err := run([]string{"scan", "--target", t.TempDir(), "--authorization-state", "authorized", "--allow-upload-target", "receiver.test:443"})
	if err == nil {
		t.Fatal("authorized state without directory accepted")
	}
}

func TestCLIRejectsUnknownAuthorizationState(t *testing.T) {
	err := run([]string{"scan", "--target", t.TempDir(), "--authorization-state", "maybe"})
	if err == nil {
		t.Fatal("invalid authorization state accepted")
	}
}
