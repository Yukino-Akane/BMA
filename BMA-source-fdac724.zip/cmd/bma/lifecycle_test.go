package main

import (
	"context"
	"encoding/json"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/report"
)

func TestDesktopChild(t *testing.T) {
	if os.Getenv("BMA_DESKTOP_TEST_CHILD") != "1" {
		return
	}
	for i, arg := range os.Args {
		if arg == "--" {
			if err := run(os.Args[i+1:]); err != nil {
				os.Exit(1)
			}
			os.Exit(0)
		}
	}
	os.Exit(2)
}

func TestDesktopClosingControlPipeSavesAndExits(t *testing.T) {
	root := t.TempDir()
	out := filepath.Join(root, "audit")
	wantOutput, err := resolveOutputPath(out)
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestDesktopChild$", "--", "watch",
		"--process", "bma-desktop-test-no-process", "--out", out,
		"--port", "0", "--no-llm", "--status-json", "--stop-on-stdin-close")
	cmd.Env = append(os.Environ(), "BMA_DESKTOP_TEST_CHILD=1")
	input, err := cmd.StdinPipe()
	if err != nil {
		t.Fatal(err)
	}
	output, err := cmd.StdoutPipe()
	if err != nil {
		t.Fatal(err)
	}
	if err = cmd.Start(); err != nil {
		t.Fatal(err)
	}
	defer func() { _ = input.Close(); _ = cmd.Wait() }()
	decoder := json.NewDecoder(output)
	var started commandStatus
	if err = decoder.Decode(&started); err != nil {
		t.Fatal(err)
	}
	if started.State != "started" || started.Output != wantOutput || !strings.HasPrefix(started.URL, "http://127.0.0.1:") {
		t.Fatalf("bad desktop startup: %+v", started)
	}
	// The pipe disappearing models both a normal quit and desktop process death.
	if err = input.Close(); err != nil {
		t.Fatal(err)
	}
	var finished commandStatus
	if err = decoder.Decode(&finished); err != nil {
		t.Fatal(err)
	}
	if finished.State != "finished" || finished.Status != "stopped" {
		t.Fatalf("bad completion: %+v", finished)
	}
	if finished.Dashboard == nil || finished.Dashboard.Status != "stopped" || finished.Dashboard.FileWatching {
		t.Fatalf("final dashboard missing or unexpected file scope: %+v", finished.Dashboard)
	}
	if err = decoder.Decode(&finished); err != io.EOF {
		t.Fatalf("unexpected stdout: %v", err)
	}
	if err = cmd.Wait(); err != nil {
		t.Fatal(err)
	}
	saved, err := report.ReadJSON(filepath.Join(out, "report.json"))
	if err != nil || saved.Status != "stopped" {
		t.Fatalf("report not saved: %v", err)
	}
	if saved.Workspace != "" || len(saved.WatchRoots) != 0 {
		t.Fatal("process-only observation selected an implicit directory")
	}
}
