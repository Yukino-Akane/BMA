package main

import (
	"encoding/json"
	"io"

	"behavior-monitoring-audit/internal/report"
)

// commandStatus is the line-delimited control channel for the desktop launcher.
// Only lifecycle fields and a bounded final summary travel on this channel.
// Full evidence stays in the session journal and report.
type commandStatus struct {
	State     string            `json:"state"`
	URL       string            `json:"url,omitempty"`
	Output    string            `json:"output,omitempty"`
	ProxyURL  string            `json:"proxy_url,omitempty"`
	Status    string            `json:"status,omitempty"`
	Dashboard *report.Dashboard `json:"dashboard,omitempty"`
}

func writeStatus(w io.Writer, status commandStatus) error {
	return json.NewEncoder(w).Encode(status)
}
