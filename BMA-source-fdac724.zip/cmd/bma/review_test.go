package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"behavior-monitoring-audit/internal/event"
	"behavior-monitoring-audit/internal/llm"
	"behavior-monitoring-audit/internal/report"
)

func TestAnalyzeThenReviewCLIWithExactPreviewAndPreservedOriginals(t *testing.T) {
	dir := t.TempDir()
	goal := event.New("s", "semantic", event.Process{}, "goal", "direct", map[string]any{"text": "synthetic task"})
	file := event.New("s", "file", event.Process{}, "file_create", "temporal", map[string]any{"path": filepath.Join(dir, "archive.zip")})
	claim := event.New("s", "semantic", event.Process{}, "claimed_action", "direct", map[string]any{"tool": "Upload"})
	netEvent := event.New("s", "net", event.Process{}, "egress", "direct", map[string]any{"source": "proxy", "metric": "network_bytes", "bytes_out": 50, "bytes_in": 1})
	other := event.New("s", "net", event.Process{}, "connection_observed", "direct", nil)
	r := report.New("s", dir, nil, []event.Event{goal, file, claim, netEvent, other})
	input := filepath.Join(dir, "input.json")
	calls := 0
	invalidReview := false
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		calls++
		var p llm.Payload
		var body struct {
			Events []event.Event     `json:"goal_and_events"`
			Prior  []json.RawMessage `json:"prior_findings"`
		}
		if json.NewDecoder(req.Body).Decode(&p) != nil || json.Unmarshal([]byte(p.Messages[1].Content), &body) != nil {
			t.Error("invalid request")
			w.WriteHeader(500)
			return
		}
		response := map[string]any{"verdict": "clean", "findings": []any{}, "unexplained_egress_ids": []string{}}
		if len(body.Prior) > 0 {
			response = map[string]any{"verdict": "suspicious", "assessments": []any{map[string]any{"finding_ids": []int{1, 2}, "relationship": "contradictory", "status": "revised", "claim": "Synthetic joint assessment", "confidence": .7, "evidence_ids": []string{file.ID, netEvent.ID, claim.ID}}}, "unexplained_egress_ids": []string{netEvent.ID}}
			if invalidReview {
				response["assessments"] = []any{}
			}
		} else {
			for _, e := range body.Events {
				if e.ID == file.ID || e.ID == netEvent.ID {
					response["verdict"] = "suspicious"
					response["findings"] = []any{map[string]any{"claim": "Synthetic interpretation of " + e.ID, "confidence": .7, "evidence_ids": []string{e.ID}}}
					break
				}
			}
		}
		encoded, _ := json.Marshal(response)
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]string{"content": string(encoded)}}}})
	}))
	defer server.Close()
	r = withTestUploadScope(r, dir, server.URL)
	if err := report.WriteJSON(input, r); err != nil {
		t.Fatal(err)
	}
	t.Setenv("BMA_API_KEY", "local-fixture-key")
	analyzed := filepath.Join(dir, "analyzed.json")
	if err := run([]string{"analyze", input, "--endpoint", server.URL, "--max-events-per-call", "3", "--out", analyzed}); err != nil {
		t.Fatal(err)
	}
	originalBytes, err := os.ReadFile(analyzed)
	if err != nil {
		t.Fatal(err)
	}
	original, err := report.ReadJSON(analyzed)
	if err != nil || len(original.Analysis.Findings) != 2 {
		t.Fatal("first pass failed", err)
	}
	firstCalls := calls
	previewPath := filepath.Join(dir, "preview.json")
	t.Setenv("BMA_API_KEY", "")
	if err := run([]string{"reconcile", analyzed, "--dry-run-llm", "--max-events-per-call", "5", "--out", previewPath}); err != nil {
		t.Fatal(err)
	}
	preview, err := report.ReadJSON(previewPath)
	if err != nil || calls != firstCalls || preview.Review == nil || preview.Review.Preview == nil || preview.Review.Request != nil {
		t.Fatal("review dry-run sent a request", err)
	}
	t.Setenv("BMA_API_KEY", "local-fixture-key")
	for _, failed := range []bool{false, true} {
		invalidReview = failed
		out := filepath.Join(dir, "reviewed.json")
		html := filepath.Join(dir, "reviewed.html")
		err := run([]string{"reconcile", analyzed, "--endpoint", server.URL, "--max-events-per-call", "5", "--out", out, "--html-out", html})
		if (err != nil) != failed {
			t.Fatal("wrong review command outcome", err)
		}
		got, readErr := report.ReadJSON(out)
		if readErr != nil {
			t.Fatal(readErr)
		}
		if !reflect.DeepEqual(got.Analysis, original.Analysis) || !reflect.DeepEqual(got.AnalysisRequest, original.AnalysisRequest) {
			t.Fatal("review destroyed first pass evidence")
		}
		if got.Review.Request.JournalPath == original.AnalysisRequest.JournalPath || got.Review.Request.RequestBodies[0] != preview.Review.Preview.RequestBodies[0] {
			t.Fatal("request provenance or preview changed")
		}
		page, _ := os.ReadFile(html)
		if !strings.Contains(string(page), "跨批复核") || !strings.Contains(string(page), "初次分批模型对账") {
			t.Fatal("report omitted either analysis stage")
		}
		if failed {
			if got.Status != "review_failed" || got.Review.Error == "" || got.Review.Result != nil || got.Review.Request.AttemptedBatches != 1 || got.Review.Request.CompletedBatches != 0 {
				t.Fatal("failed review hidden")
			}
		} else if got.Status != "reviewed" || len(got.Review.Result.Assessments) != 1 || got.Review.Result.UnexplainedTraffic[0].BytesOut != 50 {
			t.Fatal("review result missing")
		}
		beforePreviewCalls := calls
		if err := run([]string{"reconcile", out, "--dry-run-llm", "--out", previewPath}); err != nil {
			t.Fatal(err)
		}
		withPreview, err := report.ReadJSON(previewPath)
		if err != nil || withPreview.Review == nil || withPreview.Review.Preview == nil {
			t.Fatal("repeat preview missing", err)
		}
		if calls != beforePreviewCalls || withPreview.Status != got.Status || !reflect.DeepEqual(withPreview.Review.Result, got.Review.Result) || !reflect.DeepEqual(withPreview.Review.Request, got.Review.Request) || withPreview.Review.Error != got.Review.Error {
			t.Fatal("preview destroyed prior review or sent a request")
		}
	}
	after, _ := os.ReadFile(analyzed)
	if string(after) != string(originalBytes) {
		t.Fatal("input report changed")
	}
}
