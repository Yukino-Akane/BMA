package main

import (
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"behavior-monitoring-audit/internal/collect"
	"behavior-monitoring-audit/internal/report"
)

func recoverCommand(args []string) error {
	flags := flag.NewFlagSet("recover", flag.ContinueOnError)
	sessionDir := flags.String("session", "", "session directory containing session.json and events.jsonl")
	requestLog := flags.String("request-log", "", "standalone model-requests.jsonl to recover instead of a session")
	out := flags.String("out", "", "required new directory for the recovered reports")
	if len(args) > 0 && !strings.HasPrefix(args[0], "-") {
		*sessionDir, args = args[0], args[1:]
	}
	if err := flags.Parse(args); err != nil {
		return err
	}
	if flags.NArg() != 0 || (*sessionDir == "") == (*requestLog == "") || *out == "" {
		return fmt.Errorf("recover requires either a session directory or --request-log FILE, and --out NEW_DIRECTORY")
	}
	input := *sessionDir
	if *requestLog != "" {
		input = *requestLog
	}
	source, err := filepath.Abs(input)
	if err != nil {
		return err
	}
	source, err = filepath.EvalSymlinks(source)
	if err != nil {
		return err
	}
	output, err := resolveOutputPath(*out)
	if err != nil {
		return err
	}
	sourceDir := source
	if *requestLog != "" {
		sourceDir = filepath.Dir(source)
	}
	if collect.ContainsPath(sourceDir, output) {
		return fmt.Errorf("recovery output must be outside the source session directory")
	}
	var r report.Report
	if *requestLog != "" {
		r, err = report.RecoverRequests(source)
	} else {
		r, err = report.Recover(source)
	}
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(output), 0700); err != nil {
		return err
	}
	if err := os.Mkdir(output, 0700); err != nil {
		return err
	}
	if err := report.SecureDirectory(output); err != nil {
		return err
	}
	if err := writeAnalysisOutputs(r, filepath.Join(output, "report.json"), filepath.Join(output, "report.html")); err != nil {
		return err
	}
	fmt.Printf("恢复报告已保存，原始日志未改动。请查看报告中的完整性说明。\n报告：%s\n", filepath.Join(output, "report.html"))
	return nil
}
