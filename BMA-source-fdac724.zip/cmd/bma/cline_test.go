package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/report"
)

func TestWatchClineSDKSnapshot(t *testing.T) {
	dir := t.TempDir()
	workspace := filepath.Join(dir, "workspace")
	if err := os.Mkdir(workspace, 0700); err != nil {
		t.Fatal(err)
	}
	log := filepath.Join(dir, "task.messages.json")
	initial := `{"version":1,"sessionId":"task","agent":"lead","messages":[{"role":"user","ts":1789812000000,"content":"Only edit README"}]}`
	if err := os.WriteFile(log, []byte(initial), 0600); err != nil {
		t.Fatal(err)
	}
	out := filepath.Join(dir, "report")
	done := make(chan error, 1)
	go func() {
		done <- run([]string{"watch", "--process", "bma-test-nonexistent-process", "--workspace", workspace, "--agent-log", log, "--agent-format", "cline", "--duration", "2s", "--interval", "20ms", "--port", "0", "--no-llm", "--out", out})
	}()
	joined := false
	defer func() {
		if !joined {
			<-done
		}
	}()
	observed := false
	for deadline := time.Now().Add(5 * time.Second); time.Now().Before(deadline); {
		data, _ := os.ReadFile(filepath.Join(out, "events.jsonl"))
		if strings.Contains(string(data), "Only edit README") {
			observed = true
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if !observed {
		t.Fatal("initial Cline message never reached the journal")
	}
	updated := strings.TrimSuffix(initial, "]}") + `,{"role":"assistant","ts":1789812000001,"content":[{"type":"tool_use","id":"call1","name":"read_files","input":{"path":"private-input"}}]},{"role":"user","content":[{"type":"tool_result","tool_use_id":"call1","content":"private-output"}]}]}`
	if err := os.WriteFile(log, []byte(updated), 0600); err != nil {
		t.Fatal(err)
	}
	err := <-done
	joined = true
	if err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(filepath.Join(out, "report.json"))
	if err != nil {
		t.Fatal(err)
	}
	var r report.Report
	if err := json.Unmarshal(data, &r); err != nil {
		t.Fatal(err)
	}
	goals, requests := 0, 0
	for _, e := range r.Events {
		if e.Detail["source"] != "cline" {
			continue
		}
		if e.Kind == "goal" {
			goals++
		}
		if e.Kind == "claimed_action" {
			requests++
			if e.Detail["stage"] != "tool_request" || e.Detail["agent_role"] != "lead" || e.Detail["log_record"] != float64(2) || e.TS.UnixMilli() != 1789812000001 {
				t.Fatal("lost Cline source context")
			}
		}
	}
	if r.Status != "stopped" || goals != 1 || requests != 1 || strings.Contains(string(data), "private-") {
		t.Fatalf("invalid Cline report: status=%s goals=%d requests=%d", r.Status, goals, requests)
	}
	html, err := os.ReadFile(filepath.Join(out, "report.html"))
	if err != nil || !strings.Contains(string(html), "调用请求不证明操作已经执行") {
		t.Fatalf("request semantics missing from HTML: %v", err)
	}
}
