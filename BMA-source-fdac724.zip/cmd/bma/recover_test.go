package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"behavior-monitoring-audit/internal/report"
)

func TestStoreLimitWatchHelper(t *testing.T) {
	dir := os.Getenv("BMA_TEST_LIMIT_DIR")
	if dir == "" {
		return
	}
	err := run([]string{"watch", "--process", "bma-no-such-process", "--workspace", filepath.Join(dir, "workspace"), "--out", filepath.Join(dir, "session"), "--agent-log", filepath.Join(dir, "agent.jsonl"), "--port", "0", "--no-llm"})
	if !errors.Is(err, report.ErrSessionLimit) {
		t.Fatalf("expected collection limit, got %v", err)
	}
}

func TestStorageLimitStopsLiveWatchWithoutDuration(t *testing.T) {
	dir := t.TempDir()
	if err := os.Mkdir(filepath.Join(dir, "workspace"), 0700); err != nil {
		t.Fatal(err)
	}
	// This source record fits the adapter limit, but HTML-sensitive characters
	// expand during journal encoding and exceed the stored-record limit.
	fixture := "{\"role\":\"user\",\"content\":\"" + strings.Repeat("<", 720000) + "\"}\n"
	if err := os.WriteFile(filepath.Join(dir, "agent.jsonl"), []byte(fixture), 0600); err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	command := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestStoreLimitWatchHelper$")
	command.Env = append(os.Environ(), "BMA_TEST_LIMIT_DIR="+dir)
	if output, err := command.CombinedOutput(); err != nil {
		t.Fatalf("watch did not stop on storage failure: %v %s", err, output)
	}
	data, err := os.ReadFile(filepath.Join(dir, "session", "report.json"))
	if err != nil {
		t.Fatal(err)
	}
	var r report.Report
	if err := json.Unmarshal(data, &r); err != nil {
		t.Fatal(err)
	}
	if r.Status != "limit_reached" || len(r.CoverageGaps()) != 1 || r.Storage.JournalBytes > report.MaxSessionBytes {
		t.Fatal("watch lost limit disclosure or exceeded capacity")
	}
}

func TestCrashWatchHelper(t *testing.T) {
	dir := os.Getenv("BMA_TEST_CRASH_DIR")
	if dir == "" {
		return
	}
	err := run([]string{"watch", "--process", "bma-no-such-process", "--workspace", filepath.Join(dir, "workspace"), "--out", filepath.Join(dir, "session"), "--goal", "crash-test-goal", "--port", "0", "--no-llm"})
	if err != nil {
		t.Fatal(err)
	}
}

func TestRecoverAfterAbruptWatchExit(t *testing.T) {
	dir := t.TempDir()
	if err := os.Mkdir(filepath.Join(dir, "workspace"), 0700); err != nil {
		t.Fatal(err)
	}
	command := exec.Command(os.Args[0], "-test.run=^TestCrashWatchHelper$")
	command.Env = append(os.Environ(), "BMA_TEST_CRASH_DIR="+dir)
	if err := command.Start(); err != nil {
		t.Fatal(err)
	}
	defer func() {
		if command.ProcessState == nil {
			command.Process.Kill()
			command.Wait()
		}
	}()
	journal := filepath.Join(dir, "session", "events.jsonl")
	deadline := time.Now().Add(10 * time.Second)
	ready := false
	for time.Now().Before(deadline) {
		data, _ := os.ReadFile(journal)
		if bytes.Contains(data, []byte("watch_ready")) {
			ready = true
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if !ready {
		t.Fatal("test watch never became ready")
	}
	if err := command.Process.Kill(); err != nil {
		t.Fatal(err)
	}
	if err := command.Wait(); err == nil {
		t.Fatal("helper exited normally rather than being interrupted")
	}
	if _, err := os.Stat(filepath.Join(dir, "session", "report.json")); !os.IsNotExist(err) {
		t.Fatal("test did not interrupt before final report")
	}
	before, err := os.ReadFile(journal)
	if err != nil {
		t.Fatal(err)
	}
	output := filepath.Join(dir, "recovered")
	if err := run([]string{"recover", filepath.Join(dir, "session"), "--out", output}); err != nil {
		t.Fatal(err)
	}
	after, _ := os.ReadFile(journal)
	if !bytes.Equal(before, after) {
		t.Fatal("recovery modified original evidence")
	}
	data, err := os.ReadFile(filepath.Join(output, "report.json"))
	if err != nil {
		t.Fatal(err)
	}
	var r report.Report
	if err := json.Unmarshal(data, &r); err != nil {
		t.Fatal(err)
	}
	if r.Status != "recovered" || len(r.CoverageGaps()) == 0 || !bytes.Contains(data, []byte("crash-test-goal")) {
		t.Fatal("crash lost durable goal or disclosure")
	}
	if _, err := os.Stat(filepath.Join(output, "report.html")); err != nil {
		t.Fatal(err)
	}
	if err := run([]string{"recover", filepath.Join(dir, "session"), "--out", output}); err == nil {
		t.Fatal("existing recovery output overwritten")
	}
	if err := run([]string{"recover", filepath.Join(dir, "session"), "--out", filepath.Join(dir, "session", "nested")}); err == nil {
		t.Fatal("recovery allowed writing into source")
	}
}
